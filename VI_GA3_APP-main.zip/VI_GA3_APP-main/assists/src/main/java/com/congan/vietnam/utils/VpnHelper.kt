package com.congan.vietnam.utils

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.core.content.FileProvider
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import okhttp3.*
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

// API 返回的 JSON 数据类
data class VpnResponse(
    @SerializedName("download_url")
    val downloadUrl: String
)

object VpnHelper {

    private val client = OkHttpClient()

    // 1️⃣ 获取 VPN 配置的下载链接
    fun fetchVpnConfig(context: Context, apiUrl: String, fileName: String) {
        val request = Request.Builder().url(apiUrl).build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
                showToast(context, "请求失败: ${e.localizedMessage}")
            }

            override fun onResponse(call: Call, response: Response) {
                response.body?.string()?.let { json ->
                    val vpnResponse = Gson().fromJson(json, VpnResponse::class.java)
                    downloadOvpn(context, vpnResponse.downloadUrl, fileName)
                }
            }
        })
    }

    // 2️⃣ 下载 .ovpn 文件到 getExternalFilesDir(null)
    private fun downloadOvpn(context: Context, downloadUrl: String, fileName: String) {
        val request = Request.Builder().url(downloadUrl).build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
                val errorMsg = "下载失败: ${e.localizedMessage}"
                copyToClipboard(context, errorMsg)
                showToast(context, errorMsg)
            }

            override fun onResponse(call: Call, response: Response) {
                if (!response.isSuccessful || response.body == null) {
                    val errorMsg = "服务器错误: ${response.code} ${response.message}"
                    copyToClipboard(context, errorMsg)
                    showToast(context, errorMsg)
                    return
                }

                // 指定保存目录：/Android/data/你的包名/files/
                val file = File(context.getExternalFilesDir(null), fileName)

                try {
                    // 如果文件已存在，先删除旧文件，避免冲突
                    if (file.exists()) {
                        file.delete()
                    }

                    response.body!!.byteStream().use { input ->
                        FileOutputStream(file, false).use { output ->
                            input.copyTo(output)
                        }
                    }

                    // 文件保存完毕后检查
                    if (file.exists()) {
                        openOvpnWithOpenVPN(context, file)
                    } else {
                        val errorMsg = "文件未成功保存"
                        copyToClipboard(context, errorMsg)
                        showToast(context, errorMsg)
                    }

                } catch (e: Exception) {
                    e.printStackTrace()
                    val errorMsg = "文件保存失败: ${e.localizedMessage}"
                    copyToClipboard(context, errorMsg)
                    showToast(context, errorMsg)
                }
            }
        })
    }

    /**
     * 将错误信息复制到剪贴板，方便用户反馈或调试
     */
    private fun copyToClipboard(context: Context, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("错误信息", text)
        clipboard.setPrimaryClip(clip)
        showToast(context, "错误信息已复制")
    }

    // 3️⃣ 调用 OpenVPN Connect 打开 .ovpn 文件
    private fun openOvpnWithOpenVPN(context: Context, file: File) {
        try {
            // 注意第二个参数要与 AndroidManifest 中的 provider authorities 对应
            val fileUri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(fileUri, "application/x-openvpn-profile")
                setPackage("net.openvpn.openvpn")  // 指定 OpenVPN Connect 包名
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)

        } catch (e: Exception) {
            e.printStackTrace()
            val errorMsg = "无法打开 OpenVPN，请检查是否已安装：${e.localizedMessage}"
            showToast(context, errorMsg)
        }
    }

    /**
     * 在主线程显示Toast
     */
    private fun showToast(context: Context, msg: String) {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        }
    }
}
