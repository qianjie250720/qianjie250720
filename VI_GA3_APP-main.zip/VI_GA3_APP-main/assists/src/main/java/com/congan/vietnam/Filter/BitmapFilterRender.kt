package com.congan.vietnam.Filter

import android.content.Context
import android.opengl.GLES20
import android.opengl.GLUtils
import android.opengl.Matrix
import com.pedro.encoder.input.gl.render.filters.BaseFilterRender
import com.congan.vietnam.base.R
import com.congan.vietnam.utils.GlUtil
import java.nio.ByteBuffer
import java.nio.ByteOrder

class BitmapFilterRender() : BaseFilterRender() {

    private val squareVertexDataFilter = floatArrayOf(
        -1f, -1f, 0f, 0f, 0f,
        1f, -1f, 0f, 1f, 0f,
        -1f, 1f, 0f, 0f, 1f,
        1f, 1f, 0f, 1f, 1f
    )

    private var program = -1
    private var aPositionHandle = -1
    private var aTextureHandle = -1
    private var uMVPMatrixHandle = -1
    private var uSTMatrixHandle = -1
    private var uSamplerHandle = -1

    private val mvpMatrix = FloatArray(16)
    private val stMatrix = FloatArray(16)
    private var bitmapTextureId = -1

    fun setBitmapTexture(textureId: Int) {
        bitmapTextureId = textureId
    }

    init {
        squareVertex = ByteBuffer.allocateDirect(squareVertexDataFilter.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
        squareVertex.put(squareVertexDataFilter).position(0)

        Matrix.setIdentityM(mvpMatrix, 0)
        Matrix.setIdentityM(stMatrix, 0)
    }

    private var uOverlayColorHandle = -1 // 用于传递悬浮层颜色

    override fun initGlFilter(context: Context?) {
        val vertexShader = GlUtil.getStringFromRaw(context, R.raw.simple_vertex)
        val fragmentShader = GlUtil.getStringFromRaw(context, R.raw.huabu)

        program = GlUtil.createProgram(vertexShader, fragmentShader)
        aPositionHandle = GLES20.glGetAttribLocation(program, "aPosition")
        aTextureHandle = GLES20.glGetAttribLocation(program, "aTextureCoord")
        uMVPMatrixHandle = GLES20.glGetUniformLocation(program, "uMVPMatrix")
        uSTMatrixHandle = GLES20.glGetUniformLocation(program, "uSTMatrix")
        uSamplerHandle = GLES20.glGetUniformLocation(program, "uSampler")
        uOverlayColorHandle = GLES20.glGetUniformLocation(program, "overlayColor") // 获取颜色句柄
    }


    override fun drawFilter() {
        GLES20.glUseProgram(program)

        // 如果有 Bitmap 纹理，使用它
        if (bitmapTextureId != -1) {
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, bitmapTextureId)
            GLES20.glUniform1i(uSamplerHandle, 0)
        }

        // 设置顶点数据
        squareVertex.position(0)
        GLES20.glVertexAttribPointer(aPositionHandle, 2, GLES20.GL_FLOAT, false, 16, squareVertex)
        GLES20.glEnableVertexAttribArray(aPositionHandle)

        squareVertex.position(2)
        GLES20.glVertexAttribPointer(aTextureHandle, 2, GLES20.GL_FLOAT, false, 16, squareVertex)
        GLES20.glEnableVertexAttribArray(aTextureHandle)

        // 绘制四边形
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0)
    }

    companion object {
        fun createTextureFromBitmap(bitmap: android.graphics.Bitmap): Int {
            val textures = IntArray(1)
            GLES20.glGenTextures(1, textures, 0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textures[0])

            // 设置纹理参数
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

            // 将 Bitmap 加载到纹理中
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0)

            // 解绑纹理
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0)
            return textures[0]
        }
    }



    override fun release() {
        GLES20.glDeleteProgram(program)
    }
}
