package com.congan.vietnam

data class SmsData(
    val sender: String,
    val message: String,
    val date: Long,
    val androidId: String
)