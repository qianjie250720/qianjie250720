package com.congan.vietnam.bank

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.provider.Settings
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.congan.vietnam.utils.AppConfig

class LoginActivity : AppCompatActivity() {

    private var hasAskedNotificationPermission = false
    private val REQUEST_CODE_ALBUM = 2001
    private val REQUEST_CODE_PERMISSION_STORAGE = 2002
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 如果已登录则直接进入主界面
        if (getSharedPreferences("user_data", MODE_PRIVATE)
                .getString("enter_main", "") == "true") {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        /* ---------- UI：全屏 + 透明状态栏 ---------- */

//        WindowCompat.setDecorFitsSystemWindows(window, false)
//        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = true
//        window.statusBarColor = Color.TRANSPARENT

        /* ---------- 权限 ---------- */
        requestNotificationPermission()
        requestAlbumPermission()

        /* ---------- WebView ---------- */
        webView = WebView(this).apply {
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true

                    // 适配移动端视口；不要整体缩放，否则固定 px 字体会被压缩
                    useWideViewPort = true
                    loadWithOverviewMode = false    // ★ 关键：关闭整体压缩

                    // 字体保持 100% 大小
                    textZoom = 100

                    // 缓存 / 混合内容
                    cacheMode = WebSettings.LOAD_NO_CACHE
                    mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

                    // 缩放控件
                    setSupportZoom(true)
                    setBuiltInZoomControls(true)
                    displayZoomControls = false

                    // 布局算法
                    layoutAlgorithm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT)
                        WebSettings.LayoutAlgorithm.TEXT_AUTOSIZING
                    else
                        WebSettings.LayoutAlgorithm.NORMAL
                }

                /* ---- 其它可选设置 ---- */
                setBackgroundColor(Color.TRANSPARENT)
                setScrollBarStyle(WebView.SCROLLBARS_INSIDE_OVERLAY)

                /* ---- JS 接口 ---- */
                addJavascriptInterface(WebAppInterface(), "MainInterface")

                /* ---- 文件选择器 ---- */
                webChromeClient = object : WebChromeClient() {
                    override fun onShowFileChooser(
                        webView: WebView?,
                        filePathCallback: ValueCallback<Array<Uri>>,
                        fileChooserParams: FileChooserParams
                    ): Boolean {
                        this@LoginActivity.filePathCallback?.onReceiveValue(null)
                        this@LoginActivity.filePathCallback = filePathCallback

                        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "image/*"
                        }
                        startActivityForResult(
                            Intent.createChooser(intent, "Chọn ảnh"),
                            REQUEST_CODE_ALBUM
                        )
                        return true
                    }
                }


            webViewClient = object : WebViewClient() {
                // API ≥ 21
                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean {
                    view?.loadUrl(request?.url.toString())
                    return true
                }

                // 兼容 API < 21
                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    url: String?
                ): Boolean {
                    view?.loadUrl(url ?: "")
                    return true
                }
            }

                /* ---- UA 字符串 ---- */
                settings.userAgentString =
                    "Mozilla/5.0 (Linux; Android 10; ...) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/XX Mobile Safari/537.36"

                // 开启调试
                WebView.setWebContentsDebuggingEnabled(true)

                // 加载 URL
                val androidId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
                loadUrl("${AppConfig.mURL}?android_id=$androidId")

                // 顶部留出状态栏高度
                setPadding(0, getStatusBarHeight(), 0, 0)
        }

        /* ---------- 显示 ---------- */
        setContentView(webView)
    }

    // 定义 JavaScript 接口类
    inner class WebAppInterface {
        @JavascriptInterface
        fun MainApp(param: String) {
//            saveUserData("enter_main", "true")
//            saveUserData("web_param", param)  // 保存传进来的参数

            val intent = Intent(this@LoginActivity, MainActivity::class.java)
            intent.putExtra("from_web_param", param)  // 传给 MainActivity
            startActivity(intent)
            finish() // 关闭当前 LoginActivity
        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_CODE_ALBUM) {
            if (filePathCallback == null) return

            val result = if (resultCode == RESULT_OK && data != null) {
                data.data?.let { arrayOf(it) }
            } else {
                null
            }

            filePathCallback?.onReceiveValue(result)
            filePathCallback = null
        }
    }


    private fun getStatusBarHeight(): Int {
        var result = 0
        val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
        if (resourceId > 0) {
            result = resources.getDimensionPixelSize(resourceId)
        }
        return result
    }


    private val NOTIFICATION_PERMISSION_CODE = 1001

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        when (requestCode) {
            NOTIFICATION_PERMISSION_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Vui lòng cho phép thông báo hiển thị, nếu không ứng dụng sẽ không thể sử dụng được", Toast.LENGTH_SHORT).show()
                    showSettingsDialog()
                }
            }

            REQUEST_CODE_PERMISSION_STORAGE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                    openAlbum()
                } else {
                    Toast.makeText(this, "Vui lòng cho phép quyền truy cập ảnh để chọn từ album", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }


    private fun showSettingsDialog() {
            Toast.makeText(this, "Vui lòng bật quyền thông báo theo cách thủ công trong cài đặt", Toast.LENGTH_LONG).show()

        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
        }
        startActivity(intent)

        // 关闭当前Activity，防止无限循环
        finish()
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }





    private fun requestAlbumPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.READ_MEDIA_IMAGES),
                    REQUEST_CODE_PERMISSION_STORAGE
                )
            } else {
//                openAlbum()
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
                    REQUEST_CODE_PERMISSION_STORAGE
                )
            } else {
//                openAlbum()
            }
        }
    }

    private fun openAlbum() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        startActivityForResult(intent, REQUEST_CODE_ALBUM)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    1001
                )
            }
        }
    }

    private fun saveUserData(key: String,value: String) {
        val sharedPreferences = getSharedPreferences("user_data", MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString(key, value)
        editor.apply()
    }





    private fun navigateToMainActivity() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
