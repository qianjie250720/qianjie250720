package com.congan.vietnam.bank

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ScreenReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (Intent.ACTION_SCREEN_ON == intent.action) {
            // 获取当前应用的包名
            val packageName = context.packageName
            // 获取启动当前应用的 Intent
            val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                // 设置 FLAG_ACTIVITY_NEW_TASK，确保可以从广播中启动 Activity
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
            } else {
                // 打印日志或其他处理方式
                println("无法找到启动自己的应用的 Intent")
            }
        }
    }
}
