import * as keys from '@/intl/keys.js';

export const KEY_FOREX = 'forex'; // 外汇
export const KEY_FUTURE = `future`; // 期货
export const KEY_CRYPTO = `crypto`; // 虚拟币


export const GPINDEX = {
	[keys.KEY_KR]: 1,
	[keys.KEY_US]: 2,
};


export const LGRE = {
	[1]: keys.KEY_KR,
	[2]: keys.KEY_US
}



export const KEY_HOME = `home`;
export const KEY_MARKET = "market";
export const KEY_TRADE = `trade`;
export const KEY_POSITION = `position`;
export const KEY_ACCOUNT = `account`;
export const KEY_AUTH = `auth`;
export const KEY_NEW = `new`;

export const KEY_DEPOSIT = `deposit`;
export const KEY_WITHDRAW = `withdraw`;
export const KEY_CONVERT = `convert`;
export const KEY_LOANS = `loans`;

export const KEY_BUY = `buy`;
export const KEY_APPLY = `apply`;
export const KEY_RECORD = `record`;

export const KEY_STOCK = `stock`;
export const KEY_TRACK = `track`;
export const KEY_INDI = `indi`;
export const KEY_RANK = `rank`;

export const KEY_EXCHANGE = `exchange`;
export const KEY_ALL = `all`;
export const KEY_OPTIONAL = `optional`;
export const KEY_SPOTGOODS = `spotgoods`;
export const KEY_CONTRACT = `contract`;
export const KEY_WALLET = `wallet`;

export const KEY_REB = `hotList`;
export const KEY_XBB = `newcoin`;
export const KEY_ZFB = `rising`;
export const KEY_DFB = `falling`;
export const KEY_CJB = `transaction`;
export const KEY_SZ = `marketcap`;
export const KEY_GOODS = `Goods`;
export const KEY_APPL = `Record`;

// export const KEY_ROI = `roi`;
export const KEY_HOLD = `hold`;