import {
	stocks
} from '@/common/stocks.js';

// 生成随机数
export const genNumer = (min, max, isFloat) => {
	let rand = Math.random() * (max - min) + min;
	return isFloat ? parseFloat(rand.toFixed(2)) : Math.floor(rand);
}

// home 曲线图数据
export const getHomeCurves = () => {
	let dataL = [];
	let dataR = [];
	for (let i = 0; i < 5; i++) {
		dataL.push(genNumer(100, 99999, true));
		dataR.push(genNumer(1, 99, true));
	}
	return [dataL, dataR];
}

//  市场沪深 曲线图数据 (参数为当前生成数据中的某个值)
export const getFundFlowCurves = (max) => {
	let temp = [];
	for (let i = 0; i < 5; i++) {
		temp.push(genNumer(1, max, true));
	}
	return temp;
}



// home 理财速递
export const getFinanceNews = () => {
	const temp = {
		title: '爆款！上市仅三天多机构额度不足',
		url: ``,
	}
	return [temp, temp];
}


//  交易页面 最新交易
export const getLatests = () => {
	let result = [];
	result = stocks.map((v, k) => {
		return {
			id: k + 1,
			...v,
			amount: genNumer(10000, 99999999, true),
			subTitle: `百分位 `,
			rate: genNumer(-100, 100, true),
		}
	})
	return result;
}

// 交易页面 榜单
export const getRanking = () => {
	let result = [];
	result = stocks.map((v, k) => {
		return {
			id: k + 1,
			...v,
			amount: genNumer(100, 9999, true),
			rate: genNumer(-100, 999, true),
			rate1: genNumer(100, 999, true),
		}
	})
	return result;
}

// AH比价
export const getAH = () => {
	let result = [];
	result = stocks.map((v, k) => {
		return {
			id: k + 1,
			...v,
			priceA: genNumer(100, 999, true),
			rateA: genNumer(-10, 99, true),
			priceH: genNumer(100, 999, true),
			rateH: genNumer(-10, 99, true),
			premium: genNumer(-100, 999, true),
		}
	})
	return result;
}

// 大盘风向
export const getTrend = () => {
	return {
		rate: genNumer(-100, 999, true),
		rate1: genNumer(100, 999, true),
		rate2: genNumer(-100, 999, true),
		rate3: genNumer(100, 999, true),
		rate4: genNumer(100, 999, true),
	}
}

// 数据中心， 顶部数据
export const getDataCenterTop = () => {
	return {
		amount: genNumer(1000, 999999, true),
		amount1: genNumer(1000, 999999, true),
		amount2: genNumer(100, 999999, true),
	}
}

// 数据中心  列表数据
export const getDateCenterList = () => {
	let result = [];
	result = stocks.map((v, k) => {
		return {
			id: k + 1,
			...v,
			amount: genNumer(100, 999999, true),
			rate: genNumer(-10, 99, true),
			amount1: genNumer(-10000, 99999, true),
		}
	})
	return result;
}

// 沪深通ETF
export const getHSETF = () => {
	let result = [];
	result = stocks.map((v, k) => {
		return {
			id: k + 1,
			...v,
			rateNum: genNumer(-10, 99, true),
			rate: genNumer(-10, 99, true),
			amount: genNumer(100, 999999, true),
			amount1: genNumer(10000, 99999, true),
			amount2: genNumer(10000, 99999, true),
		}
	})
	return result;
}

// 龙湖榜
export const getLongHu = () => {
	let result = [];
	result = stocks.map((v, k) => {
		return {
			id: k + 1,
			...v,
			rate: genNumer(-10, 99, true),
			amount: genNumer(100, 999999, true),
			amount1: genNumer(-10000, 99999, true),
		}
	})
	return result;
}

// 资金流向
export const getDashboard = () => {
	let result = [];
	result = stocks.map((v, k) => {
		return {
			id: k + 1,
			...v,
			rate: genNumer(-10, 99, true),
			amount: genNumer(100, 999999, true),
			amount1: genNumer(-10000, 99999, true),
		}
	})
	return result;
}

// 次新股
export const getRecent = () => {
	let result = [];
	result = stocks.map((v, k) => {
		return {
			id: k + 1,
			...v,
			price: genNumer(1000, 9999, true),
			rateNum: genNumer(1, 99),
			rate: genNumer(-100, 999, true),
			TotalRate: genNumer(-100, 999, true),
			online: `2025-01-01`,
		}
	})
	return result;
}

// 仅麒麟研报
export const getReport = () => {
	const temp = {
		pic: `https://menu.mt.co.kr/common/meta/meta_mt_twonly.jpg`,
		title: `详解全国财政工作会议：2025年安排更大规模政府债券 全面深化财税体制改革`,
		persons: `吕伟、方镜、宋晓东、郭新宇`,
		origin: `民生证劵`,
		dt: `2024-08-18 16:33`,
		url: ``,
	};
	return [temp, temp, temp, temp, temp]
};

// 仅麒麟 榜单 最佳&精英
export const getReporeRanking = () => {
	const temp = {
		name: `华创证券`,
		persons: [`张宇`, `陆银波`, `文若雨`, `高拓`, `尹文琴`, `李星宇`, `元凌玲`, `夏雪`, `富春生`]
	};
	return [temp, temp, temp, temp, temp]
}
// 仅麒麟榜单 未来之星
export const getReportStar = () => {
	const temp = {
		name: `天风证券分析师`,
		persons: `孙骁骁`
	};
	return [temp, temp, temp, temp, temp]
}

// 持仓 投资收益
export const getROI = () => {
	return {
		buyAmount: genNumer(10000, 999999, true),
		ratePL: genNumer(-100, 999, true),
		pl: genNumer(10000, 999999, true),
		total: genNumer(10000, 999999, true),
	}
}

// 沪深 全市场
export const getHSALL = () => {
	let result = [];
	result = stocks.map((v, k) => {
		return {
			id: k + 1,
			...v,
			price: genNumer(10000, 999999, true),
			rateNum: genNumer(-100, 999, true),
			rate: genNumer(-100, 999, true),
		}
	})
	return result;
}

// 沪深 顶部三条数据
export const getHSBest = () => {
	let result = [];
	result = stocks.map((v, k) => {
		return {
			id: k + 1,
			...v,
			amount: genNumer(10000, 999999, true),
			rateNum: genNumer(-100, 999, true),
			rate: genNumer(-100, 999, true),
			line: true,
		}
	})
	return result;
}

// 沪深 资金流向
export const getFundFlow = () => {
	let result = [];
	const temp = [`#D7060F`, `#C896ED`, `#658BFF`, `#DCDCDE`];
	result = temp.map((v, k) => {
		return {
			id: k + 1,
			name: `特大单`,
			amount: genNumer(-100, 999, true),
			amount1: genNumer(100, 9999, true),
			amount2: genNumer(100, 9999, true),
			color: v,
		}
	});
	return result;
}

// 沪深涨幅分布
export const getPMDDetail = () => {
	return {
		todayPL: genNumer(-100, 999, true),
		todayTrade: genNumer(100, 999, true),
		todayProfitRate: genNumer(10, 99, true),
		todayLossRate: genNumer(10, 99, true),
		rise: genNumer(1000, 99999),
		fall: genNumer(100, 99999),
	}
}

// 市场 指数 市场概述
export const getKPIDashboardDetail = () => {
	return {
		buy: genNumer(10000, 9999999, true),
		sell: genNumer(10000, 9999999, true),
	}
}


// 市场通用列表数据
export const getMarketCommons = () => {
	let result = [];
	result = stocks.map((v, k) => {
		return {
			id: k + 1,
			...v,
			price: genNumer(10000, 999999, true),
			rateNum: genNumer(-100, 999, true),
			rate: genNumer(-100, 999, true),
		}
	})
	return result;
}

// // 从数组中随机返回一个元素
// export const statusBGColor = () => {
// 	const temp = [`info`, `primary`, `success`];
// 	const randomIndex = Math.floor(Math.random() * temp.length);
// 	return temp[randomIndex];
// }


// 新股
export const getIPOGoods = () => {
	let result = [];
	result = stocks.map((v, k) => {
		const temp = genNumer(0, 3);
		return {
			id: k + 1,
			...v,
			price: genNumer(10, 999, true),
			rateNum: genNumer(-100, 999, true),
			rate: genNumer(-100, 999, true),
			// 发行量
			publicQTY: genNumer(1000, 9999),
			// 募集资金
			raiseFunds: genNumer(100000, 999999),
			subDT: `2025/01/01`, // 申购
			pushDT: `2025/01/01`, // 公告
			payDT: `2025/01/01`, // 认缴
			onlieDT: `2025/01/01`, // 上线
			type: 1,
			minQTY: genNumer(1000, 9999),
			maxQTY: genNumer(10000, 99999),
			status: temp,
			statusKey: [`info`, `primary`, `success`][temp],
		}
	})
	return result;
}

export const getIPOApplys = () => {
	let result = [];
	result = stocks.map((v, k) => {
		return {
			id: k + 1,
			...v,
			type: 1,
			price: genNumer(10, 999, true),
			applyQTY: genNumer(1000, 9999), // 申购数量
			applyAmount: 0,
			success: genNumer(100, 999), // 中签数量
			msg: `message`,
			// success: item.success, // 中签数
			// successAmount: item.success_num_amount,
			// total: item.total, // 总金额
			freeze: genNumer(1000, 19999), // 已认缴金额
			sn: `abcfr1484621549895`,
			dt: `2024-01-20`,
			// 0：未中签，1:申购中，2：申购中签，3：已认缴金额，4：中签弃奖，5已上市	
			status: genNumer(0, 5),
		}
	})
	return result;
}