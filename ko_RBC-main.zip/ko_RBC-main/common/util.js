import Vue from 'vue';
import * as constants from '@/common/constants.js';
import * as linkTo from '@/common/linkTo.js';
import * as http from '@/common/http.js';
import * as fmt from '@/intl/index.js';
import {
	Msg,
	setLocale,
} from '@/localize/index.js';


/**
 * @function initialize
 */
export const initialize = () => {
	// 获取系统信息
	const systemInfo = uni.getSystemInfoSync();
	Vue.prototype.$APP_NAME = systemInfo.appName;
	Vue.prototype.$VERSION = systemInfo.appVersion;
	// 当前屏幕宽度，缓存起来，用于处理每个页面的显示方案
	Vue.prototype.$WINDOW_WIDTH = systemInfo.windowWidth;
	Vue.prototype.$WINDOW_HIGHT = systemInfo.windowHeight;
	console.log('main.js!', systemInfo);

	// 将存储的appName与当前获取的appName对比。
	if (uni.getStorageSync('APP_NAME') != Vue.prototype.$APP_NAME) {
		console.log(`Clear storage!`);
		const user = uni.getStorageSync('user') || '';
		const pwd = uni.getStorageSync('pwd') || '';
		const token = uni.getStorageSync('token') || '';
		uni.clearStorageSync();
		uni.setStorageSync('APP_NAME', Vue.prototype.$APP_NAME);
		uni.setStorageSync('token', token);
		uni.setStorageSync('user', user);
		uni.setStorageSync('pwd', pwd);
	}

	// 本地化
	console.log(fmt);
	uni.getStorageSync('lgre') || fmt.setLgre();
	// 本地化语言明文
	uni.getStorageSync('lang') || fmt.getLang();
	// 设置本地语言包
	setLocale(Vue.prototype.$DEF_LGRE);
	uni.getStorageSync('masking') || uni.setStorageSync('masking', (uni.getStorageSync('masking') || true));

	// setTabbar(); // 切换底部多语言
};

// check form
export const checkField = (value, tip) => {
	if (typeof value === 'string' && (value.trim() === '' || value === null)) {
		uni.showToast({
			title: tip,
			icon: 'none'
		});
		return false;
	}

	if (typeof value === 'number' && isNaN(value)) {
		uni.showToast({
			title: tip,
			icon: 'none'
		});
		return false;
	}
	return true;
}

// sign out
export const signOut = () => {
	uni.removeStorageSync('token');
	linkTo.home();
}

// 检查输入值 是否合法，小数是否大于指定位数。返回处理完成的数字类型的值
export const checkInputNumber = (val, point = 4) => {
	val = isNaN(val) ? 0 : Number(val);
	if (val <= 0) {
		uni.showToast({
			title: Msg.TIP_VALID,
		});
		return false;
	}
	// 计算小数点后面的位数
	const temp = val.toString().split('.')[1]?.length || 0;
	// console.log(`check`, val, temp);
	if (temp > point) {
		uni.showToast({
			title: Msg.TIP_DECIMAL_PREFIX +
				Vue.prototype.$decimal + Msg.TIP_DECIMAL_SUFFIX,
		});
		return false;
	}
	console.log(`check result:`, val);
	return val;
}
export const formatNumber = (val, decimal = 0) => {
	// 处理为规范化数字类型
	val = isNaN(val) ? 0 : Number(val);
	return decimal <= 0 ? val : val.toFixed(decimal) * 1;
};
// 数字格式化(值，是否货币) 唯有货币值需要千分符
export const formatCurrency = (num, currency = true) => {
		// console.log('num:',num);
		num = num.toString();
		// num = num.replace(/[^\d]/g, ''); // 只允许数字输入
		const intPart = num.split('.')[0]; // 获取整数部分
		const decimalPart = num.split('.')[1] ? '.' + num.split('.')[1] : ''; // 获取小数部分
		// 添加千分符
		if (currency) {
			  const fixedLocale = 'ko-KR';  // 
			const formattedIntPart = new Intl.NumberFormat(fixedLocale, {
				style: 'decimal', // 不包含货币符号。currency:包含货币符号
				// currency: Vue.prototype.$CURRENCY
				// unit: "kilometer-per-hour", // 单位
			}).format(intPart);
			return formattedIntPart + decimalPart;
		}
		return intPart + decimalPart;
	}
export const goBack = () => {
		/*#ifdef APP-PLUS*/
		uni.navigateBack({
			delta: 1
		});
		/*#endif*/
	
		/*#ifdef H5*/
		history.back();
		/*#endif*/
	}
// 金额值格式化(参数：金额，小数位数)
 export const formatMoney = (amount, decimal = 2) => {
	// 处理传入值为数字类型
	amount = isNaN(amount) ? 0 : Number(amount);
	// console.log(amount);
	const curLocale = 'ko-KR';
	const result = new Intl.NumberFormat(curLocale, {
		style: 'decimal', // 不包含货币符号。currency:包含货币符号
		// 如果传入数字包含小数。则启用小数位数
		// minimumFractionDigits: hasDecimalPoint(amount) ? decimal : 2, // 小数位数
		// maximumFractionDigits: hasDecimalPoint(amount) ? decimal : 2, // 小数位数
		currency: Vue.prototype.$CURRENCY
	}).format(amount);
	// console.log('格式化：', result);
	return result;
}
export const	checkToken = () => {
		if (!uni.getStorageSync('token') || uni.getStorageSync('token') == '') {
			uni.navigateTo({
				url: Vue.prototype.$paths.ACCOUNT_ACCESS
			});
		}
	}
// Coin格式化，数据无损输出
export const formatCoin = (coin) => {
	coin = isNaN(coin) ? 0 : Number(coin);
	const curLocale = 'ko-KR';
	const result = new Intl.NumberFormat(curLocale, {
		style: 'decimal', // 不包含货币符号。currency:包含货币符号
		currency: Vue.prototype.$CURRENCY
	}).format(coin);
	// console.log('格式化：', result);
	return result;
};
// 获取url中的 searchParams
export const getURLParams = (url = '') => {
	if (url.trim() == '') return null;
	const queryString = url.includes(`?`) ? url.split('?')[1] : null;
	const params = queryString ? queryString.split('&') : null;
	let result = {};
	params.forEach(param => {
		const [key, value] = param.split('=');
		result[key] = value;
	});
	return result;
}

// 设置数据掩码状态
export const setDataMask = (val = true) => {
	console.log(val);
	uni.setStorageSync('masking', val);
};

// 邮箱验证
export const checkEmail = (val) => {
	const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
	console.log('checkEmail:', !emailPattern.test(val))
	return emailPattern.test(val);
};

// 部分页面需要拼接股票完整LOGO的url
export const setLogo = (url) => {
	// console.log('url:',url);
	return url.includes('http') ? url : http.BASE_URL + url;
};

// 设置 Coin Logo
export const setCoinLogo = (url) => {
	return url.includes('http') ? url : http.BASE_URL + url;
};

export const isImageUrl = (url) => {
	// 使用正则表达式检查URL是否以.png或.jpg结尾
	const regex = /\.(png|jpe?g)$/i; // .jpg 和 .jpeg都支持
	return regex.test(url);
};

// 统一处理杠杆，后端数据返回不一致。
export const leverList = (val) => {
	val = val || [];
	// 如果没有数据。就返回默认杠杆 1
	if (!val || val.length <= 0) return [1];
	console.log(val);
	// 数组对象类型 
	// ganggan: [{name: "", index: ""}] 
	// ganggan: [{name: "2", index: "2"}, {name: "4", index: "4"}, ...]
	if (val.length > 0 && typeof(val[0]) === 'object') {
		// val[0].index && val[0].index * 1 > 0
		const tempFilter = val.filter(item => item.index * 1 > 0);
		const temp = tempFilter.map(item => item.index * 1);
		console.log('lever array object:', temp);
		// 数据中，添加1倍杠杆
		return temp[0] * 1 == 1 ? temp : [1, ...temp];
	} else if (Array.isArray(val)) {
		// [1, '2', '4', '5', '10']
		console.log(1, val);
		return val.map(item => item * 1);
	}

	// 字符串类型 ganggan: "2,3,4,5,6,7,8,9,10" 
	if (typeof(val) === 'string') {
		const temp = val.split(',').map(item => item * 1);
		console.log('lever string:', temp);
		// 数据中，添加1倍杠杆
		return temp[0] * 1 == 1 ? temp : [1, ...temp];
	}
};
