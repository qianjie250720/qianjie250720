<template>
	<view class="table" style="padding: 0 0;margin-top: 10px;">
		<block v-for="(v,k) in list" :key="k">
			<view @tap="linkTo(v.code,v.gid)" style="border-bottom: 1px solid #CCC;padding: 8px 0;">
				<view class="flex_row_between" style="gap: 12px;width: 100%;">
					<CustomLogo :logo="v.logo" :name="v.name"></CustomLogo>
					<view class="text_wrap" style="font-size: 14px;font-weight: 700;flex: 1; min-width: 0;">
						{{v.name}}<text style="font-size: 13px;font-weight: 300;padding-left: 12px;">({{v.code}})</text>
					</view>
					<view style="margin-left: auto;">
						<image :src="`/static/star_dark${v.track?``:`_un`}.svg`" mode="aspectFit" :style="$theme.setImageSize(16)"
							@click.stop="track(v.gid)"></image> 
					</view>
				</view>
				<view class="flex_row_between" style="gap: 12px;">
					<view style="width: 48%;">{{v.industry}}</view>
					<view style="font-size: 15px;" :style="{color:$theme.setRiseFall(v.rateNum)}">
						{{$fmt.amount(v.close,v.lgre)}}
					</view>
					<text style="font-size: 15px;margin-left: auto;" :style="{color:$theme.setRiseFall(v.rateNum)}">
						{{ $fmt.percent(v.rateNum,v.lgre)}}
					</text>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "ListRank",
		props: {
			list: {
				type: Object,
				default: {}
			}
		},
		methods: {
			linkTo(val, gid) {
				this.$linkTo.stockDetail(val, gid);
			},
			track(val) {
				this.$emit('track', val);
			}
		}
	}
</script>

<style>

</style>