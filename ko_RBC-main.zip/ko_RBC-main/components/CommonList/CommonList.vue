<template>
	<view class="table" style="padding: 0 0;margin-top: 10px;">
		<!-- <view class="table_header">
			<view class="table_th" style="width:20%;">{{$msg.COMMON_TH_NAME}}</view>
			<view class="table_th" style="width: 30%;text-align: center;">{{$msg.COMMON_TH_PRICE}}</view>
			<view class="table_th" style="width: 30%;text-align: center;">{{$msg.COMMON_TH_RATENUM}}</view>
			<view class="table_th" style="width: 20%;text-align: right;">{{$msg.COMMON_TH_RATE}}</view>
		</view> -->

		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(v,k) in list" :key="k">
				<view @tap="linkTo(v.code,v.gid)">
					<view style="font-weight: 700;padding-top: 10px;font-size: 15px;">{{v.name}}</view>
					<view class="table_row" style="padding-top: 4px;">
						<view class="table_cell" style="width: 20%;font-size: 12px;" :style="{color:$theme.getColor($theme.INFO)}">
							{{v.code}}
						</view>
						<view class="table_cell" style="width: 30%;text-align: center;"
							:style="{color:$theme.setRiseFall(v.rateNum)}">
							{{$fmt.amount(v.price,v.lgre)}}
						</view>
						<view class="table_cell" style="width: 30%;text-align: center;"
							:style="{color:$theme.setRiseFall(v.rateNum)}">
							{{$fmt.amount(v.rateNum,v.lgre)}}
						</view>
						<!-- <view class="table_cell" style="width: 20%;text-align: right;">
							<text class="rate" style="color: #FFF;width: 100%;display: inline-block;"
								:style="{backgroundColor:$theme.setRiseFall(v.rate)}">
								{{ $fmt.symbol(v.rate)+ $fmt.percent(Math.abs(v.rate))}}
							</text>
						</view> -->
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	export default {
		name: 'CommonList',
		props: {
			list: {
				type: Object,
				default: {}
			}
		},
		methods: {
			linkTo(val, gid) {
				this.$linkTo.stockDetail(val, gid);
			}
		}
	}
</script>

<style>
</style>