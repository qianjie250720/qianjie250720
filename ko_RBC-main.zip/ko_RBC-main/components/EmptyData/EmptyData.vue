<template>
	<view style="text-align: center;padding-top: 40px;">
		<image :src="`/static/empty_${img}.png`" mode="aspectFit" :style="$theme.setImageSize(size)"></image>
		<!-- <view style="font-size: 14px;" :style="{color:$theme.getColor($theme.INFO) }">0{{$msg.COMMON_EMPTY_DATA}}</view> -->
	</view>
</template>

<script>
	export default {
		name: "EmptyData",
		props: {
			img: {
				type: String,
				default: 'data'
			},
			size: {
				type: Number,
				default: 200
			}
		},
		data() {
			return {};
		},
	}
</script>

<style>

</style>