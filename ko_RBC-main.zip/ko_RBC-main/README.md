# ko_stock

# UI
[](https://lanhuapp.com/link/#/invite?sid=lx18Fnea)

# TODO
- 美股 ws
- 韩股 定时器