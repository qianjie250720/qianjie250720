import Vue from 'vue';
import * as keys from '@/intl/keys.js';
import {
	TZ
} from '@/intl/timezone.js';
import {
	CURRENCY
} from '@/intl/currency.js';


export const checkIntl = () => {
	return typeof Intl !== 'undefined'
};

export const checkIntlNumer = () => {
	console.log(`checkIntlNumer`)
	return checkIntl() && typeof Intl.NumberFormat !== 'undefined'
}

export const checkIntlDate = () => {
	console.log(`checkIntlDate`)
	return checkIntl() && typeof Intl.DateTimeFormat !== 'undefined'
}

export const checkIntlDisplay = () => {
	console.log(`checkIntlDisplay`)
	return checkIntl() && typeof Intl.DisplayNames !== 'undefined'
}

export const isIntlNumber = checkIntlNumer();
export const isIntlDate = checkIntlDate();
export const isIntlDisplay = checkIntlDisplay();

export const langIntl = (val = '') => {
	console.log(val, isIntlDisplay);
	return isIntlDisplay ? new Intl.DisplayNames(val, {
		type: "language"
	}).of(val) : LANG[val];
}


export const code = keys;
// export const timezone = TZ;
export const currency = CURRENCY;
// 每个项目所需语言
export const locales = Object.create(null);
locales[keys.KEY_US] = keys.KEY_US;
locales[keys.KEY_KR] = keys.KEY_KR;

export const lgre = Object.create(null);
Object.keys(locales).forEach(v => {
	console.log(v);
	lgre[v] = {
		code: v,
		lang: langIntl(v),
		timezone: TZ[v],
		currency: CURRENCY[v],
		flag: v,
	}
});

console.log(lgre);

export const getLgre = () => {
	return uni.getStorageSync('lgre') || Vue.prototype.$DEF_LGRE;
}

export const getTimeZone = (val = '') => {
	return val.trim() != '' ? lgre[val].timezone : uni.getStorageSync('tz');
}

export const getCurrency = (val = '') => {
	return val.trim() != '' ? lgre[val].currency : uni.getStorageSync('currency');
}

export const getLang = (val = '') => {
	return val.trim() != '' ? lgre[val].lang : uni.getStorageSync('lang');
}

export const setLgre = (locale = Vue.prototype.$DEF_LGRE) => {
	const temp = locale && locale.trim() != '' ? locale : getLgre();
	uni.setStorageSync('lgre', temp);
	uni.setStorageSync('tz', lgre[temp].timezone);
	uni.setStorageSync('currency', lgre[temp].currency);
	uni.setStorageSync('lang', lgre[temp].lang);
}



export const EXCEPT_ZERO = `exceptZero`; // 正负值
export const NEVER = `never`; // 不显示
export const NEGATIVE = `negative`; // 负数
export const ALWAYS = `always`; // 正负零

/**
 * @function check number
 * @param {string} val 需check的数值
 */
export const isNumer = (val) => {
	// console.log(val);
	// 数字类型
	if (typeof val === 'number' && !isNaN(val)) return true;
	// 字符串，尝试转换为数字并判断
	if (typeof val === 'string' && val.trim() !== '') {
		const numValue = parseFloat(val);
		return !isNaN(numValue);
	}
	return false; // 其他类型返回 false
}

/**
 * @function 数字正负平符号
 * @param {string|number} val 
 */
export const symbol = (val) => {
	if (!Vue.prototype.$symbol) return '';
	val = !isNumer(val) ? 0 : Number(val);
	const temp = [`- `, ` `, `+ `];
	const index = val == 0 ? 0 : val < 0 ? -1 : 1;
	return temp[index + 1]
}

/**
 * @function 格式化数字值
 * @param {string} str 需格式化的字符串
 * @param {number} decimal 保留小数位数
 * @return {string} 格式化为指定小数位数的string类型数值
 * @description 通常用于不限制位数或指定位数的数值。
 */
export const numer = (val, decimal = -1) => {
	val = !isNumer(val) ? "0" : val;
	// 四舍五入到指定小数位：或原样输出
	return decimal > -1 ? parseFloat(val).toFixed(decimal) : val;
};

/**
 * @function 格式化数字值(十进制)
 * @return {string} 带有符号和千分符的数字
 * @description 通常用于不限制位数或指定位数的数值。正负号、小数
 * @example $fmt.decimal(1375.64523,$lgre.code.KEY_DE)
 */
export const decimal = (val, sign = EXCEPT_ZERO, locale = Vue.prototype.$DEF_LGRE) => {
	// console.log(`??`, numer(val), val);
	// 转为字符串
	val = numer(val).toString();
	// 获取整数和小数部分
	const [intPart, decimalPart = ""] = val.split(".");
	let result = 0;
	if (isIntlNumber) {
		const max = decimalPart.length || Vue.prototype.$decimal;
		result = new Intl.NumberFormat(locale, {
			style: "decimal", // 十进制
			minimumFractionDigits: 0,
			maximumFractionDigits: max, // 显示最多位小数
			useGrouping: true, // 使用千位分隔符，默认为 true
		}).format(Math.abs(val));
	} else {
		console.log('Not Intl');
	}
	return sign != NEVER ? symbol(val) + result : result;
}

/**
 * @function 格式化传入值为指定货币格式
 * @param {string} val 需格式化的字符串
 * @param {string} sign 是否显示符号
 * @param {string} currency 货币代码
 * @param {string} locale lgre
 * @return {string} 按照指定代码，包含货币符号的千分格式化
 * @description
 * @example $fmt.currency(1375.64523,$fmt.NEVER,$lgre.code.KEY_KR)
 */
export const amount = (val, currency = Vue.prototype.$DEF_LGRE, locale = currency, sign = NEVER) => {
	// console.log(`??`, numer(val), val);
	// 转为字符串
	val = numer(val).toString();
	// 获取整数和小数部分
	const [intPart, decimalPart = ""] = val.split(".");
	if (isIntlNumber) {
		// 小数位数最大值
		const max = decimalPart.length || Vue.prototype.$decimal;
		// 再把整数和小数拼起来。
		const temp = intPart + "." + decimalPart;
		return new Intl.NumberFormat(locale, {
			style: "decimal", // 用于以特定货币格式化数字。currency
			// 指定要使用的货币代码（如 'USD'、'EUR'、'CNY' 等）
			currency: getCurrency(currency),
			// 'symbol' 显示符号，'code' 显示货币代码，'name' 显示货币名称
			// currencyDisplay: "narrowSymbol",
			signDisplay: sign,
			minimumFractionDigits: 0,
			maximumFractionDigits: max, // 显示最多位小数
		}).format(temp);
	} else {
		console.log('Not Intl');
	}
}

/**
 * @function 按照lgre格式化百分数
 * @param {string} val 需格式化的数值
 * @param {string} locale [lg-re]
 * @return {string} 格式化后的百分数
 * @description 只在类似情况下使用该函数。
 */
export const percent = (val, locale = Vue.prototype.$DEF_LGRE, sign = EXCEPT_ZERO) => {
	// console.log(`??`, numer(val), val);
	// 转为字符串
	val = numer(val).toString();
	// let result = 0;
	if (isIntlNumber) {
		return new Intl.NumberFormat(locale, {
			style: "percent",
			currencySign: "accounting",
			// exceptZero:正负号
			signDisplay: Vue.prototype.$symbol ? sign : NEVER,
			minimumFractionDigits: 0,
			maximumFractionDigits: Vue.prototype.$rate,
		}).format(val / 100);
	} else {
		console.log('Not Intl');
	}
	// return sign === NEVER ? result : (symbol(val) + result);
}



// console.log(decimal(1375.64523))
// console.log(decimal(1375.3))
// console.log(decimal(1375))
// console.log(decimal(-1375))
// console.log(decimal(`-1375`))
// console.log(decimal(null))
// console.log(decimal(undefined))

export const unit = (num) => {
	return new Intl.NumberFormat(locale, {
		style: "units",
		minimumFractionDigits: 0,
		maximumFractionDigits: 0, // 显示最多位小数
		useGrouping: true, // 是否使用千位分隔符，默认为 true
		// unit: "meter-per-second", 1,235.12 m/s
	}).format(numer(num));
}


export const setYear = (locale = Vue.prototype.$DEF_LGRE) => {
	if (isIntlDate) {
		return new Intl.DateTimeFormat(locale, {
			year: 'numeric',
			timeZone: getTimeZone()
		}).format(new Date());
	}
}

export const setYMDHMS = (val = '', locale = Vue.prototype.$DEF_LGRE) => {
	val = !val || val.trim() == '' ? new Date() : val;
	// 2025-02-05T09:00:30.265000Z
	const temp = val.split('T');
	return temp[0] + ` ` + temp[1].slice(0, 8);

	// if (isIntlDate) {
	// 	const opt = {
	// 		year: 'numeric',
	// 		month: "2-digit",
	// 		day: "2-digit",
	// 		hour: "2-digit",
	// 		minute: "2-digit",
	// 		second: "2-digit",
	// 		hour12: false, // 24小时制
	// 	};
	// 	return new Intl.DateTimeFormat(locale, {
	// 		...opt,
	// 		timeZone: getTimeZone()
	// 	}).format(val);
	// }
}


// /**
//  * @function 格式化加密货币,统一使用美元的千分符形式。
//  * @param {string} str 需格式化的字符串
//  * @param {string} sign 是否显示符号
//  * @param {string} currency 货币代码
//  * @param {string} locale lgre
//  * @return {string} 按照指定代码，包含货币符号的千分格式化
//  * @description 因为USDT 与美元1:1。多数情况，交易所会选择在显示价格时，即使是整数价格，也保留两位小数
//  */
// export const crypto = (str, sign = NEVER, currency = Vue.prototype.$DEF_LGRE, locale = currency) => {
// 	console.log(`??`, numer(val), val);
// 	// 转为字符串
// 	val = numer(val).toString();
// 	// 获取整数和小数部分
// 	const [intPart, decimalPart = ""] = val.split(".");
// 	if (isIntlNumber) {
// 		// 小数位数最大值
// 		const max = decimalPart.length || Vue.prototype.$decimal;
// 		// 再把整数和小数拼起来。
// 		const temp = intPart + "." + decimalPart;
// 		return new Intl.NumberFormat(locale, {
// 			style: "currency", // 用于以特定货币格式化数字。
// 			// 指定要使用的货币代码（如 'USD'、'EUR'、'CNY' 等）
// 			currency: Vue.prototype.$lgre.getCurrency(currency),
// 			// 'symbol' 显示符号，'code' 显示货币代码，'name' 显示货币名称
// 			// currencyDisplay: "narrowSymbol",
// 			signDisplay: sign,
// 			minimumFractionDigits: 0,
// 			maximumFractionDigits: max, // 显示最多位小数
// 		}).format(Math.abs(temp));
// 	} else {
// 		console.log('Not Intl');
// 	}
// 	return result;

// }



// /**
//  * 
//  * @type {object} fmtConfig
//  * @type {string} fmtConfig:{object}
//  * @type {string} color:显示值颜色
//  * @type {number} rate:显示值汇率
//  * @type {number} decimal:显示值限制小数的位数
//  * @description {货币代码:颜色代码}
//  * 需要格式化为哪些loacale。比如，意大利的欧元美元双显。扩展为遍历输出多显.
//  * 按照用户需求，调整此处需要遍历渲染的货币。
//  */
// /**
//  * @function 数据多种显示配置
//  * @return {object} 用于多显格式化的配置对象
//  * @type {number} rate:显示值汇率
//  * @type {number} decimal:显示值限制小数的位数
//  * @description 其他设置也可以在外部为变量赋值后，再按需调整
//  * @example
//  * this.$fmt.fmtConfig();
//  */
// export const fmtConfig = () => {
// 	let temp = {};
// 	Object.keys(localize).forEach((key, index) => {
// 		console.log(key);
// 		// 确保 temp[key] 被初始化为一个对象
// 		temp[key] = {}; // 初始化为一个新对象
// 		temp[key].rate = 1; // 默认 1
// 		temp[key].decimal = 4; // 默认小数位数 -1视为不主动限制
// 	});

// 	// 其他设置写在外面，减少遍历时多次多种 if 判断
// 	// temp['en-US'] = temp['en-US'] || {}; // 确保存在 'en-US' 对应的对象
// 	// temp['en-US'].decimal = 4; // 视为主动限制小数位数

// 	return temp;
// };


// // 函数: 将指定 locale 对象放在第一位
// export const prioritizeLocale = (config, locale = 'en-US') => {
// 	const keys = Object.keys(config);

// 	// 如果 locale 存在于 config 中，将其放在数组的开头
// 	if (keys.includes(locale)) {
// 		const prioritizedConfig = {
// 			[locale]: config[locale]
// 		};
// 		prioritizedConfig[locale].color = '';

// 		// 将其余的 locale 追加到新对象中
// 		keys.forEach((key, index) => {
// 			if (key !== locale) {
// 				prioritizedConfig[key] = config[key];
// 				prioritizedConfig[key].color = theme.colors[index];
// 			}
// 		});
// 		return prioritizedConfig;
// 	}
// 	// 如 locale 不在 config 中，返回原对象
// 	return config;
// };