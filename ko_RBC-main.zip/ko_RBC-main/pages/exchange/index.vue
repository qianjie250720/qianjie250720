<template>
	<view>
		<header class="common_header" style="gap:12px;background-color: #fedb03;">
			<view class=" common_tabs" style="flex:1;display: flex;gap: 40px;">
				<!-- <block v-for="(v,k) in tabs" :key="k">
					<view @tap="changeTab(k)" class="item_qb" :class="curKey===k?`item_ye`:``">
						{{v}}
					</view>
				</block> -->
				<view style="border-bottom: 2px #000 solid;line-height: 1.5;font-size: 16px;font-weight: 700;">모두</view>
				<view style="font-size: 16px;font-weight: 700;" @click="heyue()">계약</view>
			</view>
			<image src="/static/search.svg" mode="heightFix" :style="$theme.setImageSize(20)"
				style="cursor: pointer;margin-left: auto;" @tap="$linkTo.search()">
			</image>
			<image src="/static/kefu.png" mode="heightFix" :style="$theme.setImageSize(20)"
				style="cursor: pointer;margin-left: auto;" @tap="$linkTo.service()">
			</image>
			<image src="/static/jcy_xx.png" mode="heightFix" :style="$theme.setImageSize(20)"
				style="cursor: pointer;margin-left: auto;" @tap="$linkTo.notify()">
			</image>
		</header>

		<template v-if="curKey===$C.KEY_ALL">
			<image src="/static/qb_bg.png" mode="widthFix" style="width: 100%;"></image>

			<view style="border-bottom: 8px #f8fbff solid;"></view>

			<view class="flex" style="padding: 10px 20px;">
				<image src="/static/qb_huo.png" mode="widthFix" style="width: 20px;height: 20px;"></image>
				<view style="margin-left: 10px;color: #fedb03;">인기</view>
			</view>

			<view class="flex_row_between" style="padding: 10px 20px;">
				<block v-for="(item, key, index) in list" :key="key" v-if="index < 3">
					<view
						style="border: 1px #f3f4f6 solid;padding: 10px;text-align: left;line-height: 1.5;border-radius: 5px;width: 30%;">
						<image :src="item.logo" mode="widthFix" style="width: 35px;height: 35px;"></image>
						<view style="font-weight: 900;">{{item.name}}</view>
						<view>{{item.current_price}}</view>
						<view class="flex">
							<image :src="item.rate > 0 ? '/static/jt_zhang.png' : '/static/jt_die.png'" mode="widthFix"
								style="width: 8px;">
							</image>
							<view style="margin-left: 5px;color: #ff1111;">{{item.rate}}%</view>
						</view>
					</view>
				</block>
			</view>
			<view style="border-bottom: 8px #f8fbff solid;"></view>
			<view style="gap:12px;padding: 5px 20px;">
				<view style="display: flex;color: #b7b7b7;font-size: 12px;">
					<view style="flex: 30%;">이름</view>
					<view style="flex: 30%;text-align: center;">최신 가격(USDT)</view>
					<view style="flex: 10%;text-align: right;margin-right: 5px;">휘발성</view>
				</view>
			</view>
			<view>
				<block v-for="(item, key, index) in list" :key="key">
					<view class="flex" style="padding:10px 15px;">
						<view class="flex" style="flex: 30%;">
							<image :src="item.logo" mode="widthFix" style="width: 30px;height: 30px;"></image>
							<view style="font-weight: 900;margin-left: 10px;">{{item.name}}</view>
						</view>
						<view style="flex: 30%;text-align: center;font-weight: 500;">{{item.current_price}}</view>
						<view
							style="margin-left: 5px;color: #fff;flex: 10%;text-align: center;padding: 5px;border-radius: 5px;"
							:style="{backgroundColor:item.rate>0?`#fe0100`: '#66d166' }">{{item.rate}}%</view>
					</view>
				</block>
			</view>
			<view style="padding: 50px 0px;"></view>
		</template>

		<template v-if="curKey===$C.KEY_CONTRACT">
			<view>
				<view class="flex" style="flex: 30%;padding: 20px 15px;">
					<view class="flex">
						<view style="font-size: 20px;font-weight: 500;">ETH/USDT</view>
						<image src="/static/coin_choose.png" mode="widthFix" style="width: 12px;margin-left: 10px;">
						</image>
					</view>
					<view style="flex: 30%;text-align: right;font-size: 16px;font-weight: 500;color: #fe3737;">1875.3
					</view>
					<view style="flex: 10%;text-align: right;font-size: 16px;font-weight: 500;color: #fe3737;">-2.19%
					</view>
				</view>

				<view class="flex" style="gap: 10px;padding: 0px 15px;">
					<view style="width: 60%;">
						<u-radio-group v-model="radiovalue1" placement="row"  @change="groupChange">
							<u-radio :customStyle="{marginBottom: '8px'}" v-for="(item, index) in radiolist1"
								:key="index" :label="item.name" :name="item.name" activeColor="#fedb03" style="margin:0px 20px;" @change="radioChange">
							</u-radio>
						</u-radio-group>
						<view class="flex" style="padding:10px 0px;gap: 15px;">
							<view style="color: #888;font-size: 12px;">杠杆</view>
							<view v-for="(item, index) in 4" :key="index">
								<view>25X</view>
							</view>
						</view>
						<view style="padding: 5px 0px;">
							<view style="border: 1px #000 solid;padding: 8px;border-radius: 5px;background-color: #f6f7f8;">1875.3</view>
						</view>
						<view style="padding: 5px 0px;">
							<view style="padding: 8px;border: 1px #000 solid;border-radius: 5px;background-color: #f6f7f8;">
								<input placeholder="请输入数量" placeholder-class="placeholder" style="font-size: 14px;"/>
							</view>
						</view>
						<view style="padding:0px 0px;">
							<view style="background-color: #F5F6FB;">
								<view class="flex_row_between" style="border-radius: 12rpx;">
									<view style="flex:1;">
										<u-slider v-model="sliderVal" min="0" max="100" activeColor="#fedb03" :showValue="true" @change="changeSlider"  block-width="100"
											 blockColor="#fedb03" style="width: 300rpx;"></u-slider>
									</view>
									<view style="padding-right: 8rpx;">%</view>
									<view style="padding-right: 8rpx;color:#fedb03;" @click="sliderValMax()">Max</view>
								</view>
								<view style="display: flex;align-items: center;justify-content: space-between;padding: 5px;">
									<block v-for="(v,k) in 4" :key="k">
										<view style="text-align: center;" :style="{color:v==curPercent?'#6D41FF':'#303133'}"
											@click="changePercent(v)">25%</view>
									</block>
								</view>
							</view>
							<view style="font-size: 10px;color: #888;text-align: right;font-weight: 500;">余额:1872.34 USDT</view>
							<view style="font-size: 10px;color: #888;text-align: right;font-weight: 500;padding: 5px 0px;">最大数量:10 </view>
							 <view class="flex_row_between">
								 <view style="font-size: 10px;color: #888;">合计</view>
								 <view style="font-size: 10px;font-weight: 500;">125 USDT</view>
							 </view>
						</view>
						
						 
						 <view class="flex_row_center" style="gap: 20px;padding: 10px 0px;">
							 <view style="background-color: #fedb03;color: #fff;padding: 5px 20px;border-radius: 5px;"@click="$u.route({url:'/pages/contract/index'});">买入</view>
							 <view style="background-color: #9070f9;color: #fff;padding: 5px 20px;border-radius: 5px;">卖出</view>
						 </view>
					</view>
					<view style="width: 40%;margin-top: -10px;">
						<view class="flex_row_between" style="color: #888;font-size: 10px;padding: 5px 0px;">
							<view style="">价格</view>
							<view style="align-items: left;">数量</view>
						</view>
						<view class="flex" style="color: #fe3737;">
							<view style="font-size: 18px;">2.8452</view>
							<view style="margin-left: 15px;">2.19%</view>
						</view>
						<view>
							<block v-for="(v,k) in 5" :key="k">
								<view class="flex_row_between" style="background-color: #f0c9c8;margin: 5px 0px;line-height: 1.5;">
									<view>1.723</view>
									<view>7.1933</view>
								</view>
							</block>
						</view>
					</view>
				</view>
				<view style="border-bottom: 8px #f8fbff solid;"></view>
				
				<view></view>
				

			</view>
		</template>




		<FooterSmall :actKey="$C.KEY_NEW"></FooterSmall>
	</view>
</template>

<script>
	import {
		init,
		dispose,
		utils,
	} from '@/common/klinecharts.min.js';
	// import wallet from './components/wallet.vue';
	export default {
		components: {
			// wallet,
		},
		data() {
			return {
				isAnimat: false,
				curKey: null,
				tabs: {
					[this.$C.KEY_ALL]: '모두',
					[this.$C.KEY_CONTRACT]: '계약',
					// [this.$C.KEY_WALLET]: '钱包',
				},
				news: null,
				curNew: 0,
				bests: null,
				article: null,
				asks: [],
				bids: [],
				asksMax: 0, // asks 當前最大數量
				bidsMax: 0, // bids 當前最大數量
				socket: null,
				isConnected: false, // 是否链接socket
				industry: null,
				curId: 141,
				list: '',
				curBest: 0,
				chart: null,
				chartData: [],
				timer: null,
				ranks: null,
				curRank: 0,
				radiolist1: [{
						name: '市场',
						disabled: false
					},
					{
						name: '值指',
						disabled: false
					}
				],
				radiovalue1: '市场',
				curPercent: -1,
				sliderVal: 0, // 滑块滑动值
			}
		},
		async onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.curKey = this.curKey || Object.keys(this.tabs)[0];
			this.changeTab(this.curKey);
			// await this.$http.getTop3();
			this.getlist();
		},

		onHide() {
			this.isAnimat = false;

			this.chart = null;
			this.chartData = null;
			this.clearTimer();
		},
		deactivated() {

			this.chart = null;
			this.chartData = null;
			this.clearTimer();
		},
		onUnload() {
			this.chart = null;
			this.chartData = null;
			this.clearTimer();
		},
		onPullDownRefresh() {
			this.changeTab(this.curKey);
			this.clearTimer();
			uni.stopPullDownRefresh();
		},
		methods: {
			async changeTab(val) {
				this.curKey = val;
				this.clearTimer();
				this.chart = null;
				this.chartData = null;
				// if (this.curKey === this.$C.KEY_ALL) this.changeTabNew(this.curAll);
				// if (this.curKey === this.$C.KEY_CONTRACT) this.changeTabRank(this.curContract);
			},
			heyue(){
				uni.navigateTo({
					url:'/pages/contract/index'
				})
			},
			groupChange(n) {
			        console.log('groupChange', n);
			      },
			      radioChange(n) {
			        console.log('radioChange', n);
			      },

			async changeTabBest(val) {
				this.curBest = val;
				this.clearTimer();
				// this.onSetTimeout();
			},

			async linkTo(val) {
				this.curId = val.gid;
			},

			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
			async getlist() {
				uni.showLoading({
					title: this.$msg.API_REQUEST_DATA,
				})
				const result = await this.$http.get(`api/zong/list`);
				if (!result) return false;
				console.log(result, 5555555555555);
				this.list = result;
			},
			async getDepthList() {
				const response = await uni.request({
					url: `https://api.huobi.pro/market/depth`,
					method: 'GET',
					data: {
						symbol: this.info.locate,
						depth: 5,
						type: 'step0'
					},
				});
				const [err, res] = response;
				console.log('err:', err, 'res:', res);
				if (res && res.data.status == 'ok') {
					const temp = res.data;
					this.asks = res.data.tick.asks;
					this.bids = res.data.tick.bids;
					// 當前數組中，數量最大值， *1.01(餘量，避免求出100%)
					this.asksMax = Math.max(...this.asks.map(item => item[1])) * 1.01;
					// 當前數組中，數量最大值， *1.01(餘量，避免求出100%)
					this.bidsMax = Math.max(...this.bids.map(item => item[1])) * 1.01;
				}
				console.log('asks:', this.asks);
				console.log('bids:', this.bids);
			},
			
			connect() {
				//创建webSocket
				this.socket = uni.connectSocket({
					url: this.$http.WS_COIN_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.info(`success res:`, res);
					},
					fail: (res) => {
						console.info(`fail res:`, res);
					}
				});
				console.log(`socket:`, this.socket);
				if (this.socket) {
					this.isConnected = true; // 已连接
					this.socket.onOpen((res) => {
						console.info("socket onOpen:", res)
					});
					this.socket.onClose((res) => {
						// code:1000(手动关闭) 1006(异常关闭) 
						console.log(`onClose:`, res);
						this.isConnected = false;
						if (res.code !== 1000) {
							this.reconnectWebSocket();
						}
					});
			
					this.socket.onError((err) => {
						console.log(`onError:`, err);
						this.isConnected = false;
						this.reconnectWebSocket();
					});
					this.socket.onMessage((res) => {
						const data = JSON.parse(res.data);
						if (this.coinList) {
							if (this.coinList[data.market] && data.market && data.lastPrice > 0) {
								this.coinList[data.market].current_price = data.lastPrice;
								// this.coinList[data.market].rate = data.rate || 0;
								// this.coinList[data.market].vol = data.vol || 0;
							}
						}
						if (this.info.code == data.market && data.lastPrice > 0) {
							// console.log('data:', data);
							this.info.current_price = data.lastPrice || 0;
							this.info.rate = data.rate || 0;
							// this.info.rate_num = data.rate_num || 0;
							// this.info.vol = data.vol || 0;
						}
						// 當前買賣盤的數據
						if (this.info.code == data.market && data.type == "depth") {
							// 直接提取前五條，替換數據		
							const tempAsk = data.ask.slice(0, 5);
							const tempBid = data.bid.slice(0, 5);
							// console.log('data depth:', data);
							this.asks = tempAsk.map(item => [item.price, item.quantity]);
							this.bids = tempBid.map(item => [item.price, item.quantity]);
							// 當前數組中，數量最大值， *1.01(餘量，避免求出100%)
							this.asksMax = Math.max(...this.asks.map(item => item[1])) * 1.01;
							// 當前數組中，數量最大值， *1.01(餘量，避免求出100%)
							this.bidsMax = Math.max(...this.bids.map(item => item[1])) * 1.01;
						}
			
						// 匹配hold列表的每条数据。计算对应数据的floatPL值
						this.holdList.forEach(item => {
							if (item.code == data.market && data.lastPrice > 0) {
								item.curPrice = data.lastPrice;
								console.log(1111,data.lastPrice)
								if (item.direct == 1) {
									// 买多的计算公式: (当前价-买入价-手续费)*数量*杠杆
									item.floatPLBuy = this.$util.formatNumber(item.quantity * 1000 * (data
											.lastPrice * 1 - item.price * 1) / data.lastPrice * 1 *
										item.lever, 4);
			
									item.profitLossBuy = this.$util.formatNumber(item.quantity * 1000 * (
											data.lastPrice * 1 - item.price * 1) / data.lastPrice * 1 -
										item.fee, 4);
			
								}
								if (item.direct == 2) {
									// 卖少的计算公式: (买入价-当前价-手续费)*数量*杠杆
									item.floatPLSell = this.$util.formatNumber(item.quantity * 1000 * (item
											.price * 1 - data.lastPrice * 1) / data.lastPrice * 1 *
										item.lever, 4);
			
									item.profitLossSell = this.$util.formatNumber(item.quantity * 1000 * (
											item.price * 1 - data.lastPrice * 1) / data.lastPrice * 1 -
										item.fee, 4);
								}
							}
						});
					});
				}
			},
			// 关闭 websocket链接
			disconnect() {
				if (this.socket) {
					const result = this.socket.close();
					console.log('disconnect result:', result);
					this.socket = null;
				}
			},

		}
	}
</script>

<style>
</style>