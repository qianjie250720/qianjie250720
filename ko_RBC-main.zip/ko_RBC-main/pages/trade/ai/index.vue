<template>
	<view>
		<header class="common_header" style="gap:12px;background-color: #265bb3;height: 80px;">
			<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(16)" class="btn_back"
				@tap="$linkTo.goBack()"></image>
			<view class="dynamic_title" style="color: #fff;">{{$msg.MENU_AI}}</view>
			<!-- <image src="/static/icon_record.svg" mode="aspectFit" :style="$theme.setImageSize(16)"
				@tap="changeTab($C.KEY_DEPOSIT)"></image> -->
		</header>

		<!-- <view>
			<image src="/static/rn_bg.png" style="width: 100%;height:140px;"></image>
		</view> -->

		<view style="padding: 20px;border-bottom: 1px #f7f9fa solid;">
			<view class="flex_row_between common_tabs" style="background-color: #f7f9fa;padding: 3px;">
				<block v-for="(v, k) in tabs" :key="k">
					<view @tap="changeTab(k)" class="item" :class="curKey === k ? `item_act_dz` : ``">
						{{ v }}
					</view>
				</block>
			</view>
		</view>

		<view :class="curIndex%2==0?`left_in`:`right_in`" style="padding:20px 18px 60px 18px;">
			<template v-if="curKey===$C.KEY_BUY">
				<view class="" style="margin: 0 0 16px 0;padding: 14px 20px;">
					<!-- <view style="display: flex;align-items: center;justify-content: center;">
						<image src="/static/ai_icon.png" mode="aspectFit" :style="$theme.setImageSize(160)"></image>
					</view> -->
					<view class="form_label"> {{$msg.AI_AMOUNT}} </view>
					<view class="form_input" style="border: 1px #ccc solid;border-radius: 5px;">
						<input v-model="amount" type="digit" :placeholder="$msg.P_AI_AMOUNT"
							placeholder-class="placeholder"></input>
						<template v-if="amount && amount.length > 0">
							<image src="/static/del.svg" mode="aspectFit" @tap="amount=''"></image>
						</template>
					</view>
					<view style="margin-top: 10px;">
						<Balance :balance="!user?'': $fmt.amount(user.money)" deposit />
					</view>
					<view style="padding:24px 0 10px 0;">
						<BtnLock :isDisabled="islock" @tap="handleSubmit" className="btn_submit " style="border-radius: 5px;">
							{{$msg.COMMON_SUBMIT}}
						</BtnLock>
					</view>
				</view>
				<view style="padding:0 0 40px 0;" :style="{color:$theme.getColor($theme.SECOND)}">
					<view style="font: 14px;font-weight: 500;margin-top: 16px;margin-bottom: 16px;">
						{{$msg.AI_RULE_TITLE}}
					</view>
					<block v-for="(v,k) in $msg.AI_RULES" :key="k">
						<view style="font-size: 12px;padding-bottom: 8px;">{{`・ `+ v}}</view>
					</block>
				</view>
			</template>
			<template v-if="curKey===$C.KEY_APPLY ||curKey===$C.KEY_RECORD">
				<Record :list="list" :curKey="curKey" />
			</template>
		</view>

		<template v-if="showConfirm">
			<CommonConfirm :title="$msg.AI_MODAL_CONTENT" @cancel="cancel" @confirm="confirm">
			</CommonConfirm>
		</template>

	</view>
</template>

<script>
	import Record from './components/Record.vue';
	export default {
		components: {
			Record
		},
		data() {
			return {
				isAnimat: false,
				curKey: null,
				tabs: {
					[this.$C.KEY_BUY]: this.$msg.AI_TAB_BUY,
					[this.$C.KEY_APPLY]: this.$msg.AI_TAB_APPLY,
					[this.$C.KEY_RECORD]: this.$msg.AI_TAB_RECORD,
				},
				list: null,
				user: null,
				amount: '',
				type:'1',
				islock: false,
				showConfirm: false,
			}
		},
		computed: {
			curIndex() {
				const tem = Object.keys(this.tabs).findIndex(k => k === this.curKey)
				return !tem || tem < 0 ? 0 : tem;
			}
		},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.curKey = this.curKey || Object.keys(this.tabs)[0];
			this.changeTab(this.curKey);
		},
		onHide() {
			this.isAnimat = false;
			this.cancel();
		},
		onPullDownRefresh() {
			this.cancel();
			this.changeTab(this.curKey);
			uni.stopPullDownRefresh();
		},
		methods: {
			async changeTab(val) {
				this.list = null;
				this.curKey = val;
				if (this.curKey === this.$C.KEY_BUY)
					this.user = await this.$http.getAccount();
				if (this.curKey === this.$C.KEY_APPLY)
					this.getApplys();
				if (this.curKey === this.$C.KEY_RECORD)
					this.getSuccess();
			},

			cancel() {
				this.islock = false;
				this.showConfirm = false;
				this.detail = null;
			},

			confirm() {
				this.islock = false;
				this.showConfirm = false;
				this.buy();
			},

			handleSubmit() {
				if (!this.$util.checkField(this.amount, this.$msg.TIP_VALID)) return false;
				this.islock = true;
				this.showConfirm = true;
			},

			async buy() {
				uni.showLoading({
					title: this.$msg.API_SUBMITING,
				});
				const result = await this.$http.post(`api/rinei/buy`, {
					money: this.amount,
					type:this.type,
				});
				// console.log(result);
				this.islock = false;
				if (!result) return false;
				uni.showToast({
					title: this.$msg.COMMON_SUCCESS,
					icon: 'success'
				});
				setTimeout(() => {
					this.amount = '';
					this.changeTab(this.$C.KEY_APPLY);
				}, 1000);
			},

			async getApplys() {
				uni.showLoading({
					title: this.$msg.API_REQUEST_DATA,
				})
				const result = await this.$http.get(`api/rinei/sq-list`,{
					type:this.type,
				});
				if (!result) return null;
				console.log(result);
				this.list = result.length <= 0 ? [] : result.map(v => {
					return {
						status: v.status,
						statusTxt: v.zt,
						money: v.money * 1 || 0,
						success: v.success * 1 || 0,
						dt: v.created_at,
						ut: v.updated_at,
						sn: v.ordersn,
					}
				});
			},

			async getSuccess() {
				uni.showLoading({
					title: this.$msg.API_REQUEST_DATA,
				})
				const result = await this.$http.get(`api/rinei/order-list`,{
					type:this.type,
				});
				if (!result) return null;
				console.log(result);
				this.list = result.length <= 0 ? [] : result.map(v => {
					return {
						status: v.status,
						statusTxt: v.zt,
						price: v.price * 1 || 0,
						num: v.num * 1 || 0,
						money: v.money * 1 || 0,
						success: v.success * 1 || 0,
						ut: v.updated_at,
						dt: v.created_at,
						sn: v.ordersn,
					}
				});
			}
		}
	}
</script>

<style>
</style>