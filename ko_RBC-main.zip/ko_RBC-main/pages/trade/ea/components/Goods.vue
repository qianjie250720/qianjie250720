<template>
	<view>
		<block v-for="(item,index) in list" :key="index">
			<view style="padding:10px;">
				<view style="border: 1px #ccc solid;padding: 5px 0px;border-radius: 5px;">
					<view class="flex_row_between" style="padding:5px 20px;">
						<view style="font-size: 18px;font-weight: 700;">{{item.name}}</view>
						<view style="border: 1px #265bb3 solid;padding: 3px 10px;border-radius: 30px;" @tap="buy(item)">매수</view>
					</view>
					
					<view class="flex" style="line-height: 1.5;padding: 10px 0px;">
						<view style="flex: 20%;text-align: center;">
							<view style="color: #565656;">최저매수금액</view>
							<view style="font-weight: 500;font-size: 15px;">{{$fmt.amount(item.minAmount)}}</view>
						</view>
						<view style="flex: 30%;text-align: center;">
							<view style="color: #565656;">수익률</view>
							<view style="font-weight: 500;font-size: 15px;">{{item.fudu}}%</view>
						</view>
						<view style="flex: 10%;text-align: center;">
							<view style="color: #565656;">주기</view>
							<view style="font-weight: 500;font-size: 15px;">{{item.days}}일</view>
						</view>
					</view>
				</view>
			</view>
			
			
		</block>
	</view>
</template>

<script>
	export default {
		name: 'Goods',
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		methods: {
			buy(val) {
				this.$emit('buy', val);
			}
		}
	}
</script>

<style>
</style>