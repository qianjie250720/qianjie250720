<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(v,k) in list" :key="k">
				<view style="padding:10px 20px;">
					<view class="flex_row_between" v-if="curKey===$C.KEY_APPLY || curKey===$C.KEY_BUY">
						<view style="line-height: 1.5;">
							<view style="font-weight: 900;">{{v.name}}</view>
							<view style="color: #555;">{{v.code}}</view>
						</view>
						<view style="border: 1px #d95450 solid;padding: 5px 15px;border-radius: 30px;" @tap="buy(v)"
							v-if="curKey===$C.KEY_BUY">{{$msg.IPO_BUY}}</view>
						<view
							style="text-align: right;color: #9F8137;border: 1px #d95450 solid;padding: 5px 10px;border-radius: 30px;"
							v-if="curKey===$C.KEY_APPLY">
							{{v.msg}}
						</view>
					</view>
					<view style="border-bottom: 1px #f7f9fa solid;padding: 10px 0px;">
						<view style="display: flex;line-height: 1.8;">
							<view style="flex: 27%;" v-if="curKey===$C.KEY_BUY">
								<view style="color: #555;">공모가</view>
								<view style="color: #555;">청약한도 최대치</view>
							</view>
							<!-- <view style="flex: 20%;" v-if="curKey===$C.KEY_APPLY">
								<view style="color: #555;">공모가</view>
								<view style="color: #555;">당첨금액</view>
							</view>
							<view style="flex: 20%;text-align: right;" v-if="curKey===$C.KEY_APPLY">
								<view style="font-weight: 500;">{{$fmt.amount(v.price,v.lgre)}}</view>
								<view style="font-weight: 500;color: #d95450;">{{$fmt.amount(v.successAmount)}}</view>
							</view> -->
							<view style="flex: 20%;text-align: right;" v-if="curKey===$C.KEY_BUY">
								<view style="font-weight: 500;">{{$fmt.amount(v.price,v.lgre)}}원/주</view>
								<view style="font-weight: 500;">{{$fmt.decimal(v.subQTY,$fmt.NEVER)}}주</view>
							</view>
							<view style="flex: 20%;text-align: right;" v-if="curKey===$C.KEY_BUY">
								<view style="color: #555;">수익률</view>
								<!-- <view style="color: #555;">배정물량</view> -->
							</view>
							<!-- <view style="flex: 20%;text-align: right;" v-if="curKey===$C.KEY_APPLY">
								<view style="color: #555;">청약최대한도</view>
								<view style="color: #555;">당첨 수량</view>
							</view>
							<view style="flex: 25%;text-align: right;" v-if="curKey===$C.KEY_APPLY">
								<view style="font-weight: 500;">{{$fmt.amount(v.applyQTY)}}</view>
								<view style="font-weight: 500;">{{$fmt.amount(v.success)}}</view>
							</view> -->
							<view style="flex: 25%;text-align: right;" v-if="curKey===$C.KEY_BUY">
								<view style="font-weight: 500;">{{$fmt.amount(v.shiying)}}%</view>
								<!-- <view style="font-weight: 500;">{{$fmt.amount(v.issuedAmount,v.lgre)}}</view> -->
							</view>
						</view>

						<view v-if="curKey===$C.KEY_APPLY">
							<view class="flex_row_between" style="line-height: 1.8;">
								<view style="color: #555;">공모가</view>
								<view style="font-weight: 500;">{{$fmt.amount(v.price,v.lgre)}}</view>
							</view>
							<view class="flex_row_between" style="line-height: 1.8;">
								<view style="color: #555;">청약최대한도</view>
								<view style="font-weight: 500;">{{$fmt.amount(v.applyQTY)}}</view>
							</view>
							<view class="flex_row_between" style="line-height: 1.8;">
								<view style="color: #555;">당첨 수량</view>
								<view style="font-weight: 500;">{{$fmt.amount(v.success)}}</view>
							</view>
							<view class="flex_row_between" style="line-height: 1.8;">
								<view style="color: #555;">당첨금액</view>
								<view style="font-weight: 500;">{{$fmt.amount(v.successAmount)}}</view>
							</view>
							
							<view class="flex_row_between" style="line-height: 1.8;">
								<view style="color: #555;">청약신청시간</view>
								<view style="font-weight: 500;">{{v.dt}}</view>
							</view>
							<view class="flex_row_between">
								<view style="color: #555;">거래 코드</view>
								<view style="font-weight: 500;">{{v.sn}}</view>
							</view>
						</view>

						<view style="line-height: 1.8;" v-if="curKey===$C.KEY_RECORD">

							<view class="flex_row_between" style="margin-top: -10px;line-height: 1.8;"
								v-if="curKey===$C.KEY_RECORD">
								<view style="font-weight: 700;">{{v.name}}</view>
								<view style="color: #555;">{{v.code}}</view>
							</view>
							<view style="display: flex;line-height: 1.8;" v-if="curKey===$C.KEY_RECORD">
								<view style="flex: 20%;">
									<view style="color: #555;">공모가</view>
									<view style="color: #555;"> 배정수량</view>
								</view>
								<view style="flex: 20%;text-align: right;">
									<view style="font-weight: 500;">{{$fmt.amount(v.price,v.lgre)}}</view>
									<view style="font-weight: 500;color: #d95450;">
										{{$fmt.decimal(v.success,$fmt.NEVER)}}
									</view>
								</view>
								<!-- <view style="flex: 20%;text-align: right;">
								<view style="color: #555;">비율</view>
								<view style="color: #555;">비율 금액</view>
							</view>
							<view style="flex: 25%;text-align: right;">
								<view style="font-weight: 500;">{{$fmt.percent(v.rate)}}</view>
								<view style="font-weight: 500;color: #d95450;">{{$fmt.decimal(v.rate_num,v.lgre)}}
								</view>
							</view> -->

							</view>
							<!-- <view class="flex_row_between">
							<view style="color: #555;">총청약금액</view>
							<view style="font-weight: 700;">{{$fmt.decimal(v.applyQTY,$fmt.NEVER)}}</view>
						</view>
						<view class="flex_row_between">
							<view style="color: #555;">기납입금액</view>
							<view style="font-weight: 700;">{{$fmt.amount(v.applyAmount,v.lgre)}}</view>
						</view> -->
							<view class="flex_row_between">
								<view style="color: #555;"> 총청약금액</view>
								<view style="font-weight: 700;">{{$fmt.amount(v.winning,v.lgre)}}</view>
							</view>
							<view class="flex_row_between">
								<view style="color: #555;">기납입금액</view>
								<view style="font-weight: 700;">{{$fmt.amount(v.freeze,v.lgre)}}</view>
							</view>
							<view class="flex_row_between">
								<view style="color: #555;">미납입금액</view>
								<view style="font-weight: 700;">{{$fmt.amount(v.unPayAmount,v.lgre)}}</view>
							</view>
							<view class="flex_row_between">
								<view style="color: #555;">{{$msg.IPO_DT}}</view>
								<view style="font-weight: 700;">{{v.dt}}</view>
							</view>
							<view class="flex_row_between">
								<view style="color: #555;">{{$msg.IPO_SN}}</view>
								<view style="font-weight: 700;">{{v.sn}}</view>
							</view>
						</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	export default {
		name: "CommonList",
		props: {
			list: {
				type: Array,
				default: []
			},
			curKey: {
				type: String,
				default: ''
			}
		},
		methods: {
			buy(val) {
				this.$emit('buy', val);
			}
		}
	}
</script>

<style>
</style>