<template>
	<view>
		<template v-if="!list || list.length <= 0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(v,k) in list" :key="k">
				<view style="display: flex;padding:10px 15px;border-bottom: 1px #f7f9fa solid;">
					<view style="flex: 30%;">
						<view style="font-size: 15px;font-weight: 700;">{{v.name}}</view>
						<view style="margin-top: 8px;">{{v.code}}</view>
					</view>
					<view style="flex: 15%;">
						<view style="justify-content: flex-end; display: flex;font-size: 15px;font-weight: 700; "
							v-if="curKey===$C.KEY_BUY">
							{{$fmt.amount(v.price,v.lgre)}}
						</view>
						<view style="justify-content: flex-end; display: flex;font-size: 15px;font-weight: 700; "
							v-if="curKey===$C.KEY_APPLY">
							{{$fmt.amount(v.current_price,v.lgre)}}
						</view>
						<view style="justify-content: flex-end; display: flex; margin-top: 8px;"
							v-if="curKey===$C.KEY_BUY">{{v.day}} 천</view>
						<view style="justify-content: flex-end; display: flex; margin-top: 8px;"
							v-if="curKey===$C.KEY_APPLY">{{$fmt.amount(v.total)}}</view>
					</view>
					<view style="flex: 30%;" v-if="curKey===$C.KEY_BUY">
						<view style="justify-content: flex-end; display: flex; font-size: 15px;font-weight: 700;">
							{{v.max_num}}
						</view>
						<view style="justify-content: flex-end; display: flex;margin-top: 8px; ">{{v.min_num}}</view>
					</view>
					<view style="flex: 30%;" v-if="curKey===$C.KEY_APPLY">
						<view style="justify-content: flex-end; display: flex; font-size: 15px;font-weight: 700;">
							{{$fmt.amount(v.fee)}}
						</view>
						<view style="justify-content: flex-end; display: flex;margin-top: 8px; ">{{v.success}}</view>
					</view>

					<view style="flex: 25%;" v-if="curKey===$C.KEY_BUY">
						<view style="padding: 3px 8px;border-radius: 30px;justify-content: flex-end; display: flex; ">
							<view
								style="border: 1px #0c52b0 solid;padding: 3px 10px;border-radius: 30px ;margin-top: 5px;color: #0c52b0;"
								@tap="buy(v)">
								구매</view>
						</view>
					</view>
					<view style="flex: 25%;" v-if="curKey===$C.KEY_APPLY">
						<view style="border-radius: 30px;justify-content: flex-end; display: flex; ">
							<view style="border-radius: 30px ;margin-top: 5px;font-weight: 900;"
								:style="{color: transStatus2(v.admin_status)}">
								{{transStatus(v.admin_status)}}
							</view>
						</view>
					</view>

				</view>



				<!-- <view class="table_primary">
					<view class="flex_row_between" style="gap: 12px;width: 100%;padding-bottom: 4px; ">
						<view class="text_wrap" style="font-size: 14px;font-weight: 700;flex: 1; min-width: 0;">
							{{v.name}}
						</view>
						<text style="font-size: 13px;font-weight: 300;">({{v.code}})</text>
						<template v-if="curKey===$C.KEY_BUY">
							<view style="margin-left: auto;">
								<text class="btn_buy" @tap="buy(v)">{{$msg.OTC_BUY}}</text>
							</view>
						</template>
					</view>
					<view class="flex_row_between table_primary_tr">
						<view>{{$msg.OTC_PRICE}}</view>
						<view>{{$fmt.amount(v.price,v.lgre)}}</view>
					</view>
					<view class="flex_row_between table_primary_tr">
						<view>{{$msg.OTC_PRICE_LATEST}}</view>
						<view>{{$fmt.amount(v.current_price,v.lgre)}}</view>
					</view>

					<view class="flex_row_between table_primary_tr">
						<view>{{$msg.OTC_RATE}}</view>
						<view :style="{color:$theme.setRiseFall(v.rate)}">
							{{$fmt.percent(v.rate)}}
						</view>
					</view>
					<view class="flex_row_between table_primary_tr">
						<view>{{$msg.OTC_RATE_NUM}}</view>
						<view :style="{color:$theme.setRiseFall(v.rate)}">
							{{$fmt.amount(v.rate_num,v.lgre)}}
						</view>
					</view>

					<template v-if="curKey===$C.KEY_BUY">
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.OTC_MIN}}</view>
							<view>{{$fmt.decimal(v.min_num)}}</view>
						</view>
					</template>

					<template v-if="curKey===$C.KEY_APPLY">
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.OTC_A_QTY}}</view>
							<view>{{$fmt.decimal(v.num)}}</view>
						</view>
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.OTC_A_AMOUNT}}</view>
							<view :style="{color:$theme.PRIMARY}">{{$fmt.amount(v.amount,v.lgre)}}</view>
						</view>
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.OTC_A_PL}}</view>
							<view :style="{color:$theme.setRiseFall(v.pl)}">
								{{$fmt.amount(v.pl,v.lgre)}}
							</view>
						</view>
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.OTC_A_PL_FLOAT}}</view>
							<view :style="{color:$theme.setRiseFall(v.floatPL)}">
								{{$fmt.amount(v.floatPL,v.lgre)}}
							</view>
						</view>

							<view class="flex_row_between table_primary_tr">
					<view>{{$msg.OTC_A_LEVER}}</view>
					<view>{{$fmt.quantity(v.lever)}}</view>
				</view>
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.OTC_A_FEE}}</view>
							<view>{{$fmt.amount(v.fee,v.lgre)}}</view>
						</view>
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.OTC_DT}}</view>
							<view>{{v.dt}}</view>
						</view>

						<template v-if="v.desc!=''">
							<view class="flex_row_between table_primary_tr">
								<view>{{$msg.OTC_DESC}}</view>
							</view>
							<view class="flex_row_between table_primary_tr">
								<view></view>
								<view style="text-align: right;" :style="{color:$theme.getColor($theme.INFO)}">
									{{v.desc}} </view>
							</view>
						</template>
					</template>
				</view> -->
			</block>
		</template>
	</view>
</template>

<script>
	export default {
		name: "Record",
		props: {
			list: {
				type: Array,
				default: []
			},
			curKey: {
				type: String,
				default: ''
			}
		},
		methods: {
			buy(val) {
				this.$emit('buy', val);
			},
			transStatus(admin_status) {
				if (admin_status == 0) {
					return '심사중';
				} else if (admin_status == 1) {
					return '심사완료';
				} else if (admin_status == 2) {
					return '심사실패';
				}
			},
			transStatus2(admin_status) {
				if (admin_status == 0) {
					return '#f3c897';
				} else if (admin_status == 1) {
					return '#000';
				} else if (admin_status == 2) {
					return '#ff0b0b';
				}
			},
		}
	}
</script>

<style>
</style>