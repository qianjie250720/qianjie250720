<template>
	<view>
		<view style="display: flex; background-color: #255bb2; padding:30px 20px;height: 80px;">
			<image src="/static/arrow_left.png" mode="widthFix" style="width: 8px; height: 10px; margin-top: 5px;" @click="fanhui()">
			</image>
			<view style="text-align: center; flex: 50%; color: #fff; font-size: 16px;">시장정보</view>
		</view>
		<header class="common_header" style="gap:12px;">
			<view class="flex_row_between common_tabs" style="flex:1;">
				<block v-for="(v, k) in tabs" :key="k">
					<view @tap="changeTab(k)" class="item_xw" :class="curKey === k ? 'item_act' : ''">
						{{ v }}
					</view>
				</block>
			</view>
		</header>

		<view v-if="curKey === $C.KEY_MARKET">
			<view>
				<block v-for="(v, k) in news" :key="k" v-if="k<=50">
					<view style="padding: 20px;" @tap="$linkTo.openNews(v.url)">
						<image :src="v.pic"  style="width: 100%;height: 180px;"></image>
						<view style="padding: 10px 0px;">{{ v.dt }}</view>
						<view style="font-weight: 700;">{{ v.title }}</view>
					</view>
				</block>
			</view>
		</view>
		<view v-if="curKey === $C.KEY_NEW">
			<view>
				<block v-for="(v, k) in news2" :key="k" v-if="k<=50">
					<view style="padding: 10px 20px; border-bottom: 1px #ccc solid;" @tap="$linkTo.openNews(v.url)">
						<!-- <image :src="v.pic" mode="widthFix" style="width: 10%;"></image> -->
						<view style="padding: 10px 0px;">{{ v.dt }}</view>
						<view style="font-weight: 700;">{{ v.sum_title }}</view>
						<view style="padding: 10px 0px;">{{ v.title }}</view>
					</view>
				</block>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		components: {},
		data() {
			return {
				isAnimat: false,
				curKey: null,
				news: null,
				news2: null,
				url: '',
				// 定义 tabs 时，依赖全局常量 $C 与消息对象 $msg
				tabs: {
					[this.$C.KEY_MARKET]: this.$msg.MENU_FX,
					[this.$C.KEY_NEW]: this.$msg.MENU_KX,
				},
				// 新增缺失的属性
				curNew: 0,
				curBest: 0,
				curRank: 0,
				chartData: null,
			}
		},
		async onShow() {
			// 初始化当前 tab
			this.curKey = this.curKey || Object.keys(this.tabs)[0];
			this.changeTab(this.curKey);
		},
		onHide() {},
		deactivated() {},
		onLoad() {
			this.getxinwen();
			this.getxinwen2();
		},
		onPullDownRefresh() {},
		methods: {
			async changeTab(val) {
				this.curKey = val;
				// 重置相关数据
				this.chartData = null;
				if (this.curKey === this.$C.KEY_NEW) {
					this.changeTabNew(this.curNew);
				}
				if (this.curKey === this.$C.KEY_MARKET) {
					this.changeTabBest(this.curBest);
					this.changeTabRank(this.curRank);
				}
			},
			fanhui(){
				uni.navigateTo({
					url:'/pages/home/index'
				})
			},
			// 占位方法，根据实际需求实现
			changeTabNew(val) {
				console.log("changeTabNew called with", val);
			},
			changeTabBest(val) {
				console.log("changeTabBest called with", val);
			},
			changeTabRank(val) {
				console.log("changeTabRank called with", val);
			},
			async getxinwen() {
				uni.showLoading({
					title: this.$msg.API_REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods/get_news`, {
					current: 0
				});
				uni.hideLoading();
				if (!result) return;
				this.news = result.length <= 0 ? [] : result.map(v => {
					return {
						title: v.title,
						url: v.url,
						dt: v.created_at,
						pic: v.pic,
						sum_title: v.sum_title,
					}
				});
			},
			async getxinwen2() {
				uni.showLoading({
					title: this.$msg.API_REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods/get_news`, {
					current: 1
				});
				uni.hideLoading();
				if (!result) return;
				this.news2 = result.length <= 0 ? [] : result.map(v => {
					return {
						title: v.title,
						url: v.url,
						dt: v.created_at,
						pic: v.pic,
						sum_title: v.sum_title,
					}
				});
			},
		}
	}
</script>