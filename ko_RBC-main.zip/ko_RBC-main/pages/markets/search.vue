<template>
	<view style="background-color: #FFF;min-height: 100vh;">
		<header class="common_head" style="display: flex;align-items: center;padding: 20px 16px 12px 16px;height: auto;">
			<image src="/static/back.svg" mode="aspectFit" :style="$theme.setImageSize(16)" @tap="$linkTo.goBack()">
			</image>

			<view style="flex:1;padding:0 12px;">
				<view
					style="border-radius: 18px;display: flex;align-items: center;gap: 12px;padding:4px 16px;height: 32px; line-height: 32px;background-color: #c4c4c433;">
					<image src="/static/search.svg" mode="aspectFit" :style="$theme.setImageSize(16)" @tap="handleSearch()">
					</image>
					<input v-model="keyword" type="text" :placeholder="$msg.SEARCH_P_KEY" placeholder-class="placeholder"
						style="flex:1;"></input>
					<template v-if="keyword && keyword.length > 0">
						<image src="/static/del.svg" mode="aspectFit" style="margin-left: auto;cursor: pointer;"
							:style="$theme.setImageSize(16)" @tap="keyword=''"></image>
					</template>
				</view>
			</view>
			<view style="margin-left: auto;">
				<text style="text-align: center;padding:6px 16px;border-radius: 4px;cursor: pointer;"
					:style="{backgroundColor:$theme.getColor($theme.PRIMARY),color:$theme.getColor($theme.WHITE)}"
					@tap="handleSearch()">{{$msg.SEARCH_BTN}}</text>
			</view>

		</header>

		<view style="background-color: #FFFFFF;margin-top: -20px;">
			<CommonTitle :title="$msg.SEARCH_HISTORY">
				<image src="/static/clear.svg" mode="aspectFit" style="cursor: pointer;" :style="$theme.setImageSize(20)"
					@tap="clearKeywords()">
				</image>
			</CommonTitle>
		</view>

		<view class="search_history">
			<block v-for="(v,k) in keywords" :key="k">
				<view @tap="selectedItem(v)" class="item">{{v}}</view>
			</block>
		</view>
		<view style="background-color: #F4F4F4;height: 10px;"></view>
		<view class="right_in" style="padding:0 18px 100px 18px;">
			<CommonList :list="list" @action="linkTo" />
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false,
				keyword: '',
				keywords: [],
				list: null,
				timer: null,
			}
		},
		computed: {},
		onShow() {
			this.clearTimer();
			this.isAnimat = true;
			this.$linkTo.isAuth();
			this.keywords = uni.getStorageSync("keywords") || this.keywords;
		},
		onHide() {
			this.isAnimat = false;
			this.clearTimer();
		},
		deactivated() {
			this.clearTimer();
		},
		onUnload() {
			this.clearTimer();
		},
		onPullDownRefresh() {
			this.handleSearch();
			this.keywords = uni.getStorageSync("keywords") || this.keywords;
			uni.stopPullDownRefresh();
		},
		methods: {
			// 当前默认行为：携带数据id，跳转到stockDetail页面
			linkTo(val, gid) {
				// 可根据curKey 对跳转行为做分别处理
				this.$linkTo.stockDetail(val, gid);
			},
			clearKeywords() {
				uni.clearStorageSync("keywords");
				this.keywords = [];
				this.list = [];
			},
			selectedItem(item) {
				this.keyword = item;
				this.handleSearch();
			},
			onSetTimeout() {
				this.timer = setInterval(() => {
					console.log("setInterval");
					this.search();
				}, 3000);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
			handleSearch() {
				this.search();
				this.clearTimer();
				this.onSetTimeout();
			},
			async search() {
				if (this.keyword == '' || this.keyword.length < 2) {
					uni.showToast({
						title: this.$msg.SEARCH_P_KEY,
						icon: 'none'
					})
					return false;
				}
				uni.showLoading({
					title: this.$msg.API_REQUEST_DATA,
				})
				const result = await this.$http.post(`api/product/list`, {
					key: this.keyword,
					page: 1,
					limit: 30,
					gp_index: 0
				});
				if (!result) return null;
				const temp = result.filter(v => v.gid > 0);
				const objData = {};
				!temp || temp.length <= 0 ? null : temp.forEach(v => {
					const type = v.project_type_id || 1;
					objData[`${v.gid}`] = {
						pid: v.pid || 0,
						gid: v.gid,
						name: v.name,
						code: v.code,
						rate: v.rate * 1 || 0,
						price: v.current_price * 1 || 0,
						rateNum: v.rate_num * 1 || 0,
						type: type,
						lgre: this.$C.LGRE[type],
						track: v.is_collected == 1
					};
				});
				this.list = objData;

				if (this.list && Object.values(this.list).length > 0) {
					console.log('search result:', this.list)
					if (this.keywords.indexOf(this.keyword) < 0) {
						this.keywords.push(this.keyword);
						uni.setStorageSync("keywords", this.keywords)
					}
				}
			},
		}
	}
</script>

<style>
</style>