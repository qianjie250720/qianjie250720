<template>
	<!-- <view :class="isAnimat?'fade_in':'fade_out'"> -->
		<view>
		<header class="common_header" style="gap:12px;">
			<image src="/static/logo.png" mode="heightFix" :style="$theme.setImageSize(40)"></image>
			<!-- <view style="font-size: 20px;font-weight: 600;">{{!user?'':user.nick_name}}</view> -->
			<view style="display: flex;background-color: #f3f4f6;padding: 8px 10px;border-radius: 30px;width: 70%;" @tap="$linkTo.search()">
				<image src="/static/search.png" mode="heightFix" :style="$theme.setImageSize(15)"
					style="cursor: pointer;">
				</image>
				<view style="margin-left: 10px;font-size: 12px;color: #999;">이름/코드를 입력해주세요</view>
			</view>
			<image src="/static/kefu.png" mode="heightFix" :style="$theme.setImageSize(20)"
				style="cursor: pointer;margin-left: auto;" @tap="$linkTo.service()">
			</image>
			<image src="/static/xiaoxi.png" mode="heightFix" :style="$theme.setImageSize(20)"
				style="cursor: pointer;margin-left: auto;" @tap="$linkTo.notify()">
			</image>
		</header>
		
		<view style="text-align: center;">
			<image src="/static/shouye_bg.jpg" widthfix="heightFix" style="width: 100%;height: 180px;">
			</image>
		</view>

		<view style="text-align: center;">
			<image src="/static/banner2.png" widthfix="heightFix" style="width: 100%;height: 100px;">
			</image>
		</view>
		
		<!-- <view class="" style="padding: 10px 20px;display: flex;gap: 15px;justify-content: center;">
			<view style="background-color: #265bb3;color: #fff;padding: 10px;width: 35%;text-align: center;border-radius: 5px;" @click="chongzhi()">입금정보</view>
			<view style="background-color: #f3f4f6;color: #265bb3;padding: 10px;width: 35%;text-align: center;border-radius: 5px;" @click="tikuan()">출금신청</view>
		</view> -->

		<view class="btns" style="padding: 20px 0px;">
			<block v-for="(v,k) in btns" :key="k">
				<view class="item" @tap="v.action">
					<image mode="aspectFit" :src="`/static/home/btn_${k}.png`" :style="$theme.setImageSize(35)"
						style="cursor: pointer;">
					</image>
					<view style="font-size: 13px;margin-top: 8px;text-align: center;font-weight: 500;cursor: pointer;font-size: 15px;"
						:style="{paddingBottom:k<3 ?'25px':''}">{{v.name}}</view>
				</view>
			</block>
		</view>
		
		<!-- <view style="text-align: center;">
			<image src="/static/sy_tzbg.png" widthfix="heightFix" style="width: 100%;height: 100px;">
			</image>
		</view> -->
		
		<!-- <template>
			<view style="display: flex;background-color: #f8fbff;padding: 10px 0px;">
				<image src="/static/gonggao_bg.png" mode="widthFix" style="width: 35px;height: 35px;background-color: #fff;margin-left: 20px;"></image>
		      <u-notice-bar :text="text1" bgColor="#fff" color="#000" icon=""></u-notice-bar>
		    </view>
		</template> -->

		<!-- <template v-if="assets">
			<CommonTitle :title="$msg.ASSETS_TITLE"></CommonTitle>
			<AssetsCard :info="assets"></AssetsCard>
		</template> -->

		<!-- <CommonTitle :title="$msg.INDEX_TITLE">
			<view :style="{color:$theme.getColor($theme.PRIMARY)}" style="cursor: pointer;"
				@tap="$linkTo.markets($C.KEY_INDI)">
				{{$msg.INDEX_ALL}}
			</view>
		</CommonTitle> -->
		<!-- <view style="display: flex;padding: 10px;">
			<view style="color: #ff2626;font-weight: 900;font-size: 16px;">지수</view>
			<view style="font-weight: 900;font-size: 16px;">주식</view>
		</view> -->
		<view class="flex_row_between common_tabs" style="padding:5px 0px;border-radius: 6px;margin:15px 12px 4px 12px;background-color: #f3f4f6;">
			<block v-for="(v,k) in $msg.PLACE_TAB_BEST" :key="k">
				<view @tap="changeTabBest(k)" class="item_sec" :class="curBest===k?`item_sec_act`:``">
					<text>{{v}}</text>
				</view>
			</block>
		</view>

		<view class="left_in" style="padding:0 0 0 0;margin: -10px 0;">
			<template v-if="bests && Object.values(bests).length>0">
				<view class="card_row" style="padding-top: 12px;background-color:transparent;">
					<block v-for="(v,k) in bests" :key="k">
						<!-- <CardItem :detail="v" @action="linkTo"  show/> -->
						<CardItem :detail="v" @action="linkTo"  />
					</block>
				</view>
			</template>
		</view>
		<!-- kline -->
		<view class="common_card" style="background-color: #FFF;padding:8px;margin:8px;">
			<view id="kline-stock" style="width: 100%;height:240px;"> </view>
		</view>
		
		

		<CommonTitle :title="$msg.STOCK_TITLE" >
			<view :style="{color:$theme.getColor($theme.PRIMARY)}" style="cursor: pointer;"
				@tap="$linkTo.markets($C.KEY_STOCK)">
				{{$msg.STOCK_ALL}}
			</view>
		</CommonTitle>
		<!-- <view class="flex_row_between common_tabs" style="padding:6px 4px;border-radius: 6px;margin:0 12px 4px 12px;"
			:style="{backgroundColor:$theme.getColor($theme.PRIMARY_RGBA)}">
			<block v-for="(v,k) in tabs" :key="k">
				<view @tap="changeTab(k)" class="item_sec" :class="curKey===k?`item_sec_act`:``">
					<text>{{v}}</text>
				</view>
			</block>
		</view> -->

		<!-- <view class="flex_row_between common_tabs" style="flex:1;gap:14px;">
			<block v-for="(v,k) in tabs" :key="k">
				<view @tap="changeTab(k)" class="item" :class="curKey===k?`item_act`:``">
					{{v}}
				</view>
			</block>
		</view> -->
		<view class="right_in" style="padding:6px 18px 60px 18px;margin-top: -10px;">
			<block v-for="(v,k) in list" :key="k">
				<view @tap="$linkTo.stockDetail(v.code,v.gid)" style="border-bottom: 1px solid #CCC;padding: 8px 0;">
					<view class="flex_row_between" style="gap: 12px;width: 100%;">
						<CustomLogo :logo="v.logo" :name="v.name"></CustomLogo>
						<view class="text_wrap" style="font-size: 14px;font-weight: 700;flex: 1; min-width: 0;">
							{{v.name}}<text style="font-size: 13px;font-weight: 300;padding-left: 12px;">({{v.code}})</text>
						</view>
					</view>
					<view class="flex_row_between" style="gap: 12px;">
						<view style="width: 48%;">{{v.industry}}</view>
						<view style="font-size: 15px;" :style="{color:$theme.setRiseFall(v.rate)}">
							{{$fmt.amount(v.price,v.lgre)}}
						</view>
						<text style="font-size: 15px;margin-left: auto;" :style="{color:$theme.setRiseFall(v.rate)}">
							{{ $fmt.percent(v.rate)}}
						</text>
					</view>
				</view>
			</block>
		</view>

		<!-- <view style="text-align: center;line-height: 1.6;" :style="{color:$theme.getColor($theme.INFO)}">{{$msg.COMMON_100}}
		</view> -->

		<view style="height: 30px;"></view>

		<FooterSmall :actKey="$C.KEY_HOME"></FooterSmall>
	</view>
</template>

<script>
	import * as ext from './ext.js';
	import {
		init,
		dispose,
		utils,
	} from '@/common/klinecharts.min.js';
	// import HomeCurves from './components/HomeCurves.vue';
	export default {
		// components: {
		// 	HomeCurves
		// },
		data() {
			return {
				isAnimat: false,
				user: null,
				btns: ext.btns(),
				list: null,
				bests: null,
				curKey: null,
				tabs: {
					[this.$fmt.code.KEY_KR]: this.$msg.STOCK_TABS_KR,
					[this.$fmt.code.KEY_US]: this.$msg.STOCK_TABS_US,
				},
				// tabs: {
				// 	[this.$C.KEY_MARKET]: this.$msg.MENU_PLACE,
				// 	[this.$C.KEY_NEW]: this.$msg.MENU_NEWS,
				// },
				text1: '고향에는 벚꽃이 활짝 피었습니다. 언제 고향에 벚꽃을 보러 가실 건가요......',
				curId: 141,
				curBest: 0,
				timer: null,
				
			}
		},
		computed: {
			// assets() {
			// 	if (!this.user) return null;
			// 	return {
			// 		total: this.user.totalZichan * 1 || 0,
			// 		usd: this.user.usd * 1 || 0,
			// 		balance: this.user.money * 1 || 0,
			// 		frozen: this.user.frozen * 1 || 0,
			// 		totalPL: this.user.totalYingli * 1 || 0,
			// 		holdPL: this.user.holdYingli * 1 || 0,
			// 	}
			// },
			curGpIndex() {
				return this.$C.GPINDEX[this.curKey] || Object.keys(this.tabs)[0];
			}
		},
		async onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.getTop2();
			// this.user = await this.$http.getAccount();
			this.curKey = this.curKey || Object.keys(this.tabs)[0];
			this.changeTab(this.curKey);
			await this.$http.getTop2();
		},
		onHide() {
			this.isAnimat = false;
			this.clearTimer();
			dispose("kline-stock");
			this.chart = null;
		},
		deactivated() {
			this.clearTimer();
			dispose("kline-stock");
			this.chart = null;
		},
		onUnload() {
			this.clearTimer();
			dispose("kline-stock");
			this.chart = null;
		},
		async onPullDownRefresh() {
			this.clearTimer();
			// this.user = await this.$http.getAccount();
			this.changeTab(this.curKey);
			uni.stopPullDownRefresh();
		},
		methods: {
			getlogo() {
				return this.$BaseUrl + this.productDetails.logo
			},
			changeTab(val) {
				this.curKey = val;
				this.list = null;
				this.changeTabBest(this.curBest);
				this.getStock();
				this.clearTimer();
				if (this.curKey === this.$fmt.code.KEY_KR)
					if (!this.timer) this.onSetTimeout();
			},
			async changeTabBest(val) {
				this.curBest = val;
				// this.getTop();
				this.getTop2();
			},

			linkTo(val) {
				console.log(val);
				// this.$linkTo.stockDetail(val.gid, val.gid);
				return false;
			},
			chongzhi(){
				uni.navigateTo({
					url:'/pages/settings/deposit'
				})
			},
			tikuan(){
				uni.navigateTo({
					url:'/pages/settings/withdraw'
				})
			},

			async getStock() {
				this.list = await this.$http.getStocks(this.curGpIndex);
			},

			async getTop() {
				const result = await this.$http.getTop(this.curBest);
				if (!result) return false;
				this.bests = result.tops;
			},
			async getTop2() {
				const result = await this.$http.getTop(this.curBest, this.curId);
				if (!result) return false;
				this.bests = result.tops;
				this.chartData = result.chart;
				console.log(this.chartData)
				if (!this.chart) {
					this.chart = init('kline-stock')
					console.log(this.chart)
					this.chart.setStyles({
						candle: {
							type: "area",
							tooltip: {
								showRule: "none",
							}
						},
					});
				}
				this.chart.applyNewData(this.chartData);
				this.$forceUpdate();
			
				setTimeout(() => {
					this.article = result.article;
					this.industry = result.industry;
				}, 300);
			
			},

			onSetTimeout() {
				this.timer = setInterval(() => {
					console.log("setInterval");
					// this.getTop();
					if (this.curKey === this.$fmt.code.KEY_KR) this.getStock();
				}, 5000);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
		}
	}
</script>

<style>
</style>