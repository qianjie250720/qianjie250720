<template>
	<view>
		<block v-for="(v,k) in list" :key="k">
			<view style="align-items: center;background-color: transparent;color:#777;padding:15px 20px;line-height: 2;border-bottom: 1px #f7f9fa solid;">
				<view class="flex_row_between">
					<view style="font-size: 17px;font-weight: 900;color: #000;">
						{{v.name}} <text style="padding-left: 12px;font-size: 11px;font-weight: 300;">({{v.curcode}})</text>
					</view>
					<view style="background-color: #859ec7;padding: 0px 10px;border-radius: 5px;color: #fff;" v-if="v.project_type_id === 3">US</view>
					<view style="background-color: #859ec7;padding: 0px 10px;border-radius: 5px;color: #fff;" v-if="v.project_type_id === 1">KR</view>
				</view>
				
				<view style="display: flex;">
				<view style="flex:25%;">
					<view>{{$msg.POSITION_BUY_PRICE}}</view>
					<view>{{v.status==1?$msg.POSITION_CUR_PRICE:$msg.POSITION_SELL_PRICE}}</view>
				</view>
				<view style="flex:30%;">
					<view style="text-align: center;color: #000;font-weight: 500;">{{$fmt.amount(v.buyPrice,v.lgre)}}</view>
					<view style="text-align: center;color: #000;font-weight: 500;" v-if="v.status==1">{{$fmt.amount(v.curPrice,v.lgre)}}</view>
					<view style="text-align: center;color: #000;font-weight: 500;" v-if="v.status==2">{{$fmt.amount(v.sellPrice,v.lgre)}}</view>
				</view>
				<view style="flex:25%;">
					<view style="text-align: center;">{{$msg.POSITION_BUY_QTY}}</view>
					<view style="text-align: center;">{{$msg.POSITION_FLOAT_PL}}</view>
				</view>
				<view style="flex:25%;">
					<view style="text-align: right;color: #000;font-weight: 500;">{{$fmt.numer(v.buyNum)}}</view>
					<view style="text-align: right;color: #000;font-weight: 500;" v-if="v.status==1">{{$fmt.amount(v.buyFloatPL,v.lgre,v.lgre,$fmt.EXCEPT_ZERO)}}</view>
					<view style="text-align: right;color: #000;font-weight: 500;" v-if="v.status==2">{{$fmt.amount(v.sellFloatPL,v.lgre,v.lgre,$fmt.EXCEPT_ZERO)}}</view>
				</view>
				</view>
				
				<view style="display: flex;">
				<view style="flex:25%;">
					<view>{{$msg.POSITION_BUY_AMOUNT}}</view>
					<view>{{$msg.POSITION_TOTAL}}</view>
				</view>
				<view style="flex:30%;">
					<view style="text-align: center;color: #000;font-weight: 500;">{{$fmt.amount(v.buyAmount,v.lgre)}}</view>
					<view style="text-align: center;color: #000;font-weight: 500;" v-if="v.status==1">{{$fmt.amount(v.buyTotal,v.lgre)}}</view>
					<view style="text-align: center;color: #000;font-weight: 500;" v-if="v.status==2">{{$fmt.amount(v.sellTotal,v.lgre)}}</view>
				</view>
				<view style="flex:25%;">
					<view style="text-align: center;">{{$msg.POSITION_PL_RATE}} </view>
					<view style="text-align: center;">{{$msg.POSITION_PL}}</view>
				</view>
				<view style="flex:25%;">
					<view style="text-align: right;color: #000;font-weight: 500;" v-if="v.status==1">{{$fmt.percent(v.buyPLRate)}}</view>
					<view style="text-align: right;color: #000;font-weight: 500;" v-if="v.status==2">{{$fmt.percent(v.sellPLRate)}}</view>
					<view style="text-align: right;color: #000;font-weight: 500;">
						{{$fmt.amount(v.plAmount,v.lgre,v.lgre,$fmt.EXCEPT_ZERO)}} </view>
				</view>
				</view>
				
				<view style="display: flex;">
				<view style="flex:25%;">
					<view>{{ v.status==1? $msg.POSITION_BUY_FEE:$msg.POSITION_SELL_FEE}}</view>
				</view>
				<view style="flex:30%;">
					
					<view style="text-align: center;color: #000;font-weight: 500;" v-if="v.status==1">
						{{$fmt.amount(v.buyFee,v.lgre)}} </view>
						<view style="text-align: right;color: #000;font-weight: 500;" v-if="v.status==2">
							{{$fmt.amount(v.sellFee,v.lgre)}} </view>
				</view>
				<view style="flex:25%;">
					<view style="text-align: center;">{{$msg.POSITION_LEVER}} </view>
				</view>
				<view style="flex:25%;">
					<view style="text-align: right;color: #000;font-weight: 500;">
						{{$fmt.numer(v.double)}}</view>
				</view>
				</view>
				<view class="flex_row_between">
					<view> {{$msg.POSITION_DT}} </view>
					<view style="color: #000;font-weight: 500;"> {{v.status==1? v.buyDT:v.sellDT}} </view>
				</view>
				<view class="flex_row_between">
					<view> {{$msg.POSITION_SN}} </view>
					<view style="color: #000;font-weight: 500;"> {{v.sn}} </view>
				</view>
				
				<view style="display: flex;align-items: center;justify-content: space-between;gap: 20px;margin-top: 10px;" v-if="v.project_type_id === 1 ">
					<view class="btn_buy" style="flex:1;padding:8px 0;"
						:style="{backgroundColor:$theme.getColor($theme.PRIMARY_RGBA),color:$theme.getColor($theme.PRIMARY)}"
						@tap="$linkTo.stockDetail(v.curcode)">
						{{$msg.STOCK_DETAIL}}
					</view>
					<template v-if="v.status==1">
						<view class="btn_buy" style="flex:1;padding:8px 0;"
							:style="{backgroundColor:$theme.getColor($theme.ERROR_RGBA),color:$theme.getColor($theme.ERROR)}"
							@tap="sell(v)">
							{{$msg.POSITION_SELL}}
						</view>
					</template>
					<template v-if="v.status==2">
						<view class="btn_buy" style="flex:1;padding:8px 0;"
							:style="{backgroundColor:$theme.getColor($theme.SUCCESS_RGBA),color:$theme.getColor($theme.SUCCESS)}"
							@tap="buy(v.curcode)">
							{{$msg.POSITTON_BUY}}
						</view>
					</template>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "PositionBak",
		data() {
		        return {
		          show: false
		        }
		      }, 
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		methods: {
			 open() {
			          // console.log('open');
			        },
			        close() {
			          this.show = false
			          // console.log('close');
			        },
			sell(val) {
				this.$emit('sell', val);
			},
			buy(val) {
				this.$linkTo.stockDetail(val, 'buy');
			}
		}
	}
</script>

<style>
</style>