<template>
	<!-- <view :class="isAnimat?'fade_in':'fade_out'" class="bg_prima"> -->
		<view class="bg_prima">
		<header class="common_header" style="gap:12px;">
			<view style="color: #fff;font-size: 18px;font-weight: 900;">보유</view>
			<view style="display: flex;background-color: #f3f4f6;padding: 8px 10px;border-radius: 30px;width: 65%;" @tap="$linkTo.search()">
				<image src="/static/search.png" mode="heightFix" :style="$theme.setImageSize(15)"
					style="cursor: pointer;">
				</image>
				<view style="margin-left: 10px;font-size: 12px;color: #999;">이름/코드를 입력해주세요</view>
			</view>
			<image src="/static/sc_kf.png" mode="heightFix" :style="$theme.setImageSize(20)"
				style="cursor: pointer;margin-left: auto;" @tap="$linkTo.service()">
			</image>
			<image src="/static/sc_xx.png" mode="heightFix" :style="$theme.setImageSize(20)"
				style="cursor: pointer;margin-left: auto;" @tap="$linkTo.notify()">
			</image>
		</header>

		<!-- <view class="left_in" style="padding:0 0 10px 0;">
			<template v-if="assets">
				<AssetsCard :info="assets" />
			</template>
		</view> -->
		
         <view style="background-color: #fff;border-radius:20px 20px  0px 0px ;margin-top: 135px;">
		<view style="padding:20px;">
				   <view class="flex_row_between common_tabs" style="background-color: #f7f9fa;padding: 3px;">
				   	<block v-for="(v, k) in tabs" :key="k">
				   		<view @tap="changeTab(k)" class="item" :class="curKey === k ? `item_act_dz` : ``">
				   			{{ v }}
				   		</view>
				   	</block>
				   </view>
		</view>
		
		<template>
			<view style="padding:0px 20px;margin-top: -10px;">
				<view class="background-container">
				  <view class="overlay-text">
					  <view style="display: flex;">
						  <view style="color: #265bb3;font-weight: 900;font-size: 16px;">내 자산</view>
						 <image :src="`/static/mask_${isMask?`hide`:`show`}.png`" mode="aspectFit"
						 	:style="$theme.setImageSize(20)" @tap="toggleMask()"
						 	style="cursor: pointer;margin-left: 10px;"></image>
					  </view>
					  
					  <view style="color: #265bb3;font-size: 22px;margin-top: 10px;font-weight: 900;">{{isMask?hideData:$fmt.amount(assets.money) }}</view>
					  <view class="flex" style="margin-top: 15px;">
						  <view style="color: #265bb3;font-size: 14px;">USDT</view>
						   <view style="margin-left: 10px;color: #265bb3;font-size: 16px;font-weight: 500;">{{isMask?hideData:$fmt.amount(assets.usd) }}</view>
					  </view>
				  </view>
				</view>
			</view>
		</template>
		
		<!-- <view class="" style="padding: 20px 20px;display: flex;gap: 15px;justify-content: center;">
			<view style="background-color: #265bb3;color: #fff;padding: 10px;width: 35%;text-align: center;border-radius: 5px;" @click="chongzhi()">입금정보</view>
			<view style="background-color: #f3f4f6;color: #265bb3;padding: 10px;width: 35%;text-align: center;border-radius: 5px;" @click="tikuan()">출금신청</view>
		</view> -->
		
		<view style="line-height: 2;padding: 0px 20px;">
			<view style="margin-top: 20px;" class="flex">
				<view style="border-right: 3px solid #265bb3;height: 15px;margin: 10px 0px;"></view>
				<view style="font-weight: 900;margin-left: 10px;">계좌 잔액 세부 정보</view>
			</view>
			
			<view class="flex" style="line-height: 1.8;">
				<view class="flex" style="flex: 50%;">
					<view style="flex: 10%;color: #555;">{{$msg.ASSETS_BALANCE}}</view>
					<view style="flex: 30%;font-weight: 600;">{{$fmt.amount(assets.total) }}</view>
				</view>
				<view class="flex" style="flex: 40%;">
					<view style="flex: 10%;color: #555;">{{$msg.ASSETS_FROZEN}}</view>
					<view style="flex: 30%;font-weight: 600;">{{$fmt.amount(assets.frozen) }}</view>
				</view>
			</view>
			<view class="flex" style="line-height: 2;">
				<view class="flex" style="flex: 50%;">
					<view style="flex: 10%;color: #555;">{{$msg.ASSETS_HOLD_PL}}</view>
					<view style="flex: 30%;font-weight: 600;">{{$fmt.amount(assets.totalPL) }}</view>
				</view>
				<view class="flex" style="flex: 40%;">
					<view style="flex: 10%;color: #555;">{{$msg.ASSETS_TOTAL_PL}}</view>
					<view style="flex: 30%;font-weight: 600;">{{$fmt.amount(assets.holdPL) }}</view>
				</view>
			</view>
		</view>
		
		<view style="border-bottom: 10px #f8fbff solid;padding: 8px 0px;"></view>
		
		
		<view class="right_in" style="padding:0 0 60px 0;">
			<!-- <template v-if="curKey===$C.KEY_ROI">
				<CommonTitle title="投资收益"> </CommonTitle>
				<template v-if="roi">
					<view style="display: flex;align-items: center;justify-content: space-between;padding:20px;">
						<view>
							<view>购买金额</view>
							<view>{{$fmt.amount(roi.buyAmount)}}</view>
						</view>
						<view>
							<view>评估收益率</view>
							<view>{{$fmt.percent(roi.ratePL)}}</view>
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;padding:0 20px 20px 20px;">
						<view>
							<view>评估收益</view>
							<view>{{$fmt.amount(roi.pl)}}</view>
						</view>
						<view>
							<view>总资产</view>
							<view>{{$fmt.amount(roi.total)}}</view>
						</view>
					</view>
				</template>

				<view style="height: 10px;width: 100%;background-color: #F5F5F5;"></view>
				<CommonTitle title="投资收益趋势"> </CommonTitle>
				<view
					style="display: flex;align-items: center;justify-content: space-between;gap: 12px;font-size: 12px;padding:20px;">
					<block v-for="(v,k) in months" :key="k">
						<view style="flex:1;border-radius: 22px;padding:4px 0;text-align: center;"
							:style="$theme.setStyleTab(curTab==k)" @tap="changeMonth(k)">{{v}}
						</view>
					</block>
				</view>
				<view style="text-align: center;line-height: 9;">曲线图表</view>
			</template> -->
			<!-- 列表说明 -->
			<!-- <view style="display: flex;align-items: center;padding:12rpx 0;background-color: transparent;color:#777;border-bottom: 1px #f7f9fa solid;" v-if="curKey===$C.KEY_HOLD">
				<view style="flex:25%;text-align: center;">
					종목
				</view>
				<view style="flex:30%;">
					<view style="text-align: center;">평가손익</view>
					<view style="text-align: center;">{{$msg.POSITION_PL_RATE}}</view>
				</view>
				<view style="flex:25%;">
					<view style="text-align: center;">{{$msg.POSITION_BUY_QTY}}</view>
					<view style="text-align: center;">{{$msg.POSITION_PL}}</view>
				</view>
				<view style="flex:25%;">
					<view style="text-align: right;padding-right: 4px;">{{$msg.POSITION_BUY_PRICE}}</view>
					<view style="text-align: right;padding-right: 4px;">
						{{$msg.POSITION_CUR_PRICE}}</view>
				</view>
			</view> -->

			<template v-if="curKey===$C.KEY_HOLD||curKey===$C.KEY_RECORD">
				<template v-if="!list || list.length<=0">
					<EmptyData></EmptyData>
				</template>
				<template v-else>
					<Position :list="list" @sell="handleSell"></Position>
				</template>
			</template>
		</view>

		<template v-if="showConfirm">
			<CommonConfirm :title="$msg.POSITION_ASK" @cancel="cancel" @confirm="confirm"></CommonConfirm>
		</template>

		<FooterSmall :actKey="$C.KEY_POSITION"></FooterSmall>
	</view>
	</view>
</template>

<script>
	import Position from './components/Position.vue';
	export default {
		components: {
			Position
		},
		data() {
			return {
				isAnimat: false,
				user: null,
				curKey: null,
				tabs: {
					[this.$C.KEY_HOLD]: this.$msg.POSITION_HOLD,
					[this.$C.KEY_RECORD]: this.$msg.POSITION_RECORD,
				},
				list: null,
				showConfirm: false,
				detail: null,
				timer: null,
				isMask: null, // 是否掩码
				hideData: `*****`,
			}
		},
		beforeMount() {
			this.isMask = uni.getStorageSync('masking');
		},
		computed: {
			assets() {
				if (!this.user) return null;
				return {
					total: this.user.totalZichan * 1 || 0,
					money: this.user.with * 1 || 0,
					usd: this.user.usd * 1 || 0,
					// balance: this.user.totalZichan * 1 || 0,
					frozen: this.user.frozen * 1 || 0,
					totalPL: this.user.totalYingli * 1 || 0,
					holdPL: this.user.holdYingli * 1 || 0,
				}
			},
		},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.curKey = this.curKey || Object.keys(this.tabs)[0];
			this.changeTab(this.curKey);
		},
		onHide() {
			this.isAnimat = false;
			this.clearTimer();
		},
		deactivated() {
			this.clearTimer();
		},
		onUnload() {
			this.clearTimer();
		},
		onPullDownRefresh() {
			this.clearTimer();
			this.changeTab(this.curKey);
			uni.stopPullDownRefresh();
		},
		methods: {
			toggleMask() {
				this.isMask = !this.isMask;
				this.$util.setDataMask(this.isMask);
			},
			async changeTab(val) {
				this.clearTimer();
				this.user = await this.$http.getAccount();
				this.list = null;
				this.curKey = val;
				if (this.curKey === this.$C.KEY_HOLD || this.curKey === this.$C.KEY_RECORD) this.getList();
				if (!this.timer) this.onSetTimeout();
			},

			// onSetTimeout() {
			// 	this.timer = setInterval(() => {
			// 		console.log("setInterval");
			// 		if (this.curKey === this.$C.KEY_HOLD || this.curKey === this.$C.KEY_RECORD) this.getList();
			// 	}, 2000);
			// },
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},

			handleSell(val) {
				this.showConfirm = true;
				this.detail = val;
			},
			cancel() {
				this.showConfirm = false;
				this.detail = null;
			},

			async confirm(val) {
				uni.showLoading({
					title: this.$msg.API_SUBMITING,
				});
				const result = await this.$http.post(`api/user/sell`, {
					id: this.detail.id,
				});
				if (!result) return false;
				uni.showToast({
					icon: 'success'
				});
				setTimeout(() => {
					this.cancel();
					this.changeTab(this.curKey);
				}, 1000)
			},
			chongzhi(){
				uni.navigateTo({
					url:'/pages/settings/deposit'
				})
			},
			tikuan(){
				uni.navigateTo({
					url:'/pages/settings/withdraw'
				})
			},

			async getList() {
				// uni.showLoading({
				// 	title: this.$msg.API_REQUEST_DATA,
				// });
				const result = await this.$http.post(`api/user/order`, {
					// page: this.curPage,
					status: this.curKey === this.$C.KEY_HOLD ? 1 : 2, // 1持仓，2历史
					gp_index: 0,
				});
				if (!result) return false;
				console.log(`result:`, result);
				const temp = !result || result.length <= 0 ? [] : result;
				let tempList = [];
				if (this.curKey == this.$C.KEY_HOLD) {
					tempList = !temp || temp.length <= 0 ? [] :
						temp.filter(v => v.goods_info && v.order_buy && v.order_buy.id > 0);
				} else {
					tempList = !temp || temp.length <= 0 ? [] :
						temp.filter(v => v.goods_info && v.order_buy && v.order_buy.id > 0 && v.order_sell && v.order_sell.id > 0);
				}
				// const filterList = tempList.length <= 0 ? [] : tempList.filter(v => !ids.includes(v.id));
				// console.log(filterList);
				// 格式化所需数据
				this.list = tempList.map(v => {
					const type = v.goods_info.project_type_id;
					// const curcode = type == 1 ? v.goods_info.ncode : v.goods_info.bcode;
					const curcode = v.goods_info.code || '';
					const buyPrice = v.order_buy.price * 1 || 0;
					const buyPL = v.order_buy.yingkui * 1 || 0;
					const sellPrice = v.status == 1 ? 0 : (v.order_sell.price * 1 || 0);
					const sellPL = v.status == 1 ? 0 : (v.order_sell.yingkui * 1 || 0);
					const curPrice = v.goods_info.current_price * 1 || 0;
					const buyNum = v.order_buy.num * 1 || 0;
					return {
						id: v.id,
						status: v.status,
						project_type_id: v.goods_info.project_type_id,
						name: v.goods_info.name || '',
						curcode,
						numCode: v.goods_info.number_code || '',
						type: type,
						buyNum: v.order_buy.num * 1 || 0,
						buyPrice,
						curPrice,
						sellPrice,
						buyFee: v.order_buy.buy_fee * 1 || 0,
						sellFee: v.status == 1 ? '' : (v.order_sell.sell_fee * 1 || 0),
						buyAmount: v.order_buy.amount * 1 || 0,
						buyFloatPL: v.order_buy.float_yingkui * 1 || 0,
						sellFloatPL: v.status == 1 ? 0 : (v.order_sell.float_yingkui * 1 || 0),
						buyPLRate: this.$fmt.numer((curPrice - buyPrice) / buyPrice * 100, this.$rate) * 1,
						sellPLRate: v.status == 1 ? '' : this.$fmt.numer((sellPrice - buyPrice) / buyPrice *
							100, this.$rate) * 1,
						buyTotal: this.$fmt.numer(curPrice * buyNum, this.$decimal) * 1,
						sellTotal: this.$fmt.numer(sellPrice * buyNum, this.$decimal) * 1,
						double: v.order_buy.double || 1,
						// 1买 2卖
						plAmount: v.status == 1 ? buyPL : sellPL,
						buyDT: v.order_buy.created_at || '',
						sellDT: v.status == 1 ? '' : (v.order_sell.created_at || ''),
						sn: v.order_sn || '',
						lgre: this.$C.LGRE[type],
					}
				});
				console.log(this.list);
			},
		}
	}
</script>

<style scoped>
.background-container {
  width: 100%;
  height: 150px;
  background-image: url('/static/chic_bgm.png');
  background-size: cover;
  background-position: center;
  position: relative;
}

.overlay-text {
  position: relative;
  top: 55%;
  left: 57%;
  transform: translate(-50%, -50%);
  /* color: white; */
  /* font-size: 24px; */
  /* font-weight: bold; */
}
</style>