<template>
	<view class="bg_page_conver" 
		style="display: flex;flex-direction: column;background: linear-gradient(to bottom, #fff,#cadeff, #cadeff,#fbfcff);min-height: 100vh;">
		<view style="padding:60px 0 0 0;text-align: center;">
			<image :src="`/static/logo.png`" mode="widthFix" style="width: 120px;height: 120px;"></image>
		</view>

		<view class="sign_form">
			<!-- <view class="sign_lgre" @tap="openLgre()">
				<text class="sign_lgre_text"> {{curLang}}</text>
			</view> -->
			<view class="sign_title" style="color: #015cb3;font-size: 20px;">RBC컴퍼니</view>

			<!-- <template v-if="isPwdSign"> -->
			<view style="background-color: #e9f2ff;border-radius: 10px;">
			<view style="display: flex;">
				<view style="background-color: #015cb3;color: #fff;padding: 8px;border-radius: 10px 0px 0px 0px;width: 50%;text-align: center;">{{$msg.SIGN_TITLE_IN}}</view>
				<view style="background-color: #fff;color: #000;padding: 8px;border-radius: 0px 10px 0px 0px;width: 50%;text-align: center;" @tap="linkSignUp()">회원가입</view>
			</view>
			
			<view style="padding: 20px;">
			<view class="form_input" style="margin-bottom: 20px;border-radius: 5px;">
				<image src="/static/sign_user.png" mode="aspectFit"></image>
				<input v-model="user" type="text" placeholder="전화번호 입력" placeholder-class="placeholder"></input>
				<template v-if="user && user.length > 0">
					<image src="/static/del.svg" mode="aspectFit" @tap="user=''" style="cursor: pointer;"></image>
				</template>
			</view>
			<view class="form_input" style="border-radius: 5px;">
				<image src="/static/sign_pwd.png" mode="aspectFit"></image>
				<input v-model="password" :password="isMask" placeholder="비밀번호 입력"
					placeholder-class="placeholder"></input>
				<image :src="`/static/mask_${isMask?`hide`:`show`}.svg`" mode="aspectFit" @tap="toggleMask()"
					style="cursor: pointer;">
				</image>
			</view>
			<view class="forgot_pwd" style="margin-top: 10px;" @tap="$linkTo.service()">
				{{$msg.SIGN_FORGOT}}
			</view>
			<view style="width: 100%;margin:21.5px auto;">
				<BtnLock :isDisabled="islock" @tap="handleSubmit" className="btn_submit " style="border-radius: 5px;">
					<text>{{$msg.SIGN_TITLE_IN}}</text>
				</BtnLock>
			</view>
			</view>
			</view>

			<!-- <view class="flex_row_center">
				<view style="padding-right: 20px;">
					{{$msg.SIGN_ACCOUNT_NO}}
				</view>
				<view @tap="linkSignUp()" style="cursor: pointer;" :style="{color:$theme.getColor($theme.PRIMARY)}">
					{{$msg.SIGN_NOW_UP}}
				</view>
			</view> -->
		</view>

		<!-- <template v-if="showLang">
			<u-picker :show="showLang" :columns="[lgres]" @change="chooseLgre" @cancel="showLang=false" @confirm="confirmLgre"
				:cancelText="$msg.COMMON_CANCEL" :confirmText="$msg.COMMON_CONFIRM"
				:cancelColor="$theme.getColor($theme.CANCEL)" :confirmColor="$theme.getColor($theme.PRIMARY)" keyName="lang"
				visibleItemCount="9"></u-picker>
		</template> -->
	</view>
</template>

<script>
	// import {
	// 	lgre,
	// 	getLang,
	// 	setLgre
	// } from '@/localize/index.js';
	export default {
		data() {
			return {
				isAnimat: false,
				isMask: null,
				tag: '',
				user: '',
				password: '',
				// verCode: '',
				islock: false,
				// showLang: false,
				// isPwdSign: true,
				// isGetting: false,
				// seconds: 120,
				// secondsInterval: null,
			}
		},
		computed: {
			// curLang() {
			// 	// console.log(getLang());
			// 	return getLang();
			// },
			// lgres() {
			// 	return Object.values(lgre)
			// },
		},
		onShow() {
			this.isAnimat = true;
			this.isMask = uni.getStorageSync('masking');
			this.user = uni.getStorageSync('user');
			this.password = uni.getStorageSync('pwd');
			// this.isGetting = false;
			// this.secondsInterval = null;
		},
		onHide() {
			this.isAnimat = false;
			uni.setStorageSync('user', this.user);
			uni.setStorageSync('pwd', this.password);
			// clearInterval(this.secondsInterval);
		},
		methods: {
			toggleMask() {
				this.isMask = !this.isMask;
				this.$util.setDataMask(this.isMask);
			},
			// async getVCode() {
			// 	// send get code api ,and if success
			// 	// const result = await this.$http.getVerCode();
			// 	// if (!result) return false;
			// 	this.isGetting = true;
			// 	this.secondsInterval = setInterval(() => {
			// 		this.seconds = this.seconds - 1
			// 		if (this.seconds == 0) {
			// 			clearInterval(this.secondsInterval)
			// 			this.isGetting = false;
			// 			this.seconds = 120;
			// 		}
			// 	}, 1000);
			// },

			linkSignUp() {
				uni.setStorageSync('user', this.user);
				uni.setStorageSync('pwd', this.password);
				this.$linkTo.signup();
			},

			linkHome() {
				uni.setStorageSync('user', this.user);
				uni.setStorageSync('pwd', this.password);
				this.$linkTo.home();
			},

			// openLgre() {
			// 	this.showLang = true;
			// },
			// chooseLgre(e) {
			// 	// console.log(`changeMode e:`, e);
			// },
			// confirmLgre(e) {
			// 	// console.log(`confirmMode e:`, e);
			// 	this.showLang = false;
			// 	setLgre(e.value[0].code);
			// 	this.$forceUpdate();
			// 	window.location.reload();
			// },

			async handleSubmit() {
				if (!this.$util.checkField(this.user,
						this.$msg.P_SIGN_ACCOUNT)) return false;
				if (!this.$util.checkField(this.password,
						this.$msg.P_SIGN_PWD)) return false;

				this.islock = true;
				uni.showLoading({
					title: this.$msg.API_SUBMITING,
				});
				const result = await this.$http.post(`api/app/login`, {
					username: this.user.trim(),
					password: this.password.trim(),
					// verCode: this.verCode.trim(),
				});
				// console.log('result:', result);
				if (!result) {
					this.islock = false;
					return false;
				}
				const token = result.token.access_token || '';
				uni.setStorageSync('token', token);
				uni.setStorageSync('user', this.user);
				uni.setStorageSync('pwd', this.password);
				uni.showToast({
					title: this.$msg.API_SUCCESS_SIGNIN,
					icon: 'success'
				});
				// clearInterval(this.secondsInterval);
				setTimeout(() => {
					this.$linkTo.home();
					this.islock = false;
				}, 1000);
			},
		}
	}
</script>