<template>
	<view>
		<block v-for="(v,k) in list" :key="k">
			<view class="record_item record_table">
				<view style="text-align: right;" :style="{color:$theme.getColor($theme.PRIMARY)}">
					{{v.currency}}
				</view>
				<view class="record_tr">
					<view>{{$msg.CONVERT_FROM_AMOUNT}}</view>
					<view >
						{{$fmt.amount(v.money,$fmt.setLgre(v.fromLgre))}}
					</view>
				</view>
				<view class="record_tr">
					<view>{{$msg.CONVERT_MONEY}}</view>
					<view >
						{{$fmt.amount(v.toAmount,$fmt.setLgre(v.toLgre))}}
					</view>
				</view>
				<view class="record_tr">
					<view>{{$msg.CONVERT_DT}}</view>
					<view style="color: #121212;">{{v.dt}}</view>
				</view>
				<view class="record_tr">
					<view>{{$msg.CONVERT_SN}}</view>
					<view style="color: #121212;">{{v.sn}}</view>
				</view>
				<view class="record_tr">
					<view>{{$msg.CONVERT_DESC}}</view>
					<view style="color: #121212;">{{v.desc}}</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "FundsConvert",
		props: {
			list: {
				type: Array,
				default: []
			}
		},
	}
</script>

<style>
</style>