<template>
	<!-- <view :class="isAnimat?'fade_in':'fade_out'" > -->
		<view>
		<header class="common_header flex_row_between">
			<view class="" style="font-size: 20px;font-weight: 600;">{{$msg.MENU_ACCOUNT}}</view>
			<view>
				<image src="/static/kefu.png" mode="heightFix" :style="$theme.setImageSize(22)"
					style="cursor: pointer;margin-right: 20px;" @tap="$linkTo.service()">
				</image>
				<image src="/static/xiaoxi.png" mode="heightFix" :style="$theme.setImageSize(22)"
					style="cursor: pointer;margin-left: auto;" @tap="$linkTo.notify()">
				</image>
			</view>

		</header>

		<view class="left_in">
			<view style="display: flex;align-items: center;padding:12px 18px;" @tap="$linkTo.profile()">
				<image :src='!user||!user.avatar?`/static/avatar.png`:$util.setLogo(user.avatar)' mode="scaleToFill"
					:style="$theme.setImageSize(72)" style="border-radius: 100%;"></image>
				<view style="flex:1;color: #FFF;">
					<view
						style="padding-left: 12px;font-size: 15px;font-weight: 700;text-transform:uppercase;color: #333333;">
						{{!user?'': user.nick_name}}
					</view>
					<view style="padding-left: 12px;padding-top: 12px;color: #999999;">{{!user?'':user.mobile}}</view>
				</view>
				<image src="/static/arrow_right_line.svg" mode="aspectFit" :style="$theme.setImageSize(12)"
					style="cursor: pointer;margin-left: auto;">
			</view>

			<!-- <template v-if="assets">
				<AssetsCard :info="assets" />
			</template> -->
			<template>
				<view style="padding:0px 20px;margin-top: -10px;">
					<view class="background-container">
						<view class="overlay-text">
							<view style="display: flex;">
								<view style="color: #265bb3;font-weight: 900;font-size: 16px;">내 자산</view>
								<image :src="`/static/mask_${isMask?`hide`:`show`}.png`" mode="aspectFit"
									:style="$theme.setImageSize(20)" @tap="toggleMask()"
									style="cursor: pointer;margin-left: 10px;"></image>

								<view
									style="margin-left: auto;background-color: #fff;padding: 3px;border-radius: 5px;font-size: 12px;" @tap="$linkTo.funds()">
									세부사항</view>
							</view>

							<view style="color: #265bb3;font-size: 22px;margin-top: 10px;font-weight: 900;">
								{{isMask?hideData:$fmt.amount(assets.balance) }}</view>

						</view>
						<view class="overlay-textjy">
							<view class="flex">
							  <view style="color: #265bb3;font-size: 14px;">USDT</view>
							   <view style="margin-left: 10px;color: #265bb3;font-size: 16px;font-weight: 500;">{{isMask?hideData:$fmt.amount(assets.usd) }}</view>
							</view>
							<view  style="margin-top: 15px;line-height: 1.5;display: flex;">
								<view style="flex: 50%;">
									<view style="color: #265bb3;">총 수입</view>
									<view style="font-weight: 500;color: #265bb3;">{{isMask?hideData:$fmt.amount(assets.holdPL) }}</view>
								</view>
								<view style="flex: 30%;">
									<view style="color: #265bb3;">{{$msg.ASSETS_FROZEN}}</view>
									<view style="font-weight: 500;color: #265bb3;">{{isMask?hideData:$fmt.amount(assets.frozen) }}</view>
								</view>

							</view>
						</view>
					</view>
				</view>
			</template>
			
			<!-- <view class="" style="padding: 20px 20px;display: flex;gap: 15px;justify-content: center;">
				<view style="background-color: #265bb3;color: #fff;padding: 10px;width: 35%;text-align: center;border-radius: 5px;" @tap="$linkTo.deposit()">입금정보</view>
				<view style="background-color: #f3f4f6;color: #265bb3;padding: 10px;width: 35%;text-align: center;border-radius: 5px;" @tap="$linkTo.withdraw()">출금신청</view>
			</view> -->
			
			<view class="flex_row_between" style="padding: 20px 40px;">
				<view style="text-align: center;" @tap="$linkTo.service()">
					<image src="/static/qb_maibi.png" mode="widthFix" style="width: 45px;height: 45px;"></image>
					<view>입금</view>
				</view>
				<view style="text-align: center;" @tap="$linkTo.withdraw()">
					<image src="/static/qb_tibi.png" mode="widthFix" style="width: 45px;height: 45px;"></image>
					<view>출금</view>
				</view>
				<view style="text-align: center;" @tap="$linkTo.convert()">
					<image src="/static/qb_duihuan.png" mode="widthFix" style="width: 45px;height: 45px;"></image>
					<view>환전</view>
				</view>
			</view>
			
			<view style="text-align: center;">
				<image src="/static/wd_bgm.png" widthfix="heightFix" style="width: 100%;height: 100px;">
				</image>
			</view>

			<view style="padding:20px;background-color: #FFFFFF;border-radius: 20px 20px 0 0;min-height: 60vh;">
				<!-- <view @tap="openLgre()"
					style="display: flex;align-items: center;border-bottom: 0.5px solid #C0C0C03A;line-height: 2.4;">
					<view style="width: 6px;height: 6px;background-color: #659FFB;border-radius: 100%;"></view>
					<view style="padding-left: 12px;color: #6D6D6D;flex:1;">{{$t($msg.LGRE_TITLE)}}</view>
					<view style="font-size: 14px;font-weight: 500;" :style="{color:$theme.PRIMARY}">
						{{curLang}}
					</view>
				</view> -->

				<block v-for="(v,k) in features" :key="k">
					<view @tap="v.action"
						style="display: flex;align-items: center;border-bottom: 0.5px solid #C0C0C03A;line-height: 4.5;font-size: 13px;"
						:style="{borderBottom:`${k<features.length-1?`0.5`:`0`} solid #C0C0C03A`}">
						<!-- <view style="width: 6px;height: 6px;background-color: #659FFB;border-radius: 100%;"></view> -->
						<image mode="aspectFit" :src="`/static/set_${v.icon}.png`" :style="$theme.setImageSize(30)">
						</image>
						<view style="padding-left: 12px;flex:1;font-weight: 900;">{{v.name}}</view>
						<template v-if="v.key ===$C.KEY_AUTH">
							<view style="font-size: 12px;padding-right: 12px;"
								:style="{color:$theme.getColor([$theme.ERROR, $theme.SUCCESS][!user?-1: user.is_check])}">
								{{setAuth(!user?-1: user.is_check)}}
							</view>
						</template>
						<image src="/static/arrow_right_line.svg" mode="aspectFit" :style="$theme.setImageSize(12)">
						</image>
					</view>
				</block>
				<view
					style="text-align: center;line-height: 3;width: 90%;margin: 20px auto;font-weight: 500;font-size: 16px;border-radius: 5px;"
					:style="{backgroundColor:$theme.getColor($theme.PRIMARY_RGBA)}" @tap="$util.signOut()">
					{{$msg.SIGN_OUT}}
				</view>
				<view style="padding: 30px;"></view>
			</view>
		</view>

		<FooterSmall :actKey="$C.KEY_ACCOUNT"></FooterSmall>

		<!-- <u-picker :show="showLang" :columns="[lgres]" @change="chooseLgre" @cancel="showLang=false"
			@confirm="confirmLgre" :cancelText="$t($msg.COMMON_CANCEL)" :confirmText="$t($msg.COMMON_CONFIRM)"
			:cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY" keyName="lang"
			visibleItemCount="9"></u-picker> -->
	</view>
</template>

<script>
	import * as ext from './ext.js';
	// import {
	// 	lgre,
	// 	getLang,
	// 	setLgre
	// } from '@/localize/index.js';
	export default {
		data() {
			return {
				isAnimat: false, // 页面动画
				user: null,
				features: ext.features(),
				userAssets: null,
				isMask: null, // 是否掩码
				hideData: `*****`,
			}
		},
		beforeMount() {
			this.isMask = uni.getStorageSync('masking');
		},
		computed: {
			assets() {
				if (!this.user) return null;
				return {
					total: this.user.totalZichan * 1 || 0,
					usd: this.user.usd * 1 || 0,
					balance: this.user.money * 1 || 0,
					frozen: this.user.frozen * 1 || 0,
					totalPL: this.user.totalYingli * 1 || 0,
					holdPL: this.user.holdYingli * 1 || 0,
				}
			},
			// curLang() {
			// 	console.log(getLang());
			// 	return getLang();
			// },
			// lgres() {
			// 	return Object.values(lgre)
			// },
		},
		async onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.user = await this.$http.getAccount();
			// console.log(lgre)
		},
		onHide() {
			this.isAnimat = false;
		},
		async onPullDownRefresh() {
			this.user = await this.$http.getAccount();
			uni.stopPullDownRefresh();
		},
		methods: {
			setAuth(val) {
				const temp = val == 1 ? 0 : -1;
				return this.$msg.AUTH_STATUS[temp + 1];
			},
			toggleMask() {
				this.isMask = !this.isMask;
				this.$util.setDataMask(this.isMask);
			},
			// async getAccount() {
			// 	const result = await this.$http.getAccount();
			// 	this.user = {
			// 		avatar: result.avatar || null,
			// 		mobile: result.mobile || '',
			// 		name: result.nick_name || '',
			// 		isCheck: result.is_check || -1,
			// 	}
			// 	this.userAssets = {
			// 		totalZichan: result.totalZichan,
			// 		money: result.money,
			// 		floatPL: result.holdYingli,
			// 	}
			// },
			// openLgre() {
			// 	this.showLang = true;
			// },
			// chooseLgre(e) {
			// 	console.log(`changeMode e:`, e);
			// },
			// confirmLgre(e) {
			// 	console.log(`confirmMode e:`, e);
			// 	this.showLang = false;
			// 	setLgre(e.value[0].code);
			// 	this.$forceUpdate();
			// 	window.location.reload();
			// },
		}
	}
</script>

<style scoped>
	.background-container {
		width: 100%;
		height: 220px;
		background-image: url('/static/wd_bg.png');
		background-size: cover;
		background-position: center;
		position: relative;
	}

	.overlay-text {
		position: absolute;
		top: 35%;
		width: 80%;
		left: 45%;
		transform: translate(-50%, -50%);
		/* color: white; */
		/* font-size: 24px; */
		/* font-weight: bold; */
	}

	.overlay-textjy {
		position: absolute;
		top: 70%;
		width: 68%;
		left: 39%;
		transform: translate(-50%, -50%);
		/* color: white; */
		/* font-size: 24px; */
		/* font-weight: bold; */
	}
</style>