<script>
	export default {
		onLaunch: async function() {
			console.log('App Launch');
			uni.hideTabBar();
		},
		onShow: function() {
			console.log('App Show');
			uni.hideTabBar();
		},
		onHide: function() {
			console.log('App Hide');
			uni.hideTabBar();
		}
	}
</script>

<style lang="scss">
	@import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100..900;1,100..900&display=swap');
	@import "@/node_modules/uview-ui/index.scss";
	@import "@/common/css/animate.css";
	@import "@/common/css/style.css";


	// @media screen and (max-device-width:375px) {
	// 	page {
	// 		width: 100vw;
	// 	}
	// }

	// @media screen and (min-device-width:376px) and (max-device-width:750px) {
	// 	page {
	// 		width: 100vw;
	// 		margin: 0 auto;
	// 	}
	// }

	// @media screen and (min-device-width:751px) {
	// 	page {
	// 		width: 750px;
	// 		margin: 0 auto;
	// 	}
	// }

	* {
		font-family: "Roboto", Arial, sans-serif;
		font-optical-sizing: auto;
		font-style: normal;
		box-sizing: border-box;
	}

	body {
		background-color: #121212;
	}
</style>