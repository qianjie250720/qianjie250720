<template>
	<view class="assets_card" :style="{color:$theme.getColor($theme.WHITE),}">
		<view style="display: flex;align-items: center;gap:6px;">
			<text style="font-size: 14px;">{{$msg.ASSETS_TOTAL}}</text>
			<image :src="`/static/mask_${isMask?`hide`:`show`}.svg`" mode="aspectFit" :style="$theme.setImageSize(16)"
				@tap="toggleMask()" style="cursor: pointer;"></image>
			<view class="assets_card_btn" style="cursor: pointer;" @tap="$linkTo.funds()">{{$msg.ASSETS_DETAIL}}</view>
		</view>

		<view style="padding-bottom: 8px;">
			<view style="font-size: 28px;font-weight: 600;">
				{{isMask?hideData:$fmt.amount(info.total) }}
			</view>
			<template v-if="info.usd">
				<view style="font-size: 20px;font-weight: 600;">
					{{isMask?hideData:$fmt.amount(info.usd, $fmt.code.KEY_US,$fmt.code.KEY_US,$fmt.NEVER) }}
				</view>
			</template>
		</view>

		<view class="flex_row_between" style="gap:8px;padding-top:8px;border-top: 0.5px solid #bac2ee;">
			<view style="flex:1;">
				<view style="padding-bottom: 8px;">{{$msg.ASSETS_BALANCE}}</view>
				<view style="font-size: 15px;">{{isMask?hideData:$fmt.amount(info.balance) }}</view>
			</view>
			<template v-if="info && info.frozen">
				<view style="text-align: right;flex:1;">
					<view style="padding-bottom: 8px;">{{$msg.ASSETS_FROZEN}}</view>
					<view style="font-size: 15px;">{{isMask?hideData:$fmt.amount(info.frozen) }}</view>
				</view>
			</template>
		</view>
		<template v-if="info && info.totalPL">
			<view class="flex_row_between" style="gap:8px;padding-top: 8px;border-top: 0.5px solid #bac2ee;">
				<template v-if="info && info.totalPL">
					<view style="flex:1;">
						<view>{{$msg.ASSETS_HOLD_PL}}</view>
						<view style="font-size: 15px;"> {{isMask?hideData:$fmt.amount(info.totalPL) }} </view>
					</view>
				</template>
				<template v-if="info && info.holdPL">
					<view style="text-align: right;flex:1;">
						<view>{{$msg.ASSETS_TOTAL_PL}}</view>
						<view style="font-size: 15px;"> {{isMask?hideData:$fmt.amount(info.holdPL) }} </view>
					</view>
				</template>
			</view>
		</template>
	</view>
</template>

<script>
	export default {
		name: "AssetsCard",
		props: {
			info: {
				type: Object,
				default: {}
			}
		},
		data() {
			return {
				isMask: null, // 是否掩码
				hideData: `*****`,
			};
		},
		beforeMount() {
			this.isMask = uni.getStorageSync('masking');
		},
		methods: {
			// masking 开关
			toggleMask() {
				this.isMask = !this.isMask;
				this.$util.setDataMask(this.isMask);
			},
		}
	}
</script>

<style>

</style>