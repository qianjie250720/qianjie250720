<template>
	<view @tap="handleClick" :class="[{'btn_lock':isDisabled},className]" :style="{backgroundColor:setBGColor}">
		<slot></slot>
	</view>
</template>

<script>
	export default {
		name: "BtnLock",
		props: {
			isDisabled: {
				type: Boolean,
				default: false
			},
			className: {
				type: String,
				default: ''
			},
			bgColor: {
				type: String,
				default: ''
			}
		},
		computed: {
			setBGColor() {
				return this.bgColor == '' ? this.$theme.getColor(this.$theme.PRIMARY) : this.bgColor;
			}
		},
		methods: {
			handleClick() {
				if (!this.isDisabled) {
					this.$emit('click');
				} else {
					uni.showToast({
						title: this.$msg.TIP_BTN,
						icon: 'fail'
					});
				}
			}
		}
	}
</script>