<template>
	<view>
		<view class="overlay" @tap="cancel()"></view>
		<view class="modal_wrapper_center" style="background-color: #FFF;width: 90%;">
			<header class="header_wrapper">
				<view class="title">{{title}}</view>
			</header>
			<view class="body_wrapper">
				<slot></slot>
			</view>
			<view class="line_h"></view>
			<footer class="footer_wrapper">
				<view class="cancel" @tap="cancel()">{{setCancel}}</view>
				<view class="line_v"></view>
				<view class="confirm" @tap="confirm()">{{setConfirm}}</view>
			</footer>
		</view>
	</view>
</template>

<script>
	export default {
		name: "CommonConfirm",
		props: {
			title: {
				type: String,
				default: ''
			},
			cancelText: {
				type: String,
				default: ''
			},
			confirmText: {
				type: String,
				default: ''
			},
		},
		data() {
			return {};
		},
		computed: {
			setCancel() {
				return this.cancelText == '' ? this.$msg.COMMON_CANCEL : this.cancelText;
			},
			setConfirm() {
				return this.confirmText == '' ? this.$msg.COMMON_CONFIRM : this.confirmText;
			}
		},

		methods: {
			cancel() {
				this.$emit('cancel', '');
			},
			confirm() {
				this.$emit('confirm', '');
			}
		}
	}
</script>

<style lang="scss" scoped>
	.overlay {
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		z-index: 5;
		background-color: rgba(0, 0, 0, 0.8);
	}

	.modal_wrapper_center {
		position: fixed;
		top: 50%;
		left: 50%;
		transform: translate(-50%, -50%);
		z-index: 15;
		width: 90%;
		max-width: 700px;
		margin: 0 auto;
		border-radius: 6px;
	}

	.header_wrapper {
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 20px 20px 0 20px;
	}

	.header_wrapper>.title {
		flex: 1;
		font-size: 18px;
		font-weight: 400;
		text-align: center;
		word-break: break-word;
	}

	.body_wrapper {
		padding: 20px;
	}

	.footer_wrapper {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 12px;
		width: 100%;
		height: 48px;
	}

	.footer_wrapper>.cancel,
	.footer_wrapper>.confirm {
		flex: 1;
		text-align: center;
		cursor: pointer;
		font-weight: 500;
		font-size: 16px;
	}

	.footer_wrapper>.confirm {
		color: var(--primary);
	}

	.footer_wrapper>.line {
		color: var(--cancel);
	}
</style>