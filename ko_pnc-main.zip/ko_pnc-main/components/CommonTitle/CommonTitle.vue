<template>
	<view class="common_title" :style="{paddingTop:`${ptop}px`}">
		<view style="flex:1;font-size: 16px;font-weight:500;" :style="{color:color}">{{title}}</view>
		<slot></slot>
	</view>
</template>

<script>
	export default {
		name: "CommonTitle",
		props: {
			title: {
				type: String,
				required: true
			},
			color: {
				type: String,
				default: `#000000`
			},
			ptop: {
				type: Number,
				default: 24,
			}
		}
	}
</script>

<style>

</style>