<template>
	<view class="card_item" style="cursor: pointer;" @tap="linkTo(detail)">
		<template v-if="detail.name">
			<header class="card_item_header ellipsis" :style="{backgroundColor:$theme.setRiseFall(detail.rate)}">
				{{detail.name}}
			</header>
		</template>
		<!-- <template v-if="detail.code">
			<header class="card_item_header ellipsis" :style="{backgroundColor:$theme.setRiseFall(detail.rate)}">
				<view class="ellipsis">{{detail.name}}</view>
				<view style="font-size: 12px;padding-top: 4px;">{{detail.code}}</view>
			</header>
		</template> -->

		<template v-if="detail.price">
			<view style="text-align: center;padding-top: 10px;font-weight: 700;font-size: 14px;"
				:style="{color:$theme.setRiseFall(detail.rate),backgroundColor:$theme.setRiseFallRGBA(detail.rate)}">
				{{detail.price}}
			</view>
		</template>

		<!-- 	<template v-if="detail.price">
			<view style="text-align: center;padding-top: 10px;font-weight: 700;font-size: 14px;"
				:style="{color:$theme.setRiseFall(detail.rate),backgroundColor:$theme.setRiseFallRGBA(detail.rate)}">
				{{$fmt.amount(detail.price)}}
			</view>
		</template> -->

		<!-- <template v-if="detail.subTitle">
			<view style="text-align: center;padding-top: 10px;">
				{{detail.subTitle}}{{$fmt.percent(detail.rate)}}
			</view>
		</template> -->

		<template v-if="detail.rate">
			<view style="text-align: center;padding: 10px 0;font-weight: 700;font-size: 14px;"
				:style="{color:$theme.setRiseFall(detail.rate),backgroundColor:$theme.setRiseFallRGBA(detail.rate)}">
				<!-- <view>{{$fmt.amount(detail.rateNum)}}</view> -->
				<view>{{detail.rate==0?0:$fmt.percent(detail.rate)}}</view>
			</view>
		</template>

		<!-- <template v-if="detail.tip!=''">
			<view style="text-align: center;padding-top: 10px;">
				{{detail.tip}}
			</view>
		</template> -->
		<template v-if="detail.line || show">
			<view style="text-align: center;" :style="{backgroundColor:$theme.setRiseFallRGBA(detail.rate)}">
				<image :src="`/static/line_${detail.rate>0?`rise_red`:`fall_green1`}.png`" mode="scaleToFill"
					:style="$theme.setImageSize(96,40)">
				</image>
			</view>
		</template>
	</view>
</template>

<script>
	export default {
		name: "CardItem",
		props: {
			detail: {
				type: Object,
				default: {}
			},
			show: {
				type: Boolean,
				default: false,
			}
		},
		methods: {
			linkTo(val) {
				this.$emit(`action`, val);
			}
		}
	}
</script>

<style>

</style>