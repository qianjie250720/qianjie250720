<template>
	<view>
		<view class="overlay" @tap="close()"></view>
		<view class="modal_wrapper_bottom bottom_in" style="background-color:#FFF;">
			<header class="header_wrapper">
				<view :style="$theme.setImageSize(16)"></view>
				<view class="title"> {{ title }} </view>
				<image src="/static/close_fff.svg" mode="aspectFit" @tap.top="close()"></image>
			</header>
			<slot></slot>
		</view>
	</view>
</template>

<script>
	export default {
		name: "CommonBuy",
		props: {
			title: {
				type: String,
				default: ''
			},

		},
		data() {
			return {};
		},
		methods: {
			close() {
				this.$emit('close', '');
			}
		}
	}
</script>

<style lang="scss" scoped>
	.overlay {
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		z-index: 5;
		background-color: rgba(0, 0, 0, 0.8);
	}

	.modal_wrapper_bottom {
		position: fixed;
		bottom: 0;
		left: 0;
		right: 0;
		z-index: 13;
		width: 100%;
		max-width: 700px;
		margin: 0 auto;
		border-radius: 6px 6px 0 0;
	}

	.header_wrapper {
		display: flex;
		align-items: center;
		border-bottom: 0.5px solid var(--primary);
		background-color: var(--primary);
		border-radius: 6px 6px 0 0;
		line-height: 2.4;
		padding: 0 12px;
	}

	.header_wrapper>.title {
		flex: 1;
		text-align: center;
		color: var(--white);
		font-size: 18px;
	}

	.header_wrapper image:last-child {
		width: 16px;
		height: 16px;
		margin-left: auto;
		cursor: pointer;
	}
</style>