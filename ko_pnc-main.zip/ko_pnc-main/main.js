import Vue from 'vue';
import App from './App';
import * as constants from '@/common/constants.js';
import * as linkTo from '@/common/linkTo.js';
import * as theme from '@/common/theme.js';
import * as util from '@/common/util.js';
import * as http from '@/common/http.js';
import uView from "@/node_modules/uview-ui";
import * as fmt from '@/intl/index.js';

Vue.use(uView);

Vue.config.productionTip = false;

Vue.prototype.$C = constants; // 常量
Vue.prototype.$linkTo = linkTo; // 跳转
Vue.prototype.$util = util; // 工具类
Vue.prototype.$http = http; // http api
Vue.prototype.$fmt = fmt; // 格式化
Vue.prototype.$msg = null;
Vue.prototype.$theme = theme;
// 全局设置金额小数点保留位数
Vue.prototype.$decimal = 4;
// 全局设置率值小数点保留位数
Vue.prototype.$rate = 2;
// 全局设置，是否显示正负号
Vue.prototype.$symbol = true;
// // 默认的代码，用于部分金额格式化的依据
Vue.prototype.$DEF_LGRE = 'ko-KR';

App.mpType = 'app'
const app = new Vue({
	...App
})
app.$mount()

// 初始化设置
util.initialize();

// 白名单 将无需用户登录也可查看的页面写在这里。默认是启动页、登录页、隐私协议
const whiteList = [
	linkTo.PAGES + linkTo.LAUNCH,
	linkTo.PAGES + linkTo.SIGN_IN,
	linkTo.PAGES + linkTo.SIGN_UP,
	// linkTo.PAGES + linkTo.TERMS,
	// linkTo.PAGES + linkTo.HOME,
];
// uniapp 跳转行为
const list = ["navigateTo", "reLaunch", "switchTab"]
// 目标url是否需要权限
function hasPermission(url) {
	console.log(url);
	// console.log(uni.getStorageSync("token"));
	return (whiteList.indexOf(url) !== -1 || uni.getStorageSync("token").length > 0);
}

list.forEach((item) => {
	// 路由拦截
	uni.addInterceptor(item, {
		// 页面跳转前进行拦截, invoke根据返回值进行判断是否继续执行跳转
		invoke(e) {
			if (!hasPermission(e.url)) {
				// 将用户的目标路径保存下来 这样可以实现 用户登录之后，直接跳转到目标页面
				// uni.setStorageSync("URL", e.url)
				linkTo.signin();
				return false;
			}
			return true;
		}
	});
})