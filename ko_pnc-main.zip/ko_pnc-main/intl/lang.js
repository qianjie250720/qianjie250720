import * as keys from '@/intl/keys.js';

export const LANG = Object.create(null);
LANG[keys.KEY_US] = 'English';
LANG[keys.KEY_IN] = 'English';
LANG[keys.KEY_TR] = 'Türkçe';
LANG[keys.KEY_DE] = 'Deutsch';
LANG[keys.KEY_FR] = 'Français';
LANG[keys.KEY_IT] = 'Italiano';
LANG[keys.KEY_JP] = '日本語';
LANG[keys.KEY_TH] = 'ไทย';
LANG[keys.KEY_PT] = 'Português';
LANG[keys.KEY_ES] = 'Español';
LANG[keys.KEY_KR] = '한국의';
LANG[keys.KEY_IL] = "العربية";
LANG[keys.KEY_VN] = 'tiếng việt';
LANG[keys.KEY_RU] = 'Русский';
LANG[keys.KEY_TW] = '台湾繁体';
LANG[keys.KEY_CN] = '中文简体';