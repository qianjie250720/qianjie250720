<template>
	<view class="bg_page_conver" 
		style="display: flex;flex-direction: column;background: linear-gradient(to bottom, #fff,#cadeff, #cadeff,#fbfcff);min-height: 100vh;">
		<view style="padding:60px 0 0 0;text-align: center;">
			<image :src="`/static/logo.png`" mode="widthFix" style="width: 120px;height: 120px;"></image>
		</view>

		<view class="sign_form">
		<view class="sign_title" style="color: #015cb3;font-size: 20px;">PNC파이낸셜</view>
			
			<view style="background-color: #e9f2ff;border-radius: 10px;">
			<view style="display: flex;">
				<view style="background-color: #fff;color: #000;padding: 8px;border-radius: 10px 0px 0px 0px;width: 50%;text-align: center;" @tap="$linkTo.signin()">{{$msg.SIGN_TITLE_IN}}</view>
				<view style="background-color: #015cb3;color: #fff;padding: 8px;border-radius: 0px 10px 0px 0px;width: 50%;text-align: center;">회원가입</view>
			</view>
			
			<view style="padding: 20px;">
			<view class="form_input" style="margin-bottom: 24px;border-radius: 5px;">
				<image src="/static/sign_user.png" mode="aspectFit"></image>
				<input v-model="user" type="text" placeholder="전화번호 입력" placeholder-class="placeholder"></input>
				<template v-if="user && user.length > 0">
					<image src="/static/del.svg" mode="aspectFit" @tap="user=''" style="cursor: pointer;"></image>
				</template>
			</view>

			<view class="form_input" style="margin-bottom:24px;border-radius: 5px;">
				<image src="/static/sign_pwd.png" mode="aspectFit"></image>
				<input v-model="password" :password="isMask" placeholder="비밀번호 입력"
					placeholder-class="placeholder"></input>
				<image :src="`/static/mask_${isMask?`hide`:`show`}.svg`" mode="aspectFit" @tap="toggleMask()"
					style="cursor: pointer;"></image>
			</view>

			<view class="form_input" style="margin-bottom:24px;border-radius: 5px;">
				<image src="/static/sign_pwd.png" mode="aspectFit"></image>
				<input v-model="verifyPassword" :password="isMask" placeholder="비밀번호 재입력"
					placeholder-class="placeholder"></input>
				<image :src="`/static/mask_${isMask?`hide`:`show`}.svg`" mode="aspectFit" @tap="toggleMask()"
					style="cursor: pointer;"></image>
			</view>

			<view class="form_input" style="margin-bottom: 24px;border-radius: 5px;">
				<image src="/static/sign_invite.png" mode="aspectFit"></image>
				<input v-model="inviteCode" type="text" placeholder="초대코드 입력"
					placeholder-class="placeholder"></input>
				<template v-if="inviteCode && inviteCode.length > 0">
					<image src="/static/del.svg" mode="aspectFit" @tap="inviteCode=''"></image>
				</template>
			</view>

			<!-- <view style="display: flex;align-items: center;justify-content: center;gap:6px;">
				<image :src="`/static/${isAgree?`check`:'check_un'}.svg`" mode="aspectFit" :style="$theme.setImageSize(20)"
					style="cursor: pointer;" @tap.stop="isAgree=!isAgree">
				</image>
				<text style="margin-left: 8px;font-size: 12px;cursor: pointer;" :style="{color:$theme.getColor($theme.PRIMARY)}"
					@tap.stop="linkTerms()">
					{{$msg.SIGN_AGREE}}
				</text>
			</view> -->

			<view style="width: 100%;margin:15.5px auto;padding-top: 15px;">
				<BtnLock :isDisabled="islock" @tap="handleSubmit" className="btn_submit" style="border-radius: 5px;">
					<text>{{$msg.SIGN_TITLE_UP}}</text>
				</BtnLock>
			</view>
			</view>
			</view>

			<view style="display: flex;align-items: center;justify-content: center;">
				<view style="padding-right: 20px;">
					{{$msg.SIGN_ACCOUNT_HAVE}}
				</view>
				<view @tap="$linkTo.signin()" style="cursor: pointer;" :style="{color:$theme.getColor($theme.PRIMARY)}">
					{{$msg.SIGN_NOW_IN}}
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false, // 页面动画
				isMask: null, // 是否掩码
				tag: '', // url携带tag值
				user: '', // 账号
				password: '', // 密码
				verifyPassword: '', // 确认密码
				inviteCode: '', // 默认为 url 携带code邀请码
				isAgree: false, // 同意隐私协议
				islock: false, // 按钮是否锁定
			}
		},
		onLoad(opt) {
			console.log(opt);
		},
		onShow() {
			this.isAnimat = true;
			this.isMask = uni.getStorageSync('masking');
			this.user = uni.getStorageSync('user');
			this.password = uni.getStorageSync('pwd');
		},
		onHide() {
			this.isAnimat = false;
			uni.setStorageSync('user', this.user);
			uni.setStorageSync('pwd', this.password);
		},
		methods: {
			// masking 开关
			toggleMask() {
				this.isMask = !this.isMask;
				this.$util.setDataMask(this.isMask);
			},

			// 跳转到首页 窄屏 关闭按钮 宽屏点击应用名称
			linkHome() {
				uni.setStorageSync('user', this.user);
				uni.setStorageSync('pwd', this.password);
				this.$linkTo.home();
			},
			linkTerms() {
				uni.setStorageSync('user', this.user);
				uni.setStorageSync('pwd', this.password);
				this.$linkTo.terms();
			},

			async handleSubmit() {
				if (!this.$util.checkField(this.user,
						this.$msg.P_SIGN_ACCOUNT)) return false;
				if (!this.$util.checkField(this.password,
						this.$msg.P_SIGN_PWD)) return false;
				if (!this.$util.checkField(this.verifyPassword,
						this.$msg.SIGN_PWD_CONFIRM)) return false;
				if (!this.$util.checkField(this.inviteCode,
						this.$msg.P_SIGN_INVITATION)) return false;
				if (this.password != this.verifyPassword) {
					uni.showToast({
						title: this.$msg.TIP_PWDDIFF,
						icon: 'none'
					})
					return false;
				}
				// if (this.isAgree != true) {
				// 	uni.showToast({
				// 		title: this.$msg.TIP_CHECK_AGREE,
				// 		icon: 'none'
				// 	})
				// 	return false;
				// }
				this.islock = true;
				uni.showLoading({
					title: this.$msg.API_SUBMITING,
				});
				const result = await this.$http.post(`api/app/register`, {
					mobile: this.user.trim(),
					password: this.password.trim(),
					confirmpass: this.verifyPassword.trim(),
					invite: this.inviteCode.trim(),
					code: 123456,
				});
				console.log('result:', result);
				if (!result) {
					this.islock = false;
					return false;
				}
				uni.showToast({
					title: this.$msg.API_SUCCESS_SIGNUP,
					icon: 'success'
				})
				setTimeout(() => {
					this.islock = false;
					this.$linkTo.signin();
				}, 1000);
			}
		}
	}
</script>

<style>
</style>