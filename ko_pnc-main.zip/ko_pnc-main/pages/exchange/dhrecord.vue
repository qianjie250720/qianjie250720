<template>
	<view :class="isAnimat?'fade_out':'fade_in'">
		<header class="common_header" style="gap:12px;background-color: #275cb3;height: 80px;">
			<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(16)" class="btn_back"
				@tap="$linkTo.goBack()"></image>
			<view class="dynamic_title" style="color: #fff;">환전기록</view>
			<!-- <image src="/static/icon_record.svg" mode="aspectFit" :style="$theme.setImageSize(16)"
				@tap="changeTab($C.KEY_DEPOSIT)"></image> -->
		</header>

		<block v-for="(item,index) in list" :key="index">
			<view style="padding:8px 20px;">
				<view style="border:  1px #ccc solid;border-radius: 10px;padding: 10px;line-height: 2;">
					<view class="flex">
						<view style="flex: 30%;">{{item.type==1 ? "KRW":"USDT"}}: -{{(item.num)}}</view>
						<view class="text-center" style="flex: 10%;">환전</view>
						<view class="text-right" style="flex: 30%;">{{item.leixing}}: +{{(item.newnum)}}</view>
					</view>
					<!-- <view class="flex flex-b">
						<view>余额: 0</view>
						<view>余额: 666</view>
					</view> -->
					<view class="hui1" style="text-align: right;margin-right: 10px;">{{item.huazhuanat}}</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		components: {

		},
		data() {
			return {
				isAnimat: false,
				list: '',

			}
		},
		async onShow() {
			this.getDetail();
		},
		onHide() {
			this.isAnimat = false;
			this.chart = null;
			this.chartData = null;
			this.clearTimer();
			this.getDetail();
		},
		deactivated() {
			this.clearTimer();
		},
		onUnload() {
			this.clearTimer();
			this.getDetail();
		},
		onPullDownRefresh() {
			this.clearTimer();
		},
		methods: {
			async linkTo(val) {
				this.curId = val.gid;
			},

			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
			async getDetail() {
				uni.showLoading({
					title: this.$msg.API_REQUEST_DATA,
				})
				const result = await this.$http.get(`api/zong/huazhuan_log`);
				if (!result) return false;
				// console.log(result);
				this.list = result;
			}

		}
	}
</script>

<style scoped>

</style>