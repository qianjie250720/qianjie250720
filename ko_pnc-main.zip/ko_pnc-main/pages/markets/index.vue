<template>
	<!-- <view :class="isAnimat?'fade_in':'fade_out'" class=""> -->
		<view>
		<header class="common_header" style="background-color: #265bb3;height: 80px;">
			<view class="flex_row_between common_tabs" style="gap:32px;margin-top: 10px;">
				<block v-for="(v,k) in tabs" :key="k">
					<view @tap="changeTab(k)" class="item_zxd" :class="curKey===k?`item_zx`:``">
						{{v}}
					</view>
				</block>
			</view>
			<!-- <image src="/static/search.svg" mode="heightFix" :style="$theme.setImageSize(20)"
				style="cursor: pointer;margin-left: auto;" @tap="$linkTo.search()">
			</image> -->
			<view style="margin-left: auto;margin-top: 20px;">
				<image src="/static/sc_kf.png" mode="heightFix" :style="$theme.setImageSize(20)"
					style="margin-left: auto;margin-right: 20px;" @tap="$linkTo.service()">
				</image>
				<image src="/static/sc_xx.png" mode="heightFix" :style="$theme.setImageSize(20)"
					 @tap="$linkTo.notify()">
				</image>
			</view>
		</header>
		
		<header class="common_head" style="display: flex;align-items: center;padding: 20px 16px 12px 16px;height: auto;">
			<view style="flex:1;padding:0 12px;">
				<view
					style="border-radius: 18px;display: flex;align-items: center;gap: 12px;padding:4px 16px;height: 32px; line-height: 32px;background-color: #c4c4c433;">
					<image src="/static/search.svg" mode="aspectFit" :style="$theme.setImageSize(16)" @tap="handleSearch()">
					</image>
					<input v-model="keyword" type="text" :placeholder="$msg.SEARCH_P_KEY" placeholder-class="placeholder"
						style="flex:1;"></input>
					<template v-if="keyword && keyword.length > 0">
						<image src="/static/del.svg" mode="aspectFit" style="margin-left: auto;cursor: pointer;"
							:style="$theme.setImageSize(16)" @tap="keyword=''"></image>
					</template>
				</view>
			</view>
			<view style="margin-left: auto;">
				<text style="text-align: center;padding:6px 16px;border-radius: 4px;cursor: pointer;"
					:style="{backgroundColor:$theme.getColor($theme.PRIMARY),color:$theme.getColor($theme.WHITE)}"
					@tap="handleSearch()">{{$msg.SEARCH_BTN}}</text>
			</view>
		
		</header>

		<view :class="curIndex%2==0?`left_in`:`right_in`" style="padding:0 18px 60px 18px;">
			<!-- <template v-if="curKey===$C.KEY_STOCK">
				<view class="flex_row_between common_tabs" style="padding:10px 4px;border-radius: 6px;"
					:style="{backgroundColor:$theme.getColor($theme.PRIMARY_RGBA)}">
					<block v-for="(v,k) in tabsStock" :key="k">
						<view @tap="changeTabStock(k)" class="item_sec" :class="curStock===k?`item_sec_act`:``">
							<text>{{v}}</text>
						</view>
					</block>
				</view>
			</template> -->

			<template v-if="curKey===$C.KEY_INDI">
				<!-- <view class="common_tabs" style="display: flex;gap: 30px;">
					<block v-for="(v,k) in $msg.INDI_TABS" :key="k">
						<view @tap="changeTabIndi(k)" class="item_uzi" :class="curIndi===k?`item_po`:``">
							<text>{{v}}</text>
						</view>
					</block>
				</view> -->
			</template>
			<template v-if="curKey===$C.KEY_RANK">
				<view style="padding:10px 0px;border-radius: 6px;">
					<scroll-view :scroll-x="true" style="white-space: nowrap;width: 99%;" @touchmove.stop>
						<view class="flex_row_between common_tabs" style="gap:12px;">
							<block v-for="(v,k) in $msg.RANK_TABS" :key='k'>
								<view @tap="changeTabRank(k)" class="item_uzi" :class="curRank===k?`item_po`:``">
									<text>{{v}}</text>
								</view>
							</block>
						</view>
					</scroll-view>
				</view>
			</template>

			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<template v-if="curKey==$C.KEY_INDI">
					<ListIndicator :list="list" @action="linkTo" />
				</template>
				<template v-if="curKey===$C.KEY_RANK">
					<ListRank :list="list" @action="linkTo" @track="handleTrack" />
				</template>
				<template v-if="curKey===$C.KEY_TRACK">
					<ListTrack :list="list" @action="linkTo" @track="handleTrack" />
				</template>
				<template v-if="curKey===$C.KEY_STOCK">
					<view>
						<block v-for="(v,k) in list" :key="k">
							<view @tap="$linkTo.stockDetail(v.code,v.gid)" style="border-bottom: 1px solid #CCC;padding: 8px 0;">
								<view class="flex_row_between" style="gap: 12px;width: 100%;">
									<CustomLogo :logo="v.logo" :name="v.name"></CustomLogo>
									<view class="text_wrap" style="font-size: 14px;font-weight: 700;flex: 1; min-width: 0;">
										{{v.name}} <text style="font-size: 13px;font-weight: 300;padding-left: 12px;">({{v.code}})</text>
									</view>
								</view>
								<view class="flex_row_between" style="gap: 12px;">
									<view style="width: 48%;">{{v.industry}}</view>
									<view style="font-size: 15px;" :style="{color:$theme.setRiseFall(v.rate)}">
										{{$fmt.amount(v.price,v.lgre)}}
									</view>
									<text style="font-size: 15px;margin-left: auto;" :style="{color:$theme.setRiseFall(v.rate)}">
										{{ $fmt.percent(v.rate)}}
									</text>
								</view>
							</view>
						</block>
					</view>
				</template>
			</template>
		</view>

		<FooterSmall :actKey="$C.KEY_MARKET"></FooterSmall>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false,
				curKey: null,
				tabs: {
					[this.$C.KEY_STOCK]: this.$msg.MARKET_TAB_STOCK,
					// [this.$C.KEY_INDI]: 'US 거래',
					[this.$C.KEY_RANK]: this.$msg.MARKET_TAB_RANK,
					[this.$C.KEY_TRACK]: this.$msg.MARKET_TAB_TRACK,
				},
				curIndi: 0,
				curRank: 0,
				list: null,
				curStock: null,
				tabsStock: {
					[this.$fmt.code.KEY_KR]: this.$msg.STOCK_TABS_KR,
					// [this.$fmt.code.KEY_US]: this.$msg.STOCK_TABS_US,
				},
				timer: null,
				keyword: '',
				keywords: [],
			}
		},
		computed: {
			curIndex() {
				const tem = Object.keys(this.tabs).findIndex(k => k === this.curKey)
				return !tem || tem < 0 ? 0 : tem;
			},
			curGpIndex() {
				return this.$C.GPINDEX[this.curStock] || Object.keys(this.tabsStock)[0];
			}
		},
		onLoad(opt) {
			this.curKey = opt.tag || this.curKey;
			console.log(this.curKey)
		},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.curKey = this.curKey || Object.keys(this.tabs)[0];
			this.curStock = this.curStock || Object.keys(this.tabsStock)[0];
			this.changeTab(this.curKey);
			this.keywords = uni.getStorageSync("keywords") || this.keywords;
		},
		onHide() {
			this.isAnimat = false;
			this.clearTimer();
			this.wsClient = null;
		},
		deactivated() {
			this.clearTimer();
		},
		onUnload() {
			this.clearTimer();
		},
		onPullDownRefresh() {
			this.handleSearch();
			this.clearTimer();
			this.changeTab(this.curKey);
			uni.stopPullDownRefresh();
			this.keywords = uni.getStorageSync("keywords") || this.keywords;
		},
		methods: {
			// 当前默认行为：携带数据id，跳转到stockDetail页面
			linkTo(val, gid) {
				// 可根据curKey 对跳转行为做分别处理
				this.$linkTo.stockDetail(val, gid);
			},
			clearKeywords() {
				uni.clearStorageSync("keywords");
				this.keywords = [];
				this.list = [];
			},
			selectedItem(item) {
				this.keyword = item;
				this.handleSearch();
			},
			onSetTimeout() {
				this.timer = setInterval(() => {
					console.log("setInterval");
					this.search();
				}, 3000);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
			handleSearch() {
				this.search();
				this.clearTimer();
				this.onSetTimeout();
			},
			async search() {
				if (this.keyword == '' || this.keyword.length < 2) {
					uni.showToast({
						title: this.$msg.SEARCH_P_KEY,
						icon: 'none'
					})
					return false;
				}
				uni.showLoading({
					title: this.$msg.API_REQUEST_DATA,
				})
				const result = await this.$http.post(`api/product/list`, {
					key: this.keyword,
					page: 1,
					limit: 30,
					gp_index: 0
				});
				if (!result) return null;
				const temp = result.filter(v => v.gid > 0);
				const objData = {};
				!temp || temp.length <= 0 ? null : temp.forEach(v => {
					const type = v.project_type_id || 1;
					objData[`${v.gid}`] = {
						pid: v.pid || 0,
						gid: v.gid,
						name: v.name,
						code: v.code,
						rate: v.rate * 1 || 0,
						price: v.current_price * 1 || 0,
						rateNum: v.rate_num * 1 || 0,
						type: type,
						lgre: this.$C.LGRE[type],
						track: v.is_collected == 1
					};
				});
				this.list = objData;
			
				if (this.list && Object.values(this.list).length > 0) {
					console.log('search result:', this.list)
					if (this.keywords.indexOf(this.keyword) < 0) {
						this.keywords.push(this.keyword);
						uni.setStorageSync("keywords", this.keywords)
					}
				}
			},
			async changeTab(val) {
				console.log(1111,val)
				this.clearTimer();
				this.curKey = val;
				this.list = null;
				this.curStock = this.curStock || Object.keys(this.tabsStock)[0];
				this.curIndi = 0;
				this.curRank = 0;
				if (this.curKey === this.$C.KEY_STOCK)
					this.changeTabStock(this.curStock);
				if (this.curKey === this.$C.KEY_INDI)
					this.changeTabIndi(this.curIndi);
				if (this.curKey === this.$C.KEY_RANK)
					this.changeTabRank(this.curRank);
				if (this.curKey === this.$C.KEY_TRACK)
					this.list = await this.$http.getTrack();
			},
			async changeTabStock(val) {
				this.clearTimer();
				this.list = null;
				this.curStock = val;
				this.getStocks();
				if (this.curStock === this.$fmt.code.KEY_KR)
					if (!this.timer) this.onSetTimeout();
			},
			async changeTabIndi(val) {
				this.list = null;
				this.curIndi = val;
				this.list = await this.$http.getIndicators(this.curIndi);
			},
			async changeTabRank(val) {
				this.list = null;
				this.curRank = val;
				this.list = await this.$http.getRanking(this.curRank);
			},

			async handleTrack(val) {
				const result = await this.$http.postTrack(val);
				console.log(result);
				uni.showToast({
					title: result.message,
					icon: 'success'
				});
				setTimeout(() => {
					this.changeTabRank(this.curRank);
				}, 1000);
			},
			
			async getStocks() {
				this.list = await this.$http.getStocks(this.curGpIndex);
			},

			// 当前默认行为：携带数据id，跳转到stockDetail页面
			linkTo(val) {
				if (this.curKey == this.$C.KEY_INDI) return false;

				// 可根据curKey 对跳转行为做分别处理
				this.$linkTo.stockDetail(val);
			},

			onSetTimeout() {
				this.timer = setInterval(() => {
					console.log("setInterval");
					// this.getTop();
					if (this.curStock === this.$fmt.code.KEY_KR) this.getStocks();
				}, 3000);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
		}
	}
</script>

<style>
</style>