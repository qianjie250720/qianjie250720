<template>
	<view class="bg_page_conver launch_bg" style="position: relative;">

		<!-- <view style="text-align: center;padding-top: 19vh;">
			<image src="/static/logo_name.png" mode="heightFix" :style="$theme.setImageSize(140)"></image>
		</view> -->

		<!-- <view class="progress_tip"> {{curTip}} </view> -->

		<!-- <view style="padding:20px;line-height: 1.4;padding-top: 6vh;">
			<block v-for="(v,k) in tips" :key="k">
				<template v-if="percentage>(k*20)">
					<view style="padding-top: 20px;" :style="{color:$theme.getColor($theme.SECOND)}">
						{{v}}
					</view>
				</template>
			</block>
		</view> -->

		<view style="position: absolute;left: 0;right: 0;text-align: center;top: 20%;">
			<image src="/static/logo.png" mode="heightFix" :style="$theme.setImageSize(150)"></image>
		</view>
		
		<view style="position: absolute;left: 0;right: 0;text-align: center;top: 40%;">
			<view style="color: #005cb3;font-weight: 600;font-size: 25px;">PNC파이낸셜</view>
		</view>

		<view style="position: absolute;bottom: 80px;left: 0;right: 0;text-align: center;">
			<view style="margin: 0 auto;border-radius: 20px;background-color:rgba(255,255,255,0.5);width: 90%;">
				<view style="position: relative;width: 100%;height:16px;border-radius: 22px;">
					<view :style="setStyle"></view>
					<view class="progress_value"> {{percentage+` %`}} </view>
				</view>
			</view>
		</view>

		<!-- <view style="position: absolute;bottom: 20px;left: 0;right: 0;text-align: center;">
			<CopyrightVersion :color="$theme.getColor($theme.PRIMARY)" />
		</view> -->
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false, // 页面动画
				percentage: 1, // 进度条初始值
				timer: null,
				tips: this.$msg.LAUNCH_TIPS, // 滚动标题
			}
		},
		computed: {
			// 當前顯示文字，每20換一行文字
			curTip() {
				let temp = '';
				this.tips.forEach((v, k) => {
					if (this.percentage > (k * 20)) temp = v;
				});
				return temp;
			},

			// 设置进度条递进样式
			setStyle() {
				const temp = {
					position: 'absolute',
					bottom: 0,
					left: 0, // 决定进度条的递进方向
					height: '16px',
					width: `${this.percentage}%`,
					backgroundImage: this.$theme.linerGradient(90, `#2E67F63A`, `#8BADFF3A`),
					borderRadius: '20px',
				};
				// console.log('进度条递进完整样式:', temp);
				return temp;
			}
		},
		onLoad() {
			this.clearTimer();
			this.onSetTimeout();
		},
		onShow() {
			this.isAnimat = true;
			this.clearTimer();
			this.onSetTimeout();
		},
		onHide() {
			this.isAnimat = false;
			this.clearTimer();
		},
		onUnload() {
			this.clearTimer();
		},
		deactivated() {
			this.clearTimer();
		},
		methods: {
			onSetTimeout() {
				this.timer = setInterval(() => {
					if (this.percentage < 100) this.percentage++;
					else {
						this.clearTimer();
						// 跳转到首页 缓一秒， 否则看不到进度条加满效果
						setTimeout(() => {
							this.$linkTo.home();
						}, 1000);
					}
				}, 30);
			},
			clearTimer() {
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
				}
			},
		}
	}
</script>

<style>
</style>