<template>
	<view>
		<view class="mask" @click="handleClose()"></view>
		<view class="modal_wrapper">
			<view
				style="background-color: #FFFFFF;border-radius: 44rpx 44rpx 0 0;padding-top:40rpx;padding-bottom: 20rpx;">
				<view style="text-align: center;font-size: 32rpx;font-weight: 700;position: relative;">
					이익확정 및 손실한정
					<view style="position: absolute;top: -20rpx; right: 32rpx;" @click="handleClose()">
						<image src="/static/close.svg" mode="aspectFit" :style="$theme.setImageSize(36)"></image>
					</view>
				</view>
				<view style="padding: 40rpx;">
					<view style="display: flex;align-items: center;">
						<view style="padding-right: 10rpx;font-size: 28rpx;" :style="{color:$theme.SECOND}">
							{{info.name}}
						</view>
						<view
							style="background-color: #F3F3F3;font-size: 22rpx;border-radius: 8rpx;padding:6rpx 16rpx;margin:0 20rpx;"
							:style="{color:$theme.FALL}">
							{{info.lever+` X`}}
						</view>
						<view
							style="background-color: #F3F3F3;font-size: 22rpx;border-radius: 8rpx;padding:6rpx 16rpx;margin:0 20rpx;"
							:style="{color:info.fx==1?'#6D41FF':$theme.SECOND}">
							{{info.fxText}}
						</view>
						<view style="margin-left: auto;">
							<view class="common_tag" style="padding: 4px 6px;border-radius: 8px	;"  :style="setStyle(info.direct)">
								{{info.directText}}
							</view>
						</view>
					</view>

					<!--  -->
					<view
						style="display: flex;align-items: center;justify-content: space-between;line-height: 2.4;margin-top: 20rpx;">
						<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
							구매 가격
						</view>
						<view>{{$fmt.amount(info.price)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height:  2.4;">
						<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
							구매 수량
						</view>
						<view>{{$fmt.amount(info.quantity)}}</view>
					</view>
					<view
						style="display: flex;align-items: center;justify-content: space-between;line-height:  2.4;margin-bottom: 20rpx;">
						<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
							총 구매
						</view>
						<view>{{$fmt.amount(info.total)}}</view>
					</view>

					<TitleSecond :title="'혜택 금액'"></TitleSecond>

					
					<view style="padding: 5px 0px;">
						<view style="padding: 8px;border: 1px #ccc solid;border-radius: 5px;background-color: #f6f7f8;">
							<input v-model="profitAmount" type="digit" :placeholder="'혜택 금액'" placeholder-class="placeholder"
								style="font-size: 14px;" @blur="checkProfitAmount"/>
						</view>
					</view>

					<view style="font-size: 24rpx;margin-bottom: 40rpx;" :style="{color:$theme.LOG_LABEL}">
						{{'추정이자'+ `: `+$fmt.amount(estimatedProfit)+ ` USDT`}}
					</view>

					<TitleSecond :title="'손실금액'"></TitleSecond>
					
					<view style="padding: 5px 0px;">
						<view style="padding: 8px;border: 1px #ccc solid;border-radius: 5px;background-color: #f6f7f8;">
							<input v-model="lossAmount" type="digit" :placeholder="'손실금액'" placeholder-class="placeholder"
								style="font-size: 14px;" @blur="checkLossAmount"/>
						</view>
					</view>
					<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
						{{'추정이자' + ': ' + $fmt.amount(estimatedProfit) + ' USDT'}}
					</view>
				</view>

				<view style="margin: 60rpx auto; width: 80%;background-color:#9071f9 ;text-align: center;padding: 10px;border-radius: 5px;color: #FFFFFF;" @tap="handleSubmit()">
					확인하다
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import TitleSecond from '@/components/title/TitleSecond.vue';
	export default {
		name: 'ProfitLoss',
		components: {
			TitleSecond
		},
		props: {
			info: {
				type: Object,
				default: {}
			}
		},
		data() {
			return {
				isShow: false,
				profitAmount: '', // 止盈輸入金額
				lossAmount: '', // 止損輸入金額
				estimatedProfit: '', // 预估盈
				estimatedLoss: '', // 预估损
			}
		},
		computed: {
			// direct   1:买涨 买入 买多；2：买跌 卖出 卖少
			isBuy() {
				if (this.info) {
					return this.info.direct == 1;
				}
			},
		},
		methods: {
			handleClose() {
				this.isShow = false;
				this.$emit('action', 1);
			},

			// check 止盈输入值 并计算预估止盈值
			 // 检查止盈金额并计算估计盈利
			  checkProfitAmount() {
			    console.log(`checkProfitAmount:`, this.profitAmount);
			    if (this.profitAmount === '') return false;
			    
			    // 检查输入是否为合法数字
			    if (!this.$util.checkInputNumber(this.profitAmount)) return false;
			    
			    // 格式化后重新赋值（假设该方法返回一个数值字符串）
			    this.profitAmount = this.$util.checkInputNumber(this.profitAmount);
			    
			    // 将字符串转换为数字
			    const profitNum = Number(this.profitAmount);
			    const priceNum = Number(this.info.price);
			    
			    // 买涨时，止盈金额必须大于当前价格
			    if (this.isBuy) {
			      if (profitNum < priceNum) {
			        uni.showToast({
			          title: '이익은 가격보다 커야 합니다.',
			          icon: 'none'
			        });
			        return false;
			      }
			    } else {
			      // 买跌时，止盈金额必须小于当前价格
			      if (profitNum > priceNum) {
			        uni.showToast({
			          title: '이익은 가격보다 작아야',
			          icon: 'none'
			        });
			        return false;
			      }
			    }
			    
			    // 计算估计盈利：
			    // 买涨：盈利 = 止盈金额 - 当前价格
			    // 买跌：盈利 = 当前价格 - 止盈金额
			    this.estimatedProfit = this.isBuy ?
			      this.$util.formatNumber(profitNum - priceNum, 4) :
			      this.$util.formatNumber(priceNum - profitNum, 4);
			      
			    return true;
			  },
			
			  // 检查止损金额并计算估计亏损
			  checkLossAmount() {
			    console.log(`checkLossAmount:`, this.lossAmount);
			    if (this.lossAmount === '') return false;
			    
			    // 检查输入是否合法
			    if (!this.$util.checkInputNumber(this.lossAmount)) return false;
			    
			    // 格式化后重新赋值
			    this.lossAmount = this.$util.checkInputNumber(this.lossAmount);
			    
			    // 转换为数字
			    const lossNum = Number(this.lossAmount);
			    const priceNum = Number(this.info.price);
			    
			    // 买涨时，止损金额必须小于当前价格
			    if (this.isBuy) {
			      if (lossNum > priceNum) {
			        uni.showToast({
			          title: '손실은 가격보다 작아야',
			          icon: 'none'
			        });
			        return false;
			      }
			    } else {
			      // 买跌时，止损金额必须大于当前价格
			      if (lossNum < priceNum) {
			        uni.showToast({
			          title: '손실은 가격보다 커야 합니다.',
			          icon: 'none'
			        });
			        return false;
			      }
			    }
			    
			    // 计算估计亏损：
			    // 买涨：亏损 = 止损金额 - 当前价格
			    // 买跌：亏损 = 当前价格 - 止损金额
			    this.estimatedLoss = this.isBuy ?
			      this.$util.formatNumber(lossNum - priceNum, 4) :
			      this.$util.formatNumber(priceNum - lossNum, 4);
			      
			    return true;
			  },

			async handleSubmit() {
				// console.log(`profitAmount:`, this.profitAmount);
				// console.log(`lossAmount:`, this.lossAmount);
				// 两个输入框全都未输入时，提示用户输入
				if (this.profitAmount == '' && this.lossAmount == '') {
					uni.showToast({
						title: '유효한 값을 입력하세요.',
						icon: 'none'
					});
					return false;
				}
				let isCheck = false; // 当前带提交表单数据是否验证合法
				// 如果止盈输入框有内容，判断起合法性
				if (this.profitAmount != '') {
					// console.log(`止盈验证 profitAmount:`, this.profitAmount);
					isCheck = this.checkProfitAmount();
				}
				if (this.lossAmount != '') {
					// console.log(`止损验证 profitAmount:`, this.profitAmount);
					isCheck = this.checkLossAmount();
				}
				console.log(`验证结果:`, isCheck);
				if (!isCheck) return false;
				// 如果验证无误，执行提交事件
				uni.showLoading({
					title: '거래 진행 중',
					icon: 'loading'
				});
				// 止盈止损是可以设置一个,没有设置值的为'',
				const result = await this.$http.post(`api/zong/yingsun`, {
					id: this.info.id,
					zhiying: this.profitAmount > 0 ? this.profitAmount : '',
					zhisun: this.lossAmount > 0 ? this.lossAmount : '',
				});
				if (!result) return false;
				console.log(`result:`, result);
				uni.showToast({
					title: result.message,
					icon: 'success'
				});
				setTimeout(() => {
					this.$emit('action', 1);
				}, 1000);
			},

			setStyle(val) {
				const temp = val == 1 ? this.$theme.RISE : this.$theme.FALL;
				return {
					backgroundColor: this.$theme.RGBConvertToRGBA(temp, 20),
					color: temp,
				}
			},
		}
	}
</script>

<style lang="scss" scoped>
	.mask {
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		z-index: 1111;
		background-color: rgba(0, 0, 0, 0.6);
		cursor: pointer;
	}

	.modal_wrapper {
		position: fixed;
		bottom: 0;
		left: 50%;
		right: 0;
		z-index: 11113;
		width: 100%;
		background-color: transparent;
		animation: popopUp 300ms forwards;
		transform: translateX(-50%);
	}
</style>