<template>
	<view class="bg_primary">
		<header class="common_header" style="gap:12px;">
			<image src="/static/back.svg" mode="aspectFit" :style="$theme.setImageSize(16)" class="btn_back"
				@tap="$linkTo.goBack()"></image>
			<view class="dynamic_title">{{$msg.MENU_SCR}}</view>
			<!-- <image src="/static/icon_record.svg" mode="aspectFit" :style="$theme.setImageSize(16)"
				@tap="changeTab($C.KEY_DEPOSIT)"></image> -->
		</header>

		<view class="flex_row_between common_tabs" style="padding:12px 18px;">
			<block v-for="(v,k) in tabs" :key="k">
				<view @tap="changeTab(k)" class="item" :class="curKey===k?`item_act`:``">
					{{v}}
				</view>
			</block>
		</view>

		<view :class="curIndex%2==0?`left_in`:`right_in`" style="padding:20px 18px 60px 18px;">
			<CommonList :list="list" :curKey="curKey" @buy="showBuy" />
		</view>

		<template v-if="showConfirm">
			<CommonConfirm :title="$msg.IPO_MODAL_TITLE" @cancel="cancel" @confirm="confirm">
				<view class="flex_row_between" style="gap: 12px;width: 100%;padding-bottom: 4px; ">
					<view class="text_wrap" style="font-size: 14px;font-weight: 700;flex: 1; min-width: 0;">
						{{detail.name}}
					</view>
					<text style="font-size: 13px;font-weight: 300;">({{detail.code}})</text>
				</view>
				<view class="flex_row_between table_primary_tr">
					<view>{{$msg.IPO_PRICE}}</view>
					<view>{{$fmt.amount(detail.price,detail.lgre)}}</view>
				</view>
				<view class="flex_row_between table_primary_tr" style="padding-bottom: 12px;">
					<view>{{$msg.IPO_SHARES_ISSUED}}</view>
					<view :style="{color:$theme.getColor($theme.PRIMARY)}">
						{{$fmt.amount(detail.issuedAmount,detail.lgre)}}
					</view>
				</view>
				<view class="line_h"></view>
				<view style="padding-top: 12px;font-size: 12px;">{{$msg.IPO_MODAL_CONTENT}}</view>
			</CommonConfirm>
		</template>

	</view>
</template>

<script>
	import CommonList from './components/CommonList.vue';
	export default {
		components: {
			CommonList,
		},
		data() {
			return {
				isAnimat: false,
				curKey: null,
				tabs: {
					[this.$C.KEY_BUY]: this.$msg.SCR_TAB_BUY,
					[this.$C.KEY_APPLY]: this.$msg.SCR_TAB_APPLY,
					[this.$C.KEY_RECORD]: this.$msg.SCR_TAB_RECORD,
				},
				list: null,
				detail: null,
				showConfirm: false,
			}
		},
		computed: {
			curIndex() {
				const tem = Object.keys(this.tabs).findIndex(k => k === this.curKey)
				return !tem || tem < 0 ? 0 : tem;
			}
		},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.curKey = this.curKey || this.$C.KEY_BUY;
			this.changeTab(this.curKey);
		},
		onHide() {
			this.isAnimat = false;
			this.cancel();
		},
		onPullDownRefresh() {
			this.cancel();
			this.changeTab(this.curKey);
			uni.stopPullDownRefresh();
		},
		methods: {
			async changeTab(val) {
				this.list = null;
				this.curKey = val;
				if (this.curKey === this.$C.KEY_BUY) this.getGoods();
				if (this.curKey === this.$C.KEY_APPLY) this.getApplys();
				if (this.curKey === this.$C.KEY_RECORD) this.getRecord();
			},
			async showBuy(val) {
				this.detail = val;
				this.showConfirm = true;
			},
			cancel() {
				this.showConfirm = false;
				this.detail = null;
			},

			confirm() {
				this.showConfirm = false;
				this.buy();
			},
			async buy() {
				const result = await this.$http.post(`api/goods-scramble/doOrder`, {
					id: this.detail.id,
					num: this.detail.minNum,
					price: this.detail.price,
					// ganggan: 1,
				});
				if (!result) return false;
				uni.showToast({
					title: result.message,
					icon: "none"
				});
				setTimeout(() => {
					this.changeTab(this.$C.KEY_APPLY);
				}, 1500);
			},

			async getGoods() {
				uni.showLoading({
					title: this.$msg.API_REQUEST_DATA,
				})
				const result = await this.$http.get(`api/goods-scramble/calendar`);
				if (!result) return null;
				console.log(result);
				const temp = !result || result.filter(v => v.gid && v.gid > 0);
				this.list = !temp || temp.length <= 0 ? [] : temp.map(v => {
					const type = v.goods.project_type_id || 1;
					return {
						name: v.goods.name,
						code: v.goods.code,
						id: v.id,
						price: v.price * 1 || 0,
						latestPrice: v.goods.current_price || 0,
						issuedAmount: v.fa_amount * 1 || 0,
						minNum: v.min_num * 1 || 0,
						type: type,
						lgre: type == 1 ? this.$fmt.code.KEY_KR : this.$fmt.code.KEY_US,
					}
				});
			},

			async getApplys() {
				uni.showLoading({
					title: this.$msg.API_REQUEST_DATA,
				})
				const result = await this.$http.get(`api/goodsscramble/userApplyLog`);
				if (!result) return null;
				console.log(result);
				const temp = !result || result.filter(v => v.gid && v.gid > 0);
				this.list = !temp || temp.length <= 0 ? [] : temp.map(v => {
					const type = v.goods.project_type_id || 1;
					return {
						name: v.goods.name,
						code: v.goods.code,
						id: v.id,
						price: v.price || 0,
						latestPrice: v.goods.current_price || 0,
						rate_num: v.goods.rate_num * 1 || 0,
						rate: v.goods.rate * 1 || 0,
						applyQTY: v.apply_amount * 1 || 0, // 申购数量
						applyAmount: v.apply_amount * 1 || 0,
						success: v.success * 1 || 0,
						total: v.total * 1 || 0,
						sn: v.order_sn,
						dt: v.created_at,
						type: type,
						lgre: type == 1 ? this.$fmt.code.KEY_KR : this.$fmt.code.KEY_US,
					}
				});
			},

			async getRecord() {
				uni.showLoading({
					title: this.$msg.API_REQUEST_DATA,
				})
				const result = await this.$http.get(`api/goodsscramble/userSuccessLog`);
				if (!result) return null;
				console.log(result);
				const temp = !result || result.filter(v => v.gid && v.gid > 0);
				this.list = !temp || temp.length <= 0 ? [] : temp.map(v => {
					const type = v.goods.project_type_id || 1;
					return {
						name: v.goods.name,
						code: v.goods.code,
						id: v.id,
						price: v.price * 1 || 0,
						latestPrice: v.goods.current_price || 0,
						rate_num: v.goods.rate_num * 1 || 0,
						rate: v.goods.rate * 1 || 0,
						applyQTY: v.apply_amount * 1 || 0, // 申购数量
						applyAmount: v.apply_amount * 1 || 0,
						winning: v.success_num_amount * 1 || 0,
						success: v.success * 1 || 0,
						sn: v.order_sn,
						dt: v.created_at,
						type: type,
						lgre: type == 1 ? this.$fmt.code.KEY_KR : this.$fmt.code.KEY_US,
					}
				});
			}
		}
	}
</script>

<style>
</style>