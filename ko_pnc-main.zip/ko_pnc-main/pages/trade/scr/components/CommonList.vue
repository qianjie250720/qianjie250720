<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(v,k) in list" :key="k">
				<view class="table_primary">
					<view class="flex_row_between" style="align-items: stretch; gap: 12px;width: 100%;padding-bottom: 4px;">
						<view class="text_wrap" style="font-size: 14px;font-weight: 700;flex: 1; min-width: 0;">
							{{v.name}}
						</view>
						<text style="font-size: 13px;font-weight: 300;">({{v.code}})</text>
						<template v-if="curKey===$C.KEY_BUY">
							<view style="margin-left: auto;">
								<text class="btn_buy" @tap="buy(v)">{{$msg.SCR_BUY}}</text>
							</view>
						</template>
					</view>

					<view class="flex_row_between table_primary_tr">
						<view>{{$msg.SCR_PRICE}}</view>
						<view>{{$fmt.amount(v.price,v.lgre)}}</view>
					</view>
					<view class="flex_row_between table_primary_tr">
						<view>{{$msg.SCR_PRICE_LATEST}}</view>
						<view>{{$fmt.amount(v.latestPrice,v.lgre)}}</view>
					</view>
					<template v-if="curKey===$C.KEY_APPLY || curKey===$C.KEY_RECORD">
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.SCR_RATE}}</view>
							<view :style="{color:$theme.setRiseFall(v.rate)}">
								{{$fmt.percent(v.rate)}}
							</view>
						</view>
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.SCR_RATE_NUM}}</view>
							<view :style="{color:$theme.setRiseFall(v.rate)}">
								{{$fmt.amount(v.rate_num)}}
							</view>
						</view>
					</template>
					<template v-if="curKey===$C.KEY_BUY">
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.SCR_SHARES_ISSUED}}</view>
							<view :style="{color:$theme.getColor($theme.PRIMARY)}">{{$fmt.decimal(v.issuedAmount,$fmt.NEVER)}}
							</view>
						</view>
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.SCR_SHARES_MIN}}</view>
							<view>{{$fmt.decimal(v.minNum,$fmt.NEVER)}}
							</view>
						</view>
					</template>
					<template v-if="curKey===$C.KEY_APPLY || curKey===$C.KEY_RECORD">
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.SCR_APPLY_AMOUNT}}</view>
							<view>
								{{$fmt.amount(v.applyAmount,v.lgre)}}
							</view>
						</view>
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.SCR_APPLY_QTY}}</view>
							<view> {{$fmt.decimal(v.applyQTY,$fmt.NEVER)}} </view>
						</view>
						<template v-if="v.success>0">
							<view class="flex_row_between table_primary_tr">
								<view>{{$msg.SCR_SUCCESS_AMOUNT}}</view>
								<view :style="{color:$theme.getColor($theme.PRIMARY)}">
									{{$fmt.amount(v.success,v.lgre)}}
								</view>
							</view>
						</template>
						<template v-if="curKey===$C.KEY_APPLY">
							<view class="flex_row_between table_primary_tr">
								<view>{{$msg.SCR_TOTAL_AMOUNT}}</view>
								<view :style="{color:$theme.getColor($theme.PRIMARY)}">
									{{$fmt.amount(v.total,v.lgre)}}
								</view>
							</view>
						</template>
						<template v-else>
							<view class="flex_row_between table_primary_tr">
								<view>{{$msg.SCR_WIN_AMOUNT}}</view>
								<view :style="{color:$theme.PRIMARY}">
									{{$fmt.amount(v.winning,v.lgre)}}
								</view>
							</view>
						</template>
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.SCR_DT}}</view>
							<view>{{v.dt}}</view>
						</view>
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.SCR_SN}}</view>
							<view>{{v.sn}}</view>
						</view>
					</template>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	export default {
		name: "CommonList",
		props: {
			list: {
				type: Array,
				default: []
			},
			curKey: {
				type: String,
				default: ''
			}
		},
		methods: {
			buy(val) {
				this.$emit('buy', val);
			}
		}
	}
</script>

<style>
</style>