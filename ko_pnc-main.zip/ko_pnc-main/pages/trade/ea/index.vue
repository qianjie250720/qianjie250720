<template>
	<view class="">
		<header class="common_header" style="gap:12px;background-color: #265bb3;height: 80px;">
			<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(16)" class="btn_back"
				@tap="$linkTo.goBack()"></image>
			<view class="dynamic_title" style="color: #fff;">ETF 펀드</view>
			<!-- <image src="/static/icon_record.svg" mode="aspectFit" :style="$theme.setImageSize(16)"
				@tap="changeTab($C.KEY_DEPOSIT)"></image> -->
		</header>
		
		<!-- <view>
			<image src="/static/jijin_bg.png" style="width: 100%;height:140px;"></image>
		</view> -->

		<view style="padding: 20px;border-bottom: 1px #f7f9fa solid;">
			<view class="flex_row_between common_tabs" style="background-color: #f7f9fa;padding: 3px;">
				<block v-for="(v, k) in tabs" :key="k">
					<view @tap="changeTab(k)" class="item" :class="curKey === k ? `item_act_dz` : ``">
						{{ v }}
					</view>
				</block>
			</view>
		</view>

		<view style="padding:0 8px 60px 8px;">
			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<template v-if="curKey===$C.KEY_GOODS">
					<Goods :list="list" @buy="showBuy" :curKey="curKey" />
				</template>
				<template v-if="curKey===$C.KEY_APPL">
					<Record :list="list" :curKey="curKey"/>
				</template>
			</template>
		</view>

		<template v-if="showBuyModal && detail">
			<view style="">
				<view class="overlay" style="background-color: rgba(0,0,0,0.5);" @tap="showBuyModal=false"></view>
				<view class="modal_wrapper_center" style="background-color: #f8f8f8;">
					<view style="min-height: 30vh;">
						<view style="display: flex;align-items: center;line-height: 2.4;">
							<view :style="$theme.setImageSize(16)"></view>
							<view style="flex: 1;text-align: center;color: #000;font-size: 16px;font-weight: 900;">
								{{detail.name}}
							</view>
							<!-- <image src="/static/close_dark.svg" mode="aspectFit"
								style="margin-left: auto;padding-right: 6px;cursor: pointer;"
								:style="$theme.setImageSize(30)" @tap.top="modalClose()"></image> -->
						</view>
						<view class="position" style="padding:12px 12px 0 12px;">
							<view class="item">
								<view style="font-size: 15px;">주기</view>
								<view style="font-size: 15px;">{{detail.days}}</view>
							</view>
							<view class="item">
								<view style="font-size: 15px;">수익률</view>
								<view style="font-size: 15px;">{{detail.fudu}}%</view>
							</view>
						</view>
						<view style="padding:12px 12px 10px 12px;">
							<view style="font: 14px;font-weight: 700;margin-bottom: 8px;">
								구매 금액을 입력해주세요.
							</view>
							<view class="form_input" style="border: 1px #ccc solid;border-radius: 5px;">
								<input v-model="amount" type="digit"
									:placeholder="'최소 금액'+`: `+$fmt.amount(detail.minAmount)"
									placeholder-class="placeholder"></input>
								<template v-if="amount && amount.length > 0">
									<image src="/static/del.svg" mode="aspectFit" @tap="amount=''"></image>
								</template>
							</view>

							<Balance :balance="!user?'': $fmt.amount(user.money)" />

							<view class="btn_second"
								style="margin-top:20px;background-color: #265bb3;color: #fff;padding: 10px;text-align: center;border-radius: 5px;"
								@tap="handleBuy()">
								매수
							</view>
						</view>
					</view>
				</view>
			</view>

		</template>

	</view>
</template>

<script>
	import * as ext from './ext.js';
	import Goods from './components/Goods.vue';
	import Record from './components/Record.vue';
	export default {
		components: {
			Goods,
			Record
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curKey: 0,
				tabs: {
					[this.$C.KEY_GOODS]: '상품',
					[this.$C.KEY_APPL]: '내역',
				},
				list: null,
				detail: null,
				user: null,
				amount: '',
				showBuyModal: false,
			}
		},
		computed: {
			curIndex() {
				const tem = Object.keys(this.tabs).findIndex(k => k === this.curKey)
				return !tem || tem < 0 ? 0 : tem;
			}
		},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.curKey = this.curKey || this.$C.KEY_GOODS;
			this.changeTab(this.curKey);
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.changeTab(this.curKey);
			uni.stopPullDownRefresh();
		},
		methods: {
			changeTab(val) {
				this.list = null;
				this.curKey = val;
				if (this.curKey === this.$C.KEY_GOODS) {
					this.getGoods();
					// this.getAccount();
				}
				if (this.curKey === this.$C.KEY_APPL) this.getRecord();
			},

			modalClose() {
				this.showBuyModal = false;
				this.amount = '';
			},

			async showBuy(val) {
				this.detail = null;
				this.detail = val;
				this.getAccount();
				this.showBuyModal = true;
			},

			async handleBuy() {
				uni.showLoading({
					title: this.$msg.API_SUBMITING,
				});
				if (!this.$fmt.isNumer(this.amount)) {
					uni.showToast({
						title: this.$msg.TIP_VALID,
						icon: 'none'
					});
					return false;
				}
				uni.showLoading({
					title: this.$msg.API_SUBMITING,
				});
				const result = await this.$http.post(`api/jijin/buy`, {
					id: this.detail.id,
					// ganggan: 1,
					price: this.amount,
				});
				if (!result) return false;
				this.showBuyModal = false;
				this.amount = '';
				uni.showToast({
					title: this.$msg.COMMON_SUCCESS,
					icon: 'success'
				});
				this.changeTab(this.$C.KEY_APPL);
			},

			async getGoods() {
				this.list = await this.$http.getEAGoods();
			},
			async getRecord() {
				this.list = await this.$http.getEARecord();
			},
			async getAccount() {
				this.user = await this.$http.getAccount();
			},
		}
	}
</script>

<style>
</style>