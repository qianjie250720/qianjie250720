<template>
	<view>
		<block v-for="(item,index) in list" :key="index">
			<view style="padding: 10px;">
				<view style="border: 1px #ccc solid;border-radius: 5px;">
					<view class="flex_row_between" style="border-bottom: 1px #edeeef solid;padding: 10px;">
						<view style="font-size: 16px;font-weight: 900;">{{item.name}}</view>
						<!-- <view @tap="showSell(item)" style="border: 1px 	#265bb3 solid;padding: 3px 10px;border-radius: 30px;">卖出</view> -->
					</view>
					<view class="flex_row_between" style="border-bottom: 1px #edeeef solid;padding: 10px;">
						<view>매수가격</view>
						<view style="font-weight: 500;">{{$fmt.amount(item.price)}}</view>
					</view>
					<view class="flex_row_between" style="border-bottom: 1px #edeeef solid;padding: 10px;">
						<view>납부금액</view>
						<view style="font-weight: 500;">{{$fmt.amount(item.pay_price)}}</view>
					</view>
					<view class="flex_row_between" style="border-bottom: 1px #edeeef solid;padding: 10px;">
						<view>수익률</view>
						<view style="font-weight: 500;">{{item.fudu}}%</view>
					</view>
					<view class="flex_row_between" style="border-bottom: 1px #edeeef solid;padding: 10px;padding: 10px;">
						<view>주기</view>
						<view style="font-weight: 500;">{{item.days}}일</view>
					</view>
					<view class="flex_row_between" style="border-bottom: 1px #edeeef solid;padding: 10px;">
						<view>수수료</view>
						<view style="font-weight: 500;">{{item.fee}}</view>
					</view>
					<view class="flex_row_between" style="border-bottom: 1px #edeeef solid;padding: 10px;">
						<view>거래시간</view>
						<view style="font-weight: 500;">{{item.sdt}}</view>
					</view>
					<view class="flex_row_between" style="border-bottom: 1px #edeeef solid;padding: 10px;">
						<view>마감시간</view>
						<view style="font-weight: 500;">{{item.edt}}</view>
					</view>
					<view class="flex_row_between" style="border-bottom: 1px #edeeef solid;padding: 10px;">
						<view>주문번호</view>
						<view style="font-weight: 500;">{{item.ordersn}}</view>
					</view>
				</view>
			</view>
			
		</block>
	</view>
</template>

<script>
	export default {
		name: 'Record',
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		methods: {
			sell(val) {
				this.$emit('sell', val);
			},
			async showSell(val) {
				const result = await uni.showModal({
					// title: '5555',
					content: '确认要卖出吗？',
					cancelText: '取消',
					confirmText: '确认',
					confirmColor: this.$theme.PRIMARY,
					cancelColor: '#999999',
				});
				if (result[1].confirm) {
					this.handleSell(val.id);
				}
			},
			async handleSell(id) {
				uni.showLoading({
					// title: this.API_SUBMITING,
				});
				const result = await this.$http.post(`api/jijin/sell`, {
					id
				});
				if (!result) return false;
				uni.showToast({
					title: result,
					icon: 'none'
				});
				this.changeTab(this.curKey);
			},
		}
	}
</script>

<style>
</style>