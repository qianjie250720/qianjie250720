import * as constants from '@/common/constants.js';
import {
	Msg,
} from '@/localize/index.js';

export const tabs = () => {
	return [{
		key: constants.KEY_GOODS,
		name: translate(Msg.EA_GOODS),
	}, {
		key: constants.KEY_APPLY,
		name: translate(Msg.EA_RECORD),
	}]
}