<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(v,k) in list" :key="k">
				<view style="line-height: 1.8;border-bottom: 1px #f7f9fa solid;padding: 10px 0px;">
					<view style="display: flex;">
						<view style="flex: 20%;">
							<view style="color: #555;">신청금액</view>
							<view style="color: #555;" v-if="curKey===$C.KEY_RECORD">주식가격</view>
						</view>
						<view style="flex: 20%;text-align: right;">
							<view style="font-weight: 500;">{{$fmt.amount(v.money)}}</view>
							<view style="font-weight: 500;" v-if="curKey===$C.KEY_RECORD">{{$fmt.amount(v.price)}}</view>
						</view>
						<view style="flex: 25%;text-align: right;">
							<view style="color: #555;">배정금액</view>
							<view style="color: #555;" v-if="curKey===$C.KEY_RECORD">배정수량</view>
						</view>
						<view style="flex: 25%;text-align: right;">
							<view style="font-weight: 500;">{{$fmt.amount(v.success)}}</view>
							<view style="font-weight: 500;" v-if="curKey===$C.KEY_RECORD">{{$fmt.amount(v.num)}}</view>
						</view>
					</view>
					<view class="flex_row_between">
						<view style="color: #555;">신청시간</view>
						<view style="font-weight: 500;">{{v.dt}}</view>
					</view>
					<view class="flex_row_between">
						<view style="color: #555;">주문번호</view>
						<view style="font-weight: 500;">{{v.sn}}</view>
					</view>
					<view class="flex_row_between table_primary_tr">
						<view style="margin-left: auto;">
							<text class="common_status" :style="$theme.statusStyle(v.status)">{{v.statusTxt}}</text>
						</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	export default {
		name: "Record",
		props: {
			list: {
				type: Array,
				default: []
			},
			curKey: {
				type: String,
				default: ''
			}
		},
	}
</script>

<style>
</style>