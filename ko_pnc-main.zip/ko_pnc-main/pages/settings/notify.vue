<template>
	<view>
		<header class="common_header" style="gap:12px;background-color: #265bb3;height: 80px;">
			<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(16)" class="btn_back"
				@tap="$linkTo.goBack()"></image>
			<view class="dynamic_title" style="color: #fff;">발표</view>
			<!-- <image src="/static/icon_record.svg" mode="aspectFit" :style="$theme.setImageSize(16)"
				@tap="changeTab($C.KEY_DEPOSIT)"></image> -->
		</header>

		<view class="right_in">
			<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(v,k) in list" :key="k">
					<view style="border-radius: 10px;padding:10px;margin-top:7px;"
						:style="{backgroundColor:k%2==0?`#F1F9FF`:$theme.TRANSPARENT}" @tap="linkDetail(v.url)">
						<view class="ellipsis" style="font-size: 14px;font-weight: 500;color: #515151;">
							{{v.title}}
						</view>
						<view style="color: #9A9A9A;font-size: 9px;padding: 10px;text-align: right;">{{v.created_at}}</view>
					</view>
				</block>
			</template>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false, // 页面动画
				keywords: '',
				list: null,
			}
		},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.getList();
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.getList();
			uni.stopPullDownRefresh();
		},
		methods: {
			async getList() {
				uni.showLoading({
					title: this.$msg.API_REQUEST_DATA,
				});
				const result = await this.$http.post(`api/Article/list`,{
					type:3
				});
				if (!result) return false;
				this.list = result;
			},

			// async getDetail(val) {
			// 	uni.showLoading({
			// 		title: this.$msg.API_REQUEST_DATA,
			// 	});
			// 	const result = await post(`api/Article/list`, {
			// 		type: 3
			// 	});
			// 	if (!result) return false;
			// 	return result;
			// }
		}
	}
</script>

<style>
</style>