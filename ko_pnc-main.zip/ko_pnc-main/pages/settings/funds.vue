<template>
	<view>
		<!-- <header class="common_header" style="gap:12px;background-color: #0d53b0;">
			<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(16)" class="btn_back"
				@tap="$linkTo.goBack()"></image>
			<view class="dynamic_title" style="color: #fff;">{{$msg.MENU_FUNDS}}</view>
		</header>

		<view class="flex_row_between common_tabs" style="padding:12px 18px;">
			<block v-for="(v,k) in tabs" :key="k">
				<view @tap="changeTab(k)" class="item" style="padding:7px 4px;" :class="curKey===k?`item_act_cz`:``">
					{{v}}
				</view>
			</block>
		</view> -->

		<view :class="curIndex%2==0?`left_in`:`right_in`" >
			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<template v-if="curKey===$C.KEY_RECORD">
					<FundsTrade :list="list" />
				</template>
				<template v-if="curKey===$C.KEY_DEPOSIT">
					<FundsDeposit :list="list" />
				</template>
				<template v-if="curKey===$C.KEY_WITHDRAW">
					<FundsWithdraw :list="list" @cancel="" />
				</template>
				<template v-if="curKey===$C.KEY_CONVERT">
					<FundsConvert :list="list" />
				</template>
				<template v-if="curKey===$C.KEY_LOANS">
					<FundsLoans :list="list" />
				</template>
			</template>
		</view>

		<template v-if="showConfirm">
			<CommonConfirm :title="$msg.FUNDS_MODAL_TITLE" @cancel="cancel" @confirm="confirm">
			</CommonConfirm>
		</template>
	</view>
</template>

<script>
	import FundsTrade from './components/FundsTrade.vue';
	import FundsDeposit from './components/FundsDeposit.vue';
	import FundsWithdraw from './components/FundsWithdraw.vue';
	import FundsConvert from './components/FundsConvert.vue';
	import FundsLoans from './components/FundsLoans.vue';
	export default {
		components: {
			FundsTrade,
			FundsDeposit,
			FundsWithdraw,
			FundsConvert,
			FundsLoans,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curKey: null,
				list: null,
				tabs: {
					[this.$C.KEY_RECORD]: this.$msg.FUNDS_TRADES,
					[this.$C.KEY_DEPOSIT]: this.$msg.FUNDS_DEPOSIT,
					[this.$C.KEY_WITHDRAW]: this.$msg.FUNDS_WITHDRAW,
					// [this.$C.KEY_CONVERT]: this.$msg.FUNDS_CONVERT,
					// [this.$C.KEY_LOANS]: this.$msg.FUNDS_LOANS,
				},
				showConfirm: false,
			}
		},
		computed: {
			curIndex() {
				const tem = Object.values(this.tabs).findIndex(v => v.key === this.curKey)
				return !tem || tem < 0 ? 0 : tem;
			}
		},
		onLoad(opt) {
			console.log(opt);
			this.curKey = opt.tag || this.curKey;
		},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.curKey = this.curKey || Object.keys(this.tabs)[0];
			this.changeTab(this.curKey);
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.changeTab(this.curKey);
			uni.stopPullDownRefresh();
		},
		methods: {
			async changeTab(val) {
				this.list = null;
				this.curKey = val;
				if (this.curKey === this.$C.KEY_RECORD) this.getTradeRecord();
				if (this.curKey === this.$C.KEY_DEPOSIT) this.getDepositRecord();
				if (this.curKey === this.$C.KEY_WITHDRAW) this.getWithdrawRecord();
				if (this.curKey === this.$C.KEY_CONVERT) this.getConvertRecord();
				if (this.curKey === this.$C.KEY_LOANS) this.getLoans();
			},

			openDialog() {
				this.showConfirm = true;
			},

			cancel() {
				this.showConfirm = false;
				this.detail = null;
			},

			confirm(val) {
				this.showConfirm = false;
				this.detail = val;
				this.cancelWithdraw();
			},

			async cancelWithdraw() {
				uni.showLoading({
					title: this.$msg.API_SUBMITING,
				});
				const result = await post(`api/app/qx`, {
					id: this.detail.id,
				});
				if (!result) return null;
				console.log(result);
				uni.showToast({
					title: this.$msg.COMMON_SUCCESS,
					icon: 'success'
				});
				setTimeout(() => {
					this.changeTab(this.curKey);
				}, 1500);
			},

			async getTradeRecord() {
				uni.showLoading({
					title: this.$msg.API_REQUEST_DATA,
				})
				const result = await this.$http.get(`api/user/finance`);
				if (!result) return false;
				console.log(result);
				this.list = result.length <= 0 ? [] : result.map(v => {
					// console.log(temp[v.ident])
					const lgre = !v.ident || v.ident == '' ? this.$fmt.code.KEY_KR : this.$fmt.code.KEY_US;
					return {
						after: v.after * 1 || 0,
						before: v.before * 1 || 0,
						money: v.money * 1 || 0,
						dt: v.created_at,
						desc: v.desc,
						lgre: lgre,
					}
				});
			},

			async getDepositRecord() {
				uni.showLoading({
					title: this.$msg.API_REQUEST_DATA,
				})
				const result = await this.$http.get(`api/user/recharge`);
				if (!result) return false;
				console.log(result);
				this.list = result.length <= 0 ? [] : result.map(v => {
					const lgre = !v.desc || v.desc == '' ? this.$fmt.code.KEY_KR : this.$fmt.code.KEY_US;
					return {
						money: v.money * 1 || 0,
						dt: v.created_at,
						desc: v.desc_type,
						sn: v.order_sn,
						// reason:v.reason,
						status: v.status,
						statusLabel: this.$msg.FUNDS_STATUS[v.status],
						lgre: lgre,
					}
				});
			},

			async getWithdrawRecord() {
				uni.showLoading({
					title: this.$msg.API_REQUEST_DATA,
				})
				const result = await this.$http.get(`api/user/withdraw`);
				if (!result) return false;
				console.log(result);
				this.list = result.length <= 0 ? [] : result.map(v => {
					const lgre = !v.desc || v.desc == '' ? this.$fmt.code.KEY_KR : this.$fmt.code.KEY_US;
					return {
						money: v.money * 1 || 0,
						dt: v.created_at,
						desc: v.desc_type,
						sn: v.order_sn,
						reason: v.reason,
						status: v.status,
						statusLabel: this.$msg.FUNDS_STATUS[v.status],
						id: v.id,
						lgre: lgre,
					}
				});
			},

			async getConvertRecord() {
				uni.showLoading({
					title: this.$msg.API_REQUEST_DATA,
				})
				const result = await this.$http.get(`api/user/huazhuan_log`);
				if (!result) return false;
				console.log(result);
				this.list = result.length <= 0 ? [] : result.map(v => {
					const from = v.type == 1 ? this.$fmt.code.KEY_KR : this.$fmt.code.KEY_US;
					const to = v.type == 1 ? this.$fmt.code.KEY_US : this.$fmt.code.KEY_KR;
					return {
						money: v.num * 1 || 0,
						dt: v.created_at,
						desc: v.fangxiang,
						sn: v.ordersn,
						type: v.type,
						status: v.status,
						currency: v.leixing,
						toAmount: v.newnum,
						fromLgre: from,
						toLgre: to,
					}
				});
			},

			async getLoans() {
				uni.showLoading({
					title: this.$msg.API_REQUEST_DATA,
				})
				const result = await this.$http.get(`api/app/daikuanlog`);
				if (!result) return false;
				console.log(result);
				this.list = result.length <= 0 ? [] : result.map(v => {
					const lgre = !v.desc || v.desc == '' ? this.$fmt.code.KEY_KR : this.$fmt.code.KEY_US;
					return {
						money: v.money * 1 || 0,
						dt: v.created_at,
						sn: v.ordersn,
						type: v.type,
						status: v.status,
						haikuan: v.haikuan * 1 || 0,
						zhouqi: v.zhouqi * 1 || 0,
						lixi: v.lixi * 100 || 0,
						haikuantime: v.haikuantime,
						success: v.success * 1 || 0,
						lgre: lgre,
					}
				});
			}
		}
	}
</script>

<style>
</style>