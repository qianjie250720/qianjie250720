<template>
	<view class="bg_primary">
		<header class="common_header" style="gap:12px;">
			<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(16)" class="btn_back"
				@tap="$linkTo.goBack()"></image>
			<view class="dynamic_title" style="color: #fff;">출금</view>
			<image src="/static/icon_record.png" mode="aspectFit" :style="$theme.setImageSize(20)" style="cursor: pointer;"
				@tap="$linkTo.funds($C.KEY_WITHDRAW)"></image>
		</header>

		<view class="right_in" style="padding:20px 0 60px 0;">

			<!-- <template v-if="assets">
				<AssetsCard :info="assets" />
			</template> -->
			
			<view style="line-height: 1.8;padding:52px 20px;">
				<!-- <view style="color: #fff;">계정 잔액</view>
				<view style="color: #fff;font-size: 16px;">{{$fmt.amount(user.money)}}</view> -->
			</view>

			<view style="margin: 16px 0px;padding: 10px 15px;background-color: #fff;border-radius: 20px 20px 0px 0px;">
				<view style="font-size: 15px;font-weight: 900;padding: 10px 0px;">출금금액선택 (최소100만원)</view>
				<view style="display: flex;align-items: center;flex-wrap: wrap; justify-content: space-between;">
					<block v-for="(item,index) in amountList" :key="index">
						<view
							style="border-radius: 6px;text-align: center; width: 30%;padding: 8px;margin: 5px;"
							:style="setStyle(curPos==index)" @click="quantity(item,index)">
							{{$fmt.amount(item)}}
						</view>
					</block>
				</view>
				<view class="form_label" style="padding: 5px 0px;">
					
					<text><view style="padding-top: 4px;font-size: 13px;">
					출금 금액:
					<text style="padding:4px 0 8px 4px;">(잔액 {{$fmt.amount(user.money < 0 ? 0 : user.money)}})</text>
				</view></text>
				</view>

				<view class="form_input" style="background-color: #f7f9fa;border-radius: 5px;">
					<input v-model="amount" type="digit" :placeholder="$msg.P_WITHDRAW_ANOUNT"
						placeholder-class="placeholder"></input>
					<template v-if="amount && amount.length > 0">
						<image src="/static/del.svg" mode="aspectFit" @tap="amount=''"></image>
					</template>
				</view>
				

				<view class="form_label" style="margin-top: 20px;">출금 비밀번호</view>
				<view class="form_input" style="background-color: #f7f9fa;border-radius: 5px;">
					<input v-model="password" :password="isMask" :placeholder="$msg.P_WITHDRAW_PWD"
						placeholder-class="placeholder"></input>
					<image :src="`/static/mask_${isMask?`hide`:`show`}.svg`" mode="aspectFit" @tap="toggleMask()"></image>
				</view>
				
				
				<view :style="{color:$theme.BLACK_70}">
					<view style="font: 14px;font-weight: 500;margin-top: 16px;margin-bottom: 16px;">
						출금 가이드라인
					</view>
					<block v-for="(v,k) in $msg.WITHDRAW_RULES" :key="k">
						<view style="font-size: 12px;padding-bottom: 8px;">{{`・`+ v}}</view>
					</block>
				</view>
			</view>

			<view style="padding:10px 18px 25px 18px;">
				<BtnLock :isDisabled="islock" @tap="handleSubmit" className="btn_submit" style="border-radius: 5px;">
					{{$msg.WITHDRAW_BTN}}
				</BtnLock>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false,
				user: null,
				amount: '',
				password: '',
				isMask: null,
				curPos: 0, // 当前选中预置金额。
				islock: false,
			}
		},
		computed: {
			assets() {
				if (!this.user) return null;
				return {
					total: this.user.totalZichan * 1 || 0,
					usd: this.user.usd * 1 || 0,
					balance: this.user.money * 1 || 0,
					frozen: this.user.frozen * 1 || 0,
					totalPL: this.user.totalYingli * 1 || 0,
					holdPL: this.user.holdYingli * 1 || 0,
				}
			},
			amountList() {
				return [100000, 500000, 1000000, 5000000, 10000000, 50000000];
			},
		},
		created() {
			this.amount = this.amountList[this.curPos];
		},
		async onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.isMask = uni.getStorageSync('masking');
			this.user = await this.$http.getAccount();
		},
		onHide() {
			this.isAnimat = false;
		},
		async onPullDownRefresh() {
			this.user = await this.$http.getAccount();
			uni.stopPullDownRefresh();
		},
		methods: {
			quantity(val, index) {
				this.curPos = index;
				this.amount = val;
			},
			setStyle(val) {
				return {
					// ...val ? this.$theme.LG_PRIMARY : this.$theme.LG_SECOND,
					backgroundImage: val? 'linear-gradient(90deg, #265bb3, #265bb3)':'linear-gradient(90deg, #f7f9fa, #f7f9fa)',
					color: val ? '#FFFFFF' : '#121212',
					// borderRadius: `44rpx`,
					// border: `1px solid ${val? this.$theme.TRANSPARENT:'#e4013e'}`
				}
			},
			// masking 开关
			toggleMask() {
				this.isMask = !this.isMask;
				this.$util.setDataMask(this.isMask);
			},
			async handleSubmit() {
				if (!this.$util.checkField(this.amount, this.$msg.P_WITHDRAW_ANOUNT)) return false;
				if (!this.$util.checkField(this.password, this.$msg.P_WITHDRAW_PWD)) return false;
				this.islock = true;
				const result = await this.$http.post(`api/app/withdraw`, {
					type: 1,
					total: this.amount,
					pay_pass: this.password,
					remakes: "",
				});

				this.islock = false;
				if (!result) return false;
				uni.showToast({
					icon: 'success'
				});
				setTimeout(() => {
					this.$linkTo.funds($C.KEY_WITHDRAW)
				}, 1000)
			},
		}
	}
</script>

<style>
</style>