<template>
	<view class="bg_primary">
		<header class="common_header" style="gap:12px;">
			<image src="/static/back.svg" mode="aspectFit" :style="$theme.setImageSize(16)" class="btn_back"
				@tap="$linkTo.goBack()"></image>
			<view class="dynamic_title">{{$msg.MENU_LOANS}}</view>
		</header>

		<view class="left_in" style="padding:20px 0 40px 0;">
			<template v-if="assets">
				<AssetsCard :info="assets" />
			</template>
			<view class="common_card" style="margin: 16px 18px;padding: 14px 20px;">
				<view class="form_label"> {{$msg.LOANS_AMOUNT}} </view>
				<view class="form_input">
					<input v-model="amount" type="digit" :placeholder="$msg.LOANS_AMOUNT_TIP"
						placeholder-class="placeholder"></input>
					<template v-if="amount && amount.length > 0">
						<image src="/static/del.svg" mode="aspectFit" @click="amount=''"></image>
					</template>
				</view>
				<view style="padding-top: 4px;font-size: 11px;margin-bottom: 16px;">
					{{$msg.LOANS_TIPS}}
					<text style="padding:4px 0 8px 4px;">{{$fmt.amount(10000)}}</text>
				</view>

				<view class="form_label"> {{$msg.LOANS_CYCLE}} </view>
				<view class="form_input" style="gap:12px;" @tap="showCycle=true">
					<view style="flex:1;"><text style="color:#999;padding-right: 12px;">{{$msg.LOANS_ZQ}}</text> {{curCycle}}
					</view>
					<view>|</view>
					<view style="flex:1;"><text style="color:#999;padding-right: 12px;">{{$msg.LOANS_RATE}}</text>
						{{$fmt.percent(curRate * 100)}}
					</view>
				</view>
			</view>
			<view style="padding:10px 20px;">
				<BtnLock :isDisabled="islock" @tap="handleSubmit" className="btn_submit radius_22">
					{{$msg.COMMON_SUBMIT}}
				</BtnLock>
			</view>

			<view style="padding:0 18px 40px 18px;">
				<view style="font: 14px;font-weight: 500;margin-top: 16px;margin-bottom: 16px;">
					{{$msg.LOANS_RULE_TITLE}}
				</view>
				<block v-for="(v,k) in $msg.LOANS_RULES" :key="k">
					<view style="font-size: 12px;padding-bottom: 8px;">{{k+1 +`. `+ v}}</view>
				</block>
			</view>
		</view>

		<template v-if="showCycle">
			<u-picker :show="showCycle" :columns="[setCycles]" @change="chooseCycle" @cancel="showCycle=false"
				@confirm="confirmCycle" :cancelText="$msg.COMMON_CANCEL" :confirmText="$msg.COMMON_CONFIRM"
				:cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY" keyName="label"
				visibleItemCount="9"></u-picker>
		</template>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false,
				user: null,
				amount: '',
				islock: false,
				cycles: [],
				curCycle: '',
				curRate: '',
				showCycle: false,
			}
		},
		computed: {
			assets() {
				if (!this.user) return null;
				return {
					total: this.user.totalZichan * 1 || 0,
					balance: this.user.money * 1 || 0,
					frozen: this.user.frozen * 1 || 0,
					totalPL: this.user.totalYingli * 1 || 0,
					holdPL: this.user.holdYingli * 1 || 0,
				}
			},
			setCycles() {
				if (!this.cycles || Object.values(this.cycles).length <= 0) return [];
				return Object.entries(this.cycles).map(([key, value]) => ({
					key: Number(key),
					value: value,
					label: this.$msg.LOANS_ZQ + ` ${Number(key)} - ${this.$msg.LOANS_RATE} ${value*100}%`
				}));
			}
		},
		async onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.user = await this.$http.getAccount();
			const result = await this.$http.getConfig();
			console.log(result);
			this.cycles = JSON.parse(result.get('daikuan_zhouqi'));
			console.log(this.cycles);
		},
		onHide() {
			this.isAnimat = false;
			this.curCycle = '';
			this.curRate = '';
			this.amount = '';
		},
		async onPullDownRefresh() {
			this.user = await this.$http.getAccount();
			const result = await this.$http.getConfig();
			console.log(result);
			this.cycles = JSON.parse(result.get('daikuan_zhouqi'));
			console.log(this.cycles);
			uni.stopPullDownRefresh();
		},
		methods: {
			chooseCycle(e) {
				console.log(`changeMode e:`, e);
			},
			confirmCycle(e) {
				console.log(`confirmMode e:`, e);
				this.showCycle = false;
				this.curCycle = e.value[0].key;
				this.curRate = e.value[0].value;
			},

			async handleSubmit() {
				if (!this.$util.checkField(this.amount, this.$msg.TIP_VALID)) return false;
				if (!this.$util.checkField(this.curCycle, this.$msg.LOANS_CYCLE_TIP)) return false;
				this.islock = true;
				uni.showLoading({
					title: this.$msg.API_SUBMITING,
				});
				const result = await this.$http.post(`api/app/daikuan`, {
					money: this.amount.trim(),
					zhouqi: this.curCycle,
					lixi: this.curRate,
				});
				this.islock = false;
				if (!result) return false;
				uni.showToast({
					icon: 'success'
				});
				setTimeout(() => {
					this.$linkTo.loansRecord()
				}, 1000)
			},
		}
	}
</script>

<style>
</style>