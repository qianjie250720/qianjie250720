<template>
	<view>
		<header class="common_header" style="gap: 12px; background-color: #275cb3; height: 80px;">
			<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(16)" class="btn_back"
				@tap="$linkTo.goBack()" />
			<view class="dynamic_title" style="color: #fff;">환전</view>
			<image src="/static/icon_record.png" mode="aspectFit" :style="$theme.setImageSize(20)" @tap="$linkTo.dhrecord()" />
		</header>

		<!-- 입력 부분 -->
		<view style="margin: 20rpx 0; padding: 0 20px;">
			<template v-if="curMode === 1">
				<!-- KRW -> USDT: 입력창은 KRW 표시 -->
				<view class="flex" style="padding: 10px 0;">
					<view class="flex" style="background-color: #f3f5f7; padding: 5px 20px; border-radius: 30px;">
						<image src="/static/logo.png" mode="widthFix" style="width: 30px; height: 30px;" />
						<view style="font-weight: 900; margin-left: 10px;">{{ curCoin.unit }}</view>
					</view>
				</view>
				<view class="flex_row_between" style="border: 1px #e9eaeb solid; padding: 10px; border-radius: 5px;">
					<input v-model="amount" placeholder="금액을 입력해주세요." placeholder-class="placeholder" />
					<view style="border-left: 2px #c0c0c1 solid; padding: 5px 10px; width: 60px;">
						<text>{{ curCoin.unit }}</text>
					</view>
				</view>
			</template>
			<template v-else>
				<!-- USDT -> KRW: 입력창은 USDT 표시 -->
				<view class="flex" style="padding: 10px 0;">
					<view class="flex" style="background-color: #f3f5f7; padding: 5px 20px; border-radius: 30px;">
						<image src="/static/logo.png" mode="widthFix" style="width: 30px; height: 30px;" />
						<view style="font-weight: 900; margin-left: 10px;">{{ curCoin.unit }}</view>
					</view>
				</view>
				<view class="flex_row_between" style="border: 1px #e9eaeb solid; padding: 10px; border-radius: 5px;">
					<input v-model="amount" placeholder="금액을 입력해주세요." placeholder-class="placeholder" />
					<view style="border-left: 2px #c0c0c1 solid; padding: 5px 10px; width: 60px;">
						<text>{{ curCoin.unit }}</text>
					</view>
				</view>
			</template>
		</view>

		<!-- 전환 토글 버튼 -->
		<view style="display: flex; align-items: center; justify-content: center; padding: 30px 0;">
			<image src="/static/convert_toggle.png" mode="aspectFit" :style="$theme.setImageSize(50)"
				@click="toggleMode" />
		</view>

		<!-- 교환 결과 표시 -->
		<view style="margin: 20rpx 0; padding: 0 20px;">
			<view style="margin-left: auto;">
				<template v-if="curMode === 2">
					<view style="font-weight: 900;">교환</view>
					<view class="flex" style="padding: 10px 0;">
						<view class="flex" style="background-color: #f4f7ff; padding: 5px 20px; border-radius: 30px;">
							<image src="/static/logo.png" mode="widthFix" style="width: 30px; height: 30px;" />
							<view style="font-weight: 900; margin-left: 10px;">{{ usdtInfo.unit }}</view>
						</view>
					</view>
					<view class="flex_row_between" style="border: 1px #e9eaeb solid; padding: 10px; border-radius: 5px;">
						<view style="padding-right: 20rpx;">{{ toAmount }}</view>
						<view style="border-left: 2px #c0c0c1 solid; padding: 5px 10px; width: 60px;">
							<text>{{ usdtInfo.unit }}</text>
						</view>
					</view>
				</template>
				<template v-else>
					<view style="font-weight: 900;">교환</view>
					<view class="flex" style="padding: 10px 0;">
						<view class="flex" style="background-color: #f4f7ff; padding: 5px 20px; border-radius: 30px;">
							<image src="/static/logo.png" mode="widthFix" style="width: 30px; height: 30px;" />
							<view style="font-weight: 900; margin-left: 10px;">{{ usdtInfo.unit }}</view>
						</view>
					</view>
					<view class="flex_row_between" style="border: 1px #e9eaeb solid; padding: 10px; border-radius: 5px;">
						<view style="padding-right: 20rpx;">{{ toAmount }}</view>
						<view style="border-left: 2px #c0c0c1 solid; padding: 5px 10px; width: 60px;">
							<text>{{ usdtInfo.unit }}</text>
						</view>
					</view>
				</template>
			</view>
		</view>

		<!-- 수수료, 실제 도착액, 계좌 잔고 정보 -->
		<view style="line-height: 2; font-size: 10px; padding: 20px;">
			<view class="flex_row_between" style="color: #8a8a8a;">
				<view>환전금액</view>
				<view>{{$fmt.amount(toAmount)}}</view>
			</view>
			<view class="flex_row_between" style="color: #8a8a8a;">
				<view>계좌잔액</view>
				<view>{{$fmt.amount(assets.balance)}}</view>
			</view>
			<view class="flex_row_between" style="color: #8a8a8a;">
				<view>USD</view>
				<view>{{$fmt.amount(assets.usd)}}</view>
			</view>
		</view>

		<!-- 제출 버튼 -->
		<view style="padding: 50px 20px;">
			<BtnLock :isDisabled="islock" @tap="handleSubmit"
				style="border-radius: 5px; padding: 10px; text-align: center; background-color: #275cb3; color: #fff;">
				{{$msg.COMMON_SUBMIT}}
			</BtnLock>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false,
				user: null,
				amount: '', // 입력 금액
				password: '',
				// curMode: 1: KRW → USDT, 2: USDT → KRW
				curMode: 1,
				isMask: null,
				islock: false,
				usd_gbp:'',
				gbp_usd:'',
				rate: 1,
				curRate: 1, // 실제 환율
				curCurrency: 'KRW', // 현재 주화
				curCoin: {
					unit: 'KRW'
				}, // 주화 정보
				usdtInfo: {
					unit: 'USDT'
				} // 부화 정보
			};
		},
		computed: {
			assets() {
				if (!this.user) return null;
				return {
					total: Number(this.user.totalZichan) || 0,
					balance: Number(this.user.money) || 0,
					usd: this.user.usd * 1 || 0,
					frozen: Number(this.user.frozen) || 0,
					totalPL: Number(this.user.totalYingli) || 0,
					holdPL: Number(this.user.holdYingli) || 0
				};
			},
			// 계산된 환전 금액 (환율에 따른)
			toAmount() {
				console.log('转换计算:', this.amount + '，汇率:' + this.curRate);
				if (this.amount === '' || this.amount <= 0) return '';
				return this.curMode === 1
					? (this.amount * this.curRate).toFixed(4)
					: (this.amount * this.curRate).toFixed(4);
			},
			
			isPrimary() {
				return this.curCurrency === 'KRW';
			},
			fromUnit() {
				return this.isPrimary ? '₩' : '$';
			}
		},
		async onShow() {
		  this.$linkTo.isAuth();
		  this.isAnimat = true;
		  this.isMask = uni.getStorageSync('masking');
		  this.user = await this.$http.getAccount();
		  // 先获取配置数据，这样 this.gbp_usd 和 this.usd_gbp 会被设置好
		  await this.getConfig();
		  // 然后根据当前货币更新汇率
		  this.getRate();
		},
		onHide() {
			this.isAnimat = false;
		},
		async onPullDownRefresh() {
			this.user = await this.$http.getAccount();
			this.getRate();
			this.getConfig();
			uni.stopPullDownRefresh();
		},
		methods: {
			// 모드 전환 (KRW → USDT : mode 1, USDT → KRW : mode 2)
			toggleMode() {
				this.curMode = this.curMode === 1 ? 2 : 1;
				this.amount = ''; // 금액 초기화
				// 모드 전환에 따라 주화 정보 교환
				[this.curCoin, this.usdtInfo] = [this.usdtInfo, this.curCoin];
				this.toggleCurrency();
			},
			// masking 상태 전환
			toggleMask() {
				this.isMask = !this.isMask;
				this.$util.setDataMask(this.isMask);
			},
			// 통화 코드 전환 및 환율 업데이트
			toggleCurrency() {
				this.curCurrency = this.curMode === 1 ? 'KRW' : 'USD';
				this.getRate();
			},
			// 환율 업데이트 (모의)
			getRate() {
				if (this.curCurrency === 'KRW') {
					// 가정: 1 KRW = 0.00072 USDT
					this.curRate = this.gbp_usd;
				} else {
					// 가정: 1 USDT = 1454.2 KRW
					this.curRate = this.usd_gbp;
				}
			},
			async getConfig() {
				uni.showLoading({
					title: this.$msg.API_REQUEST_DATA,
				})
				const result = await this.$http.get(`api/app/config`,{
					
				});
				if (!result) return null;
				console.log(result);
				this.gbp_usd = result[36].value;
				this.usd_gbp = result[37].value;
			},
			async handleSubmit() {
				if (!this.amount) {
					uni.showToast({
						title: '금액을 입력해주세요.',
						icon: 'none'
					});
					return false;
				} else if (this.amount <= 99 ) {
					uni.showToast({
						title: '최소 입력은 100입니다.',
						icon: 'none'
					});
					return false;
				}
				uni.showLoading({});
				// KRW → USDT: mode 1 -> type 1, USDT → KRW: mode 2 -> type 2
				const type = this.curMode === 1 ? 1 : 2;
				const result = await this.$http.post('api/zong/huazhuan', {
					type: type,
					num: this.amount
				});
				uni.hideLoading();
				if (!result) return false;
				console.log('result:', result);
				uni.showToast({
					title: result.message,
					icon: 'success'
				});
				setTimeout(() => {
					uni.navigateTo({
						url: '/pages/exchange/dhrecord'
					});
				}, 1000);
			}
		}
	};
</script>

<style>
	/* 필요에 따라 스타일 조정 */
</style>
