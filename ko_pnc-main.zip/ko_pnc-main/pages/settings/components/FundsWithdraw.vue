<template>
	<view>
		<header class="common_header" style="gap:12px;background-color: #0d53b0;height: 80px;">
			<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(16)" class="btn_back"
				@tap="$linkTo.goBack()"></image>
			<view class="dynamic_title" style="color: #fff;">출금 기록</view>
		</header>
		<block v-for="(v,k) in list" :key="k">
			<!-- <view class="table_primary">
				<view class="flex_row_between table_primary_tr">
					<view style="flex:1;"></view>
					<view class="common_status" :style="$theme.statusStyle(v.status)">
						{{v.statusLabel}}
					</view>
				</view>
				<view class="flex_row_between table_primary_tr">
					<view>{{$msg.FUNDS_W_MONEY}}</view>
					<view style="font-size: 14px;">
						{{$fmt.amount(v.money,$fmt.setLgre(v.lgre))}}
					</view>
				</view>
				<view class="flex_row_between table_primary_tr">
					<view>{{$msg.FUNDS_W_DT}}</view>
					<view>{{v.dt}}</view>
				</view>
				<view class="flex_row_between table_primary_tr">
					<view>{{$msg.FUNDS_W_SN}}</view>
					<view>{{v.sn}}</view>
				</view>

				<view class="flex_row_between table_primary_tr">
					<view>{{$msg.FUNDS_W_REASON}}</view>
					<view :style="{color:$theme.getColor($theme.INFO)}">{{v.reason}}</view>
				</view>
				<view class="flex_row_between table_primary_tr">
					<view></view>
					<template v-if="v.status==0">
						<view style="margin-left: auto;">
							<view class="btn_buy" @tap="cancel(v)">
								{{$msg.FUNDS_W_CANCEL}}
							</view>
						</view>
					</template>
					<template v-if="v.status==2">
						<view style="margin-left: auto;">
							<view class="common_status" :style="$theme.statusStyle(v.status)" @tap="$linkTo.service()">
								{{v.statusLabel}}
							</view>
						</view>
					</template>
				</view>
			</view> -->
			
			<view style="line-height: 2;padding:10px 20px;border-bottom: 1px #ccc solid;">
				<view class="flex_row_between">
					<view style="font-size: 15px;font-weight: 900;" :style="{ color: transStatus2(v.status) }">{{transStatus(v.status)}}</view>
					<view style="font-size: 16px;font-weight: 900;">{{$fmt.amount(v.money,$fmt.setLgre(v.lgre))}}</view>
				</view>
				<view class="flex_row_between">
					<view>{{v.dt}}</view>
					<view >{{v.sn}}</view>
				</view>
				<view class=" table_primary_tr">
					<view></view>
					<template v-if="v.status==0">
						<view style="padding: 5px;">
							<view @tap="cancel(v)" style="padding: 5px;background-color: #0e54b0;color: #fff;text-align: center;border-radius: 5px;">
								{{$msg.FUNDS_W_CANCEL}}
							</view>
						</view>
					</template>
					<template v-if="v.status==2">
						<view style="margin-left: auto;">
							<view style="padding: 5px;background-color: #fee5e6;color: #fff;text-align: center;" :style="$theme.statusStyle(v.status)" @tap="$linkTo.service()">
								{{v.statusLabel}}
							</view>
						</view>
					</template>
				</view>
			</view>

		</block>
	</view>
</template>

<script>
	export default {
		name: 'FundsWithdraw',
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		methods: {
			cancel(val) {
				this.$emit('cancel', val);
			},
			transStatus(status) {
			    if (status == 0) {
			      return '리뷰 대기 중';
			    } else if (status == 1) {
			      return '출금 성공';
			    } else if (status == 2) {
			      return '출금 실패';
			    }
			  },
			  transStatus2(status) {
			    if (status == 0) {
			      return '#000';
			    } else if (status == 1) {
			      return '#f3c897';
			    } else if (status == 2) {
			      return '#ff0b0b';
			    }
			  },
		}
	}
</script>

<style>
</style>