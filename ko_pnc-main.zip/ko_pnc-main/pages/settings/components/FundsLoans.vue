<template>
	<view>
		<block v-for="(v,k) in list" :key="k">
			<view class="record_item record_table">
				<view style="text-align: right;" :style="{color:[$theme.PRIMARY,$theme.RISE,$theme.FALL][v.status]}">
					{{$msg.LOANS_STATUS[v.status]}}
				</view>
				<view class="record_tr">
					<view>{{$t($msg.LOANS_AMOUNT)}}</view>
					<view style="color: #121212;">{{$fmt.amount(v.money)}}</view>
				</view>
				<view class="record_tr">
					<view>{{$t($msg.LOANS_SUCCESS)}}</view>
					<view>{{$fmt.amount(v.success)}}</view>
				</view>
				<view class="record_tr">
					<view>{{$t($msg.LOANS_ZQ)}}</view>
					<view style="color: #121212;">{{$fmt.numer(v.zhouqi)}}</view>
				</view>
				<view class="record_tr">
					<view>{{$t($msg.LOANS_RATE)}}</view>
					<view style="color: #121212;">{{$fmt.percent(v.lixi)}}</view>
				</view>

				<view class="record_tr">
					<view>{{$t($msg.LOANS_AMOUNT_H)}}</view>
					<view>{{$fmt.amount(v.haikuan)}}</view>
				</view>

				<view class="record_tr">
					<view>{{$t($msg.LOANS_HKDT)}}</view>
					<view style="color: #121212;">{{v.haikuantime}}</view>
				</view>
				<view class="record_tr">
					<view>{{$t($msg.LOANS_DT)}}</view>
					<view style="color: #121212;">{{v.dt}}</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "FundsLoans",
		props: {
			list: {
				type: Array,
				default: []
			}
		},
	}
</script>

<style>
</style>