<template>
	<view>
		<header class="common_header" style="gap:12px;background-color: #0d53b0;height: 80px;">
			<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(16)" class="btn_back"
				@tap="$linkTo.goBack()"></image>
			<view class="dynamic_title" style="color: #fff;">거래 내역</view>
		</header>
		<block v-for="(v,k) in list" :key="k">
			<view class="" style="border-bottom: 1px #ccc solid;padding: 20px;">
				<view class="flex_row_between table_primary_tr" :style="{paddingTop: k==0?``:`6px`}" >
					<view style="font-size: 15px;font-weight: 900;">{{$msg.FUNDS_TRADE_AFTER}}</view>
					<view style="font-size: 15px;">{{$fmt.amount(v.after,$fmt.setLgre(v.lgre))}}</view>
				</view>
				<view class="flex_row_between table_primary_tr">
					<view style="font-size: 15px;font-weight: 900;">{{$msg.FUNDS_TRADE_BEFORE}}</view>
					<view style="font-size: 15px;">{{$fmt.amount(v.before,$fmt.setLgre(v.lgre))}}</view>
				</view>
				<view class="flex_row_between table_primary_tr">
					<view style="font-size: 15px;font-weight: 900;">{{$msg.FUNDS_MONEY}}</view>
					<view style="font-size: 15px;font-weight: 900;">
						{{$fmt.amount(v.money,$fmt.setLgre(v.lgre))}}
					</view>
				</view>
				<view class="flex_row_between table_primary_tr">
					<view style="font-size: 15px;font-weight: 900;">{{$msg.FUNDS_TRADE_DT}}</view>
					<view style="font-size: 15px;">{{v.dt}}</view>
				</view>
				<view class="flex_row_between table_primary_tr">
					<view style="font-size: 15px;font-weight: 900;">{{$msg.FUNDS_TRADE_DESC}}</view>
				</view>
				<view class="flex_row_between table_primary_tr">
					<view></view>
					<view style="text-align: right;color: #888;">{{v.desc}} </view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: 'FundsTrade',
		props: {
			list: {
				type: Array,
				default: []
			}
		},
	}
</script>

<style>
</style>