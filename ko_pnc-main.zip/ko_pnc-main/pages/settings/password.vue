<template>
	<view>
		<header class="common_header" style="gap:12px;background-color: #0c52b0;height: 80px;">
			<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(16)" class="btn_back"
				@tap="$linkTo.goBack()"></image>
			<view class="dynamic_title" style="color: #fff;">{{setTitle}}</view>
		</header>

		<view class="right_in" style="padding:20px 0px;">
			<view class="" style="margin: 0 0 16px 0;padding: 14px 20px;">
				<view class="form_label">{{$msg.SET_PWD_OLD}} </view>
				<view class="form_input" style="background-color: #f3f5f7;border-radius: 5px;">
					<image src="/static/pwd_old.svg" mode="aspectFit"></image>
					<input v-model="oldPwd" :password="isMask" :placeholder="$msg.P_SET_PWD_OLD"
						placeholder-class="placeholder"></input>
					<image :src="`/static/mask_${isMask?`hide`:`show`}.svg`" mode="aspectFit" @tap="toggleMask()"></image>
				</view>
				<view @tap="$linkTo.service()" style="font-size: 11px;text-align: right;padding-top: 4px;">
					{{$msg.SET_PWD_FORGOT}} <text style="padding:0 4px;cursor: pointer;"
						:style="{color:$theme.getColor($theme.PRIMARY)}">{{$msg.SET_PWD_LINK_SERVICE}}</text>
				</view>

				<view class="form_label" style="margin-top: 16px;"> {{$msg.SET_PWD_NEW}} </view>
				<view class="form_input" style="background-color: #f3f5f7;border-radius: 5px;">
					<image src="/static/pwd_new.svg" mode="aspectFit"></image>
					<input v-model="newPwd" :password="isMask" :placeholder="$msg.P_SET_PWD_NEW"
						placeholder-class="placeholder"></input>
					<image :src="`/static/mask_${isMask?`hide`:`show`}.svg`" mode="aspectFit" @tap="toggleMask()"></image>
				</view>

				<view class="form_label" style="margin-top: 16px;"> {{$msg.SET_PWD_CONFIM}} </view>
				<view class="form_input" style="background-color: #f3f5f7;border-radius: 5px;">
					<image src="/static/pwd_new.svg" mode="aspectFit"></image>
					<input v-model="confimPwd" :password="isMask" :placeholder="$msg.P_SET_PWD_CONFIM"
						placeholder-class="placeholder"></input>
					<image :src="`/static/mask_${isMask?`hide`:`show`}.svg`" mode="aspectFit" @tap="toggleMask()"></image>
				</view>
			</view>
			<view style="padding:80px 20px;">
				<BtnLock :isDisabled="islock" @tap="handleSubmit" className="btn_submit" style="border-radius: 5px;">
					{{$msg.COMMON_SUBMIT}}
				</BtnLock>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false,
				isMask: false,
				oldPwd: "",
				newPwd: "",
				confimPwd: "",
				isPay: false,
				islock: false,
			}
		},
		computed: {
			setTitle() {
				return this.isPay ? this.$msg.MENU_PWD_PAY : this.$msg.MENU_PWD_ACCOUNT
			}
		},
		onLoad(opt) {
			// console.log(opt);
			this.isPay = opt.tag || this.isPay;
		},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.isMask = uni.getStorageSync('masking');
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			uni.stopPullDownRefresh();
		},
		methods: {

			toggleMask() {
				this.isMask = !this.isMask;
				this.$util.setDataMask(this.isMask);
			},

			async handleSubmit() {
				if (!this.$util.checkField(this.oldPwd,
						this.$msg.P_SET_PWD_OLD)) return false;
				if (!this.$util.checkField(this.newPwd,
						this.$msg.P_SET_PWD_NEW)) return false;
				if (!this.$util.checkField(this.confimPwd,
						this.$msg.P_SET_PWD_CONFIM)) return false;
				if (this.newPwd != this.confimPwd) {
					uni.showToast({
						title: this.$msg.TIP_SET_PWDDIFF,
						icon: 'none'
					});
					return false;
				}
				this.islock = true;
				uni.showLoading({
					title: this.$msg.API_SUBMITING
				});
				const temp = this.isPay ? `updatePayPassword` : `updateLoginPassword`;
				const result = await this.$http.post(`api/user/${temp}`, {
					oldpass: this.oldPwd.trim(),
					newpass: this.newPwd.trim(),
					confirmpass: this.confimPwd.trim(),
				});
				console.log(result);
				if (!result) {
					this.islock = false;
					return false;
				}
				uni.showToast({
					title: this.$msg.COMMON_SUCCESS,
					icon: 'success'
				});
				setTimeout(() => {
					this.$linkTo.settings();
					this.islock = false;
				}, 1000)
			},
		}
	}
</script>

<style>
</style>