import socket
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
import sys

def scan_port(ip, port, stop_event):
    if stop_event.is_set():
        return None
    try:
        with socket.create_connection((ip, port), timeout=3):
            stop_event.set()
            return port
    except:
        return None

def scan_ports(ip, start_port=30000, end_port=35000, max_workers=1000):
    stop_event = threading.Event()
    ports = range(start_port, end_port + 1)

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_port = {executor.submit(scan_port, ip, port, stop_event): port for port in ports}

        for future in as_completed(future_to_port):
            port = future_to_port[future]
            result = future.result()
            if result:
                print(f"{ip}:{result}", flush=True)
                stop_event.set()
                # 找到后立刻返回
                return f"{ip}:{result}"

    return None

if __name__ == "__main__":

    result = scan_ports("10.147.18.70")
