import sys
import subprocess

# 确保 Python 输出支持 UTF-8
# sys.stdout = codecs.getwriter("utf-8")(sys.stdout.buffer, 'replace')
# sys.stderr = codecs.getwriter("utf-8")(sys.stderr.buffer, 'replace')

import threading
import time
from AGRI import monitor_activity_AGRI
from monitor import run_in_thread
from saomiao import sm_start


import os

def main():

    mode = sys.argv[1] if len(sys.argv) > 1 else "jiancha"
    android_id = sys.argv[2] if len(sys.argv) > 2 else None  # 可选 android_id
    device_id = sys.argv[3] if len(sys.argv) > 3 else None  # 可选 device_id
    wifi_ip = sys.argv[4] if len(sys.argv) > 4 else None

    # 打印当前模式和传入参数
    print(f"[INFO] 当前模式：{mode}")
    print(f"[INFO] Android ID：{android_id if android_id else '未提供'}")
    print(f"[INFO] 设备 ID：{device_id if device_id else '未提供'}")

    if mode == "saomiao":
        sm_start(wifi_ip)

if __name__ == "__main__":
    main()
