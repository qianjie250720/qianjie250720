import re
import win32evtlog
import win32evtlogutil
import pywintypes

def get_rdp_history_from_security_log():
    """
    从 Security 日志中读取历史 RDP 登录记录：
    - 事件 ID = 4624（成功登录）
    - LogonType = 10（RemoteInteractive，即 RDP）
    - 通过正则匹配 'Source Network Address' 获取远程 IP
    """
    server = 'localhost'  # 本地读取，也可改为远程主机名
    logtype = 'Security'  # 日志名称
    # 打开事件日志
    handle = win32evtlog.OpenEventLog(server, logtype)

    flags = (
        win32evtlog.EVENTLOG_BACKWARDS_READ  # 从最新的往回读
        | win32evtlog.EVENTLOG_SEQUENTIAL_READ
    )

    # 用来匹配“Source Network Address: x.x.x.x”
    ip_pattern = re.compile(r'Source Network Address:\s+(\S+)')
    # 用来匹配“Logon Type: 10”或“Logon Type:\s+10”
    # 有些系统会在格式化文本里出现类似“Logon Type:         10”
    logon_type_10_pattern = re.compile(r'Logon Type:\s+10')

    results = []

    while True:
        events = win32evtlog.ReadEventLog(handle, flags, 0)
        if not events:
            break

        for event in events:
            # 只关心事件 ID = 4624（账号成功登录）
            # event.EventID 有时可能包含高位，实际要用 event.EventID & 0xFFFF
            if (event.EventID & 0xFFFF) == 4624:
                # 将事件转换成可读文本
                try:
                    message = win32evtlogutil.SafeFormatMessage(event, logtype)
                except pywintypes.error:
                    # 某些事件可能无法被正确解析，跳过
                    continue

                # 判断是否是远程登录 (Logon Type = 10)
                if logon_type_10_pattern.search(message):
                    # 匹配 IP
                    match = ip_pattern.search(message)
                    if match:
                        ip_address = match.group(1)
                        # 事件生成时间
                        time_generated = event.TimeGenerated  # pywintypes.datetime 对象
                        # 转成普通字符串更易阅读
                        time_str = time_generated.strftime('%Y-%m-%d %H:%M:%S')
                        results.append((time_str, ip_address))

    # 按时间排序（其实已经是倒序读，但还是保险处理一下）
    results.sort()

    return results

if __name__ == "__main__":
    rdp_history = get_rdp_history_from_security_log()
    if not rdp_history:
        print("在 Security 日志里，没有找到任何 RDP 成功登录的历史记录（4624 + LogonType=10）.")
    else:
        print("=== 历史 RDP 登录记录 (从 Security 日志解析) ===")
        for (t, ip) in rdp_history:
            print(f"时间: {t}, 来自IP: {ip}")
