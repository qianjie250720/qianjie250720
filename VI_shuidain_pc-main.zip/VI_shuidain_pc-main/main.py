import sys
import subprocess
import codecs
# 确保 Python 输出支持 UTF-8
sys.stdout = codecs.getwriter("utf-8")(sys.stdout.buffer, 'replace')
sys.stderr = codecs.getwriter("utf-8")(sys.stderr.buffer, 'replace')

import threading
import time
from Jiancha import Jiancha_main
from VTB import monitor_activity
from BIDV import monitor_activity_BIDV
from AGRI import monitor_activity_AGRI
from monitor import run_in_thread
from saomiao import scan_ports


import os

def main():
    # 检查命令行参数，至少要有 mode 参数
    # if len(sys.argv) < 2:
    #     print("❌ 错误：缺少必要参数！正确格式：main.exe <mode> [android_id] [device_id]")
    #     sys.exit(1)

    mode = sys.argv[1] if len(sys.argv) > 1 else "jiancha"
    android_id = sys.argv[2] if len(sys.argv) > 2 else None  # 可选 android_id
    device_id = sys.argv[3] if len(sys.argv) > 3 else None  # 可选 device_id
    wifi_ip = sys.argv[4] if len(sys.argv) > 4 else None

    # 打印当前模式和传入参数
    # print(f"[INFO] 当前模式：{mode}")
    # print(f"[INFO] Android ID：{android_id if android_id else '未提供'}")
    # print(f"[INFO] 设备 ID：{device_id if device_id else '未提供'}")

    if mode == "saomiao":
        scan_ports(wifi_ip)

    elif mode == "jianting":
        monitoring_thread = threading.Thread(target=run_in_thread,args=(device_id, android_id+"..."))
        monitoring_thread.start()
        # monitor_activity_and_capture(device_id, android_id+"...")

    elif mode == "jiancha":
        Jiancha_main()

    elif mode == "yemain":
        """通过 ADB 获取当前活动页面，指定设备"""
        try:
            result = subprocess.check_output(
                ["adb", "-s", device_id, "shell", "dumpsys", "window"],
                encoding="utf-8",
                errors="ignore"
            )
            for line in result.splitlines():
                if "mCurrentFocus" in line or "mFocusedApp" in line:
                    parts = line.split()
                    for part in parts:
                        if "/" in part:
                            return part.strip("{}")
            return None
        except subprocess.CalledProcessError as e:
            print(f"❌ 获取活动页面时出错: {e}")
            return None

    elif mode == "vtb":
        if not device_id:
            print("❌ 错误：VTB 模式需要提供设备 ID！")
            sys.exit(1)

        target_activity = "com.vietinbank.ipay/.activity.HomeActivity"
        activity_thread = threading.Thread(target=monitor_activity, args=(target_activity, device_id), daemon=True)
        activity_thread.start()

        while True:

            time.sleep(1)

    elif mode == "agri":
        if not device_id:
            print("❌ 错误：BIDV 模式需要提供设备 ID！")
            sys.exit(1)
        # target_activity = "com.vnpay.Agribank3g/com.vnpay.agribank3g.ui.activities.login.LoginActivity"

        target_activity = "com.vnpay.Agribank3g/com.vnpay.agribank3g.ui.activities.home.HomePreLoginActivity"
        activity_thread = threading.Thread(target=monitor_activity_AGRI, args=(target_activity, device_id), daemon=True)
        activity_thread.start()

        while True:
            time.sleep(1)


    elif mode == "bidv":
        if not device_id:
            print("❌ 错误：BIDV 模式需要提供设备 ID！")
            sys.exit(1)

        target_activity = "com.vnpay.bidv/.ui.activities.home.HomeActivity"
        activity_thread = threading.Thread(target=monitor_activity_BIDV, args=(target_activity, device_id), daemon=True)
        activity_thread.start()

        while True:
            time.sleep(1)
    else:
        print("❌ 无效的功能参数！请输入 'jiancha' 或 'vtb'")
        sys.exit(1)

if __name__ == "__main__":
    main()
