import os
import subprocess
import winreg
import sys
import ctypes


def add_to_path(bin_path):
    """使用 setx 命令更新系统 PATH"""
    try:
        subprocess.run(f'setx PATH "%PATH%;{bin_path}"', shell=True, check=True)
        print(f"已成功添加到 PATH: {bin_path}")
    except subprocess.CalledProcessError as e:
        print(f"更新 PATH 失败：{e}")


def check_grep_installed():
    """检查 grep 是否已安装"""
    try:
        subprocess.run(["grep", "--version"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
        return True
    except FileNotFoundError:
        return False

def install_grep_silently(installer_path, install_dir):
    """静默安装 grep"""
    subprocess.run([installer_path, "/silent", f"/DIR={install_dir}"], check=True)
    print("grep 安装完成！")


def check_zerotier_installed():
    common_path = r"C:\ProgramData\ZeroTier\One\zerotier-one_x64.exe"
    if os.path.isfile(common_path):
        print(f"检测到 {common_path} 存在。ZeroTier 应已安装。")
        return True
    else:
        print(f"未找到 {common_path}，ZeroTier 可能未安装或安装在其他目录。")
        return False




def install_zerotier_silently(installer_path):
    """尝试静默安装 ZeroTier，如果失败则打开安装界面"""

    if not os.path.exists(installer_path):
        print(f"⚠️ 安装程序未找到：{installer_path}")
        return

    log_path = os.path.join(os.getcwd(), "zerotier_install_log.txt")
    print("🟢 开始静默安装 ZeroTier...")

    try:
        # 静默安装 ZeroTier
        result = subprocess.run(
            ["msiexec", "/i", installer_path, "/qn", "/norestart", f"/l*v {log_path}"],
            check=True,
            shell=True
        )
        print("✅ ZeroTier 安装完成！")
    except subprocess.CalledProcessError as e:
        print(f"❌ 静默安装失败，错误码：{e.returncode}")
        print("⚠️ 尝试手动安装 ZeroTier...")

        # 打开安装界面，用户手动安装
        try:
            subprocess.run(["msiexec", "/i", installer_path], check=True, shell=True)
            print("✅ ZeroTier 手动安装完成！")
        except subprocess.CalledProcessError as e:
            print(f"❌ 手动安装失败，错误码：{e.returncode}")

    # 检查日志是否生成
    if os.path.exists(log_path):
        print(f"📜 安装日志已生成：{log_path}")
    else:
        print("⚠️ 错误：日志文件未生成，请检查安装路径和权限！")


def set_file_permissions(file_path):
    """使用 icacls 为文件添加 Everyone 的完全控制权限"""
    try:
        subprocess.run(["icacls", file_path, "/grant", "Everyone:(F)"], check=True)
        print(f"{file_path} 的权限已修改为 Everyone 可完全控制。")
    except subprocess.CalledProcessError as e:
        print(f"修改权限失败：{e}")
    except FileNotFoundError:
        print(f"文件未找到：{file_path}")


def run_electron():
    """运行 Electron 应用"""
    electron_path = os.path.abspath("electron")
    if os.path.exists(electron_path):
        subprocess.run(["npm", "start"], cwd=electron_path, shell=True)
    else:
        print(f"Electron 目录未找到：{electron_path}")
        # sys.exit(1)



def find_root_directory(target_folder="kongzhi"):
    """从当前目录向上查找目标目录（默认 'kongzhi'）"""
    current_dir = os.getcwd()

    while True:
        if os.path.basename(current_dir) == target_folder:
            return current_dir  # 找到 "kongzhi" 目录，返回路径
        parent_dir = os.path.dirname(current_dir)  # 获取上一级目录
        if parent_dir == current_dir:  # 已经到达根目录，仍未找到
            raise FileNotFoundError(f"未找到根目录 '{target_folder}'")
        current_dir = parent_dir  # 继续向上查找

def Jiancha_main():
    # zi_yuan_dir = os.path.abspath("/resources/ziyuan")
    # grep_installer_path = os.path.join(zi_yuan_dir, "grep-2.5.4-setup.exe")
    # zerotier_installer_path = os.path.join(zi_yuan_dir, "ZeroTier.msi")

    # # 获取当前目录
    current_dir = find_root_directory()

    # # 拼接 `resources\ziyuan` 目录
    resources_ziyuan_path = os.path.join(current_dir, "resources", "ziyuan")

    # 直接在当前目录下查找文件
    grep_installer_path = os.path.join(resources_ziyuan_path, "grep-2.5.4-setup.exe")
    zerotier_installer_path = os.path.join(resources_ziyuan_path, "ZeroTier.msi")

    print("Grep Installer Path:", grep_installer_path)
    print("ZeroTier Installer Path:", zerotier_installer_path)
    print("资源目录:", resources_ziyuan_path)

    add_to_path(resources_ziyuan_path)


    # 后续逻辑示例：
    if not os.path.exists(zerotier_installer_path):
        print(f"安装程序未找到：{zerotier_installer_path}")
        sys.exit(1)
    if not os.path.exists(grep_installer_path):
        print(f"安装程序未找到：{grep_installer_path}")
        sys.exit(1)


    install_dir = r"C:\grep"
    bin_path = os.path.join(install_dir, "bin")
    auth_token_path = r"C:\ProgramData\ZeroTier\One\authtoken.secret"
    ZeroTier_path = r"C:\ProgramData\ZeroTier\One"



    # 安装 ZeroTier
    if not check_zerotier_installed():
        print("系统中未检测到 ZeroTier，开始安装...")
        if os.path.exists(zerotier_installer_path):
            install_zerotier_silently(zerotier_installer_path)
            add_to_path(ZeroTier_path)

        else:
            print(f"安装程序未找到：{zerotier_installer_path}")
            exit(1)
    else:
        print("系统中已检测到 ZeroTier，无需安装。")

    # 安装 grep
    if not check_grep_installed():
        print("系统中未检测到 grep，开始安装...")
        if os.path.exists(grep_installer_path):
            install_grep_silently(grep_installer_path, install_dir)
            add_to_path(r"C:\grep\bin")

        else:
            print(f"安装程序未找到：{grep_installer_path}")
            exit(1)
    else:
        print("系统中已检测到 grep，无需安装。")

    # 设置 authtoken.secret 的权限
    if os.path.exists(auth_token_path):
        set_file_permissions(auth_token_path)
    else:
        print(f"文件未找到：{auth_token_path}")


if __name__ == "__main__":
    Jiancha_main()