const { BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');

/**
 * 动态生成输入框的HTML
 * @param {Object} messages 例如: { connectIp: '请输入连接IP:', pairingCode: '请输入配对码:' }
 * @param {Object} defaultValues 默认值对象, 如 { connectIp: '10.147.17.', pairingCode: '' }
 * @returns {string} 生成的HTML字符串
 */
function generateFieldsHtml(messages, defaultValues = {}) {
  let html = '';
  // 遍历所有键值对
  for (const key of Object.keys(messages)) {
    const labelText = messages[key];
    const defaultValue = defaultValues[key] || ''; // 如果有默认值则使用，否则空字符串
    html += `
      <label>${labelText}</label><br>
      <input id="${key}" type="text" style="width: 100%; padding: 8px;" value="${defaultValue}" /><br><br>
    `;
  }
  return html;
}

/**
 * 显示一个带多个输入框的对话框
 * @param {Object} options
 * @param {string} [options.title] 窗口标题
 * @param {Object} options.messages - 要求用户输入的字段说明, 如 { deviceAddress: '请输入配对码IP地址...', connectIp: '请输入IP...' }
 * @param {Object} [options.defaultValues] - 每个字段的默认值, 如 { deviceAddress: '10.147.17.', connectIp: '10.147.17.' }
 * @returns {Promise<Object|null>} - 用户输入的键值对, 或 null 表示窗口被关闭
 */
function showInputBox(options) {
  return new Promise((resolve) => {
    const inputWin = new BrowserWindow({
      width: 600,
      height: 400,
      modal: true,
      parent: BrowserWindow.getFocusedWindow(),
      webPreferences: {
        contextIsolation: false,
        nodeIntegration: true,
      },
    });

    const title = options.title || 'Input Required';
    const fieldsHtml = generateFieldsHtml(options.messages, options.defaultValues);

    const htmlContent = `
      <html>
      <body style="font-family: Arial; margin: 20px;">
          <h2>${title}</h2>
          <div>
            ${fieldsHtml}
            <button id="submitButton" style="padding: 10px 20px;">提交</button>
          </div>
          <script>
              const { ipcRenderer } = require('electron');
              document.getElementById('submitButton').onclick = () => {
                  const inputs = document.querySelectorAll('input');
                  const formData = {};
                  inputs.forEach(input => {
                      formData[input.id] = input.value;
                  });
                  
                  console.log("📩 发送数据到主进程:", formData); // ✅ 确保数据正确传递
                  ipcRenderer.send('input-box-response', formData);

                  setTimeout(() => { window.close(); }, 100); // ✅ 确保数据发送后才关闭
              };
          </script>
      </body>
      </html>
    `;

    inputWin.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(htmlContent));

    ipcMain.removeAllListeners('input-box-response'); // ✅ 防止重复监听
    ipcMain.once('input-box-response', (event, formData) => {
      console.log("📩 收到用户输入数据:", formData); // ✅ 确保数据返回
      resolve(formData);
      inputWin.close();
    });

    inputWin.on('closed', () => {
      resolve(null);
    });
  });
}


function showSingleInputBox(options) {
  return new Promise((resolve) => {
      const inputWin = new BrowserWindow({
          width: 1000,
          height: 800,
          modal: true,
          parent: BrowserWindow.getFocusedWindow(),
          webPreferences: {
              contextIsolation: false,
              nodeIntegration: true,
          },
      });

      inputWin.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(`
          <html>
          <body style="font-family: Arial; margin: 20px;">
              <h3>${options.title || 'Input Required'}</h3>
              <label>${options.message || '请输入内容:'}</label><br>
              <input id="userInput" type="text" style="width: 100%; padding: 8px;" /><br><br>
              <button id="submitButton" style="padding: 10px 20px;">提交</button>
              <script>
                  const { ipcRenderer } = require('electron');
                  document.getElementById('submitButton').onclick = () => {
                      const userInput = document.getElementById('userInput').value;
                      if (!userInput.trim()) {
                          alert('输入不能为空！');
                          return;
                      }
                      ipcRenderer.send('single-input-response', userInput); // 发送用户输入
                  };
              </script>
          </body>
          </html>
      `));

      // 接收输入内容
      ipcMain.once('single-input-response', (event, userInput) => {
          resolve(userInput);
          inputWin.close();
      });

      inputWin.on('closed', () => {
          resolve(null); // 窗口关闭时返回 null
      });
  });
}

module.exports = { showInputBox,showSingleInputBox };
