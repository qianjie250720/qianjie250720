const { exec, spawn } = require("child_process");
const { dialog } = require("electron");
const logger = require("./logger.js");
const path = require("path");
const { showSingleInputBox } = require("./showInputBox.js");
const { getDeviceConfig, setDeviceConfig,zhangdan } = require("./config-utils.js");


const adbPath = "adb"; // 你的 ADB 路径，可修改
const pythonPath = "python"; // 如果需要，你可以指定 Python 的完整路径


const execCommand = async (command, logger) => {
    return new Promise((resolve, reject) => {
        exec(command, (error, stdout, stderr) => {
            if (error) {
                reject(error);
            } else {
                resolve(stdout.trim());
            }
        });
    });
};


const logMessage = (logWindow, message, level = "log-message", isPinned = false) => {
    if (logWindow && logWindow.webContents) {
        logWindow.webContents.send(level, message, isPinned);
    }
};

// **打开 VCB 应用并输入密码**
const openVCB = async (logWindow,android_id) => {
    logMessage(logWindow,'❗切记请不要再VCB页面');

    // 显示输入框
    const userInput = await showSingleInputBox({
        title: '请输入登录密码',
        message: '请输入密码',
    });

    if (!userInput) {
        logMessage(logWindow,'未提供输入内容');
        dialog.showErrorBox('错误', '未提供输入内容，请重新操作！'); // 错误弹窗
        return;
    }

    logMessage(logWindow,`User Input: ${userInput}`);

    try {

        const config = getDeviceConfig(android_id);
        if (!config || !config.connectIp) {
            logMessage(logWindow,"❌ 设备未找到，请检查配置！");
            return;
          }
        
        const deviceId = config.connectIp;

        // 启动应用 com.VCB
        const startAppCommand = `${adbPath} -s ${deviceId} shell monkey -p com.VCB -c android.intent.category.LAUNCHER 1`;
        try {
            await execCommand(startAppCommand);
            
            logMessage(logWindow,'应用 VCB 已成功启动');
        } catch (error) {
           
            logMessage(logWindow,`启动应用失败: ${error.message}`);
            dialog.showErrorBox('错误', `启动应用失败: ${error.message}`); // 错误弹窗
            return;
        }

        // 1. 模拟 TAB 键按三次
        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');
      

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');
      

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        // 2. 输入用户提供的文字
        for (const char of userInput) {
            await execCommand(`${adbPath} -s ${deviceId} shell input text ${char}`);
            logMessage(logWindow,`输入字符 ${char} 成功`);
        }

        // 3. 模拟按两次回车
        await execCommand(`${adbPath} -s ${deviceId} shell  input keyevent 66`);
        logMessage(logWindow,'寻找成功 点击中');

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 66`);
        logMessage(logWindow,'寻找成功 点击中');


    } catch (error) {
        logMessage(logWindow,`操作失败: ${error.message}`);
    }
};


// **执行 Python 脚本 VCB2**
const executeVCB2 = (android_id, click_positions) => {
    // Python 脚本路径（当前目录下的 VCB.py）
    const scriptPath = path.join(__dirname, "VCB.py");

    return new Promise((resolve, reject) => {


        console.log(`VCB2 Received android_id: ${android_id}, click_positions: click_positions`);
        // 调用 Python 脚本，并传递 android_id 参数
        const pythonProcess = spawn("python", [scriptPath, 'zhixing', android_id, click_positions]);

        let output = "";
        let error = "";

        // 监听 Python 标准输出
        pythonProcess.stdout.on("data", (data) => {
            const message = data.toString().trim();
            console.log(`Python stdout: ${message}`); // 打印每次的标准输出内容
            output += message + "\n"; // 累加到 output
        });

        // 监听 Python 错误输出
        pythonProcess.stderr.on("data", (data) => {
            const errorMessage = data.toString().trim();
            console.error(`Python stderr: ${errorMessage}`); // 打印每次的错误输出内容
            error += errorMessage + "\n"; // 累加到 error
        });

        // 监听 Python 脚本结束事件
        pythonProcess.on("close", (code) => {
            if (code === 0) {
                console.log(`Python script finished successfully:\n${output}`);
                resolve(output.trim()); // 返回 Python 脚本的输出结果
            } else {
                console.error(`Python script failed with error:\n${error}`);
                reject(new Error(`Python script failed with code ${code}: ${error}`));
            }
        });

        // 捕获其他异常
        pythonProcess.on("error", (err) => {
            console.error(`Failed to start Python script: ${err.message}`);
            reject(new Error(`Failed to start Python script: ${err.message}`));
        });
    });
};

module.exports = { openVCB , executeVCB2 };
