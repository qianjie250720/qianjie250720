const { exec } = require("child_process");
const { dialog } = require("electron");
const logger = require("./logger");

const { showSingleInputBox } = require("./showInputBox.js");
const { autoTypeString } = require("./auto-type.js");
const { getDeviceConfig, setDeviceConfig } = require("./config-utils.js");


const adbPath = "adb"; // 确保你的 ADB 路径正确

// **延迟函数**
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const execCommand = async (command, logger) => {
    return new Promise((resolve, reject) => {
        exec(command, (error, stdout, stderr) => {
            if (error) {
                console.error(`命令失败: ${error.message}`);
                reject(error);
            } else {
                console.log(`命令成功: ${stdout.trim()}`);
                resolve(stdout.trim());
            }
        });
    });
};

const logMessage = (logWindow, message) => {
    if (logWindow && logWindow.webContents) {
        logWindow.webContents.send("log-message", message);
    }
};
// **VTB 登录**
const vtbLogin = async (logWindow,{ android_id,androidWidth, androidHeight, StatusBarHeight, NavigationBarHeight }) => {
    logMessage(logWindow,'VTB登录');

    

    // 显示输入框
    const userInput = await showSingleInputBox({
        title: '请输入登录内容',
        message: '请输入内容',
    });

    if (!userInput) {
        logMessage(logWindow,'未提供输入内容');
    
        dialog.showErrorBox('错误', '未提供输入内容，请重新操作！');
        return;
    }

    logMessage(logWindow,`输入内容: ${userInput}`);
 
    const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    try {

        const config = getDeviceConfig(android_id);

        if (!config || !config.connectIp) {
            logMessage(logWindow, "❌ 设备未找到，请检查配置！");
            return;
        }

        const deviceId = config.connectIp;

        await execCommand(`${adbPath}  -s ${deviceId} shell input keyevent 61`);
        await execCommand(`${adbPath}  -s ${deviceId} shell input keyevent 61`);
        await execCommand(`${adbPath}  -s ${deviceId} shell input keyevent 61`);
        await execCommand(`${adbPath}  -s ${deviceId} shell input keyevent 61`);

        await delay(2000); // 等待 2 秒

        const phoneParams = {
            screenWidth: androidWidth,
            screenHeight: androidHeight,
            navBarHeight: NavigationBarHeight
        };


        autoTypeString(logWindow,deviceId,userInput, phoneParams);

        await delay(2000); // 等待 2 秒

        const halfX = Math.round(androidWidth * 0.1); // 左边 50%

        await execCommand(`${adbPath}  -s ${deviceId} shell input keyevent 61`);
        await execCommand(`${adbPath}  -s ${deviceId} shell input keyevent 61`);
        await execCommand(`${adbPath}  -s ${deviceId} shell input keyevent 61`);
        await execCommand(`${adbPath}  -s ${deviceId} shell input keyevent 66`);

    } catch (error) {
        logMessage(logWindow,`操作失败: ${error.message}`);
        
    }
};

// **VTB 输入金额**
const vtbEnterAmount = async (logWindow,more,{ android_id,androidWidth, androidHeight }) => {

    // 显示输入框
    const money = await showSingleInputBox({
        title: '请输入转账金额',
        message: '请输入内容',
    });

    if (!money) {
     
        logMessage(logWindow,'未提供输入内容');
        dialog.showErrorBox('错误', '未提供输入内容，请重新操作！');
        return;
    }

    console.log(`User Input: ${money}`);
    logger.info(`User Input: ${money}`);



    const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));


    try {

        const config = getDeviceConfig(android_id);

        if (!config || !config.connectIp) {
            logMessage(logWindow, "❌ 设备未找到，请检查配置！");
            return;
        }

        const deviceId = config.connectIp;

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        if(more==1){
            await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        }
        await delay(2000); // 等待 2 秒

        // 2. 输入用户提供的文字
        for (const char of money) {
            await execCommand(`${adbPath} -s ${deviceId} shell input text ${char}`);
            logMessage(logWindow,`输入字符 ${char} 成功`);
        }

        await delay(2000); // 等待 2 秒

        const halfX = Math.round(androidWidth * 0.5); // 左边 50%
        const y = Math.round(androidHeight * 0.2);
        // await execCommand(`${adbPath} -s ${deviceId} shell input tap ${halfX} ${y}`);

        // for (let percentage = 10; percentage <= 20; percentage += 5) {
        //     const y = Math.round(androidHeight * (percentage / 100));
        //     console.log(`点击坐标: (${halfX}, ${y})`);
        //     await execCommand(`${adbPath} -s ${deviceId} shell input tap ${halfX} ${y}`);
        // }
        await execCommand(`${adbPath}  -s ${deviceId} shell input keyevent 4`);




        await delay(2000); // 等待 2 秒

        for (let percentage = 70; percentage <= 90; percentage += 5) {
            const y = Math.round(androidHeight * (percentage / 100));
            console.log(`点击坐标: (${halfX}, ${y})`);
            await execCommand(`${adbPath} -s ${deviceId} shell input tap ${halfX} ${y}`);
        }

    } catch (error) {
        logMessage(logWindow,`操作失败: ${error.message}`);
    }
};




// **VTB 输入验证码**
const vtbEnterVerificationCode = async (logWindow,{ android_id, androidWidth, androidHeight }) => {
    // 显示输入框
    const yzm = await showSingleInputBox({
        title: '请输入验证码',
        message: '请输入内容',
    });

    if (!yzm) {
        logMessage(logWindow,'未提供输入内容');
        dialog.showErrorBox('错误', '未提供输入内容，请重新操作！');
        return;
    }

    logMessage(logWindow,`输入内容: ${yzm}`);

    const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

    try {

        const config = getDeviceConfig(android_id);

        if (!config || !config.connectIp) {
            logMessage(logWindow, "❌ 设备未找到，请检查配置！");
            return;
        }

        const deviceId = config.connectIp;

        // 2. 输入用户提供的文字
        for (const char of yzm) {
            await execCommand(`${adbPath} -s ${deviceId} shell input text ${char}`);
            logMessage(logWindow,`输入字符 ${char} 成功`);
        }

        await delay(2000); // 等待 2 秒

        const halfX = Math.round(androidWidth * 0.5); // 左边 50%

        for (let percentage = 70; percentage <= 90; percentage += 5) {
            const y = Math.round(androidHeight * (percentage / 100));
            console.log(`点击坐标: (${halfX}, ${y})`);
            await execCommand(`${adbPath} -s ${deviceId} shell input tap ${halfX} ${y}`);
        }


    } catch (error) {
        logMessage(logWindow,`操作失败: ${error.message}`);
    }
};

module.exports = { vtbLogin, vtbEnterAmount, vtbEnterVerificationCode };
