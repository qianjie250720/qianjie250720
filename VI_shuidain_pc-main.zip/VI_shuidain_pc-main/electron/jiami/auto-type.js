// auto-type.js

const { execSync } = require('child_process');

// 延迟函数，返回一个 promise，指定 ms 后 resolve
function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

/////////////////////////////////////////////
// 字母键盘的布局（alpha）
//
// 注意：
// 第一排：Q W E R T Y U I O P，共 10 个键，每个占 1 单位
// 第二排：A S D F G H J K L（实际9个），左右各预留 0.5 单位，所以以数组方式为：
//         [0.5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0.5]
// 第三排：SHIFT, Z, X, C, V, B, N, M, DEL，权重为 [1.5,1,1,1,1,1,1,1,1.5]
// 第四排：SYM, comma, space, dot, HIDE，权重为 [1.5,1,4.3,1,2.2]
/////////////////////////////////////////////
const alphaLayout = [
  // 第一排
  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
  // 第二排（预留左右各0.5）
  [0.5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0.5],
  // 第三排
  [1.5, 1, 1, 1, 1, 1, 1, 1, 1.5],
  // 第四排
  [1.5, 1, 4.3, 1, 2.2]
];

const alphaKeys = [
  // 第一排：10个
  ['q','w','e','r','t','y','u','i','o','p'],
  // 第二排：11项（两侧预留空位）
  ['_empty','a','s','d','f','g','h','j','k','l','_empty'],
  // 第三排：9项
  ['SHIFT','z','x','c','v','b','n','m','DEL'],
  // 第四排：5项
  ['SYM','comma','space','dot','HIDE']
];

/////////////////////////////////////////////
// 数字/符号键盘的布局（symbol）
//
// 假设符号键盘有 5 行
/////////////////////////////////////////////
const symbolLayout = [
  // 第一排：数字 1~0
  [1,1,1,1,1,1,1,1,1,1],
  // 第二排：@,#,$,%,&,*,-,+,(,)
  [1,1,1,1,1,1,1,1,1,1],
  // 第三排：~,^,<,>,|,\,{,},[,]
  [1,1,1,1,1,1,1,1,1,1],
  // 第四排：=,!,",',:,;,/,?,DEL(2)；这里简化表示为 8键+DEL(2)=10 单位
  [1,1,1,1,1,1,1,1,2],
  // 第五排：ABC, comma, backtick, space, underscore, dot, HIDE
  [1.2,1,1,3,1,1,1.8]
];

const symbolKeys = [
  ['1','2','3','4','5','6','7','8','9','0'],
  ['@','#','$','%','&','*','-','+','(',')'],
  ['~','^','<','>','|','\\','{','}','[',']'],
  ['=','!','"',"'",':',';','/','?','DEL'],
  ['ABC',',','`',' ','_','.','HIDE']
];


/////////////////////////////////////////////
// 核心：getKeyCoordinate()
// 计算目标键的中心坐标
//
// 参数：
//   - screenWidth, screenHeight, navBarHeight
//   - keyboardType: 'alpha' 或 'symbol'
//   - targetKey: 要点击的键 (例如 'q' 或 'a' 或 'SHIFT' 等)
/////////////////////////////////////////////
function getKeyCoordinate({ 
  screenWidth, 
  screenHeight,
  navBarHeight, 
  keyboardType,   // 'alpha' 或 'symbol'
  targetKey 
}) {
  // 1) 选择对应布局
  let layoutRows, layoutKeys;
  if (keyboardType === 'symbol') {
    layoutRows = symbolLayout;
    layoutKeys = symbolKeys;
  } else {
    layoutRows = alphaLayout;
    layoutKeys = alphaKeys;
  }
  
  // 2) 计算键盘区域
  // 我们假设键盘占用“可用高度”的 35%
  const availableHeight = screenHeight - navBarHeight;
  const keyboardHeight = availableHeight * 0.35;
  
  // 3) 关于垂直方向的处理
  // 对于符号键盘：行数 = 布局数组实际行数（这里为5）。
  // 对于字母键盘：原有字母键盘只有4行，
  //    但按照要求它在符号键盘中从第二行开始布局，
  //    因此我们统一使用符号键盘的5等分来划分键盘区域，
  //    同时令字母键盘的有效行索引 = foundRow + 1.
  let totalRows, effectiveRowIndex;
  if (keyboardType === 'symbol') {
    totalRows = layoutRows.length;  // 例如 5
  } else {
    totalRows = 5;  // 强制按照5行划分
  }
  
  // 键盘顶部 y（键盘区域在屏幕底部）
  const keyboardTopY = screenHeight - navBarHeight - keyboardHeight;
  const rowHeight = keyboardHeight / totalRows;
  
  // 4) 在“水平”方向，对应行的权重数组（假设每行总权重为10）
  // 并找出目标键所在的行、列（对于字母键盘 targetKey 如 q、a 等
  // 注意：如果所在行中有空键，例如第二排的 _empty，则不会匹配目标键）
  let foundRow = -1, foundCol = -1;
  for (let r = 0; r < layoutKeys.length; r++) {
    const row = layoutKeys[r];
    const colIndex = row.indexOf(targetKey);
    if (colIndex !== -1) {
      foundRow = r;
      foundCol = colIndex;
      break;
    }
  }
  
  if (foundRow === -1 || foundCol === -1) {
    // 没找到按键
    return { x: -1, y: -1 };
  }
  
  // 如果是字母键盘，则调整有效行索引（下移一行）
  if (keyboardType === 'alpha') {
    effectiveRowIndex = foundRow + 1;
  } else {
    effectiveRowIndex = foundRow;
  }
  
  // 计算该行的垂直中心：用整体5分之一的区间来划分
  const rowTop = keyboardTopY + effectiveRowIndex * rowHeight;
  const rowBottom = rowTop + rowHeight;
  const keyCenterY = Math.floor((rowTop + rowBottom) / 2);
  
  // 5) 计算水平 x 坐标
  // 取当前行的权重数组
  const rowWeights = layoutRows[foundRow];
  const sumWeight = rowWeights.reduce((acc, w) => acc + w, 0); // 理论上应等于10
  const unitWidth = screenWidth / sumWeight;
  
  let weightBefore = 0;
  for (let i = 0; i < foundCol; i++) {
    weightBefore += rowWeights[i];
  }
  const currentWeight = rowWeights[foundCol];
  const keyX1 = weightBefore * unitWidth;
  const keyX2 = (weightBefore + currentWeight) * unitWidth;
  const keyCenterX = Math.floor((keyX1 + keyX2) / 2);
  
  return { x: keyCenterX, y: keyCenterY };
}


/////////////////////////////////////////////
// tapKey：用 adb 点击指定键
/////////////////////////////////////////////
async function tapKey(deviceId,keyName, phoneParams, currentKb) {
  const { x, y } = getKeyCoordinate({
    ...phoneParams,
    keyboardType: currentKb,
    targetKey: keyName
  });
  if (x >= 0 && y >= 0) {
    const adbCmd = `adb -s ${deviceId} shell input tap ${x} ${y}`;
    console.log(`点击 ${keyName} => ${adbCmd}`);
    execSync(adbCmd);
  } else {
    console.log(`找不到键 ${keyName} 的坐标`);
  }
   // 延时 500 毫秒
   await delay(500);
}


// 辅助函数：判断字符类型（简单分类）
function getCharType(ch) {
  if (/[A-Z]/.test(ch)) return 'upper';
  if (/[a-z]/.test(ch)) return 'lower';
  if (/[0-9]/.test(ch)) return 'digit';
  return 'symbol';
}


const logMessage = (logWindow, message) => {
    if (logWindow && logWindow.webContents) {
        logWindow.webContents.send("log-message", message);
    }
};

/////////////////////////////////////////////
// autoTypeString：根据输入字符串依次点击相应按键
/////////////////////////////////////////////
function autoTypeString(logWindow,deviceId,inputStr, phoneParams) {
  // currentMode: 'alpha' 或 'symbol'
  let currentMode = 'alpha';
  for (let i = 0; i < inputStr.length; i++) {
    
    const ch = inputStr[i];
    logMessage(logWindow,'正在输入密码'+ch);
    const type = getCharType(ch);
    if (type === 'upper') {
      if (currentMode !== 'alpha') {
        tapKey(deviceId,'ABC', phoneParams, 'symbol');
        currentMode = 'alpha';
      }
      tapKey(deviceId,'SHIFT', phoneParams, 'alpha');
      tapKey(deviceId,ch.toLowerCase(), phoneParams, 'alpha');
    } else if (type === 'lower') {
      if (currentMode !== 'alpha') {
        tapKey(deviceId,'ABC', phoneParams, 'symbol');
        currentMode = 'alpha';
      }
      tapKey(deviceId,ch, phoneParams, 'alpha');
    } else if (type === 'digit' || type === 'symbol') {
      if (currentMode !== 'symbol') {
        tapKey(deviceId,'SYM', phoneParams, 'alpha');
        currentMode = 'symbol';
      }
      tapKey(deviceId,ch, phoneParams, 'symbol');
    }
  }
}

module.exports = {
  autoTypeString,
  tapKey,
  getKeyCoordinate
};
