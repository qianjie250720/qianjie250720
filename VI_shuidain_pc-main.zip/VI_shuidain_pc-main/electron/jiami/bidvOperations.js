const {ipcMain, BrowserWindow } = require("electron");
const logger = require("./logger");
const { getDeviceConfig, setDeviceConfig } = require("./config-utils.js");
const path = require('path');
const { exec, spawn } = require('child_process');

const adbPath = "adb";
const scrcpyPath = "scrcpy";

const {
  killAllAdbConnections,
  adbConnect,
  showFullPairingForm,
  startScrcpy
} = require("./adbManager");


// 记录日志
const logMessage = (logWindow, message) => {
  if (logWindow && logWindow.webContents) {
    logWindow.webContents.send("log-message", message);
  }
};

const clearMessage = (logWindow) => {
  if (logWindow && logWindow.webContents) {
    logWindow.webContents.send("clear-message");
  }
};

// **启动 scrcpy**
const openScrcpy = async (logWindow, android_id) => {
  clearMessage(logWindow)

  // createLogWindow(mainWindow)
  logMessage(logWindow, `📡 开始启动，设备 ID: ${android_id}`);

  const config = getDeviceConfig(android_id);
  if (config && config.connectIp) {
    logMessage(logWindow, `🔎 已保存的连接记录: ${config.connectIp}`);

    logMessage(logWindow, `=======开始连接历史记录请稍等======`);

    adbConnect(logWindow, config.connectIp, android_id, (connected) => {
      if (connected) {
        logMessage(logWindow, "✅ 直接连接成功，启动");
        startScrcpy(logWindow, config.connectIp);
      } else {
        logMessage(logWindow, logWindow, "❌ 直接连接失败，弹出配对输入框");
        showFullPairingForm(logWindow, android_id, (pairSuccess) => {
          if (pairSuccess) {
            const newConfig = getDeviceConfig(android_id);
            logMessage(logWindow, "✅ 设备配对 + 连接成功");
            startScrcpy(logWindow, newConfig.connectIp);
          } else {
            logMessage(logWindow, "❌ 设备连接失败");
          }
        });
      }
    });
  } else {
    logMessage(logWindow, "❌ 没有连接记录，弹出输入框");
    showFullPairingForm(logWindow, android_id, (pairSuccess) => {
      if (pairSuccess) {
        const newConfig = getDeviceConfig(android_id);
        logMessage(logWindow, "✅ 设备配对 + 连接成功，启动");
        startScrcpy(logWindow, newConfig.connectIp);
      } else {
        logMessage(logWindow, "❌ 设备连接失败");
      }
    });
  }
};





// **关闭无障碍功能**
const closeAccessibility = (logWindow, android_id) => {
  const config = getDeviceConfig(android_id);

  if (!config || !config.connectIp) {
    logMessage(logWindow, "❌ 设备未找到，请检查配置！");
    return;
  }

  const deviceId = config.connectIp;

  // ✅ 先设置为空值
  exec(`${adbPath} -s ${deviceId} shell settings put secure enabled_accessibility_services null`, (error) => {
    if (error) {
      logMessage(logWindow, `❌ 清空无障碍服务失败: ${error.message}`);
      return;
    }

    // ✅ 关闭无障碍功能
    exec(`${adbPath} -s ${deviceId} shell settings put secure accessibility_enabled 0`, (error) => {
      if (error) {
        logMessage(logWindow, `❌ 关闭无障碍功能失败: ${error.message}`);
      } else {
        logMessage(logWindow, `✅ 设备 ${deviceId} 无障碍功能已关闭`);
      }
    });
  });
};


// **开启无障碍功能**
const openAccessibility = (logWindow,android_id) => {
  const config = getDeviceConfig(android_id);

  if (!config || !config.connectIp) {
    logMessage(logWindow,"❌ 设备未找到，请检查配置！");
    return;
  }

  const deviceId = config.connectIp;
  const bao=process.env.BAO

  exec(`${adbPath} -s ${deviceId} shell settings put secure enabled_accessibility_services "com.ven.assists.shuidian/com.ven.assists.AssistsService"`, (error) => {
    if (error) {
      logMessage(logWindow,`❌ 开启无障碍服务失败: ${error.message}`);
      return;
    }

    exec(`${adbPath} -s ${deviceId} shell settings put secure accessibility_enabled 1`, (error) => {
      if (error) {
        logMessage(logWindow,`❌ 开启无障碍功能失败: ${error.message}`);
      } else {
        logMessage(logWindow,`✅ 设备 ${deviceId} 无障碍功能已开启`);
      }
    });
  });
};


// **超级黑屏**
const superHeiping = (logWindow,android_id) => {
  const config = getDeviceConfig(android_id);

  if (!config || !config.connectIp) {
    logMessage(logWindow,"❌ 设备未找到，请检查配置！");
    return;
  }

  const deviceId = config.connectIp;

  const scrcpyArgs = `-s ${deviceId} --max-size 800 --video-bit-rate 2M --max-fps 30 --turn-screen-off`;
  const command = `${scrcpyPath} ${scrcpyArgs}`;

  exec(command, (error) => {
    if (error) {
      logMessage(logWindow,`❌ scrcpy 运行失败: ${error.message}`);
      return;
    }
    logMessage(logWindow,"✅ scrcpy 运行成功");
  });
};

module.exports = { closeAccessibility, openAccessibility, openScrcpy, superHeiping };
