<script>
	export default {
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style>
	@font-face {
	  font-family: 'MyCustomFont';
	  src: url('/static/OpenSans-VariableFont_wdth,wght.ttf') format('truetype');
	}
	
	body {
	  font-family: 'MyCustomFont', sans-serif; /* 全局字体设置 */
	}
</style>
