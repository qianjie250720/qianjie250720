<template>
	<view class="container">
		<!-- 页面主体内容 -->
		<view class="main-content">
			<slot></slot>
		</view>

		<!-- 自定义底部菜单 -->
		<view class="custom-tabbar">
			<!-- 下凹的 SVG 背景 -->
			<view class="tabbar-bg">
				<svg viewBox="0 0 100 68" preserveAspectRatio="none">
					<path fill="#ffffff" stroke="#F3F4F6" stroke-width="1" d="M0,0
H15
C28,0 36,0 42,28
C46,42 54,42 58,28
C64,0 72,0 85,0
H100
V68
H0
Z" />
				</svg>
			</view>

			<!-- 左边两个按钮 -->
			<view class="tabbar-left">
				<view v-for="(item, idx) in leftTabs" :key="idx" class="tab-item" :class="{ active: current === idx }"
					@click="switchTab(item.pagePath, idx)">
					<image :src="current === idx ? item.selectedIconPath : item.iconPath" class="tab-icon" />
					<text class="tab-text">{{ item.text }}</text>
				</view>
			</view>

			<!-- 中间凸出按钮 -->
			<view class="tabbar-middle">
				<view class="middle-button" @click="switchTab(middleTab.pagePath, 2)">
					<view class="middle-circle">
						<image :src="current === 2 ? middleTab.selectedIconPath : middleTab.iconPath"
							class="middle-icon" />
					</view>
				</view>
			</view>

			<!-- 右边两个按钮 -->
			<view class="tabbar-right">
				<view v-for="(item, idx) in rightTabs" :key="idx + 3" class="tab-item"
					:class="{ active: current === idx + 3 }" @click="switchTab(item.pagePath, idx + 3)">
					<image :src="current === (idx + 3) ? item.selectedIconPath : item.iconPath" class="tab-icon" />
					<text class="tab-text">{{ item.text }}</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'tabBar',
		props: {
			current: {
				type: Number,
				default: 0
			}
		},
		data() {
			return {
				timer: null,
				tabList: [{
						"pagePath": "pages/index/index",
						"text": "Trang chủ",
						"iconPath": "/static/tabs/1.png",
						"selectedIconPath": "/static/tabs/1_s.png"
					},
					{
						"pagePath": "pages/free/free",
						"text": "Quan tâm",
						"iconPath": "/static/tabs/2.png",
						"selectedIconPath": "/static/tabs/2_s.png"
					},
					{
						"pagePath": "pages/marketQuotations/marketQuotations",
						"text": "Thị trường",
						"iconPath": "/static/tabs/3.png",
						"selectedIconPath": "/static/tabs/3_s.png"
					},
					{
						"pagePath": "pages/position/position",
						"text": "Sổ lệnh",
						"iconPath": "/static/tabs/4.png",
						"selectedIconPath": "/static/tabs/4_s.png"
					},
					{
						"pagePath": "pages/my/my",
						"text": "Của tôi",
						"iconPath": "/static/tabs/5.png",
						"selectedIconPath": "/static/tabs/5_s.png"
					}
				]
			}
		},
		computed: {
			// 左 2 个
			leftTabs() {
				return this.tabList.slice(0, 2)
			},
			// 中间 1 个
			middleTab() {
				return this.tabList[2]
			},
			// 右 2 个
			rightTabs() {
				return this.tabList.slice(3)
			}
		},
		methods: {
			switchTab(path, index) {
				this.current = index
				uni.navigateTo({
					url: '/' + path
				})
			},
			
		}
	}
</script>

<style scoped>
	/* 布局骨架 */
	.container {
		position: relative;
		height: 20vh;
		display: flex;
		flex-direction: column;
	}

	.main-content {
		flex: 1;
		overflow: auto;
	}

	/* 底部导航容器 */
	.custom-tabbar {
		position: fixed;
		bottom: 0;
		left: 0;
		right: 0;
		height: 68px;
		background-color: transparent;
		/* 让 SVG 背景可见 */
		z-index: 1000;
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding-bottom: env(safe-area-inset-bottom);
		/* iPhone 安全区 */
	}

	/* SVG 凹槽背景 */
	.tabbar-bg {
		position: absolute;
		top: 0;
		left: 0;
		right: 0;
		height: 68px;
		z-index: -1;
	}

	.tabbar-bg svg {
		width: 100%;
		height: 100%;
	}

	/* 左容器，放左2个菜单 */
	.tabbar-left {
		display: flex;
		flex-direction: row;
		align-items: center;
		justify-content: space-around;
		width: 40%;
		/* 可根据需要调节 */
	}

	/* 中容器，纯粹放凸起按钮 */
	.tabbar-middle {
		position: relative;
		width: 0;
		/* 不参与分配宽度，让左右能平均排布 */
	}

	/* 右容器，放右2个菜单 */
	.tabbar-right {
		display: flex;
		flex-direction: row;
		align-items: center;
		justify-content: space-around;
		width: 40%;
		/* 可根据需要调节 */
	}

	/* 单个 tab-item 样式 */
	.tab-item {
		width: 50%;
		/* 两个在各自的 35% 容器里，再平均分 */
		display: flex;
		flex-direction: column;
		align-items: center;
		font-size: 12px;
		color: #999;
	}

	.tab-item.active {
		color: #EA5A40;
	}

	.tab-icon {
		width: 24px;
		height: 24px;
		margin-bottom: 5px;
	}

	/* 凸出按钮 */
	.middle-button {
		position: absolute;
		bottom: 0px;
		left: 50%;
		transform: translateX(-50%);
		z-index: 2;
	}

	.middle-circle {
		width: 50px;
		height: 50px;
		background-color: white;
		border-radius: 50%;
		box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.middle-icon {
		width: 46px;
		height: 46px;
	}
</style>