<template>
	<view style="background-color: #F8F8F8;min-height: 100vh;">
		<view>

			<view class="flex flex-b padding-20 padding-top-20" style="padding-top: 48rpx;color: #fff;">
				<image src="/static/arrow_left.png" mode="aspectFit" style="width: 20px;height: 24rpx;" @tap="goBack()">
				</image>
				<view style="flex:1;text-align: center;color: #EA5A40;font-size: 28rpx;font-weight: 700;">
					Tìm kiếm
				</view>
			</view>


			<view class="input_wrapper" style="margin:12rpx 24rpx;box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;">
				<input placeholder="Nhập tên cổ phiếu/ mã" type="text" v-model="value"
					:placeholderStyle="$theme.setPlaceholder()"></input>
				<image src="/static/sousuo.png" mode="aspectFit" style="width: 36rpx;height: 36rpx;margin-left: auto;"
					@click="searchButton()">
				</image>
			</view>

			<!-- <view class="jump-search">
				<image src="../../static/sousuo.png" mode=""></image>
				<view class="function">
					<input type="text" class="code" placeholder='Nhập tên cổ phiếu/ mã' v-model="value"
						:placeholderStyle="$theme.setPlaceholder()">
					<view class="button" @click="searchButton()">Tìm kiếm</view>
				</view>
			</view> -->
		</view>
		<view v-if="!searchList || searchList.length<=0">
			<view style="display: flex;align-items: center;justify-content: center;margin-top: 30%;">
				<image src="/static/zanwujilu.png" style="width: 180px;height: 140px;"></image>
				
			</view>
			<view style="text-align: center;margin-top: 20px;font-weight: 600;">Không có lịch sử tìm kiếm</view>
		</view>
		<view v-else>
			<view class="padding-20 margin-10 radius10 flex flex-b" v-for="(item,index) in searchList" :key="index"
				@tap="detailed(item.name)"
				style="box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(27, 31, 35, 0.15) 0px 0px 0px 1px;">
				<view class="flex">
					<view class="bold" style="color: #000;">{{item.name}}</view>
				</view>
				<view class="flex gap20">
					<view :style="{ color:item.rate === 0 ?'#d7e500' : (item.rate > 0 ? '#43c776' :'#ff0000') }">{{toThousandFilter(item.current_price)}} </view>
					<view :style="{ color:item.rate === 0 ?'#d7e500' : (item.rate > 0 ? '#43c776' :'#ff0000') }">{{item.rate}}%</view>
				</view>
			</view>
		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				searchList: '',
				value: '',
				pager: {
					page: 1,
					limit: 20
				}
			};
		},
		onReachBottom() {
			this.status = 'loading';
			this.pager.page++;
			this.searchButton()
		},
		methods: {
			// 根据当前平台，执行回退方式
			goBack() {
				/*#ifdef APP-PLUS*/
				uni.navigateBack({
					delta: 1
				});
				/*#endif*/

				/*#ifdef H5*/
				history.back();
				/*#endif*/
			},
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,')
			},
			detailed(gid) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/marketQuotations/productDetails' + `?gid=${gid}`
				});
				// console.log(gid, "携带");
			},
			//搜索
			async searchButton() {
				if (this.value == '') {
					uni.$u.toast('Không được để trống trong tìm kiếm');
					// let list = await this.$http.post('api/product/list', {
					// 	key: this.value,
					// 	page: this.pager.page,
					// 	limit: this.pager.limit,
					// })
					// console.log(this.pager.page, '=== >this.pager.page');
					// if (this.pager.page > 1) {
					// 	this.searchList = [...this.searchList, ...list.data.data]
					// } else {
					// 	this.searchList = ''
					// 	this.searchList = list.data.data
					// }
					// if (list.data.data.length < this.pager.limit) {
					// 	this.status = 'nomore'
					// }
					// // console.log(this.searchList);
					// uni.$u.toast('正在加载中...');
				} else {
					// console.log(1111);
					// uni.$u.toast('搜索中,请稍等...');
					uni.showLoading({
						title: "Đang tải...",
						mask: true, // 显示透明蒙层，防止触摸穿透
					});
					let list = await this.$http.post('api/product/list', {
						key: this.value,
						page: 1,
						limit: 9999999,
					})
					this.searchList = list.data.data
					uni.hideLoading();
					uni.showLoading({
						title: "Đang tải...",
						mask: true, // 显示透明蒙层，防止触摸穿透
					});
					// uni.$u.toast('正在加载中...');
					setTimeout(() => {
						uni.hideLoading();
					}, 2000)
					// uni.$u.toast('加载完成');
				}

			},
			mounted() {
				// this.searchButton()
			},
			onShow() {
				// this.searchButton()
			}
		}
	}
</script>

<style lang="scss">

</style>