<template>
	<!-- 登录 -->
	<view class="page_bg" style="min-height: 100vh;">
		<!-- <view class="head-background">
			<view class="head-image" @tap="home()">
			</view>
		</view> -->
		<view style="display: flex;align-items: center;padding-top: 60px;" class="justify-center">
			<image src="/static/logo.png" mode="widthFix" style="width: 240rpx;"></image>
		</view>

		<view class="padding-25 margin-top-10">
			<view
				style="display: flex;align-items: center;border: 1px #F3F4F6 solid;width: 90%;margin-left: 5%;border-radius: 8px;background: #F3F4F6;">
				<view class="flex-1 bold text-center"
					style="font-size: 15px;padding:10px;color: #EA5A40;border-radius: 8px;background-color: #fff;">
					Đăng nhập
				</view>
				<view class="flex-1  text-center" style="font-size: 15px;color:#000;background: #F3F4F6;padding:10px;"
					@tap="register()">
					Mở tài khoản
				</view>
			</view>

			<view
				style="background-color: #fff;border-radius: 8px;padding: 20px;margin-top: 20px;box-shadow: #F7F7F7 0px 6px 24px 0px, rgba(0, 0, 0, 0.08) 0px 0px 0px 1px;">

				<view class="flex gap5">
					<image src="/static/zhanghu.png" mode="widthFix" style="width: 14px;"></image>
					<view class="bold font-size-14 text-center">Tài khoản</view>
				</view>
				<view style="border-bottom: 1px solid #CACACA;">
					<input placeholder='Vui lòng nhập tài khoản' v-model="value1" type="text"
						style="color: #000;margin-top: 10px;width: 90%;" :placeholderStyle="$theme.setPlaceholder()" />
				</view>
				<view class="input-field margin-top-25">
					<view class="flex gap5">
						<image src="/static/mima.png" mode="widthFix" style="width: 14px;"></image>
						<view class="bold font-size-14 text-center">Mật khẩu</view>
					</view>
					<view style="border-bottom: 1px solid #CACACA;display: flex;align-items: center;">
						<template v-if="isMask">
							<input type="password" placeholder='Vui lòng nhập mật khẩu' v-model="value2"
								style="color: #000;margin-top: 10px;width: 90%;"
								:placeholderStyle="$theme.setPlaceholder()" />
						</template>
						<template v-else>
							<input type="text" placeholder='Vui lòng nhập mật khẩu' v-model="value2"
								style="color: #000;margin-top: 10px;width: 90%;"
								:placeholderStyle="$theme.setPlaceholder()" />
						</template>
						<image :src="`/static/${isMask?'hide':'show'}_gray.png`" mode="aspectFit"
							style="width: 32rpx;height: 32rpx;margin-left: auto;padding-right: 12rpx;"
							@click="toggleMask()">
						</image>

					</view>
				</view>
			</view>

			<view style="padding-top: 24rpx;">
				<u-checkbox-group>
					<u-checkbox shape="" activeColor="#EA5A40" label="Tôi đồng ý với thỏa thuận bảo vệ dữ liệu cá nhân."
						v-model="isAgree" labelColor="#CCC" labelSize="12px" @change="changeAgree" :checked="isAgree"
						iconColor="#FFF"></u-checkbox>
				</u-checkbox-group>
			</view>
			<!-- <view style="color: #000;text-align: right;padding-top: 12rpx;font-size: 24rpx;" @click="forget()">Quên mật
				khẩu？</view> -->
		</view>


		<view class="btn_common" style="font-size: 32rpx;width: 80%;margin: 10rpx auto;line-height: 64rpx;"
			@click="gain_login">
			Đăng nhập
		</view>

		<view @click="showPopup"
			style="display: flex;align-items: center;justify-content: space-between;padding: 0 20px;margin-top: 40px;color: #EA5A40;font-weight: 700;">
			<view>Quên mật khẩu? </view>
			<view>Liên hệ bộ phận Chăm Sóc Khách Hàng</view>
		</view>
		<view v-if="showModal" class="modal-mask" @click="hidePopup">

			<view class="modal-content" @click.stop>
				<view @click="hidePopup" style="text-align: right;"> <text style="font-size: 20px;font-weight: 700;margin-bottom: 10px;">X</text> </view>
				<image src="/static/viber.jpg" mode="heightFix" style="height: 400px;" ></image>
				
			</view>
		</view>
		
		
		
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				value1: "",
				value2: '',
				isMask: true,
				isAgree: false,
				showModal: false,
			};
		},
		onShow() {
			// console.log(`login in!`);
			this.isMask = uni.getStorageSync('mask');
			this.changeAgree(this.isAgree);
		},
		methods: {
			showPopup() {
				this.showModal = true;
			},
			hidePopup() {
				this.showModal = false;
			},

			// 勾选用户隐私协议
			changeAgree(e) {
				this.isAgree = e;
			},
			// 显隐掩码
			toggleMask() {
				this.isMask = !this.isMask;
				uni.setStorageSync('mask', this.isMask);
			},
			//忘记密码
			forget() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/logon/forgot/forgot'
				});
			},
			// 跳转到注册
			register() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/logon/register/register'
				});
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			//登录
			async gain_login() {
				if (!this.isAgree) {
					uni.showToast({
						title: `Chọn đồng ý chính sách`,
						icon: 'none'
					})
					return false;
				}

				let list = await this.$http.post('api/app/login', {
					username: this.value1,
					password: this.value2,
				})
				if (list.data.code == 0) {
					const token = list.data.data.token.access_token
					uni.setStorageSync('token', token);
					uni.$u.toast('Đăng nhập thành công');
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/index/index',
						});
						this.$router.go(0)
					}, 500)

				} else {
					uni.$u.toast(list.data.message);
				}
			},
			// //数据请求
			// async login_liufu() {
			// 	try {
			// 		uni.removeStorageSync('url');
			// 	} catch (e) {}
			// 	let list = await this.$http.get(
			// 		'https://sm8-x8ax6-b574-u99hy-w4uv-dgm4-s-p-c.oss-cn-hongkong.aliyuncs.com/sotck-S1GT9GYprH0PVgMLwapC0nYzLAoDa0bd.txt', {
			// 			// language: this.$i18n.locale
			// 		})
			// 	// 接口域名
			// 	console.log(list.data, '接口位置')
			// 	uni.setStorageSync('url', list.data);
			// },

		},

		// async mounted() {
		// 	// await this.login_liufu()
		// }

	}
</script>

<style lang="scss">
	.modal-mask {
		position: fixed;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		background-color: rgba(0, 0, 0, 0.5);
		display: flex;
		justify-content: center;
		align-items: center;
		z-index: 999;
	}

	.modal-content {
		background-color: #fff;
		padding: 20px;
		border-radius: 10px;
		text-align: center;
	}


	.head-background {
		// background-image: url('/static/ad_bg.jpg');
		// background-position: 0 0;
		// background-repeat: no-repeat;
		// background-size: 100% 100%;
		// background-image: linear-gradient(to right, #0841E3, #121327);
		width: 100%;
		// height: 480rpx;
		background-size: 100%;
		margin: 0 auto;
		z-index: -1;
		padding: 20rpx 0 0;
		// border-radius: 0 0 45% 45%/0 0 35% 35%;

		.head-image {
			width: 20rpx;
			height: 20rpx;
			margin: 30rpx;

			image {
				width: 20rpx;
				height: 20rpx;
			}
		}
	}

	.logo {

		text-align: center;
		margin: auto;
		border-radius: 50%;
		margin-top: -250rpx;

		image {
			width: 350rpx;
			height: 200rpx;
			border-radius: 50%;
		}
	}

	.erty {
		text-align: center;
		margin: 100rpx 20rpx 0;

		.input-field {
			display: flex;
			align-items: center;
			background: #f5f5f5;
			border-radius: 10rpx;
			margin: 40rpx 20rpx;
			padding: 20rpx;

			image {
				width: 30rpx;
				height: 30rpx;
			}

			input {
				width: 100%;
				margin-left: 30rpx;
				text-align: left;
				font-size: 32rpx;
			}
		}
	}

	.jump-registration {
		color: #ffb044;
		margin: 0 40rpx;
	}

	.signIn {
		margin: 100rpx 30rpx 30rpx;
		background-image: linear-gradient(to right, #FFB044, #FF2D30);
		border-radius: 10rpx;
		color: #fff;
		font-weight: 800;
		font-size: 32rpx;
		text-align: center;
		padding: 20rpx;
	}
</style>