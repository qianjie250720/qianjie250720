<template>
	<view>
		<view class="flex flex-b padding-20 padding-top-20" style="padding-top: 48rpx;color: #fff;">
			<image src="/static/logo_name.png" mode="widthFix" style="width: 40px;height: 33px;"></image>
			<view style="color:#EA5A40" class="bold font-size-16">Sổ lệnh</view>
			<image src="/static/sousuo.png" mode="widthFix" style="width: 20px;height: 20px;"
				@click="$u.route({url:'/pages/searchFor/searchFor'});"></image>
		</view>

		<view style="padding: 15px;">
			<image src="/static/chicang.png" style="width: 100%;height: 200px;"></image>
			<view class="flex flex-b" style="background-color: #F3F4F6;padding: 5px 10px;font-size: 14px;align-items: center;">
				<view>Tổng tài sản
					<image :src="`/static/mask_${isMask?'show':'hide'}.png`" mode="aspectFit"
						style="width: 32rpx;height: 32rpx;padding-left: 12px;" @click="toggleMask()">
					</image>
				</view>
				<view>{{isMask?`******`:toThousandFilter(userInfo.totalZichan*1+userInfo.holdYingli*1)}}</view>
			</view>
			<view class="flex flex-b" style="background-color: #F7FCFF;padding: 5px 10px;font-size: 14px;">
				<view>Tổng lãi lỗ</view>
				<view>{{isMask?`******`:toThousandFilter(userInformation.holdYingli*1)}}</view>
			</view>
			<view class="flex flex-b" style="background-color: #F3F4F6;padding: 5px 10px;font-size: 14px;">
				<view>Tổng giá trị thị trường</view>
				<view>{{isMask?`******`:toThousandFilter(userInformation.frozen*1)}}</view>
			</view>

			<view class="flex flex-b" style="background-color: #F7FCFF;padding: 5px 10px;font-size: 14px;">
				<view>Sức mua</view>
				<view>{{isMask?`******`:toThousandFilter(userInformation.money*1)}}</view>
			</view>
		</view>
		<view class="margin-10 flex flex-b gap10" style="margin-bottom: 20px;">
			<image src="/static/tixian.png" mode="widthFix" class="flex-1" @click="silver()"
				style="box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;border-radius: 10px;"></image>
			<image src="/static/chongzhi.png" mode="widthFix" class="flex-1" @click="prove()"
				style="box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;border-radius: 10px;"></image>
		</view>

		<view style="background-color: #F3F4F6;height: 5px;"></view>

		<view
			style="display: flex;background-color: #F3F4F6;border-radius: 5px;box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(27, 31, 35, 0.15) 0px 0px 0px 1px;margin-top: 10px;margin:10px 40px;">
			<view class="flex-1 text-center" style="color: #000;padding: 5px;"
				:style="1 === tabs_index ? 'background: #fff;border-radius: 5px;bold;' : ''" @click="changeTabs(1)">Lệnh
				mua</view>
			<view class="flex-1 text-center" style="color: #000;padding: 5px;"
				:style="2 === tabs_index ? 'background: #fff;border-radius: 5px;bold;' : ''" @click="changeTabs(2)">Lệnh
				bán</view>
		</view>

		<!-- list -->
		<view style="padding:24rpx;">
			<view style="display: flex;align-items: center;color:#AAA;font-size: 12px;">
				<view style="flex:0 0 34%;">Mã CK</view>
				<view style="flex:0 0 28%;">
					<view>Giá vốn</view>
					<view>Giá TT </view>
				</view>
				<view style="flex:0 0 16%;">Khối lượng</view>
				<view style="margin-left: auto;">Lãi/lỗ</view>
			</view>
			<block v-for="(item,index) in list" :key="index">
				<view
					style="display: flex;align-items: center;justify-content: space-around; color:#000;padding: 20rpx 0;border-bottom: 1px solid #333;"
					@click="detail(item)">
					<view style="flex:0 0 34%;"><text
							style="font-weight: 900;padding:4rpx;border-radius: 4rpx;color:#121212;font-size: 13px;"
							:style="{backgroundColor:item.status==1?`#12F6B8`:`#FF2D30`}">{{item.status==1?`M`:`B`}}</text>
						<text style="padding-left: 8rpx;">{{item.name}}</text>
					</view>
					<view v-if="item.status==1" style="flex:0 0 25%;font-size: 13px;">
						<view style="color:#3E6EB2;">{{toThousandFilter(item.buyPrice)}}</view>
						<view>{{toThousandFilter(item.currentPrice)}}</view>
					</view>
					<view v-if="item.status==2" style="flex:0 0 25%;font-size: 13px;">
						<view style="color:#3E6EB2;">{{toThousandFilter(item.buyPrice)}}</view>
						<view>{{toThousandFilter(item.sellPrice)}}</view>
					</view>
					<view style="flex:0 0 16%;font-size: 13px;">
						<view style="text-align: center;">{{ toThousandFilter(item.buyQTY )}}</view>
						<template v-if="item.status==2">
							<view style="text-align: center;">
								{{ toThousandFilter(item.sellQTY )}}
							</view>
						</template>
					</view>
					<view style="margin-left: auto;font-size: 13px;">
						<template v-if="item.status==1">
							<view style="text-align: right;" :style="{color: item.buyProfit >0?`#12F6B8`:`#FF2D30`}">
								{{toThousandFilter(item.buyProfit)}}
							</view>
							<view style="text-align: right;"
								:style="{color: item.buyProfitRate >0?`#12F6B8`:`#FF2D30`}">
								{{item.buyProfitRate.toFixed(2)}}%
							</view>
						</template>
						<template v-if="item.status==2">
							<view style="text-align: right;" :style="{color: item.sellProfit >0?`#12F6B8`:`#FF2D30`}">
								{{toThousandFilter(item.sellProfit)}}
							</view>
							<view style="text-align: right;"
								:style="{color: item.sellProfitRate >0?`#12F6B8`:`#FF2D30`}">
								{{item.sellProfitRate.toFixed(2)}}%
							</view>
						</template>
					</view>
				</view>
			</block>
		</view>

		<template v-if="showModal && detailInfo">
			<view class="mask" @tap="handleClose()"></view>
			<view class="modal_wrapper" style="margin-bottom: 90px;">
				<view
					style="background-color:#151517;border-radius: 24rpx ;padding-top:40rpx;padding-bottom: 20rpx;">
					<view style="display: flex;align-items: center;">
						<view style="flex:0 0 10%;"></view>
						<view style="flex: 1;text-align: center;font-size: 32rpx;font-weight: 700;color:#FFFFFF;">
							CHI TIẾT LỆNH
						</view>
						<view style="flex:0 0 10%;" @tap="handleClose()">
							<image src="/static/close.png" mode="aspectFit" style="width: 16px;height: 16px;"></image>
						</view>
					</view>
					<view style="margin-top: 24rx;padding:24rpx;">
						<!-- 股票代码 数量 买入价格 -->
						<view style="display: flex;align-items: center;margin:48rpx 0 0 0;">
							<view style="flex:0 0 33.33%;color:#DBDBDC;font-size: 12px;">Mã CK</view>
							<view style="flex:0 0 33.33%;color:#DBDBDC;text-align: center;font-size: 12px;">Khối lượng
							</view>
							<view style="flex:0 0 33.33%;color:#DBDBDC;text-align: right ;font-size: 12px;">Giá mua
							</view>
						</view>
						<view style="display: flex;align-items: center;padding-bottom: 12rpx;">
							<view style="flex:0 0 33.33%;color:#FFF;">
								<view>{{detailInfo.name}}
									<template v-if="detailInfo.status==1">
										<text style="font-size: 12px;padding-left: 4px;"
											:style="{color: detailInfo.buyProfitRate >0?`#12F6B8`:`#FF2D30`}">
											{{detailInfo.buyProfitRate.toFixed(2)}}%
										</text>
									</template>
									<template v-if="detailInfo.status==2">
										<text style="font-size: 12px;padding-left: 4px;"
											:style="{color: detailInfo.sellProfitRate >0?`#12F6B8`:`#FF2D30`}">
											{{detailInfo.sellProfitRate.toFixed(2)}}%
										</text>
									</template>
								</view>
								<view style="font-size: 11px;">
									{{detailInfo.status==1? detailInfo.buyCT:detailInfo.sellCT}}
								</view>
							</view>
							<view style="flex:0 0 33.33%;color:#FFF;text-align: center;">
								{{toThousandFilter(detailInfo.buyQTY)}}
							</view>
							<view style="flex:0 0 33.33%;color:#DBDBDC;text-align: right;">
								<!-- :class="detailInfo.goods_info.rate>=0?'color-green':'color-red'" -->
								{{toThousandFilter(detailInfo.buyPrice)}}
							</view>
						</view>
						<!-- 个股总金额 盈亏额 现价 -->
						<view style="display: flex;align-items: center;margin:16rpx 0 0 0;">
							<view style="flex:0 0 33.33%;color:#DBDBDC;font-size: 12px;">Tổng vốn</view>
							<view style="flex:0 0 33.33%;color:#DBDBDC;text-align: center;font-size: 12px;">Lãi/Lỗ
							</view>
							<view style="flex:0 0 33.33%;color:#DBDBDC;text-align: right;font-size: 12px;">Giá TT
							</view>
						</view>
						<view style="display: flex;align-items: center;padding-bottom: 12rpx; ">
							<view style="flex:0 0 33.33%;color:#FFF;">
								{{toThousandFilter(detailInfo.buyAmont)}}
							</view>
							<template v-if="detailInfo.status==1">
								<view style="flex:0 0 33.33%;text-align: center;"
									:style="{color: detailInfo.buyProfit >0?`#12F6B8`:`#FF2D30`}">
									{{toThousandFilter(detailInfo.buyProfit)}}
								</view>
							</template>
							<template v-if="detailInfo.status==2">
								<view style="flex:0 0 33.33%;text-align: center;"
									:style="{color: detailInfo.sellProfit >0?`#12F6B8`:`#FF2D30`}">
									{{toThousandFilter(detailInfo.sellProfit)}}
								</view>
							</template>
							<view style="flex:0 0 33.33%;color:#DBDBDC;text-align: right;" v-if="detailInfo.status==1">
								{{toThousandFilter(detailInfo.currentPrice)}}
							</view>
							<view style="flex:0 0 33.33%;color:#DBDBDC;text-align: right;" v-if="detailInfo.status==2">
								{{toThousandFilter(detailInfo.sellPrice)}}
							</view>
							
						</view>

						<!-- 个股现价金额 交易费 杠杆倍数 -->
						<view style="display: flex;align-items: center;margin:16rpx 0 0 0;">
							<view style="flex:0 0 33.33%;color:#DBDBDC;font-size: 12px;">Giá trị TT</view>
							<view style="flex:0 0 33.33%;color:#DBDBDC;text-align: center;font-size: 12px;">Phí giao
								dịch
							</view>
							<view style="flex:0 0 33.33%;color:#DBDBDC;text-align: right;font-size: 12px;">Margin
							</view>
						</view>
						<view style="display: flex;align-items: center;padding-bottom: 12rpx; ">
							<view style="flex:0 0 33.33%;color:#FFF;">
								{{toThousandFilter(detailInfo.total)}}
							</view>
							<view style="flex:0 0 33.33%;color:#FFF;text-align: center;">
								{{toThousandFilter(detailInfo.buyFee)}}
							</view>
							<view style="flex:0 0 33.33%;">
								<view style="color:#DBDBDC;text-align: right;padding-right: 24rpx;">{{detailInfo.lever}}
								</view>
							</view>
						</view>

						<view style="display: flex;align-items: center;margin-top: 80rpx;justify-content: center;">
							<!-- 卖出 -->
							<template v-if="detailInfo.status==1">
								<view style="color: white;background-color: #EA393F;padding:16rpx 0;text-align: center;
								width: 40%;border-radius: 12rpx;margin-left: 24rpx;" @click="handleSell()">
									Bán</view>
							</template>
							<!-- 买入 -->
							<template v-if="detailInfo.status==2">
								<view style="color: white;background-color:#17A85B;padding:16rpx 0;text-align: center;
									width: 40%;border-radius: 12rpx;margin-right: 24rpx;" @click="linkBuy(detailInfo.name.split('/')[0])">
									Mua</view>
							</template>
						</view>
					</view>
				</view>
			</view>
		</template>
		<!-- 弹窗 -->
		<u-modal :show="showSell" title="Nhắc nhở" @cancel="showSell=false" cancel-text="Huỷ bỏ" confirm-text="Xác nhận"
			@confirm="confirm()" showCancelButton content='Bạn xác nhận bán ra?'>
			<!-- <view class="quantity-input">
				<input class="" placeholder="Vui lòng nhập" type="number" v-model="quantity">
				<view class="">Lô chẵn</view>
			</view> -->
			<!-- <input class="" placeholder="Vui lòng nhập" type="number" v-model="quantity"> -->
		</u-modal>

		<tabBar :current="3"></tabBar>
	</view>
</template>

<script>
	import tabBar from '@/components/tabBar.vue';
	import getStatusBarHeightAndNavbarHeight from '@/utils/getStatusBarHeightAndNavbarHeight.js';
	export default {
		components: {
			tabBar
		},
		data() {
			return {
				isMask: true,
				statusBar: getStatusBarHeightAndNavbarHeight.statusBar,
				list: [], // 我的持仓
				tabs_index: 1,
				userInformation: '',
				curPage: 1,
				detailInfo: null, // 明细数据
				showModal: false, // 显示持仓明细
				showSell: false, // 显示卖出确认层
				bank_card_info:'',
				userInfo:'',
			};
		},
		computed: {
			tempTip() {
				return `Khớp hết`
			}
		},
		onShow() {
			this.curPage = 1
			this.gaint_info();
			this.getOrder();
			if (!this.$util.checkToken()) return false;
			this.isMask = uni.getStorageSync('mask');
		},
		//下拉刷新
		onPullDownRefresh() {
			//关闭加载提示
			setTimeout(() => {
				uni.hideLoading();
				uni.stopPullDownRefresh();
			}, 1000);
			this.curPage = 1;
			this.list = [];
			this.getOrder();
			this.gaint_info();
		},
		onReachBottom() {
			// this.curPage = this.curPage + 1;
			// this.getOrder()
		},
		methods: {
			// 银转证
			silver() {

				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/certificateBank/silver'
				});

			},
			// 证转银
			prove() {

				if (this.bank_card_info && this.userInfo.idno !== null) {
					uni.navigateTo({
						//保留当前页面，跳转到应用内的某个页面
						url: '/pages/my/components/certificateBank/prove'
					});
				} else if (this.bank_card_info == null) {
					uni.$u.toast('Vui lòng liên kết tài khoản ngân hàng');
					setTimeout(() => {
						uni.navigateTo({
							//保留当前页面，跳转到应用内的某个页面
							url: '/pages/my/components/bankCard/renewal'
						});
					}, 2000)
				} else if (this.userInfo.idno == null) {
					uni.$u.toast('Chưa xác thực danh tính');
					setTimeout(() => {
						uni.navigateTo({
							//保留当前页面，跳转到应用内的某个页面
							url: '/pages/index/components/openAccount/openAccount'
						});
					}, 2000)
				}
			},
			// 跳转到买入
			linkBuy(val) {
				uni.navigateTo({
					url: `/pages/marketQuotations/purchase?gid=${val}`
				})
			},
			handleClose() {
				this.showModal = false;
				uni.showTabBar();
			},
			detail(val) {
				uni.hideTabBar();
				this.detailInfo = val;
				this.showModal = true;
			},
			// 卖出
			handleSell() {
				this.showSell = true;
			},
			// 点击确认
			confirm() {
				this.showSell = false;
				this.closingFunction()
			},
			// 平仓功能
			async closingFunction() {
				uni.showLoading({
					title: "Đang bán ra, vui lòng chờ trong giây lát...",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/user/sell', {
					id: this.detailInfo.id,
					// quantity: this.quantity
					quantity: this.detailInfo.buyQTY * 1
					// price: item.price
				})
				uni.hideLoading();
				console.log()
				// console.log(item.id, '平仓功能');
				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					this.showSell = false;
					this.showModal = false;
					this.getOrder();
				} else {
					uni.$u.toast(list.data.message);
				}
			},

			// 显隐掩码
			toggleMask() {
				this.isMask = !this.isMask;
				uni.setStorageSync('mask', this.isMask);
			},
			linkDeposit() {
				uni.navigateTo({
					url: `/pages/my/components/certificateBank/silver`
				})
			},
			linkWithdraw() {
				uni.navigateTo({
					url: `/pages/my/components/certificateBank/prove`
				})
			},

			async getOrder() {
				uni.showLoading();
				const result = await this.$http.post(`api/user/order`, {
					status: this.tabs_index,
					page: this.curPage
				});
				uni.hideLoading();
				console.log(`result:`, result);
				if (result.data.code == 0) {
					// this.curPage = this.curPage + 1; // 加一页
					const res = result.data.data;
					let filterData = [];
					if (this.tabs_index == 1) {
						filterData = res.filter(item => item.goods_info && item.order_buy);
					} else if (this.tabs_index == 2) {
						filterData = res.filter(item => item.goods_info && item.order_buy && item.order_sell);
					}
					this.list = filterData.map(item => {
						return {
							id: item.id,
							// 持仓盈利率 =（最终价 - 买入价） / 买入价 *100%
							buyProfitRate: (item.goods_info.current_price * 1 - item.order_buy.price * 1) /
								item.order_buy.price * 100,
							// 卖出盈利率计算： 盈利比=（卖出价 - 买入价） / 买入价 *100% 
							sellProfitRate: item.status == 2 ? (item.order_sell.price * 1 - item.order_buy
								.price * 1) / item.order_buy.price * 100 : '',
							status: item.status, // 1买 2卖
							name: item.goods_info.name, // 名称
							buyPrice: item.order_buy.price, // 买入价
							sellPrice: item.status == 2 ? item.order_sell.price : '', // 卖出价
							currentPrice: item.goods_info.current_price, // 最新价
							buyQTY: item.order_buy.num, // 买入数量
							sellQTY: item.status == 2 ? item.order_sell.num : '', // 卖出数量
							buyProfit: item.order_buy.yingkui, // 买入盈亏额
							sellProfit: item.status == 2 ? item.order_sell.yingkui : '', // 卖出盈亏额
							buyAmont: item.order_buy.amount,
							lastPrice: item.goods_info.last_price,
							total: item.order_buy.num * 1 * (item.goods_info.current_price * 1), //个股现价金额 
							buyFee: item.order_buy.buy_fee, // 交易费
							lever: item.order_buy.double, // 杠杆
							buyCT: item.order_buy.created_at, // 买入时间
							sellCT: item.status == 2 ? item.order_sell.created_at : '', // 卖出时间
						}
					});
				}
				this.gaint_info();

				// this.$http.get('api/user/order', {
				// 	status: this.tabs_index,
				// 	page: this.page
				// }).then(res => {
				// 	uni.hideLoading();
				// 	if (res.data.data.length > 0) {
				// 		const temp = res.data.data.filter(item => item.goods_info && item.order_buy);
				// 		if (this.storehouse.length > 0) {
				// 			console.log("add order")
				// 			this.storehouse.push(...temp)
				// 		} else {
				// 			this.storehouse = temp
				// 		}
				// 	}
				// });
			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
				this.userInfo = list.data.data
				this.bank_card_info = list.data.data.bank_card_info
			},
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,')
			},

			changeTabs(index) {
				this.tabs_index = index
				this.curPage = 1;
				this.list = [];
				this.getOrder();
				this.gaint_info()
			},

		}
	}
</script>

<style lang="less" scoped>
	@import url("@/common/css/rc.css");

	page {
		color: #353539;
		font-family: ArialMT;
	}

	.mask {
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		z-index: 11;
		cursor: pointer;
		background-color: rgba(0, 0, 0, 0.6);
	}

	.modal_wrapper {
		position: fixed;
		bottom: 0;
		left: 50%;
		right: 0;
		z-index: 13;
		width: 100%;
		background-color: transparent;
		animation: popopUp 300ms forwards;
		transform: translateX(-50%);
	}

	.tab {
		.active {
			color: #FFF;

			font-weight: bold;
			display: flex;
			justify-content: center;
			padding: 5px;
			border-radius: 6rpx;
		}
	}
</style>