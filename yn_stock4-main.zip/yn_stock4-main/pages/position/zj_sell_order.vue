<template>
	<view>
		<view class="dabokl">
			<view class="sert">
				
				<u-navbar title="ALR" @rightClick="rightClick" bgColor="#121327" titleStyle="color:#fff" leftIconColor="#fff" height="100rpx" :autoBack="true">
				</u-navbar>

				<!-- 弹窗 -->
				<u-modal :show="show" :title="title" @cancel="cancel" cancel-text="Huỷ bỏ" confirm-text="Xác nhận"
					@confirm="confirm(confirmation)" :showCancelButton='showCancelButton' :content='content'>
					<view class="quantity-input">
						<input class="" placeholder="Vui lòng nhập số tiền" type="number" v-model="quantity">
						<!-- <view class="">Lô chẵn</view> -->
					</view>
				</u-modal>

				<view v-show="Inv == 0" class="up-and-down-range" style="margin-top: 120rpx;">
					<view class="" style="border-bottom: 1px solid #e9e9e9;padding: 30rpx 0 ;"
						v-for="(item,index) in storehouse" :key="index">
						<view class="display" style="margin:0 30rpx ;color: #fff;">
							<view class="share-certificate" >
								<h6>{{item.goods_info.name}}</h6>

							</view>
							<view >
								X{{item.double}}
							</view>
							
							<!-- 	<view class="position" @click="closingFunction(item)">
									平仓
								</view> -->
						</view>

						<view class="" >
							<view class="display" style="margin: 30rpx 30rpx 20rpx;font-size: 26rpx;">
								<!-- <view class="buy-up" v-if="item.direct=1">买涨↑</view> -->
								<view class="time">Thời gian mua:{{item.updated_at}}</view>
							</view>
							<view class="shadow">
								
								
								
								<view class="display" >
									<view class="">Lãi suất:</view>
									<view class="quantity" v-if="item.status==2">{{toThousandFilter(item.interest)}}</view>
									
								</view>
							</view>
							<view class="shadows">
								<view class="display">
									<view class="">Giá mua vào:</view>
									<view class="quantity">{{toThousandFilter(item.user_pay)}}</view>
								</view>
								
								<!-- <view class="display" v-if="item.status==2">
									<view class="">盈利:</view>
									<view class="quantity">{{toThousandFilter(item.user_pay)}}</view>
								</view> -->
							</view>
							
							
						</view>
					</view>

					<view class="finished-text">
						Đã hết
					</view>
				</view>
			</view>
		</view>
		<!--更新-弹窗 -->
		<lerugeupdate ref="update" :downloadUrl="update.url" :updateDesc="update.title" :force="true" />
	</view>
</template>

<script>
	export default {
		
		data() {
			return {
				quantity: "",

				// //是否更新
				// updateFlag: false,
				// //每次版本更新都要修改
				// version: '2.1',
				// popupshow: true,
				downloadUrl: '',
				updateDesc: "",
				update: '',
				// closeOnClickOverlay: false,
				Inv: 0,
				items: ['Nắm giữ vị thế', 'Lịch sử'],
				show: false,
				title: 'Nhắc nhở',
				content: 'Bạn xác nhận bán ra?',
				showCancelButton: true,
				storehouse: '',
				storehouses: '',
				subscribe: '',
				luckyNumber: '',
				userInformation: '',
				updata: true,
				timerId: null,

			}
		},
		// watch: {
		// 	Inv: 'position'
		// },
		//下拉刷新
		onPullDownRefresh() {
			uni.showLoading({
				title: 'Đang tải',
			});
			//关闭加载提示
			setTimeout(() => {
				uni.hideLoading();
			}, 1000);
			this.hold()
			uni.stopPullDownRefresh()
		},

		methods: {
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			// 平仓
			position(id) {
				this.show = true;
				this.confirmation = id


			},
			//点击取消
			cancel() {
				this.show = false;
			},
			// 点击确认
			confirm(confirmation) {
				// this.show = false;
				// console.log(confirmation, '点击确定');
				this.closingFunction(confirmation)
				this.show = false;
			},
			//产品详情
			productDetails(gid) {
				uni.navigateTo({
					url: '/pages/marketQuotations/productDetails' +
						`?gid=${gid}`
				});
			},

			//点击下标
			subscript() {
				this.Inv == items.index
				// console.log(this.Inv, '下标');
			},
			
			// 银转证
			silver(money, bank_card_info, idno) {
				if (bank_card_info && idno !== null) {
					uni.navigateTo({
						//保留当前页面，跳转到应用内的某个页面
						url: '/pages/my/components/certificateBank/silver' + `?money=${money}`
					});
				} else if (bank_card_info == null) {
					uni.$u.toast('Thẻ ngân hàng không ràng buộc');
					setTimeout(() => {
						uni.navigateTo({
							//保留当前页面，跳转到应用内的某个页面
							url: '/pages/my/components/bankCard/renewal'
						});
					}, 2000)
				} else if (idno == null) {
					uni.$u.toast('Không xác thực tên thật');
					setTimeout(() => {
						uni.navigateTo({
							//保留当前页面，跳转到应用内的某个页面
							url: '/pages/index/components/openAccount/openAccount'
						});
					}, 2000)
				}

			},
			
			// 持仓
			async hold() {
				let list = await this.$http.get('api/user/order_zj', {
					// language: this.$i18n.locale
					status: 2
				})
				this.storehouse = list.data.data
				// console.log(list.data.data, '持仓');

			},
			
			// 平仓功能
			async closingFunction(confirmation) {

				if (this.quantity * 1 < 1) {
					uni.showToast({
						title: "Bán tối thiểu 1 cổ phiếu",
						icon: "none"
					})
					return;
				}
				uni.showLoading({
					title: "Đang bán ra, vui lòng chờ trong giây lát...",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/user/sell_zj', {
					id: confirmation,
					quantity: this.quantity
					// price: item.price
				})
				this.hold()
				// console.log(item.id, '平仓功能');
				if (list.data.code == 0) {
					this.updata = false
					this.updata = true
					
					uni.$u.toast(list.data.message);
					// this.$router.go(0)
					uni.hideLoading();

				} else {
					uni.$u.toast(list.data.message);
					uni.hideLoading();
				}

			},
			//版本更新
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},
			
			
		},
		mounted() {
			this.is_token()
		},
		onShow() {
			this.is_token()
			this.hold()
		},
		onLoad() {
		},
		onUnload() {
			console.log('持仓结束1');
			clearInterval(this.timerId);
		},
		onHide() {
			console.log('持仓结束2');
			clearInterval(this.timerId);
		},

	}
</script>

<style lang="scss">
	::v-deep .u-modal__content__text {
			text-align: center;
		}
	
		.toubu {
			width: 100%;
			// height: 120rpx;
			background-image: linear-gradient(to right, #0841E3, #061CC1);
			display: flex;
			justify-content: space-between;
			color: #fff;
			padding: 80rpx 0 80rpx 0;
			display: flex;
			justify-content: flex-end;
	
			.search {
				padding-right: 30rpx;
	
				image {
					width: 40rpx;
					height: 40rpx;
				}
			}
		}
	
		.dabokl {
			background: #fff;
			width: 100%;
			margin-top: -50rpx;
			border-radius: 30rpx 30rpx 0 0;
			padding-top: 30rpx;
	
			.available-balance {
				display: flex;
				align-items: center;
				justify-content: space-between;
				padding: 30rpx;
				border-bottom: 10rpx solid #f4f4f4;
				font-size: 30rpx;
	
				.balance {
					font-weight: 600;
				}
	
	
				.change {
					background: #87b52c;
					color: #FFFFFF;
					padding: 10rpx 50rpx;
					font-size: 16rpx;
					border-radius: 20rpx;
				}
			}
	
			.funding-situation {
				display: flex;
				align-items: center;
				justify-content: space-around;
				text-align: center;
				padding: 30rpx;
				border-bottom: 10rpx solid #f4f4f4;
				font-size: 30rpx;
	
				.xian {
					height: 100rpx;
					width: 2rpx;
					background: #9e9e9e;
				}
	
	
			}
	
	
			.inv-h-w {
				background-color: #FFFFFF;
				height: 80rpx;
				display: flex;
				margin-top: 50rpx;
			}
	
			.inv-h {
				font-size: 28rpx;
				flex: 1;
				text-align: center;
				color: #666666;
	
				position: relative;
			}
	
			.inv-h-se {
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: bold;
				color: #87b52c;
			}
	
			.inv-h-se:after {
				content: '';
				position: absolute;
				bottom: 20rpx;
				// top: auto;
				left: 42%;
				height: 6rpx;
				width: 44rpx;
				background-color: #87b52c;
			}
	
			//我的持仓
			.up-and-down-range {
	
				// padding: 0 30rpx;
				.share-certificate {
					h6 {
						font-size: 30rpx;
						margin: 10rpx 0;
					}
				}
	
				.position {
					background-image: linear-gradient(to right, #87b52c, #87b52c);
					color: #fff;
					padding: 10rpx 30rpx;
					border-radius: 30rpx;
					font-size: 28rpx;
				}
	
				.up-date {
					width: 30%;
	
					text {
						color: #87b52c;
						font-weight: 600;
					}
				}
	
				.buy-up {
					color: red;
					width: 30%;
				}
	
				.time {
					color: #666;
					// width: 60%;
					text-align: right;
				}
	
				.shadow {
					background: #87b52c;
					display: flex;
					justify-content: space-between;
					align-items: center;
					padding: 20rpx 30rpx;
	
					font-size: 26rpx;
	
					.display {
						width: 40%;
	
						.quantity {
							color: #fff;
						}
					}
				}
	
				.shadows {
	
					display: flex;
					justify-content: space-between;
					align-items: center;
					padding: 6rpx 30rpx;
					font-size: 26rpx;
	
					.display {
						width: 40%;
	
						.quantity {
							color: #87b52c;
							text-align: right;
							width: 50%;
						}
					}
				}
	
			}
	
			// 没有更多
			.finished-text {
				color: #969799;
				font-size: 28rpx;
				margin: 30rpx auto;
				text-align: center;
				padding: 30rpx 0;
			}
	
			// 我的交易
			.transaction {
	
				// padding: 0 30rpx;
				// padding: 0 30rpx;
				.share-certificate {
					h6 {
						font-size: 30rpx;
						margin: 10rpx 0;
					}
				}
	
				.position {
					background-image: linear-gradient(to right, #87b52c, #87b52c);
					color: #fff;
					padding: 10rpx 30rpx;
					border-radius: 30rpx;
					font-size: 28rpx;
				}
	
				.up-date {
					text {
						color: #2036d5;
						font-weight: 600;
					}
				}
	
				.buy-up {
					color: red;
				}
	
				.time {
					color: #666;
				}
	
				.shadow {
					background: #aac0ff;
					display: flex;
					justify-content: space-between;
					align-items: center;
					padding: 20rpx 30rpx;
					font-size: 26rpx;
	
					.display {
						width: 40%;
	
						.quantity {
							color: #87b52c;
						}
					}
				}
	
				.shadows {
	
					display: flex;
					justify-content: space-between;
					align-items: center;
					padding: 6rpx 30rpx;
					font-size: 26rpx;
	
					.shadows-dis {
						width: 40%;
	
						.quantity {
							margin: 10rpx 0;
							color: #87b52c;
						}
					}
	
					.display {
						width: 40%;
	
						.quantity {
							color: #87b52c;
						}
					}
				}
	
	
				// 没有更多
				.finished-text {
					color: #969799;
					font-size: 28rpx;
					margin: 30rpx auto;
					text-align: center;
					padding: 30rpx 0;
				}
			}
	
		}
	
		.quantity-input {
			background-color: #f5f5f5;
			border: 2rpx solid #e0e0e0;
			border-radius: 10rpx;
			padding: 10rpx 20rpx;
			display: flex;
			font-size: 28rpx;
			width: 100%;
		}
	</style>