<template>
	<!-- 大宗交易 -->
	<view style="background-color: #F8F8F8;min-height: 100vh;">
		<view class="college-bg">
			<image src="/static/arrow_left.png" mode="aspectFit" style="width: 20px;height: 24rpx;" @tap="$u.route({url:'/pages/index/index'});">
			</image>
			<view style="flex:1;text-align: center;color: #EA5A40;font-size: 28rpx;font-weight: 700;">
				Cổ Phiếu Ưu Đãi
			</view>
		</view>
		
		
		<view style="display: flex;background-color: #F3F4F6;border-radius: 5px;width: 80%;margin-left: 10%;box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;">
				<view style="color: #000;background: #fff;padding: 10px;border-radius: 5px;" class="flex-1 text-center bold"> Danh sách </view>
				<view style="color: #000;padding: 10px;" class="flex-1 text-center" @tap="blockTransactions()"> Lịch sử đăng ký </view>
		</view>

		<view style="margin: 20px;box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;border-radius: 6px;" class="padding-15 radius10" v-for="(item,index) in business"
			:key="index">
			<view class="flex gap10">
			
				<view>
					<view style="color: #000;">{{item.goods.name}}</view>
				</view>
			</view>
			<view class="flex flex-b" style="line-height: 2.4;">
				<view>Giá đặt lệnh</view>
				<view style="color: #43C776;">{{toThousandFilter(item.price)}}</view>
			</view>

			<view @click="detail(item)" class="btn_common"
				style="font-size: 32rpx;width: 90%;margin:6rpx auto;line-height: 46rpx;margin-top: 24rpx;">
				Chi tiết
			</view>
		</view>


		<u-popup :show="show" @close="close" :round="20" mode="bottom" :closeable='closeable'>
			<view class="largeAmount">
				<view class="business" style="color: #000;">
					Đặt lệnh
				</view>
				<view class="price" style="color: #000;">Giá đặt lệnh</view>
				<view class="purchase-price">{{toThousandFilter(detailId.price)}}</view>
				<view class="purchase-text">
					<u-input type="number" placeholder="" v-model="value1" color="#000"></u-input>
					<view class="hand" style="color:#666;">Khối lượng</view>
				</view>

				<!-- <view class="amount" style="margin-bottom: 20rpx;">1 Lô chẵn = 100 Cổ phiếu </view> -->

				<view class="amount"> Số tiền yêu cầu mua
					<text>{{toThousandFilter(detailId.price*this.value1/curLever)}}
					</text>
				</view>

				<!-- 杠杆默认有一个数组，当数组大于1，视为开启杠杆功能 -->
				<template v-if="leverList.length>1">
					<view style="font-size: 14px;margin-top: 10px;color: #000;">
						Margin
					</view>

					<view style="display: flex;align-items: center;flex-wrap: wrap;margin-left: 30rpx;">
						<block v-for="(item,index) in leverList" :key="index">
							<view
								style="border-radius: 8rpx;width:12%;margin:10rpx;padding:6rpx 10rpx;line-height: 1.6;text-align: center;"
								:style="{color:curLever==item? '#121212' :'#999',backgroundColor:curLever==item?'#ebdbff'
												:'#F1F1F1'}" @click="chgangeLever(item)">
								{{item}}
							</view>
						</block>
					</view>
				</template>

				<!-- 
				<view class="available"   v-if="detailId.gg_moren>0" >
					<u-input type="number" :disabled="true" placeholder="" v-model="ganggan" inputAlign='right'>
					</u-input>
				</view>
				<view class="available"  @tap.stop="ganggan_show=true" v-if="detailId.gg_moren==0">										
					<u-input type="number" :disabled="true" placeholder="" v-model="ganggan" inputAlign='right'>
					</u-input>
				</view> -->


				<!-- <view class="available">
					<u-input type="password" placeholder="请输入资金密码" v-model="value2"></u-input>
				</view> -->
				<view class="fund margin-top-15">
					Sức mua <text>{{toThousandFilter(availableFunds.money)}}</text>
				</view>
				<view>
					<view class="purchase "
						style="background-color:#43C776 ;color:#FFF; width: 85%;margin: 20px;height: 64rpx;line-height: 64rpx; border-radius: 5px;text-align: center;"
						@click="bulkPurchase(detailId.id)">Đặt lệnh</view>
				</view>
			</view>

		</u-popup>

		<!-- <u-action-sheet :show="ganggan_show" :actions="actions" title="Margin (Đòn bẩy)" @close="ganggan_show = false"
			@select="Select">
		</u-action-sheet> -->

	</view>
</template>

<script>
	export default {
		data() {
			return {
				leverList: [], // 杠杆值数组
				curLever: 1, // 当前杠杆值
				// actions: [{
				// 		name: '1',
				// 		index: 1
				// 	}
				// ],
				show: false,
				closeable: true,
				business: "",
				detailed: '',
				value1: '',
				value2: '',
				availableFunds: '',
				detailId: '',
				// ganggan:2,
				// ganggan_show:false
			}
		},
		computed: {
			buyAmount() {
				return !this.curLever ? 0 : this.detail.price * this.amount / this.curLever;
			}
		},
		methods: {
			// 选择杠杆
			chgangeLever(val) {
				this.curLever = val;
			},

			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			// Select(e) {
			// 	console.log(e);
			// 	this.ganggan = e.index
			// 	// this.columns = this.detailedData.ganggan
			// 	// console.log(this.title, '99999');
			// },
			close() {
				this.show = false
				// console.log('close');
			},
			detail(item) {
				this.show = true
				this.bulkDetails(item)
				// console.log(this.bulkDetails, '987654');
			},
			blockTransactions() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/blockTransactions/blockTransactions'
				});
			},
			//列表
			async largeAmount() {
				let list = await this.$http.get('api/goods-bigbill/list', {})
				this.business = list.data.data
				// console.log(list.data.data, '大宗交易');
			},
			//详情
			async bulkDetails(item) {
				let list = await this.$http.get('api/goods-bigbill/detail', {
					id: item.id
				})
				this.detailed = list.data.data.goods
				this.detailId = list.data.data
				console.log(list.data);
				if (this.detailId.gg_moren && this.detailId.gg_moren > 0) {
					this.curLever = this.detailId.gg_moren;
				}
				// if (this.detailId.gg_moren > 0) {
				// 	this.ganggan = this.detailId.gg_moren
				// } else {
				// 	this.ganggan = 1
				// }

				// console.log(this.detailed, '大宗交易');
			},
			async userInfo() {
				let list = await this.$http.get('api/user/fastInfo', {})
				this.list = list.data.data
				// this.actions = list.data.data.ganggan
				console.log(list.data.data.ganggan);
				// 处理杠杆，后端数据返回不一致。
				const temp = list.data.data.ganggan || [];
				if (!temp || temp.length <= 0) return false;
				// ganggan: [{name: "", index: ""}] 
				// ganggan: [{name: "2", index: "2"}, {name: "4", index: "4"}, ...]
				if (temp[0].index && temp[0].index * 1 > 0) {
					this.leverList = temp.map(item => item.index * 1);
					console.log('array object:', this.leverList);
					return false;
				}
				// ganggan: "2,3,4,5,6,7,8,9,10"
				if (typeof(temp) === 'string') {
					this.leverList = temp.split(',').map(item => item * 1);
					console.log('string:', this.leverList);
					return false;
				}
				// if (typeof(temp) == 'array') {
				// 	this.leverList = temp.filter(item => item * 1);
				// }
			},
			//点击购买
			async bulkPurchase(id) {
				let list = await this.$http.post('api/goods-bigbill/doOrder', {
					id: id,
					num: this.value1,
					pay_pass: this.value2,
					ganggan: this.curLever, // 杠杆
				})
				if (list.data.code == 0) {
					this.show = false
					uni.$u.toast(list.data.message);
					this.value1 = ''
					this.value2 = ''
					this.available()
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/index/components/newShares/blockTransactions/blockTransactions'
						});
					}, 1000)
				} else {
					// if (list.data.code == 1) {
					// 	setTimeout(() => {
					// 		uni.navigateTo({
					// 			url: '/pages/my/components/certificateBank/silver'
					// 		});
					// 	}, 1000)
					// }

					if (this.value1 == '') {
						this.show = false
						uni.$u.toast('Vui lòng nhập số lượng');
						setTimeout(() => {
							this.show = true
						}, 1000)
					}
					// else if (this.value2 == '') {
					// 	this.show = false
					// 	uni.$u.toast('请填写资金密码');
					// 	setTimeout(() => {
					// 		this.show = true
					// 	}, 1000)
					// } 
					else {
						this.show = false
						uni.$u.toast(list.data.message);
						setTimeout(() => {
							this.show = true
						}, 1000)
					}
				}
			},
			//可用资金
			async available() {
				let list = await this.$http.get('api/user/info', {})
				this.availableFunds = list.data.data
			},

		},

		//取小数点之后的2位
		filters: {
			addZero: function(data) {
				return data.toFixed(2)
			}
		},
		mounted() {
			this.largeAmount()
			this.available()
			this.userInfo()
			// this.bulkDetails()
		},
		
	}
</script>

<style lang="scss">


	//弹窗
	.largeAmount {
		padding: 30rpx;

		.business {
			text-align: center;
			font-size: 30rpx;
			color: #333;
			border-bottom: 1rpx solid #e0e0e0;
			padding-bottom: 30rpx;

		}

		.price {
			color: #333;
			font-weight: 500;
			margin: 30rpx 0;
		}

		.purchase-price {
			color: #4bae4f;
			margin: 10rpx;
			font-weight: 600;
		}

		.purchase-text {
			display: flex;
			justify-content: space-between;
			align-items: center;
			border: 1rpx solid #4bae4f;
			padding: 0 20rpx;
			border-radius: 10rpx;
			margin: 20rpx 0;

			.hand {
				border-left: 1rpx solid #4bae4f;
				padding-left: 30rpx;
			}
		}

		.amount {
			color: #999;
			font-size: 24rpx;

			text {
				color: #4bae4f;
				margin-left: 20rpx;
			}
		}

		.available {
			border: 1rpx solid #ebebeb;
			padding: 0 20rpx;
			border-radius: 10rpx;
			margin: 20rpx 0;
		}

		.fund {
			color: #999;
			font-size: 24rpx;

			text {
				color: #f33030;
				margin-left: 20rpx;
			}
		}


	}
</style>