<template>
	<view class="launch">

		

		<view style="display: flex;align-items: center;justify-content: center;padding-top: 150%;">
			
			<view style="background: linear-gradient(to bottom, #FFC65E, #FF8E2B);padding: 10px;width: 60%;border-radius: 20px;height: 30px;line-height: 30px;" class="text-center bold">
				Trải nghiệm ngay
			</view>

		</view>
		<!-- <view style="display: flex;align-items: center;justify-content: center;">
			<view style="margin-top: 20px;text-align: center;font-size: 48rpx;font-family: 700;color:#FFFFFF;">
				ABinvest
			</view>
		</view> -->

		<ProgressThird></ProgressThird>

	</view>
</template>

<script>
	import ProgressThird from '@/components/progress/ProgressThird.vue';
	export default {
		components: {
			ProgressThird
		},
	}
</script>

<style lang="scss" scoped>
	/* 启动页 */
	.launch {
		width: 100%;
		height: 100vh;
		padding-top: 0;
		background-image: url('/static/launch_bg.png');
		background-repeat: no-repeat;
		background-position: 0 0;
		background-size: cover;
		/* background-image: linear-gradient(180deg, #FFF3D1, transparent); */
	}
</style>