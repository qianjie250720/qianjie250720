<template>
	<view>
		<view class="college-bg">
			<image src="/static/arrow_left.png" mode="aspectFit" style="width: 20px;height: 24rpx;" @tap="goBack()">
			</image>
			<view style="flex:1;text-align: center;color: #EA5A40;font-size: 28rpx;font-weight: 700;">Danh sách thông báo
			</view>
		</view>
		<view style="padding:36rpx;">
			<view v-html="item.content"> </view>
		</view>
	</view>
</template>

<script>
</script>

<style>
</style>