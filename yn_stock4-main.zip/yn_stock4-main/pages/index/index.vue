<template>

	<view class="page_body">
		<view>
			<!-- 背景图 -->
			<view
				style="width: 100%;height: 400px;background-image: url('/static/beijing.png');background-size: cover;background-position:0 0;background-repeat: no-repeat;">
				<view style="padding: 10px 30px;display: flex;align-items: center;justify-content:space-between;">
					<view @click="$u.route({url:'/pages/searchFor/searchFor'});">
						<view
							style="background-color: #fff;width: 240px;height: 44px;border-radius: 6px;box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;">
						</view>
						<image src="/static/sousuo.png" mode="widthFix"
							style="width:24px;height: 24px;position: absolute;left: 10%;top: 2.2%;"></image>
						<view style="position:absolute;left: 19%;top: 2.5%;color: #888888;">Mã chứng khoán</view>
					</view>
					<view style="display: flex;">
						<image src="/static/kefu_1.png" @click="customer()"
							style="width: 24px;height: 24px;background-color: #FFFFFF;border-radius: 10px;padding: 10px;box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;">
						</image>
						<!-- <image src="/static/ling.png" @click="notify()"
							style="width: 24px;height: 24px;background-color: #FFFFFF;border-radius: 10px;padding: 10px;margin-left: 14px;box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;">
						</image> -->
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding: 0 20px;">
					<view style="display: flex;">
						<view style="display: flex;align-items: center;justify-content: center;margin-left: 36rpx;">
							<u-avatar size='60' :src="userInfo.avatar" shape=""
								default-url="/static/logo.png"></u-avatar>
						</view>
						<view>
							<view style="display: flex;align-items: center; padding:10rpx 20rpx;">
								<view style="font-size: 36rpx;color:#000;">
									{{userInfo.real_name}}
								</view>
							</view>
							<view style="display: flex;align-items: center; padding:0 20rpx;">
								<view style="font-size: 32rpx;color:#82807f;">
									ID: {{userInfo.p_mobile}}
								</view>
							</view>
						</view>
					</view>
					<view>
						<view style="display: flex;align-items:center;justify-content: right;">
							<view
								style="font-size: 16px;font-weight: 700;color: #000;line-height: 2;text-align: center;">
								{{isMask?`******`: toThousandFilter(userInfo.totalZichan*1+userInfo.holdYingli*1)}}
							</view>
							<image :src="`/static/mask_${isMask?'show':'hide'}.png`" mode="aspectFit"
								style="width: 32rpx;height: 32rpx;padding-left: 12rpx;" @click="toggleMask()">
							</image>
						</view>
						<view
							style="display: flex;align-items: center;color: #000;line-height: 1.4;justify-content: right;">
							<view :style="{color:userInfo.holdYingli>0?'#43c776':'red'}" class="bold">
								{{isMask?`******`:toThousandFilter(userInfo.holdYingli)}}
							</view>
							<view style="font-size: 24rpx;padding-right: 24rpx;">Tổng lãi lỗ</view>
						</view>
					</view>
				</view>
				<view style="display: flex;justify-content: center;margin: 10px 0;">
					<image src="/static/line_1.png" style="width: 360px;height: 1px;"></image>
				</view>
				<view
					style="display: flex;align-items: center;justify-content: space-around;text-align: center;margin-top: 20px;">
					<view @click="chongzhi()">
						<image src="/static/cunkuan_1.png" style="width: 36px;height: 36px;"></image>
						<view style="font-size: 16px;font-weight: 700;margin-top: 6px;">Nộp tiền</view>
					</view>
					<view @click="tixian()">
						<image src="/static/qukuan_1.png" style="width: 36px;height: 36px;"></image>
						<view style="font-size: 16px;font-weight: 700;margin-top: 6px;">Chuyển khoản </view>
					</view>

					<view @click="$u.route({url:'/pages/marketQuotations/marketQuotations'});">
						<image src="/static/jioayi_1.png" style="width: 36px;height: 36px;"></image>
						<view style="font-size: 16px;font-weight: 700;margin-top: 6px;">Giao dịch</view>
					</view>
					<view @click="tiaozhuan('/pages/index/components/openAccount/openAccount')">
						<image src="/static/shiming_1.png" style="width: 36px;height: 36px;"></image>
						<view style="font-size: 16px;font-weight: 700;margin-top: 6px;">Định danh</view>
					</view>
				</view>
			</view>
		</view>
		<view style="padding: 0 20px;margin-top: -150px;">
			<view
				style="background-image: url('/static/iconbeijing.png');background-size:100% 100%;background-position:0 0;background-repeat: no-repeat;width: 100%;height: 200px;box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;border-radius: 10px;">
				<view
					style="display: flex;flex-wrap: wrap;gap: 20px;padding: 10px 50px 10px 48px;text-align: center;justify-content:space-between;">
					<view @click="tiaozhuan('/pages/function/big')">
						<image src="/static/dazong_1.png" style="width: 50px;height: 50px;"></image>
						<view style="color: #FFFFFF;margin-top: 6px;font-weight:700;">Cổ Phiếu Ưu Đãi</view>
					</view>

					<view @click="tiaozhuan('/pages/index/components/newShares/newShares?index=2')">
						<image src="/static/xingu_1.png" style="width: 50px;height: 50px;"></image>
						<view style="color: #FFFFFF;margin-top: 6px;font-weight:700;">Cổ phiếu IPO</view>
					</view>
				</view>
				<view
					style="display: flex;flex-wrap: wrap;gap: 20px;padding: 10px 68px 10px 60px;text-align: center;justify-content:space-between;">
					<view @click="tiaozhuan( '/pages/my/components/commonFunctions/capitalDetails?index=0')">
						<image src="/static/xieyi_1.png" style="width: 50px;height: 50px;"></image>
						<view style="color: #FFFFFF;margin-top: 6px;font-weight:700;"> LS dòng tiền </view>
					</view>
					<view @click="$u.route({url:'/pages/position/position'});">
						<image src="/static/changwai_1.png" style="width: 50px;height: 50px;"></image>
						<view style="color: #FFFFFF;margin-top: 6px;font-weight:700;"> Sổ lệnh </view>
					</view>
				</view>
			</view>
		</view>
		<!-- <view style="display: flex;align-items: center;justify-content: space-between;padding: 10px 20px;margin-top: 10px;">
			<image src="/static/banner1_1.png" style="width: 180px;height: 80px;box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;border-radius: 10px;"></image>
			<image src="/static/banner1_2.png" style="width: 180px;height: 80px;box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;border-radius: 10px;"></image>
		</view> -->
		<!-- <view style="margin: 10px;">
			<view class="flex gap10">
				<view class="flex-1 text-center" @click="chongzhi()">
					<view>
						<image src="/static/cunkuan.png" mode="widthFix" style="width: 100%;"></image>
					</view>
					<view class="bold font-size-14 margin-top-10">Nộp tiền</view>
				</view>
				<view class="flex-1 text-center" @click="tixian()">
					<view>
						<image src="/static/qukuan.png" mode="widthFix" style="width: 100%;"></image>
					</view>
					<view class="bold font-size-14 margin-top-10">Rút tiền</view>
				</view>
				<view class="flex-1 text-center" @click="tiaozhuan('/pages/function/big')">
					<view>
						<image src="/static/OTC.png" mode="widthFix" style="width: 100%;"></image>
					</view>
					<view class="bold font-size-14 margin-top-10">Quyền mua</view>
				</view>
			</view>
			<view class="flex margin-top-10 gap10">
				<view class="flex-1 text-center" @click="tiaozhuan('/pages/index/components/openAccount/openAccount')">
					<view>
						<image src="/static/shiming.png" mode="widthFix" style="width: 100%;"></image>
					</view>
					<view class="bold font-size-14 margin-top-10">Danh tính</view>
				</view>
				<view class="flex-1 text-center"
					@click="tiaozhuan('/pages/index/components/newShares/newShares?index=2')">
					<view>
						<image src="/static/dazong.png" mode="widthFix" style="width: 100%;"></image>
					</view>
					<view class="bold font-size-14  margin-top-10">Cổ phiếu mới</view>
				</view>
				<view class="flex-1 text-center" @click="tiaozhuan( '/pages/index/components/fund/fund')">
					<view>
						<image src="/static/yinsi.png" mode="widthFix" style="width: 100%;"></image>
					</view>
					<view class="bold font-size-14 margin-top-10">ETF</view>
				</view>
			</view>
		</view> -->
		<view style="margin: 15px;">
			<image src="/static/banner.png" mode="widthFix"
				style="width: 100%;box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;border-radius: 10px;"></image>
		</view>
		<view class="flex gap10" style="margin: 0 15px;">
			<view
				style="background: linear-gradient( 180deg, #EA5A40 0%, #D63B1F 100%);width: 6px;height: 20px;border-radius: 20px;">
			</view>
			<view class="bold">
				Chỉ số phổ biến
			</view>
		</view>
		<template v-if="topList && topList.length>0">
			<view class="padding-10" style="margin:24rpx 0;">
				<!-- <image src="/static/banner.jpg" style="width: 100%;border-radius: 10px;" mode="widthFix"></image> -->
				<scroll-view :scroll-x="true" style="white-space: nowrap;padding: 0 10px 0 10px;" @touchmove.stop>
					<block v-for="(item,index) in topList" :key="index">
						<view
							style="width: 240rpx;display: inline-block; padding:10px;margin-right: 10px;border-radius: 12rpx;box-shadow: rgba(0, 0, 0, 0.05) 0px 6px 24px 0px, rgba(0, 0, 0, 0.08) 0px 0px 0px 1px;">
							<view style="color:#fff;">{{item.name}}</view>
							<image :src="`/static/line_${item.rate>0?'rise':'fall'}.png`" mode="aspectFit"
								style="width: 210rpx;height: 72rpx;"></image>
							<view style="font-size: 28rpx;" :style="$theme.setStockRiseFall(item.rate>0)">
								{{toThousandFilter1(item.current_price)}}

							</view>
							<view style="font-size: 24rpx;" :style="$theme.setStockRiseFall(item.rate>0)">
								{{item.rate_num}} ({{item.rate}}%)
							</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between;padding-top: 16rpx;">
								<view style="border-radius: 12rpx;background-color: #FF606A;width: 30%;height: 6rpx;">
								</view>
								<view
									style="border-radius: 12rpx;background-color: #FDD355;width: 20%;height: 6rpx;margin:0 6rpx;">
								</view>
								<view style="border-radius: 12rpx;background-color: #1AC5A8;width: 50%;height: 6rpx;">
								</view>
							</view>
						</view>
					</block>
				</scroll-view>
			</view>
		</template>

		<!-- 	<view class="navBar flex flex-wrap">
			<view class="nav-item flex flex-column align-center" v-for="item,index in nav"
				@click="tiaozhuan(item.route)">
				<view class="">
					<u-image :showLoading="true" :src="item.icon" width="50px" height="50px" bgColor="#eee">
					</u-image>
				</view>
				<view class="text-center margin-top-10" style="color: #CBCBCF;font-size: 14px;">
					<span>{{item.title}}</span>
				</view>
			</view>
		</view> -->
		<!-- notify -->
		<!-- <view class="notify flex align-center padding-10">
			<u-notice-bar text="Hiển thị thông báo Marquee"  bgColor='#442f84'
				color='#ffb044'></u-notice-bar>
		</view> -->

		<view>
			<view class="flex gap10" style="margin-left: 15px;">
				<view
					style="background: linear-gradient( 180deg, #EA5A40 0%, #D63B1F 100%);width: 6px;height: 20px;border-radius: 20px;">
				</view>
				<view class="bold">
					Danh sách cổ phiếu
				</view>

				<view style="margin-left: auto;" @click="linkStocks()">
					<image src="/static/arrow_right.png" mode="aspectFit" style="width: 24rpx; height: 24rpx;"></image>
				</view>
			</view>

			<block v-for="(item,index) in stockList" :key="index">
				<view class="radius10 flex flex-b" style="margin: 10px 10px 10px 15px;" @tap="detailed(item.name)">
					<view class="flex flex-1">
						<view class="bold">{{item.name}}</view>
					</view>
					<view class="flex-1">
						<image :src="item.rate>0?'/static/lv.png':'/static/hong.png'" mode="aspectFit"
							style="width:60px; height: 60px;"></image>
					</view>
					<view class="gap20 flex-1 text-center">
						<view :style="{ background:item.rate===0 ?'#d7e500' : (item.rate > 0 ? '#43c776' :'#ff0000') }"
							style="padding: 5px 10px;color: #fff;border-radius: 5px;">
							{{toThousandFilter(item.current_price)}}
						</view>
						<view class="flex justify-end margin-top-5" style="font-size: 12px;">{{item.fBVol}}</view>
					</view>
					<view class="flex-1 justify-end flex">
						<view>
							<view :style="{ color:item.rate===0 ?'#d7e500' : (item.rate > 0 ? '#43c776' :'#ff0000') }">
								{{item.rate}}%</view>
							<view class="flex gap5 justify-end">
								<view class="flex align-center margin-top-5">
									<image
										:src="item.rate ===0 ? '' :(item.rate>0?'/static/zhang.png':'/static/die.png') "
										mode="aspectFit" style="width:6px; height: 6px;"></image>
								</view>
								<view
									:style="{ color:item.rate===0 ?'#d7e500' : (item.rate > 0 ? '#43c776' :'#ff0000') }"
									style="font-size: 12px;">
									{{item.rate_num}}
								</view>
							</view>
						</view>

					</view>
				</view>
			</block>
		</view>
		<view style="padding: 0 20px;">
			<image src="/static/homebanner_1.png"
				style="width: 100%;height: 80px;box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;border-radius: 10px;">
			</image>
		</view>
		<view class="hotspot">
			<view class="flex gap10">
				<view
					style="background: linear-gradient( 180deg, #EA5A40 0%, #D63B1F 100%);width: 6px;height: 20px;border-radius: 20px;">
				</view>
				<view class="bold">
					Điểm tin thị trường
				</view>

				<view style="margin-left: auto;" @click="linkNews()">
					<image src="/static/arrow_right.png" mode="aspectFit" style="width: 24rpx; height: 24rpx;"></image>
				</view>
			</view>
			<view v-for="(item,index) in news" :key="index" style="margin-top: 10px;" class="flex gap10">
				<view @click="to_skip('/pages/index/components/newsDetail',1,item.title,item.id)">
					<image :src="item.pic" style="width: 100px;height: 100px;border-radius: 10px;"></image>
				</view>
				<view @click="to_skip('/pages/index/components/newsDetail',1,item.title,item.id)">
					<view class="bold font-size-16">{{setText(item.title)}}</view>
					<view class="font-size-14 hui1 margin-top-5">{{setText(item.content,100)}}</view>
					<view class="font-size-14 hui1 margin-top-5">{{item.created_at}}</view>
				</view>
			</view>

		</view>


		<tabBar :current="0"></tabBar>
	</view>
</template>

<script>
	import tabBar from '@/components/tabBar.vue';

	export default {
		components: {
			tabBar
		},
		data() {
			return {
				isMask: true,
				statusBarHeight: 0,
				topList: [],
				userInfo: '',
				tel: '',
				bank_card_info: '',
				item: '',
				banner: [
					'https://finhay-wp.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2023/09/15153347/nghe-moi-gioi-chung-khoan.jpg',
					'https://finhay-wp.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2023/09/12164644/tai-san-rong-la-gi.jpg',
					'https://finhay-wp.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2023/09/11093813/vi-sao-can-quan-ly-danh-muc-dau-tu.jpg',
				],
				bannerLoding: true,

				index: [{
						name: 'BMP',
						value: '36817.65'
					},
					{
						name: 'TIP',
						value: '36817.65'
					},
					{
						name: 'VGC',
						value: '36817.65'
					}
				],
				// 新闻最新列表 适当条数
				headlines: [{
						tag: 'HOT',
						content: 'conversational AI system that listens,conversational AI system that listens,'
					},
					{
						tag: 'NEW',
						content: 'conversational AI'
					},
					{
						tag: 'HOT',
						content: 'conversational AI system that listens,conversational AI system that listens,'
					},
					{
						tag: 'NEW',
						content: 'conversational AI'
					}
				],
				// 
				headlines_banner: [{
						title: 'thông tin độc quyền',
						summary: 'Nắm bắt các điểm nóng của ngành và hành động ngay lập tức'
					},
					{
						title: 'Tập trung vào các điểm nóng của ngành',
						summary: 'Tin tức mới, tất cả đều có trong đó'
					},
				],
				//
				headlines_market: [{
						title: 'Khuyến nghị phổ biến',
						icon: "../../static/index/hong@2x.png",
						background: "#FFF3F5"
					},
					{
						title: 'cổ phiếu chính',
						icon: "../../static/index/huang@2x.png",
						background: "#FFFDF2"
					},
					{
						title: 'Xếp hạng lãi và lỗ',
						icon: "../../static/index/jiantou@2x.png",
						background: "#F8F7FF"
					},
				],
				// 
				hotspot: [],
				// 加载更多
				page: 1,
				loadmore_status: 'loadmore',
				news: [],
				stockList: [],
			}
		},
		computed: {

		},
		onLoad() {},
		onShow() {
			// console.log(`index onShow:`, 1);
			this.getSystemInfo();
			this.getBanner();
			this.gaint_info();
			// bannerLoding is false
			setTimeout(() => {
				this.bannerLoding = false;
			}, 1500)
			this.gain_views()
			// this.getTopList();
			this.getStockList();
		},
		onReachBottom() {
			// TODO 触底虚拟获取数据
			this.loadmore_status = 'loading';

			setTimeout(() => {
				this.loadmore_status = 'nomore';
				// if (this.page >= 5) return this.loadmore_status = 'nomore';
				// this.page++;
				// this.hotspot.push({
				// 	cover: '../../static/index/tock-chart.jpg',
				// 	title: 'Tiêu đề tin tức chỉ hiển thị một dòng',
				// 	summary: 'Tóm tắt nội dung tin tức hiển thị hai dòng văn bản màu xám. Tóm tắt nội dung tin tức hiển thị hai dòng văn bản màu xám.'
				// });
				// if (this.page >= 5)
				// 	this.loadmore_status = 'nomore';
				// else
				// 	this.loadmore_status = 'loading';
			}, 2000)
		},
		methods: {
			// 显隐掩码
			toggleMask() {
				this.isMask = !this.isMask;
				uni.setStorageSync('mask', this.isMask);
			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {})
				this.userInfo = list.data.data
				this.bank_card_info = list.data.data.bank_card_info

			},
			// 跳转到新闻页面
			linkNews() {
				uni.navigateTo({
					url: `/pages/newsList`
				})
			},
			linkStocks() {
				uni.navigateTo({
					url: `/pages/marketQuotations/marketQuotations`
				})
			},
			//客服
			customer() {
				uni.navigateTo({
					url: '/pages/index/components/customer/customer'
				});
			},
			openNews(val) {
				window.open(val)
			},
			//客服
			notify() {
				uni.navigateTo({
					url: '/pages/notify/index'
				});
			},
			// linkETF() {
			// 	uni.navigateTo({
			// 		url: `/pages/index/components/fund/fund`
			// 	})
			// },

			// 文字超出一行。转换为...
			setText(val, num = 26) {
				let temp = '';
				return temp = val.length <= 26 ? val : val.slice(0, num) + '...'
			},
			detailed(gid) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/marketQuotations/productDetails' + `?gid=${gid}`
				});
				// console.log(gid, "携带");
			},
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,')
			},
			toThousandFilter1(num) {
				return (+num || 0).toFixed(2).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,')
			},
			async getStockList() {
				let list = await this.$http.post('api/goods/updownlist', {
					page: 1,
					limit: 10,
				})
				// console.log(`getStockList:`, list);
				if (list.statusCode == 200) {
					if (list.data && list.data.goods) {
						this.stockList = Object.values(list.data.goods);
					}
					this.topList = list.data.zhishu
				}
				// console.log(`getStockList:`, this.stockList);
			},

			// async getTopList() {
			// 	let list = await this.$http.post('api/goods/updownlist', {
			// 		page: 1,
			// 		limit: 10,
			// 	})
			// 	//上证指数
			// 	this.topList = list.data.zhishu
			// },

			linAccount() {
				uni.switchTab({
					url: `/pages/my/my`
				})
			},

			tiaozhuan(url) {
				if (!this.$util.checkToken()) return false;
				if (url == "/pages/marketQuotations/marketQuotations") {
					uni.switchTab({
						url: url
					})
				} else if (url == "/pages/position/position") {
					uni.switchTab({
						url: url
					})
				} else {
					uni.navigateTo({
						url: url
					});
				}
				console.log(url);


			},

			chongzhi() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/certificateBank/silver'
				});
			},
			tixian() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/certificateBank/prove'
				});
			},



			searchFor() {
				uni.navigateTo({
					url: '/pages/searchFor/searchFor'
				});
			},
			to_skip(url, type, title, id) {
				if (type == 1) {
					uni.navigateTo({
						url: url + `?title=${title}&id=${id}`
					});
				} else if (type == 2) {
					uni.switchTab({
						url: url
					});
				}
			},

			getBanner() {
				// 示例请求

			},
			//新闻
			async gain_views() {
				let list = await this.$http.get('api/article/list', {
					type: 11,
				})
				// console.log(this.list1[index].type, '新闻列表')
				this.news = list.data.data
				// uni.hideLoading();
				// uni.stopPullDownRefresh();

			},
			/** 
			 * 获取设备系统信息
			 */
			getSystemInfo() {
				uni.getSystemInfo({
					success: (res) => {
						this.statusBarHeight = res.statusBarHeight || 0;
					},
					fail: (err) => {
						console.error('Failed to obtain system information:', err);
					},
				});
			},
		}
	}
</script>

<style lang="less" scoped>
	.chongzhi {
		display: flex;
		align-items: center;
		flex: 1 1 auto;
		justify-content: center;
		margin: 3px 6px;
		border-radius: 8px;
		color: #3E6EB2;
		font-size: 15px;
		line-height: 2.4;
		text-align: center;
		border: 2px solid #3E6EB2;
	}

	.tixian {
		display: flex;
		align-items: center;
		justify-content: center;
		flex: 1 1 auto;
		margin: 3px 6px;
		border-radius: 8px;
		color: #FFFFFF;
		font-size: 15px;
		line-height: 2.4;
		text-align: center;

	}


	.head {
		width: 100%;
		overflow: hidden;

		.arc {
			width: 140%;
			height: 260rpx;
			background: #27285E;
			border-radius: 50%;
			border-radius: 0 0 50% 50%;
			margin-left: -20%;

			.fun {
				width: 66%;

				.logo {
					flex: 1;
				}

				.site-title {
					flex: 1;
				}

				.menu {
					flex: 1;
				}
			}
		}
	}

	.banner {
		margin-top: -50rpx;
		height: 200rpx;
		padding: 0 24rpx;
	}

	.navBar {
		width: 100%;
		margin-top: 60rpx;

		.nav-item {
			width: 25%;
			min-height: 180rpx;
			color: #35353A;

			& ._title {
				width: 90%;
				word-wrap: break-word;
				overflow-wrap: break-word;
			}
		}
	}

	.notify {
		// padding: 14rpx;

		// padding: 24rpx;
		// background: #F8F7FF;

		& ._content {
			color: #35353A;
			margin-left: 26rpx;
		}
	}



	.headlines {
		padding: 24rpx;

		& ._title {
			padding: 30rpx 0;
		}



		.item {
			margin-bottom: 30rpx;

			.tag {
				width: 70rpx;
				height: 40rpx;
				padding: 2px 20rpx;
			}

			// item tag
			.NEW {
				color: #27285E;
				font-size: 24rpx;
				background: #F8F7FF;
				border-radius: 6rpx;
			}

			.HOT {
				color: #9E2224;
				font-size: 24rpx;
				background: #FFF3F5;
				border-radius: 6rpx;
			}

			.summary {
				width: 690rpx;
				white-space: nowrap;
				overflow: hidden;
				text-overflow: ellipsis;
				margin-left: 30rpx;
				color: #35353A;
				font-size: 26rpx;
			}
		}

		.headlines-banner {
			.swiper {
				width: 100%;
				height: 170rpx;
				background: #F7F7F7;
				background-size: 100%;
				background-position: center;
				background-repeat: no-repeat;
				border-radius: 40rpx;
				overflow: hidden;

				swiper-item {
					.swiper-item {
						width: 100%;
						padding: 30rpx;
						display: flex;
						flex-direction: column;

						.title {
							width: 100%;
							font-size: 24rpx;
							font-weight: bold;
							color: #9E2224;
							margin-bottom: 20rpx;
						}

						.summary {
							font-size: 30rpx;
							color: #35353A;
						}
					}

				}
			}
		}
	}

	.market {
		margin-top: 30rpx;
		width: 100%;

		.market-item {
			width: 25%;
			min-height: 90rpx;
			position: relative;
			padding: 24rpx;
			border-radius: 40rpx;

			.title {
				text-align: center;
				line-height: 40rpx;
				font-size: 24rpx;
				color: #35353A;
				width: 90%;
				white-space: pre-line;
			}

			.icon {
				position: absolute;
				right: 24rpx;
				bottom: 24rpx;
			}
		}
	}

	.hotspot {
		padding: 24rpx;

		& ._title {
			padding: 30rpx 0;
			margin-bottom: 15rpx;
		}

		.item {
			margin-bottom: 60rpx;

			.content {
				width: 442rpx;

				.title {
					font-size: 28rpx;
					color: #35353A;
					white-space: nowrap;
					overflow: hidden;
					text-overflow: ellipsis;
					margin-bottom: 40rpx;
				}

				.summary {
					font-size: 24rpx;
					line-height: 40rpx;
					color: #858587;
					overflow: hidden;
					text-overflow: ellipsis;
					display: -webkit-box;
					-webkit-box-orient: vertical;
					-webkit-line-clamp: 2;
				}
			}
		}
	}
</style>