<template>
	<view style="background-color: #F8F8F8;min-height: 100vh;">

		<view class="college-bg">
			<image src="/static/arrow_left.png" mode="aspectFit" style="width: 20px;height: 24rpx;"
				@tap="$u.route({url:'/pages/index/index'});">
			</image>
			<view style="flex:1;text-align: center;color: #EA5A40;font-size: 28rpx;font-weight: 700;">
				ETF
			</view>
		</view>


		<view
			style="display: flex;background-color: #F3F4F6;border-radius: 5px;width: 80%;margin-left: 10%;box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;margin-top: 10px;">
			<view style="color: #000;padding: 10px;" class="flex-1 text-center " @click="sectionChange(0)"
				:style="current==0?'background: #fff;border-radius: 5px;':''"> Quỹ ETF SKS  </view>
			<view style="color: #000;padding: 10px;" class="flex-1 text-center" @click="sectionChange(1)"
				:style="current==1?'background: #fff;border-radius: 5px;bold':''"> Lịch sử giao dịch</view>
		</view>



		<view v-if="current==0">
			<!-- <view class="tile">Vốn tối ưu</view> -->
			<!-- <view class="boxk">Vốn tối ưu, thu nhập tốt hơn</view> -->
			<view class="stock-fund" v-for="(item,index) in list">

				<view class="flex flex-b margin-top-10">
					<view class="bold">{{item.name}}</view>
					<view> {{item.zhouqi}} ngày</view>
				</view>

				<view class="flex flex-b margin-top-10">
					<view>Tỷ suất lợi nhuận</view>
					<view style="color: #43C776;"> {{item.syl}}</view>
				</view>

				<view class="flex flex-b margin-top-10">
					<view>{{item.gz==1?'Nhận lãi hàng ngày':'Nhận lãi từ thứ hai đến thứ sáu'}}</view>
					<view style="color: #43C776;">{{toThousandFilter(item.min_price)}}</view>
				</view>


				<view class="btn_common" style="font-size: 32rpx;line-height: 48rpx;margin-top: 20px;"
					@click="buy(index)">
					Mua
				</view>
			</view>

			<!-- ws 获取的理财资金 -->
			<view class="stock-fund">
				<view style="display: flex;align-items: center;line-height: 1.6;font-size: 32rpx;color:#AAA;">
					<view class="flex-2">Tên</view>
					<view class="flex-2">Giá hiện tại</view>
					<view class="flex-1 text-center" style="">Tăng</view>
				</view>
				<block v-for="(item,index) in wealthNames" :key="item.name">
					<view
						style="display: flex;align-items: center;line-height: 1.8;padding-bottom: 12rpx;border-bottom: 1px solid #666;">
						<view class="flex-1">{{item.name}}</view>
						<view class="flex-1" :style="{color:item.current_price*1>0?`#12F6B8`:`#FF2D30`}">
							{{item.current_price}}
						</view>
						<view style="margin: auto;">
							<view style="padding-right: 24rpx;" :style="{color:item.rate*1>0?`#12F6B8`:`#FF2D30`}">
								{{item.rate}}%
							</view>
						</view>
					</view>
				</block>
			</view>
		</view>

		<view v-if="current==1">
			<view
				style="font-size: 14px;box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(27, 31, 35, 0.15) 0px 0px 0px 1px;margin: 20px;background-color: #fff;"
				class="padding-10 radius10" v-for="(item,index) in order_list">
				<view class="flex flex-b">
					<view>Mua Quỹ FUESVS</view>
					<view style="color: #365B8F;">Quỹ ETF SVS</view>
				</view>
				<view class="flex flex-b margin-top-10">
					<view>Số tiền </view>
					<view style="color: #365B8F;">{{toThousandFilter(item.price)}}</view>
				</view>
				<view class="flex flex-b margin-top-10">
					<view>Chu kỳ đáo hạn quỹ</view>
					<view style="color: #365B8F;">{{item.zhouqi+' ngày'}}</view>
				</view>
				<view class="flex flex-b margin-top-10">
					<view>Ngày thanh toán</view>
					<view style="color: #365B8F;">{{item.endtime}}</view>
				</view>
				<view class="flex flex-b margin-top-10">
					<view>Mã giao dịch</view>
					<view style="color: #365B8F;">{{item.ordersn}}</view>
				</view>
				<view class="flex flex-b margin-top-10">
					<view>Margin (Đòn bẩy)</view>
					<view style="color: #365B8F;">{{item.ganggan}}</view>
				</view>
				<view class="flex flex-b margin-top-10">
					<view>Lợi nhuận hiện tại </view>
					<view style="color: #365B8F;">{{item.syl}}</view>
				</view>

				<view @click="sell(item.id)" v-if="item.status==1" class="text-center padding-5 margin-top-10 radius10"
					style="color:#FFF;background-color: #FF2D30; ">Bán</view>
			</view>

		</view>

		<u-modal :show="xiangqing_show" title="Chi tiết lợi nhuận" :closeOnClickOverlay="true"
			:showConfirmButton="false" @close="xiangqing_show=false" @confirm="confirm" @cancel="xiangqing_show=false">
			<view class="slot-content" style="position: relative;width: 100%;">

				<view v-for="(item,index) in xq_list">
					<u-cell :title="item.created_at" :value="'+'+item.shouyi"></u-cell>
				</view>
			</view>

		</u-modal>

		<u-modal :show="show_js" :title="title" :content='content' :closeOnClickOverlay="true"
			:showConfirmButton="false" @close="show_js=false">
			<view class="slot-content">
				<rich-text :nodes="content"></rich-text>
			</view>
		</u-modal>

		<u-popup :show="show_buy" @close="show_buy=false" :round="20" mode="bottom" :closeable='true'>
			<view class="largeAmount">
				<view class="business" style="color: #000;">
					Đặt lệnh
				</view>
				<view class="flex flex-b margin-top-10">
					<view>
						<view>Tên</view>
						<view class="bold margin-top-5">{{goods_buy.name}}</view>
					</view>

					<view>
						<view>Tên</view>
						<view class="bold margin-top-5">{{goods_buy.zhouqi}} ngày</view>
					</view>
				</view>
				<view style="background-color: #F3F4F6;height: 1px;margin-top: 10px;"></view>

				<view class="flex flex-b margin-top-10">
					<view>
						<view>Tỷ suất lợi nhuận ước tính</view>
						<view style="color: #43C776;margin-top: 5px;">{{goods_buy.syl}}</view>
					</view>

					<view>
						<view>Lợi nhuận ước tính</view>
						<view style="color: #43C776;margin-top: 5px;" class="text-right">
							{{price?toThousandFilter(goods_buy.syls*goods_buy.zhouqi*price*0.01):0}}
						</view>
					</view>
				</view>

				<view class="price" style="color: #000;">Giá đặt lệnh</view>
				<view class="purchase-text">
					<u-input type="number" placeholder="" v-model="price" color="#000"></u-input>
					<view class="hand" style="color:#666;">Khối lượng</view>
				</view>

				<!-- <view class="amount" style="margin-bottom: 20rpx;">1 Lô chẵn = 100 Cổ phiếu </view> -->



				<!-- 杠杆默认有一个数组，当数组大于1，视为开启杠杆功能 -->
				<template v-if="leverList.length>1">
					<view style="font-size: 14px;margin-top: 10px;color: #000;">
						Margin
					</view>

					<view style="display: flex;align-items: center;flex-wrap: wrap;margin-left: 30rpx;">
						<block v-for="(item,index) in leverList" :key="index">
							<view
								style="border-radius: 8rpx;width:12%;margin:10rpx;padding:6rpx 10rpx;line-height: 1.6;text-align: center;"
								:style="{color:curLever==item? '#121212' :'#999',backgroundColor:curLever==item?'#ebdbff'
												:'#F1F1F1'}" @click="chgangeLever(item)">
								{{item}}
							</view>
						</block>
					</view>
				</template>

				<view>
					<view class="purchase "
						style="background-color:#43C776 ;color:#FFF; height: 80rpx;line-height: 80rpx; border-radius: 5px;text-align: center;margin-top: 10px;"
						@click="bulkPurchase(detailId.id)">Đặt lệnh</view>
				</view>
			</view>

		</u-popup>


		<u-action-sheet :show="show" :actions="actions" title="Bội số (đòn bẩy)" @close="show = false" @select="Select">
		</u-action-sheet>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				ganggan: 10,
				leverList: [],
				show: false,
				actions: [{
					name: '1',
					index: 1
				}],
				current: 0,
				show_js: false,
				title: "",
				content: "",
				show_buy: false,
				list: [],
				jijin_name: '',
				goods_buy: [],
				price: '',
				order_list: [],
				xiangqing_show: false,
				xq_list: [],
				socket: null,
				isConnected: false, // 是否链接socket
				wealthNames: [],
			};
		},
		computed: {
			tabs() {
				return [`Quỹ ETF SVS`, `Đơn hàng`]
			},
		},
		onShow() {
			if (this.socket) this.disconnect();
			if (!this.$util.checkToken()) return false;
			this.getlist();
			this.userInfo();
		},
		onHide() {
			if (this.socket) this.disconnect();
		},
		onUnload() {
			if (this.socket) this.disconnect();
		},
		deactivated() {
			if (this.socket) this.disconnect();
		},
		methods: {
			// 根据当前平台，执行回退方式
			goBack() {
				/*#ifdef APP-PLUS*/
				uni.navigateBack({
					delta: 1
				});
				/*#endif*/

				/*#ifdef H5*/
				history.back();
				/*#endif*/
			},
			async sell(id) {
				uni.showModal({
					content: "Bạn có chắc chắn muốn bán không?",
					cancelText: "Hủy bỏ",
					confirmText: "Bán",
					success: (res) => {
						if (res.confirm) {
							this._sell(id)
						} else {
							console.log('cancel') //点击取消之后执行的代码
						}
					}

				})

			},
			async _sell(id) {
				var list = await this.$http.get('api/jijin/sell', {
					id: id,
				})
				uni.hideLoading()
				if (list.data.code == 1) {

					uni.$u.toast(list.data.message);
				} else {
					uni.$u.toast(list.data.message);
					this.getlist()
				}
			},
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			Select(e) {
				console.log(e);
				this.ganggan = e.index
				// this.columns = this.detailedData.ganggan
				// console.log(this.title, '99999');
			},
			//实名认证
			async userInfo() {
				let list = await this.$http.get('api/user/fastInfo', {})
				if (list.data.code == 1) {
					uni.reLaunch({
						url: "/pages/logon/logon/logon"
					})
				}
				this.actions = list.data.data.ganggan

				const temp = list.data.data.ganggan || [];
				if (!temp || temp.length <= 0) return false;

				if (temp[0].index && temp[0].index * 1 > 0) {
					this.leverList = temp.map(item => item.index * 1);
					console.log('array object:', this.leverList);
					return false;
				}
				// ganggan: "2,3,4,5,6,7,8,9,10"
				if (typeof(temp) === 'string') {
					this.leverList = temp.split(',').map(item => item * 1);
					console.log('string:', this.leverList);
					return false;
				}
			},
			async xiangqing(id) {

				var list = await this.$http.post('api/jijin/info', {
					id: id,

				})

				console.log(list)
				this.xq_list = list.data
				this.xiangqing_show = true
			},
			buy(index) {
				this.jijin_name = this.list[index].name
				this.show_buy = true
				this.goods_buy = this.list[index]
				this.goods_buy.syls = this.goods_buy.syl.replace('%', '');
			},
			jieshao(index) {
				console.log(index);
				this.content = this.list[index].content
				this.show_js = true
			},
			confirm() {
				console.log(this.goods_buy);
				var price = this.price
				this.show_buy = false
				uni.showLoading({

				})
				if (!price || price == '') {
					console.log(price);
					// uni.showToast({
					// 	icon:'none',
					// 	title:'请输入金额'
					// })
					uni.$u.toast('Vui lòng nhập số tiền');
				}


				this.buy_goods(price)
			},
			async buy_goods(price) {

				var list = await this.$http.get('api/jijin/buy', {
					id: this.goods_buy.id,
					price: price,
					ganggan: this.ganggan
				})
				uni.hideLoading()
				if (list.data.code == 1) {
					this.show_buy = false
					uni.$u.toast(list.data.message);
				} else {
					uni.$u.toast("Giao dịch thành công ");
					this.getlist()
				}

			},
			async getlist() {
				var list = await this.$http.get('api/jijin/list')
				console.log("基金列表", list);
				this.list = list.data.jj_list
				this.order_list = list.data.order;

				if (this.current == 0) {

					var etf_list = await this.$http.post('api/goods/list')
					console.log(11111, etf_list);


					this.wealthNames = etf_list.data.data
					this.connect();
				}
			},

			// websocket 断线重连
			reconnectWebSocket() {
				// 连接中，并且非手动关闭
				if (this.isConnected) return;
				console.log(`reconnect!`, this.isConnected);
				this.socket = null;
				console.log(`reconnect! socket:`, this.socket);
				this.connect();
			},
			// websocket链接
			connect() {
				//创建webSocket
				this.socket = uni.connectSocket({
					url: this.$http.WsUrl,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.info(`success res:`, res);
					},
					fail: (res) => {
						console.info(`fail res:`, res);
					}
				});
				console.log(`socket:`, this.socket);
				if (this.socket) {
					this.isConnected = true; // 已连接
					this.socket.onOpen((res) => {
						console.info("socket onOpen:", res);
						uni.sendSocketMessage({
							data: `{"type":"sub","topic":"stockRealtimeByListV2","variables":["E1VFVN30","FUEABVND","FUEBFVND","FUEDCMID","FUEFCV50","FUEIP100","FUEKIV30","FUEKIVFS","FUEKIVND","FUEMAV30","FUEMAVND","FUESSV30","FUESSV50","FUESSVFL","FUEVFVND","FUEVN100"],"component":"priceTableEquities"}`
						});
					});
					this.socket.onClose((res) => {
						// code:1000(手动关闭) 1006(异常关闭) 
						console.log(`onClose:`, res);
						this.isConnected = false;
						if (res.code !== 1000) {
							this.reconnectWebSocket();
						}
					});

					this.socket.onError((err) => {
						console.log(`onError:`, err);
						this.isConnected = false;
						this.reconnectWebSocket();
					});

					this.socket.send({
						data: `{"type":"sub","topic":"stockRealtimeByListV2","variables":["E1VFVN30","FUEABVND","FUEBFVND","FUEDCMID","FUEFCV50","FUEIP100","FUEKIV30","FUEKIVFS","FUEKIVND","FUEMAV30","FUEMAVND","FUESSV30","FUESSV50","FUESSVFL","FUEVFVND","FUEVN100"],"component":"priceTableEquities"}`,
						success: (res) => {
							console.log(`send res:`, res);
						}
					});

					this.socket.onMessage((res) => {
						const data = JSON.parse(res.data);
						// console.log(`data:`, data)
						// wealthNames
						this.wealthNames.forEach(item => {
							if (item.name == data[0]) {
								console.log(item.name, data[41])
								if (data[41] * 1 > 0) {
									item.current_price = data[41];
									item.rate = data[52];
								}

							}
						});
					});
				}
			},
			// 关闭 websocket链接
			disconnect() {
				if (this.socket) {
					const result = this.socket.close();
					console.log('disconnect result:', result);
					this.socket = null;
				}
			},
			// socket() {
			// 	var that = this;
			// 	uni.onSocketClose(function(res) {
			// 		console.log('WebSocket 已关闭！');
			// 	});

			// 	uni.connectSocket({
			// 		url: this.$http.WsUrl,
			// 		success(res) {
			// 			console.log("连接成功");
			// 		},
			// 		fail() {
			// 			console.log("连接失败");
			// 		}
			// 	});
			// 	uni.onSocketOpen(function(res) {
			// 		console.log('WebSocket连接已打开！');
			// 		uni.sendSocketMessage({
			// 			data: `{"type":"sub","topic":"stockRealtimeByListV2","variables":["E1VFVN30","FUEABVND","FUEBFVND","FUEDCMID","FUEFCV50","FUEIP100","FUEKIV30","FUEKIVFS","FUEKIVND","FUEMAV30","FUEMAVND","FUESSV30","FUESSV50","FUESSVFL","FUEVFVND","FUEVN100"],"component":"priceTableEquities"}`
			// 		});

			// 	});
			// 	uni.onSocketMessage(function(res) {
			// 		// console.log('收到服务器内容：' + );
			// 		var arr = JSON.parse(res.data);
			// 		console.log('收到服务器内容：' + arr);

			// 		// 然后再获取第41个是实时价
			// 		// 52是上涨比例

			// 		// wealthNames
			// 		that.wealthNames.forEach(item => {
			// 			if (item.name == arr[0]) {
			// 				item.current_price = arr[41];
			// 				item.rate = arr[52];
			// 			}
			// 		});

			// 		// if (that.productDetails.name == arr[0]) {
			// 		// 	console.log('收到服务器内容：' + arr);
			// 		// 	// console.log('goods：' + arr[53]);
			// 		// 	that.today.current_price = arr[41]
			// 		// 	that.today.rate = arr[52]
			// 		// }
			// 	});
			// 	uni.onSocketError(function(res) {
			// 		console.log('WebSocket连接打开失败，请检查！');
			// 		uni.showToast({
			// 			icon: 'none',
			// 			title: 'Mạng chậm'
			// 		})
			// 	});
			// },




			sectionChange(index) {
				console.log(index)
				this.current = index;
				if (this.socket) this.disconnect();
				this.getlist();
			},
			home() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			fundDetails() {
				uni.navigateTo({
					url: '/pages/index/components/fund/fundDetails'
				});
			}

		}
	}
</script>


<style lang="scss">
	.slot-content {
		flex-direction: column !important;
	}


	.tile {
		color: #333;
		font-size: 32rpx;
		font-weight: 500;
		margin: 10rpx 20rpx;
		font-weight: 700;
	}

	.boxk {
		color: rgb(153, 153, 153);
		margin: 0px 20rpx;
		font-size: 24rpx;
	}

	.stock-fund {
		margin: 20rpx 30rpx;
		padding: 40rpx 20rpx;
		border-radius: 10rpx;
		color: #000;
		box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(27, 31, 35, 0.15) 0px 0px 0px 1px;
	}




	.largeAmount {
		padding: 30rpx;

		.business {
			text-align: center;
			font-size: 30rpx;
			color: #333;
			border-bottom: 1rpx solid #e0e0e0;
			padding-bottom: 30rpx;

		}

		.price {
			color: #333;
			font-weight: 500;
			margin: 30rpx 0;
		}

		.purchase-price {
			color: #4bae4f;
			margin: 10rpx;
			font-weight: 600;
		}

		.purchase-text {
			display: flex;
			justify-content: space-between;
			align-items: center;
			border: 1rpx solid #4bae4f;
			padding: 0 20rpx;
			border-radius: 10rpx;
			margin: 20rpx 0;

			.hand {
				border-left: 1rpx solid #4bae4f;
				padding-left: 30rpx;
			}
		}

		.amount {
			color: #999;
			font-size: 24rpx;

			text {
				color: #4bae4f;
				margin-left: 20rpx;
			}
		}

		.available {
			border: 1rpx solid #ebebeb;
			padding: 0 20rpx;
			border-radius: 10rpx;
			margin: 20rpx 0;
		}

		.fund {
			color: #999;
			font-size: 24rpx;

			text {
				color: #f33030;
				margin-left: 20rpx;
			}
		}


	}
</style>