<!-- 大宗交易记录 -->
<template>
	<view>
		<view class="college-bg">
			<image src="/static/arrow_left.png" mode="aspectFit" style="width: 20px;height: 24rpx;"
				@tap="$util.goBack()">
			</image>
			<view style="flex:1;text-align: center;color: #EA5A40;font-size: 28rpx;font-weight: 700;">
				GIAO DỊCH THỎA THUẬN
			</view>
		</view>

		<view style="display: flex;align-items: center;justify-content: space-between;padding:24rpx;">
			<block v-for="(v,k) in tabs" :key="k">
				<view @click="changeTab(k)" style="text-align: center;" class="flex-1"
					:style="{borderColor:curTab==k?'#EA5A40':'transparent',color:curTab==k?'#EA5A40':'#AAA'}">{{v}}
				</view>
			</block>
		</view>

		<view class="" v-for="(item,index) in setList" :key="index">
			<view style="font-size: 14px;line-height: 1.6;box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(27, 31, 35, 0.15) 0px 0px 0px 1px;" class="padding-10 margin-10">
				<view class="flex flex-b color-white ">
					<view>{{item.goods_info.name}}</view>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view style="color: #AAA;font-size: 13px;">Khối lượng khớp lệnh </view>
					<view style="color: #000;">{{toThousandFilter(item.order_buy.num)}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view style="color: #AAA;font-size: 13px;">Margin (Đòn bẩy)</view>
					<view style="color: #000;">{{item.order_buy.double}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view style="color: #AAA;font-size: 13px;">Giá mua vào </view>
					<view style="color: #dc353c;">{{toThousandFilter(item.order_buy.price)}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view style="color: #AAA;font-size: 13px;">Số tiền thanh toán</view>
					<view style="color: #000;">{{toThousandFilter(item.order_buy.amount)}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view style="color: #AAA;font-size: 13px;">Thời gian mua</view>
					<view style="color: #000;">{{item.created_at}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view style="color: #AAA;font-size: 13px;">Trạng thái</view>
					<view style="color:#50a42e;" v-if="item.order_buy.admin_status==1">Đã khớp lệnh</view>
					<view style="color:#f82672 ;" v-if="item.order_buy.admin_status==2">Hủy lệnh</view>
					<view style="color: #000;" v-if="item.order_buy.admin_status==0">Chờ khớp lệnh</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: [],
				curTab: 1,
			};
		},
		computed: {
			tabs() {
				return [`Chờ khớp lệnh`, `Đã khớp lệnh`, `Hủy lệnh`];
			},
			// 过滤
			setList() {
				return this.list.filter(item => item.order_buy.admin_status == this.curTab);
			},
		},
		onShow() {
			this.getList()
		},
		methods: {
			changeTab(val) {
				this.curTab = val;
				this.getList();
			},
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			async getList() {
				const result = await this.$http.post('api/goods-bigbill/user-order-log', );
				if (result.data.code == 0) {
					const temp = result.data.data;
					this.list = temp.filter(item => item.order_buy);
				}
			},
		},
	}
</script>

<style lang="scss">
	
</style>