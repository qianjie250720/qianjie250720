<!-- 学院 -->
<template>
	<view>
		<view class="college-bg">
			<image src="/static/arrow_left.png" mode="aspectFit" style="width: 20px;height: 24rpx;"
				@tap="$util.goBack()">
			</image>
			<view style="flex:1;text-align: center;color: #EA5A40;font-size: 28rpx;font-weight: 700;">CHI TIẾT CỔ PHIẾU MỚI
			</view>
		</view>

		<template v-if="detail">
			<view style="margin: 24rpx 24rpx 0 24rpx;">
				<view style="color: #fff;font-size: 28rpx;font-weight: 500;">{{detail.name}}</view>
				<view
					style="display: flex;align-items: center;justify-content: space-between;color: #FFF;line-height: 2.4;">
					<view style="color: #000;font-size: 13px;">Giá phát hành</view>
					<view style="color: #000;font-weight: 700;">{{toThousandFilter(detail.price)}}</view>
				</view>
				<view
					style="display: flex;align-items: center;justify-content: space-between;color: #FFF;line-height: 2.4">
					<view style="color: #000;font-size: 13px;">Tổng KL phát hành</view>
					<view style="color: #000;font-weight: 700;">{{toThousandFilter(detail.fa_amount)}}</view>
				</view>
			</view>
			<!-- 步骤条 -->
			<!-- <view style="background-color: #FFF;padding:12rpx;margin:0 24rpx;border-radius: 12rpx;">
				<u-steps current="0" activeColor="#3E6EB2">
					<u-steps-item title="Ngày mua" :desc="detail.shengou_date"></u-steps-item>
					<u-steps-item title="Công bố" :desc="detail.gb_date"></u-steps-item>
					<u-steps-item title="Đăng ký" :desc="detail.rj_date"></u-steps-item>
					<u-steps-item title="Đợi niêm yết" :desc="detail.online_date"></u-steps-item>
				</u-steps>
			</view> -->

			<view style="margin:12rpx 24rpx;">
				<!-- <view
					style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
					Tổng quan phát hành cổ phiếu {{detail.name}}
					<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
						 border-radius: 8px;">
					</view>
					<view
						style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; #000 font-weight: 800; width: 100%; text-align: center;">
						Tổng quan phát hành cổ phiếu {{detail.name}}</view>
				</view> -->

				<view
					style="display: flex;align-items: center;justify-content: space-between;color: #FFF;line-height: 2.4">
					<view style="color: #000;font-size: 13px;">Tổng quỹ vốn</view>
					<view style="color: #000;font-weight: 700;">{{toThousandFilter(detail.fa_muji_zijin)}}</view>
				</view>

				<view
					style="display: flex;align-items: center;justify-content: space-between;color: #FFF;line-height: 2.4">
					<view style="color: #000;font-size: 13px;">Thời gian mua</view>
					<view style="color: #000;font-weight: 700;">{{detail.shengou_date}}</view>
				</view>
			</view>

			<view style=" border-top: 1rpx dashed #ccc;padding: 20rpx 0;margin: 24rpx;">
				<view
					style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
					Khối lượng mua
					<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					 border-radius: 8px;">
					</view>
					<view
						style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color:#000; font-weight: 800; width: 100%; text-align: center;">
						Khối lượng mua</view>
				</view>
				<view class="input_wrapper">
					<input placeholder="Vui lòng nhập khối lượng cần mua" type="number" v-model="quantity"
						:placeholderStyle="$theme.setPlaceholder()"></input>
				</view>

				<view
					style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
					Margin ( Đòn bẩy )
					<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					 border-radius: 8px;">
					</view>
					<view
						style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color:#000; font-weight: 800; width: 100%; text-align: center;">
						Margin ( Đòn bẩy )</view>
				</view>
				<view class="input_wrapper">
					<view style="width: 90%;" @click="chooseLever()">{{ganggan}}</view>
				</view>
			</view>

			<view class="btn_common" style="font-size: 32rpx;width: 80%;margin: 20rpx auto;line-height: 64rpx;"
				@click="purchase()">Mua</view>

			<u-action-sheet :show="ganggan_show" :actions="actions" title="Margin (Đòn bẩy)"
				@close="ganggan_show = false" @select="Select">
			</u-action-sheet>

			<!-- 弹窗 -->
			<!-- <u-modal :show="show" title="Nhấn xác nhận để mua" @cancel="cancel" @confirm="confirm()" cancelText='Hủy bỏ'
				confirmText="Xác nhận" showCancelButton :content='content'>
			</u-modal> -->

		</template>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				id: '', // 带入参
				detail: null, // 详情
				quantity: '',

				actions: [{
					name: '1',
					index: 1
				}],
				ganggan: 1,
				ganggan_show: false,
			};
		},
		//传值过来接收
		onLoad(opt) {
			this.id = opt.id || this.id;
		},
		// 进入页面就开始渲染
		onShow() {
			this.userInfo();
			this.getDetail()
		},
		methods: {
			chooseLever() {
				this.ganggan_show = true;
			},

			Select(e) {
				console.log(e);
				this.ganggan = e.index
				// this.columns = this.detailedData.ganggan
				// console.log(this.title, '99999');
			},
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},

			// 点击申购
			async purchase() {
				let list = await this.$http.post('api/goods-shengou/doOrder', {
					num: this.quantity,
					id: this.detail.id,
					ganggan: this.ganggan
					// price: this.price
				})
				if (list.data.code == 0) {
					uni.showLoading({
						title: "Đang khớp lệnh, vui lòng chờ trong giây lát ...",
						mask: true, // 显示透明蒙层，防止触摸穿透
					});
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/index/components/newShares/applyPurchase/applyPurchase'
						});
						uni.hideLoading();
					}, 1000)
				} else {
					uni.$u.toast(result.data.message);
				}
			},
			//
			async getDetail() {
				const result = await this.$http.get('api/goods-shengou/detail', {
					id: this.id
				});
				console.log(result);
				if (result.data.code == 0) {
					const temp = result.data.data;
					this.detail = {
						id: temp.id,
						price: temp.price * 1,
						name: temp.goods.name,
						fa_amount: temp.fa_amount,
						fa_muji_zijin: temp.fa_muji_zijin,

						shengou_date: temp.shengou_date || `Chưa công bố`,
						gb_date: temp.gb_date || 'unannounced',
						rj_date: temp.rj_date || 'unannounced',
						online_date: temp.online_date || 'unannounced',
					};
				}
			},
			async userInfo() {
				const result = await this.$http.get('api/user/fastInfo', {})
				if (result.data.code == 0) {
					const temp = result.data.data;
					// // 应客户需求，改为固定杠杆1 /by 2024.06.06
					// list.data.data.ganggan.splice(0, 1);
					// // console.log(list.data.data.ganggan);
					this.actions = temp.ganggan;
				}
			},

		},


	}
</script>

<style lang="scss">
	//  u-picker 样式覆盖
	::v-deep .u-popup__content {
		background-color: #151517 !important;

		.uni-picker-view-mask {
			background: none !important;
		}

		.u-picker__view__column__item {
			background-color: #333 !important;
		}

		.u-action-sheet__item-wrap__item__name {
			color: #FFF !important;
		}

		.u-action-sheet__header__title {
			color: #FFF;
		}

		.u-action-sheet--hover {
			background-color: #333 !important;
		}
	}

	.college-bg {
		padding: 48rpx;
		background-color: #FFFAF9;
		margin-bottom: 24rpx;
		display: flex;
		align-items: center;
	}

	.college-content {
		margin: 30rpx 0;
		padding: 10rpx 30rpx;
	}
</style>