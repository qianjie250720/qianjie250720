<template>
	<view style="background-color: #F8F8F8;min-height: 100vh;">
		<!-- 头部选项卡 -->
		<view class="college-bg">
			<image src="/static/arrow_left.png" mode="aspectFit" style="width: 20px;height: 24rpx;" @tap="$u.route({url:'/pages/index/index'});">
			</image>
			<view style="flex:1;text-align: center;color: #EA5A40;font-size: 28rpx;font-weight: 700;">
				{{list[current]}}
			</view>
		</view>

		<!-- 内容 -->
		<view style="padding-top: 20px;">
			<!-- <view v-if="current == 2">
				<zhaijuan :newShares_list2='newShares_list2' ></zhaijuan>
			</view> -->


			<view v-if="current == 2">
				<applyPurchase :newShares_list='newShares_list'></applyPurchase>
			</view>

			<!-- <view v-if="current == 3">
				<newShareRaising></newShareRaising>
			</view> -->

		
			<!-- <view v-if="current == 3">
				<newBondPlacement></newBondPlacement>
			</view> -->


			<view v-if="current == 0">
				<vipScramble></vipScramble>
			</view>

			<!-- <view v-if="current == 3">
				<subscriptionBonds></subscriptionBonds>
			</view> -->
		</view>
	</view>

	</view>
</template>

<script>
	import zhaijuan from "../../../../components/new-shares/zhaijuan.vue";
	import applyPurchase from "../../../../components/new-shares/applyPurchase.vue";
	import newShareRaising from "../../../../components/new-shares/newShareRaising.vue";
	// import subscriptionBonds from "../../../../components/new-shares/subscriptionBonds.vue";
	// import newBondPlacement from "../../../../components/new-shares/newBondPlacement.vue";
	
	import vipScramble from "../../../../components/new-shares/vipScramble.vue";
	export default {
		components: {
			zhaijuan,
			applyPurchase,
			newShareRaising,
			// subscriptionBonds,
			// newBondPlacement,
		
			vipScramble,

		},
		data() {
			return {
				current: 0,
				list: ['Giao dịch', 'Quyền mua', "CỔ PHIẾU MỚI"],
				newShares_list: "",
				newShares_list2: "",

			};
		},
		onLoad(option) {
			if (option.index) {
				this.current = option.index
				// this.newShares()
				if (this.current == 2) {
					this.newShares()
				}
				// this.newShares2()
			}
		},
		onShow() {
			if (!this.$util.checkToken()) return false;
		},

		methods: {
			// 根据当前平台，执行回退方式
			goBack() {
				/*#ifdef APP-PLUS*/
				uni.navigateBack({
					delta: 1
				});
				/*#endif*/

				/*#ifdef H5*/
				history.back();
				/*#endif*/
			},
			searchFor() {
				uni.navigateTo({
					url: '/pages/searchFor/searchFor'
				});
			},
			select(item) {
				this.current = item.index;
			},
			//新股申购
			async newShares() {
				let list = await this.$http.post('api/goods-shengou/calendar', {
					type: 1,
				})
				this.newShares_list = list.data.data
			},
			async newShares2() {
				let list = await this.$http.post('api/goods-shengou/zhaijuan', {
					type: 2,
				})
				this.newShares_list2 = list.data.data
				// console.log(list.data.data, '待申购');
			},
		},

	}
</script>

<style lang="scss">
	//公共css 开始
	.display {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}


</style>