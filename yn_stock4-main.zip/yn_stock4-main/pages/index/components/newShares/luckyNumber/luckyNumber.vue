<!-- 中签记录 -->
<template>
	<view style="background-color: #F8F8F8;min-height: 100vh;">
		<view class="college-bg">
			<image src="/static/arrow_left.png" mode="aspectFit" style="width: 20px;height: 24rpx;"
				@tap="$u.route({url:'/pages/index/components/newShares/newShares?index=2'});">
			</image>
			<view style="flex:1;text-align: center;color: #EA5A40;font-size: 28rpx;font-weight: 700;">
				LỊCH SỬ ĐĂNG KÝ
			</view>
		</view>
		
		<view style="display: flex;background-color: #F3F4F6;border-radius: 5px;width: 80%;margin-left: 10%;box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;">
				<view style="color: #000;background: #fff;padding: 10px;border-radius: 5px;" class="flex-1 text-center bold">  Lịch sử đăng ký </view>
				<view style="color: #000;padding: 10px;" class="flex-1 text-center" @tap="$u.route({url:'/pages/index/components/newShares/applyPurchase/applyPurchase'});"> Lệnh đã gửi </view>
		</view>
		

		<view class="" v-for="(item,index) in list" :key="index">
			<view style="font-size: 14px;line-height: 1.6;box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(27, 31, 35, 0.15) 0px 0px 0px 1px;" class="padding-10 margin-10 radius10">
				<view class="flex flex-b bold">
					<view>{{item.goods.name}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view style="color: #000;font-size: 13px;">Giá mua</view>
					<view style="color: #365B8F;">{{toThousandFilter(item.price)}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view style="color: #000;font-size: 13px;">Khối lượng đăng ký </view>
					<view style="color: #365B8F;">{{toThousandFilter(item.apply_amount)}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view style="color: #000;font-size: 13px;">Margin (Đòn bẩy)</view>
					<view style="color: #365B8F;">{{item.ganggan}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view style="color: #000;font-size: 13px;">Khối lượng trúng thầu </view>
					<view style="color: #365B8F;">{{toThousandFilter(item.success)}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view style="color: #000;font-size: 13px;">Số tiền thanh toán </view>
					<view style="color: #365B8F;">{{toThousandFilter(item.total)}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view style="color: #000;font-size: 13px;">Mã giao dịch</view>
					<view style="color: #365B8F;">{{item.order_sn}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view style="color: #000;font-size: 13px;">Trạng thái</view>
					<view style="color: #f6ab44;">{{item.message}}</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: [],
			};
		},
		onLoad(option) {},
		onShow() {
			this.shengou()
		},

		methods: {
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			// 中签记录
			async shengou() {
				let list = await this.$http.post('api/goods-shengou/user-success-log', {
					// status: 2,
					// language: this.$i18n.locale
				})
				this.list = list.data.data
				// console.log(list.data.data)
			},

			// async subscription(item) {
			// 	let list = await this.$http.get('api/goods-shengou/pay', {
			// 		id: item.id
			// 	})
			// 	if (list.data.code == 0) {
			// 		uni.$u.toast(list.data.data.message);
			// 		if (list.data.data.success == 0) {
			// 			setTimeout(() => {
			// 				uni.navigateTo({
			// 					//保留当前页面，跳转到应用内的某个页面
			// 					url: '/pages/my/components/certificateBank/silver'
			// 				});
			// 			}, 500)
			// 		} else {
			// 			uni.redirectTo({
			// 				url: '/pages/index/components/newShares/luckyNumber/luckyNumber',
			// 			});
			// 			this.$router.go(0)

			// 		}
			// 	} else {
			// 		uni.$u.toast(list.data.data.message);
			// 	}
			// },
		},
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 48rpx;
		background-color: #FFFAF9;
		margin-bottom: 24rpx;
		display: flex;
		align-items: center;
	}
</style>