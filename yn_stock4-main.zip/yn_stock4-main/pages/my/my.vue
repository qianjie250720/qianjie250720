<template>
	<view>
		<view class="flex flex-b padding-20 padding-top-20" style="padding: 24rpx;color: #fff;">
			<!-- <image src="/static/logo_name.png" mode="widthFix" style="width: 130px;height: 70px;"></image>
			<image src="/static/search.png" mode="widthFix" style="width: 20px;height: 20px;"
				@click="$u.route({url:'/pages/searchFor/searchFor'});"></image> -->
		</view>

		<view style="display: flex;align-items: center;">
			<view>
				<view style="display: flex;align-items: center;justify-content: center;margin-left: 36rpx;">
					<u-avatar size='60' :src="userInfo.avatar" shape="" default-url="/static/logo.png"></u-avatar>
				</view>
			</view>
			<view style="flex:1;">
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view>
						<view style="display: flex;align-items: center; padding:10rpx 20rpx;">
							<view style="font-size: 36rpx;color:#000;">
								{{userInfo.real_name}}
							</view>
						</view>
						<view style="display: flex;align-items: center; padding:0 20rpx;">
							<view style="font-size: 32rpx;color:#82807f;">
								ID: {{userInfo.p_mobile}}
							</view>
						</view>
					</view>
					<view style="margin-left: auto;" @click="customer()">
						<image mode="aspectFit" :src="`/static/kefu.png`"
							style="width:40px;height: 30px;padding-right: 10px;">
						</image>
					</view>
				</view>
				<!-- 这是认证成功的 -->
				<template v-if="userInfo.is_check==1">
					<view style="display: flex;align-items: center;">
						<image src="../../static/renzheng2.png" mode=""
							style="padding-right: 12rpx;width: 14px;height: 16px;"></image>
						<view class="" style="font-size: 20rpx;color:#999;">Tài khoản đã định danh 
						</view>
					</view>
				</template>
				<template v-else>
					<view style="display: flex;align-items: center;padding-left: 20rpx;" @tap="notCertified()">
						<image src="../../static/renzheng.png" mode=""
							style="padding-right: 12rpx;width: 14px;height: 16px;"></image>
						<view class="" style="font-size: 20rpx;color:#999;">Tài khoản chưa hoàn tất bước xác
							minh danh tính
						</view>
					</view>
				</template>
			</view>
		</view>
		
		<view style="margin:20rpx;border-radius: 20rpx;background-image: url(/static/position_card_bg.png);
		background-repeat: no-repeat;background-position: 0 0;background-size: 100% 100%;box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;">
			<view style="display: flex;flex-direction: column;justify-content: space-between;">
				<view style="padding: 30rpx;0 24rpx 24rpx;">
					<view style="display: flex;align-items: center;margin-left: 16px;" class="justify-center">
						<view style="color: #000;font-size: 14px;">Tổng tài sản (VND)</view>
						<image :src="`/static/mask_${isMask?'show':'hide'}.png`" mode="aspectFit"
							style="width: 32rpx;height: 32rpx;padding-left: 12rpx;" @click="toggleMask()">
						</image>
					</view>
					<view style="font-size: 48rpx;font-weight: 700;color: #000;line-height: 2;text-align: center;">
						{{isMask?`******`: toThousandFilter(userInfo.totalZichan*1+userInfo.holdYingli*1)}}
					</view>
					<view style="display: flex;align-items: center;color: #000;line-height: 1.4;" class="justify-center">
						<view style="font-size: 24rpx;padding-right: 24rpx;">Tổng lãi lỗ</view>
						<view :style="{color:userInfo.holdYingli>0?'#43c776':'red'}" class="bold">
							{{isMask?`******`:toThousandFilter(userInfo.holdYingli)}}
						</view>
					</view>
					<view style="display: flex;align-items: center;color: #000;line-height: 1.4;" class="justify-center">
						<view style="font-size: 24rpx;padding-right: 24rpx;">Tổng giá trị thị trường</view>
						<view style="color: #000;font-weight: 700;">{{isMask?`******`:toThousandFilter(userInfo.frozen)}}</view>
					</view>
					<view style="display: flex;align-items: center;color: #000;line-height: 1.4;" class="justify-center">
						<view style="font-size: 24rpx;padding-right: 24rpx;">Sức mua</view>
						<view style="color: #000;font-weight: 700;">{{isMask?`******`:toThousandFilter(userInfo.money)}}</view>
					</view>
				</view>
			</view>
		</view>
		
		<view class="margin-10 flex flex-b gap10">
			<image src="/static/tixian.png" mode="widthFix" class="flex-1" @click="silver()" style="box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;border-radius: 10px;"></image>
			<image  src="/static/chongzhi.png" mode="widthFix" class="flex-1" @click="prove()" style="box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;border-radius: 10px;"></image>
		</view>
		<view
			style="display: flex;flex-wrap: wrap;justify-content: space-between;margin: 10rpx 20rpx;border-radius: 8rpx;">
			
			<block v-for="(item,index) in nav" :key="index">
				<view style="width: 99%;">
					<view style="display: flex;align-items: center;margin:10rpx;;padding:20rpx 0rpx;" class="gap10"
						@click="actionEvent(item,index)">
						<image mode="aspectFit" :src="`/static/my/${item.icon}.png`" style="width:30px;height: 30px;">
						</image>
						<text style="font-size: 28rpx;color: #000;margin-left: 10px;" class="flex-3 bold">{{item.name}}</text>
						<image src="/static/arrow_right.png" mode="aspectFit" style="width: 12px;height: 12px;"></image>
					</view>
				</view>
			</block>

		</view>

		<!-- -->
		<view class="btn_common" style="font-size: 30rpx;width: 80%;margin: 60rpx auto;line-height: 64rpx;"
			@click="signOut"> Đăng xuất</view>
		
		<tabBar :current="4"></tabBar>
	</view>
</template>

<script>
	import Profile from '@/components/Profile.vue';
	import tabBar from '@/components/tabBar.vue';
	// import annular from "./components/annular/annular.vue"
	export default {
		components: {
			Profile,
			tabBar
		},
		data() {
			return {
				isMask: true,
				// popupshow: true,
				downloadUrl: '',
				updateDesc: "",
				update: '',
				closeOnClickOverlay: false,
				//手机号
				tel: '',
				userInfo: '',
				is_check: '',
				bank_card_info: '',
				item: '',
				nav: [{
						name: 'Đổi mật khẩu',
						url: '/pages/my/components/commonFunctions/changePassword',
						icon: 'signin_pwd',
						mode: 'link',
					}, {
						name: 'Mật khẩu giao dịch',
						url: '/pages/my/components/commonFunctions/fundPassword',
						icon: 'pay_pwd',
						mode: 'link',
					}, {
						name: 'Liên kết ngân hàng',
						url: '/pages/my/components/bankCard/renewal',
						icon: 'bank_card',
						mode: 'link',
					}, {
						name: 'LS dòng tiền',
						url: '/pages/my/components/commonFunctions/capitalDetails?index=0',
						icon: 'capital_deatil',
						mode: 'link',
					},
					{
						name: 'Điều khoản & Thỏa thuận',
						url: '/pages/my/components/other/aboutUs',
						icon: 'about',
						mode: 'link',
					},
					// {
					// 	name: 'Đăng xuất',
					// 	url: '',
					// 	icon: 'sign_out',
					// 	mode: 'sign_out',
					// }
				]
			}
		},
		onShow() {
			if (!this.$util.checkToken()) return false;
			this.gaint_info();
			this.isMask = uni.getStorageSync('mask');
		},
		//下拉刷新
		onPullDownRefresh() {
			uni.showLoading({
				title: 'Loading',
			});
			//关闭加载提示
			setTimeout(() => {
				uni.hideLoading();
			}, 1000);
			this.gaint_info()
			uni.stopPullDownRefresh()
		},

		methods: {
			// 显隐掩码
			toggleMask() {
				this.isMask = !this.isMask;
				uni.setStorageSync('mask', this.isMask);
			},
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,')
			},
			signOut() {
				uni.removeStorageSync("token")
				uni.navigateTo({
					url: "/pages/logon/logon/logon"
				})
			},

			actionEvent(item, index) {

				uni.navigateTo({
					url: item.url,
				})
			},

			//客服
			customer() {
				uni.navigateTo({
					url: '/pages/index/components/customer/customer'
				});
			},


			// 银转证
			silver() {
			
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/certificateBank/silver'
				});
		
		
		
			},
			// 证转银
			prove() {
				
				if (this.bank_card_info && this.userInfo.idno !== null) {
					uni.navigateTo({
						//保留当前页面，跳转到应用内的某个页面
						url: '/pages/my/components/certificateBank/prove'
					});
				} else if (this.bank_card_info == null) {
					uni.$u.toast('Vui lòng liên kết tài khoản ngân hàng');
					setTimeout(() => {
						uni.navigateTo({
							//保留当前页面，跳转到应用内的某个页面
							url: '/pages/my/components/bankCard/renewal'
						});
					}, 2000)
				} else if (this.userInfo.idno == null) {
					uni.$u.toast('Chưa xác thực danh tính');
					setTimeout(() => {
						uni.navigateTo({
							//保留当前页面，跳转到应用内的某个页面
							url: '/pages/index/components/openAccount/openAccount'
						});
					}, 2000)
				}
				
				
			},

			// 卡管理
			manage(bank_name, bank_sub_name, card_sn) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/bankCard/binding' +
						`?bank_name=${bank_name}&bank_sub_name=${bank_sub_name}&card_sn=${card_sn}`
				});
				// console.log(bank_name, '22222');
			},



			//实名认证
			notCertified() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					// url: '/pages/index/components/openAccount/openAccount'
					url: '/pages/marketQuotations/authentication'
				});
			},


			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInfo = list.data.data
				this.bank_card_info = list.data.data.bank_card_info
			},

		},



	}
</script>

<style lang="scss">
	@import url("@/common/css/rc.css");

	.attestation {
		color: #fff;

		.success {
			display: flex;
			justify-content: center;
			align-items: center;
		}

		.certification-icon {
			padding: 4rpx 10rpx;
			background-color: transparent;
			border-radius: 40rpx;
			font-size: 28rpx;


			image {
				width: 30rpx;
				height: 30rpx;
				margin: 0;
			}

			view {
				margin: 0 10rpx;
			}

			.you {
				width: 20rpx;
				height: 20rpx;
			}
		}
	}



	//总资产
	.total-assets {
		box-shadow: 0 2rpx 2rpx 0 #e3e3e3;
		background: #fff;
		border-radius: 20rpx;
		margin: -100rpx 30rpx 0rpx;
		// display: flex;
		// justify-content: space-between;
		flex-wrap: wrap;
		align-items: center;
		padding: 30rpx;

		.account {
			// border: 20rpx solid #ea3544;
			border-radius: 30rpx;
			padding: 60rpx;
			margin: 30rpx;
			text-align: center;

			.assets-money {
				color: #ea3544;
				font-size: 46rpx;
				font-weight: 800;
			}

			.assets-text {
				color: #999;
				font-size: 28rpx;
			}
		}


		.fund {
			display: flex;
			flex-wrap: wrap;
			justify-content: space-around;
			align-items: center;
			margin: 30rpx 0;

			.hushen {
				width: 45%;
				font-size: 28rpx;
				display: flex;
				flex-direction: column;
				align-items: center;

				image {
					width: 30rpx;
					height: 30rpx;
					margin-right: 10rpx;
				}

				.money {
					color: #ea3544;
					font-size: 28rpx;
					margin-top: 20rpx;
					font-weight: bold;

				}
			}

		}

	}

	.press {
		// width: 100%;
		// box-shadow: 0rpx 2rpx 2rpx 2rpx #cfcfcf;
		margin: 30rpx 10rpx;
		padding: 10rpx 20rpx;
		border-radius: 10px;

		.bank-to-securities {
			padding: 24rpx 0;
			// width: 48%;
			// background: linear-gradient(to left, #4CA1AF, #C4E0E5);
			// background: linear-gradient(to left, #17A75B, #1fe67c);
			background: #0a9696;

			border-radius: 10rpx;
			color: #fff;
			flex-wrap: 800;
			font-size: 30rpx;
			text-align: center;
			margin: 30rpx 0;
			box-shadow: 0rpx 2rpx 2rpx 2rpx #e3e3e3;
		}

		.certificate-to-bank {
			padding: 24rpx 0;
			// width: 48%;
			// background: linear-gradient(to left, #17A75B, #1fe67c);
			// background: #E5CDAC;
			background: #a2c6b6;
			border-radius: 10rpx;
			color: #fff;
			flex-wrap: 800;
			font-size: 30rpx;
			text-align: center;
			margin: 30rpx 0;
			box-shadow: 0rpx 2rpx 2rpx 2rpx #e3e3e3;
		}
	}

	.tile {
		margin: 30rpx;
	}

	.common-use {
		display: flex;
		justify-content: space-around;
		align-items: center;
		text-align: center;
		background: #fff;
		box-shadow: 0rpx 2rpx 2rpx 2rpx #f4f4f4;
		border-radius: 10px;
		// border: 1rpx solid #cfcfcf;
		margin: 30rpx;
		padding: 40rpx 20rpx;
		font-size: 28rpx;

		image {
			width: 60rpx;
			height: 60rpx;

		}
	}

	.card {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin: 60rpx 30rpx;

		image {
			width: 20rpx;
			height: 20rpx;
			margin-left: 10rpx;
		}
	}

	//线
	.thread {
		height: 1rpx;
		width: 100%;
		background: #e0e0e0;
	}

	.ganh {
		background: #fff;
		box-shadow: 0rpx 2rpx 2rpx 2rpx #f4f4f4;
		border-radius: 10px;
		margin: 30rpx;
		font-size: 28rpx;

		.renew {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 20rpx;

			.version-update {
				display: flex;
				justify-content: flex-start;
				align-items: center;
			}

			.renew-img {
				margin: 10rpx 10rpx 0 0;

				image {
					width: 40rpx;
					height: 40rpx;
				}


			}

			.right-side {
				image {
					width: 20rpx;
					height: 20rpx;
				}
			}

		}


	}
</style>