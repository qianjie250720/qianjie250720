<!-- 资金明细 -->
<template>
	<view style="background-color: #F8F8F8;min-height: 100vh;">
		
		
		<view class="college-bg">
			<image src="/static/arrow_left.png" mode="aspectFit" style="width: 20px;height: 24rpx;" @tap="$u.route({url:'/pages/index/index'});">
			</image>
			<view style="flex:1;text-align: center;color: #EA5A40;font-size: 28rpx;font-weight: 700;">
				Chi tiết dòng tiền
			</view>
		</view>
			
			
		
		<view style="display: flex;background-color: #F3F4F6;border-radius: 5px;box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(27, 31, 35, 0.15) 0px 0px 0px 1px;margin-top: 10px;margin: 15px;">
			<view style="color: #000;padding: 5px;" class="flex-1 text-center" @click="changeTab(index)"
				:style="current==index?'background: #fff;border-radius: 5px;bold;':''" v-for="(item,index) in tabs">
				{{item}}
			</view>
		</view>
		
		<view class="college-content">
			<!-- <u-tabs lineColor="#fff" :current="current" :list="list1" @click="select"
				:activeStyle="{color: '#fff',fontWeight: 'bold',}" :inactiveStyle="{color: '#e9f2de'}"></u-tabs> -->
			<!-- <view v-if="current == 0">
				<template v-if="!fundDetails || fundDetails.length<=0">
					<view style="text-align: center;margin-top: 10vh;">
						<image src="/static/empty_data.png" mode="aspectFit" style="width: 480rpx;height: 480rpx;">
						</image>
					</view>
				</template>
				<template v-else>
					<view v-for="(item,index) in fundDetails" :key="index">
						<view  style="color: #000;background-color: #fff;padding:20rpx;border-radius: 12rpx;line-height: 1.8;box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(27, 31, 35, 0.15) 0px 0px 0px 1px;padding: 10px;margin: 15px;font-size: 14px;">
						
							
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view>Số tiền</view>
								<view style="color: #43C776;"> {{toThousandFilter(item.money)}}  đ</view>
							</view>
							
							
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view>Số dư</view>
								<view> {{toThousandFilter(item.after)}}  đ</view>
							</view>
							
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view>Số dư trước giao dịch</view>
								<view>{{toThousandFilter(item.before)}} đ</view>
							</view>
							
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view>Thời gian</view>
								<view>{{item.created_at}}</view>
							</view>
							
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view>{{item.desc}}</view>
							</view>
							
							
						</view>
					</view>
				</template>
			</view> -->
			<view v-if="current == 0">
				<template v-if="!rechargeRecord || rechargeRecord.length<=0">
					<view style="text-align: center;margin-top: 10vh;">
						<image src="/static/empty_data.png" mode="aspectFit" style="width: 480rpx;height: 480rpx;">
						</image>
					</view>
				</template>
				<template v-else>
					<view class="" v-for="(item,index) in rechargeRecord" :key="index">
						<view style="color: #000;background-color: #fff;padding:20rpx;border-radius: 12rpx;line-height: 1.8;box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(27, 31, 35, 0.15) 0px 0px 0px 1px;padding: 10px;margin: 15px;font-size: 14px;">
						
							<view class="flex flex-b">
								<view>Nạp tiền</view> 
								<view style="color: #43C776;"> {{toThousandFilter(item.money)}} đ</view>
							</view>
							
							<view class="flex flex-b">
								<view>Trạng thái</view>
								<view>
									<view class="flex gap5" v-if="item.status==0" style="color: #d50000;">
										<u-icon name="clock" color='#d50000' size="12"></u-icon>Đang xem xét
									</view>
									<view class="flex gap5" v-if="item.status==1" style="color: #5AC725;">
										<u-icon name="checkmark-circle" color='#5AC725' size="12"></u-icon>Nạp tiền thành
										công
									</view>
									<view class="flex gap5" v-if="item.status==2" style="color: #F9AE3D;">
										<u-icon name="close-circle" color='#F9AE3D' size="12"></u-icon>Thất bại, liên hệ với
										khách hàng
									</view>
								</view>
							</view>
							
							<view class="flex flex-b">
								<view>Mã giao dịch</view>
								<view>{{item.order_sn}}</view>
							</view>
							<view class="flex flex-b">
								<view>Thời gian</view>
								<view>{{item.created_at}}</view>
							</view>
							
						</view>
					</view>
				</template>

			</view>
			<view v-if="current == 1">
				<template v-if="!withdrawalRecords || withdrawalRecords.length<=0">
					<view style="text-align: center;margin-top: 10vh;">
						<image src="/static/empty_data.png" mode="aspectFit" style="width: 480rpx;height: 480rpx;">
						</image>
					</view>
				</template>
				<template v-else>
					<view class="" v-for="(item,index) in withdrawalRecords" :key="index">
						<view style="color: #000;background-color: #fff;padding:20rpx;border-radius: 12rpx;line-height: 1.8;box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(27, 31, 35, 0.15) 0px 0px 0px 1px;padding: 10px;margin: 15px;font-size: 14px;">
							
							<view class="flex flex-b">
								<view>Rút tiền</view>
								<view style="color: #43C776;"> {{toThousandFilter(item.money)}} đ</view>
							</view>
							
							<view class="flex flex-b">
								<view>Trạng thái</view>
								<view>
									<view class="flex gap5" v-if="item.status==0" style="color: #d50000;">
										<u-icon name="clock" color='#d50000' size="12"></u-icon>Đang xử lý
									</view>
									<view class="flex gap5" v-if="item.status==1" style="color: #5AC725;">
										<u-icon name="checkmark-circle" color='#5AC725' size="12"></u-icon>Rút tiền thành công
									</view>
									<view class="flex gap5" v-if="item.status==2" style="color: #F9AE3D;">
										<u-icon name="close-circle" color='#F9AE3D' size="12"></u-icon>Thất bại, liên hệ với khách hàng
									</view>
								</view>
							</view>
							<view class="flex flex-b">
								<view>Mã giao dịch</view>
								<view>{{item.order_sn}}</view>
							</view>
							<view class="flex flex-b">
								<view>Thời gian</view>
								<view>{{item.created_at}}</view>
							</view>
						</view>
					</view>
				</template>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				current: 0,
				fundDetails: [],
				rechargeRecord: [],
				withdrawalRecords: [],
			};
		},
		computed: {
			tabs() {
				return ['Lịch sử nạp tiền', 'Lịch sử rút tiền']
			}
		},

		onLoad(item) {
			this.current = item.index || 0;
		},

		onShow() {
			// if (this.current == 0) this.fund()
			if (this.current == 0) this.recharge()
			if (this.current == 1) this.withdrawal()
		},
		methods: {
			changeTab(val) {
				this.current = val;
				// if (this.current == 0) this.fund()
				if (this.current == 0) this.recharge()
				if (this.current == 1) this.withdrawal()
			},
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,')
			},
			// 根据当前平台，执行回退方式
			goBack() {
				/*#ifdef APP-PLUS*/
				uni.navigateBack({
					delta: 1
				});
				/*#endif*/

				/*#ifdef H5*/
				history.back();
				/*#endif*/
			},
			// select(item) {
			// 	// console.log(item);
			// 	this.current = item.index;
			// 	// console.log(this.current, '9989999999');
			// },
			// 资金明细
			async fund() {
				let list = await this.$http.get('api/user/finance', {})
				this.fundDetails = list.data.data
				console.log(this.fundDetails);
			},
			//充值记录
			async recharge() {
				let list = await this.$http.get('api/user/recharge', {

				})
				this.rechargeRecord = list.data.data
			},
			//提现记录
			async withdrawal() {
				let list = await this.$http.get('api/user/withdraw', {

				})
				this.withdrawalRecords = list.data.data
			},

		},

	}
</script>

<style lang="scss">


	.college-content {
		width: 100%;

		//选项卡一
		.fund {
			margin: 30rpx;

			.display {
				margin-top: 20rpx;
			}

			.time {
				color: #999;
				font-size: 24rpx;
			}

			.amount {
				color: #999;
				font-weight: 600;
				font-size: 30rpx;
				margin-top: 10rpx;
			}
		}

		//选项卡二
		.takeNotes {
			margin: 30rpx;
			font-size: 26rpx;
			box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;

			.business {
				display: flex;

				.corporate {
					background-color: #7266ba;
					color: #fff;
					border-radius: 4rpx;
					padding: 2rpx 10rpx;
					font-size: 24rpx;

				}

				.recharge {
					font-weight: 700;
					color: #000;
					margin: 0 20rpx 0 0;
				}

				.money {
					color: #BB1815;
					font-weight: 600;
				}

			}

			.underReview {
				display: flex;
				align-items: baseline;
				color: #d50000;
			}

			.underReview_b {
				display: flex;
				align-items: baseline;
				color: #5AC725;
			}

			.underReview_c {
				display: flex;
				align-items: baseline;
				color: #F9AE3D;
			}


			.order {
				margin-top: 10rpx;
				display: flex;
				font-size: 24rpx;
				color: #666;

				text {
					margin: 0 20rpx 0 10rpx;
				}
			}
		}
	}
</style>