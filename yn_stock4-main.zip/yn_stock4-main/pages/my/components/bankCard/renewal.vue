<!-- 绑定银行卡 -->
<template>
	<view>
		<view class="college-bg">
			<image src="/static/arrow_left.png" mode="aspectFit" style="width: 20px;height: 24rpx;" @tap="goBack()">
			</image>
			<view style="flex:1;text-align: center;color: #EA5A40;font-size: 28rpx;font-weight: 700;">Liên kết ngân hàng
			</view>
		</view>
		<view style="display: flex;align-items: center;justify-content: center;padding: 0 10px;text-align:start;">
			<image src="/static/bank_lock.png" style="width: 42px;height: 38px;margin-right: 10px;"></image>
			<text style="font-size: 18px;font-weight: 700;">Thông tin của bạn sẽ được mã hóa và bảo mật theo tiêu chuẩn hàng đầu thế giới.</text>
		</view>
		<view class="college-content" style="border-radius: 0;margin-top: 24rpx;">
			<view style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
				Tên chủ thẻ
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					 border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color:#000; font-weight: 800; width: 100%; text-align: center;">
					Tên chủ thẻ</view>
			</view>
			<view class="input_wrapper">
				<input placeholder="Vui lòng nhập" type="text" v-model="value"
					:placeholderStyle="$theme.setPlaceholder()"></input>
			</view>

			<view style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
				Tên ngân hàng
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					 border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color:#000; font-weight: 800; width: 100%; text-align: center;">
					Tên ngân hàng</view>
			</view>
			<view class="input_wrapper">
				<input placeholder="Vui lòng nhập" type="text" v-model="value2"
					:placeholderStyle="$theme.setPlaceholder()"></input>
			</view>

			<view style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
				Số tài khoản
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					 border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color:#000; font-weight: 800; width: 100%; text-align: center;">
					Số tài khoản</view>
			</view>
			<view class="input_wrapper">
				<input placeholder="Vui lòng nhập" type="text" v-model="value4"
					:placeholderStyle="$theme.setPlaceholder()"></input>
			</view>

			<view style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
				Mật khẩu giao dịch
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					 border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color:#000; font-weight: 800; width: 100%; text-align: center;">
					Mật khẩu giao dịch </view>
			</view>
			<view class="input_wrapper">
				<input placeholder="Nhập mật khẩu giao dịch " maxlength="6" type="text" v-model="value5"
					:placeholderStyle="$theme.setPlaceholder()" style="width: 90%;"></input>
			</view>

			<!-- <view style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
				Vui lòng nhập mật khẩu giao dịch
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					 border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; #000 font-weight: 800; width: 100%; text-align: center;">
					Vui lòng nhập mật khẩu giao dịch</view>
			</view> -->
			<view class="input_wrapper">
				<input placeholder="Xác nhận mật khẩu giao dịch" type="text" maxlength="6" v-model="value6"
					:placeholderStyle="$theme.setPlaceholder()" style="width: 95%;"></input>
			</view>

		</view>
		<view style="padding: 0 20px;">
			<view style="padding: 0 10px;">Điều kiện trước khi liên kết</view>
			<view class="checkbox-wrapper" @click="toggleCheckbox()">
				<view v-if="!isChecked">
					<view style="width: 20px;height: 20px;border: 1px solid #000;"></view>
				</view>
				<view v-else>
					<image src="/static/bank_11.png" style="width: 40px;height: 30px;" ></image>
				</view>
				<checkbox :checked="isChecked" color="#EA5A40" :disabled="!allFilled" style="display: none;">
				</checkbox>
				
				<view style="margin-left: 10px;">Số dư tài khoản NH lớn hơn 50,000 VND.</view>
			</view>
		</view>


		<view :disabled="!canSubmit" :class="{'active': canSubmit}" class="btn_common"
			:style="{backgroundColor:isChecked? '#EA5A40' : 'gray'}"
			style="font-size: 32rpx;width: 80%;margin: 20rpx auto;line-height: 64rpx;" @click="replaceBank()">
			Nhấp và xác nhận
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

				value: '',
				value2: '',
				value3: '',
				value4: '',
				value5: '',
				value6: '',
				isChecked: false,
				
			};
		},
		computed: {
			allFilled() {
				return this.value && this.value2 && this.value5 && this.value4 && this.value6
			},

			canSubmit() {
				return this.allFilled = this.isChecked
			},
		},
		methods: {
			// 根据当前平台，执行回退方式
			goBack() {
				/*#ifdef APP-PLUS*/
				uni.navigateBack({
					delta: 1
				});
				/*#endif*/

				/*#ifdef H5*/
				history.back();
				/*#endif*/
			},

			toggleCheckbox() {
				if (!this.allFilled) {
					uni.showToast({
						title: 'Thông tin nhập chưa đầy đủ, Chưa thể sử dụng',
					})
					return
				}
				this.isChecked = !this.isChecked
			},

			//跟换银行卡
			async replaceBank() {
				if (!this.canSubmit) return
				let list = await this.$http.post('api/user/bindBankCard', {
					//value2和value3反了
					//value2应该是bank_name  
					//value3应该是bank_sub_name
					realname: this.value,
					bank_name: this.value,
					bank_sub_name: this.value2,
					card_sn: this.value4,
					password: this.value5,
					pas_word2: this.value6,
				})

				// if (!this.canSubmit) {
				// uni.showToast({
				// 	title: 'Thông tin nhập chưa đầy đủ, Chưa thể sử dụng',
				// })
				if (list.data.code == 0) {
					uni.$u.toast('Hệ thống liên kết thành công ');
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/my/my'
						});
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}


				// }



			},
		},
		// mounted() {
		// 	this.replaceBank()
		// },
	}
</script>

<style lang="scss">
	
	
	.checkbox-wrapper {

		display: flex;
		align-items: center;
		margin: 25px 0;
		padding: 10px;
	}

	.checkbox {
		width: 20px;
		height: 20px;
		border: 1px solid #000000;
		border-radius: 4px;
		margin-right: 10px;
		position: relative;
		transition: all 0.2s;
	}

	.checkbox.checked {
		background-color: #007aff;

		border-color: #007aff;
	}

	.checkmark {
		color: white;
		font-size: 16px;
	}

	.active {


		cursor: pointer;
	}

	.disable {

		opacity: 0.5;
		cursor: not-allowed;

	}

	.college-bg {
		padding: 48rpx;
		background-color: #FFFAF9;
		margin-bottom: 24rpx;
		display: flex;
		align-items: center;
	}

	.college-content {
		margin: 30rpx 0;
		padding: 10rpx 30rpx;
	}
</style>