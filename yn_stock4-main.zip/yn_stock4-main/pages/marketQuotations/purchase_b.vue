<template>
	<view style="padding-bottom: 100rpx;min-height: 100vh;">
		<!-- 头部 -->
		<header style="padding:48rpx 24rpx 10rpx 24rpx;display: flex;align-items: center;">
			<view style="margin-right: auto;" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" style="width: 20px;height: 24rpx;">
				</image>
			</view>
			<view style="flex:1;">
				<!-- <template v-if="detail">
					<view style="padding-left: 60rpx;">
						<view style="color: #fff;font-size: 16px;font-weight: 700;text-transform:uppercase;">
							{{detail.exchange+` / `}}
							<text>{{detail.code.split(':')[0]}}</text>
						</view>
						<view :style="$theme.setStockRiseFall(detail.rate>0)">
							<text>{{toThousandFilter(today.current_price)}}</text>
							<text style="padding-left: 48rpx;">{{detail.rate}}%</text>
						</view>
					</view>
				</template> -->
			</view>
			<view style="margin-left: auto;"></view>
		</header>
		<view style="color: #FFF;">{{detail}}</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				gid: '',
				type: '', // 0买，1卖
				detail: null, //
			}
		},
		onLoad(opt) {
			this.gid = opt.gid || this.gid;
			this.type = opt.type || this.type;
		},
		onShow() {
			this.getDetail();
		},
		onHide() {

		},

		methods: {
			async getDetail() {
				const result = await this.$http.post(`api/product/info`, {
					gid: this.gid,
					// time_index: this.time_index
				});
				console.log(`result:`, result);
				if (result.data.code == 0) {
					const temp = result.data.data;
					this.detail = {
						name: temp[0].exchange + ` / ` + temp[0].code.split(':')[0],
						price: temp[0].current_price * 1,
						rate: temp[0].rate * 1,
						rateNum: temp[0].rate_num * 1,
						// 
						close: temp[1].yesterday.close,
						open: temp[1].today.open,
						high: temp[1].today.high,
						low: temp[1].yesterday.low,

					};
					console.log(`detail:`, this.detail);
				}
			},
		}
	}
</script>

<style>
</style>