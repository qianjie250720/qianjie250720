<template>
	<view>
		<view class="college-bg">
			<image src="/static/arrow_left.png" mode="aspectFit" style="width: 20px;height: 24rpx;" @tap="goBack()">
			</image>
			<view style="flex:1;text-align: center;color: #EA5A40;font-size: 28rpx;font-weight: 700;">
				Thông tin Định Danh
			</view>
		</view>
		<view>
			<image src="/static/auth_banner.png" mode="widthFix" style="width: 100%;"></image>
		</view>

		<!-- <view style="padding:24rpx;font-size: 30rpx;color: #000;font-weight: 700;">
			<view>Giấy tờ tùy thân</view>
			<view style="font-weight: 400;margin-top: 10px;font-size: 14px;">Vui lòng chuẩn bị giấy tờ tùy thân của bạn và đảm bảo đáp ứng các điều kiện sau đây.</view>
			<view style="margin-top: 10px;">1. CCCD gắn chip còn hiệu lực và nguyên bản</view>
			<view style="margin-top: 10px;">2. Không đeo khẩu trang</view>
			<view style="margin-top: 10px;">3. Không nhắm mắt</view>
			<view style="margin-top: 10px;">4. Không nghiêng mặt</view>
			<view style="margin-top: 10px;">5. Không nhắm mắt</view>
			<view style="margin-top: 10px;">6. Không nghiêng mặt</view>
		</view> -->

		<view class="college-content" style="border-radius: 0;margin-top: 24rpx;">
			<view style="position: relative;color: transparent;color:#EA5A40;font-weight: 700;" class="flex gap5">
				<image src="/static/gerenxinxi.svg" mode="widthFix" style="width:20px;"></image>
				<view style="font-size: 14px;">Thông tin cá nhân</view>
			</view>
			
			
			<view style="margin-top: 10px;">
				<view>
					<view style="font-size: 14px;color:#000;">
						Mặt trước
					</view>
					<view style="border: 1px #F3F4F6 solid;padding: 60px;margin: 10px 0;border-radius: 5px;" class="flex justify-center">
						<image src="/static/purchase/xiangji.png" @click="selectImg('obverse')"
							mode="widthFix" style="margin: 10px 0;width:90px;height: 90px;"  v-if="!obverseUrl"></image>
					</view>
					
					<image :src="!obverseUrl?`/static/purchase/xiangji.png`:obverseUrl" @click="selectImg('obverse')"
						mode="widthFix" style="margin: 10px 0;width:90%;height: auto;" v-if="obverseUrl"></image>
				</view>
			
				<view>
					<view style="font-size: 14px;color:#000;">
						Mặt sau
					</view>
					<view style="border: 1px #F3F4F6 solid;padding: 60px;margin: 10px 0;border-radius: 5px;" class="flex justify-center">
						<image src="/static/purchase/xiangji.png" @click="selectImg('reverse')"
							mode="widthFix" style="margin: 10px 0;width:90px;height: 90px;"  v-if="!reverseUrl"></image>
					</view>
					
					<image :src="!reverseUrl?`/static/purchase/xiangji.png`:reverseUrl" @click="selectImg('reverse')"
						mode="widthFix" style="margin: 10px 0;width:90%;height: auto;" v-if="reverseUrl"></image>
				</view>
			</view>
			
			<view style="color:#000;margin-top: 10px;font-weight: 700;">
				Vui lòng kiểm tra và nhập thông tin chính xác.
			</view>
			
			<view style="color:#000;margin-top: 10px;">
				Họ và Tên
			</view>
			<view class="input_wrapper">
				<input placeholder="Vui lòng nhập Họ và Tên" type="text" v-model="value1"
					:placeholderStyle="$theme.setPlaceholder()"></input>
			</view>

			<view style="color:#000;">
				Số CCCD/CMND / Hộ chiếu
			</view>
			<view class="input_wrapper">
				<input placeholder="Vui lòng nhập số Căn cước công dân" type="text" v-model="value2"
					:placeholderStyle="$theme.setPlaceholder()"></input>
			</view>
			
			<view style="color:#000;">
				Giới tính
			</view>
			<view class="margin-top-10">
				
					<view class="flex flex-b gap10">
						<view style="background-color: #F0F4FD;padding: 10px 20px;" class="flex-1 flex radius10 gap5" @click="sex=1">
							<view style="border-radius: 50%;width: 20px;height: 20px;border: 1px #4799B6 solid;background-color: #D5EDFF;" class="flex justify-center align-center">
								<view style="border-radius: 50%;width: 10px;height: 10px;background-color: #3A6989;" v-if="sex==1"></view>
							</view>
							<view>Nam </view>
						</view>
						<view style="background-color: #FFF4F2;padding: 10px 20px;" class="flex-1 flex radius10 gap5" @click="sex=2">
							<view style="border-radius: 50%;width: 20px;height: 20px;border: 1px #EA5A40 solid;background-color: #FFDDD6;" class="flex justify-center align-center">
								<view style="border-radius: 50%;width: 10px;height: 10px;background-color: #EA5A40;" v-if="sex==2"></view>
							</view>
							<view>Nữ </view>
						</view>
					</view>
					
			</view>
			
			<view style="color:#000;margin-top: 10px;">
				Ngày tháng năm sinh
			</view>
			<view class="input_wrapper">
				<input placeholder="Ngày tháng năm sinh" type="text" v-model="birthday" :placeholderStyle="$theme.setPlaceholder()"></input>
			</view>
			
		</view>

		

		<!-- 凭证 -->
		<!-- <view class="bold" style="color:#EA5A40;padding:0 30rpx;font-size: 14px;">Chụp/ Tải ảnh chữ ký</view>
		<view style="display: flex;border-radius: 12rpx;padding:0 12px;">
			<image :src="!qianmingUrl?`/static/auth_name.png`:qianmingUrl" @click="selectImg('qianming')"
				mode="widthFix" style="margin: 10px 0;width:90%;height: auto;"></image>
		</view> -->

		<!-- 身份证 -->
		<view style="background-color: #EA5A40;text-align: center;margin:20px 15px;border-radius: 5px;padding: 10px;color: #fff;">
			<view class="bottom-content" style="background-color: transparent;">
				<view class="">
					<view class="submit"  @click="gain_aouonym()">Hoàn thành </view>
					<!-- <view class="submit" v-if="userinfo.is_check==1">Hoàn thành </view> -->
				</view>
			</view>
		</view>
		<view style="height: 20px;"></view>
		<!-- <view class="upload" style="margin-top: 30px;color: #fff;">Lưu ý khi tải căn cước công dân</view> -->
		<!-- <view class="notes-documents" style="margin-top: 30px;">
					<view class="careful">
						<view>
							<image src="../../static/purchase/biaozhun01.png" mode=""></image>
						</view>
						<view class="standard">
							<u-icon name="checkmark-circle-fill" color="#4db872"></u-icon>
							Tiêu chuẩn
						</view>
					</view>
					<view class="careful">
						<view>
							<image src="../../static/purchase/biaozhun02.png" mode=""></image>
						</view>
						<view class="standard">
							<u-icon name="close-circle-fill" color="#ee6560"></u-icon>
							Mất khung
						</view>
					</view>

					<view class="careful">
						<view>
							<image src="../../static/purchase/biaozhun03.png" mode=""></image>
						</view>
						<view class="standard">
							<u-icon name="close-circle-fill" color="#ee6560"></u-icon>
							Ảnh mờ
						</view>
					</view>

					<view class="careful">
						<view>
							<image src="../../static/purchase/biaozhun04.png" mode=""></image>
						</view>
						<view class="standard">
							<u-icon name="close-circle-fill" color="#ee6560"></u-icon>
							Chói sáng
						</view>
					</view>
				</view> -->
		<!-- </view> -->


		<!-- <view style="color: #AAA;padding:24rpx;font-size: 28rpx;line-height: 1.6;">
			<view style="line-height: 2.8;font-size: 28rpx;">Điều kiện tải lên</view>
			<view>1.Nội dung ảnh chụp chân thật, rõ nét, không được chỉnh sửa.</view>
			<view>2.Số CCCD và tên rõ ràng, hỗ trợ JPG/JPEG/PNG。</view>
			<view>3.CMND hoặc CCCD phải còn hạn ít nhất 6 tháng và không bị mờ số . Có thể
				sử dụng hình ảnh CMND hoặc CCCD để tải lên .</view>
			<view>4.Đảm bảo đường truyền tốt.</view>
		</view> -->
	</view>
</template>


<script>
	import md5 from 'js-md5'
	export default {

		data() {
			return {
				obverseUrl: '', // 正面
				reverseUrl: '', // 反面
				qianmingUrl: '', // 签名
				//
				value1: '',
				value2: '',
				userinfo: {},
				//倒计时
				second: Math.round(Math.random() * 6),
				timer: null,
				sex:1,
				birthday:""
			};
		},
		onShow() {
			if (!this.$util.checkToken()) return false;
			this.userInfo();
		},
		methods: {
			// 根据当前平台，执行回退方式
			goBack() {
				/*#ifdef APP-PLUS*/
				uni.navigateBack({
					delta: 1
				});
				/*#endif*/

				/*#ifdef H5*/
				history.back();
				/*#endif*/
			},

			// 点击上传
			async selectImg(name) {
				const result = await uni.chooseImage({
					count: 1,
					sizeType: ['compressed'],
					sourceType: ['album'],
				});
				console.log('result:', result);
				const imageFile = result[1].tempFiles[0];
				console.log('imageFile:', imageFile);

				if (name == "obverse") {
					this.upimg("obverse", imageFile.path)
				} else if (name == "reverse") {
					this.upimg("reverse", imageFile.path)
				} else if (name == "qianming") {
					this.upimg("qianming", imageFile.path)
				}
			},
			// 上传图片
			async upimg(type, tempFilePath) {
				uni.showLoading({
					title: "Đang gửi, vui lòng đợi..."
				})
				let Request = "Qwd3N5yp"
				let time = parseInt(new Date().getTime() / 1000)
				let str_url = ("/api/app/upload").toLowerCase()

				let mdd = md5("XPFXMedS" + Request + str_url + time);

				const result = await uni.uploadFile({
					url: this.$http.BaseUrl + '/api/app/upload?t=' + time + "&sign=" + mdd,
					filePath: tempFilePath,
					name: 'file',
				});

				console.log('result:', result);
				uni.hideLoading();
				if (result[1].statusCode == 200) {
					const temp = JSON.parse(result[1].data);
					console.log('temp:', temp);
					if (type == 'obverse') {
						this.obverseUrl = temp[0].url;
					} else if (type == "reverse") {
						this.reverseUrl = temp[0].url;
					} else if (type == "qianming") {
						this.qianmingUrl = temp[0].url;
					}
				}
			},

			// // 插件上传身份证
			// // 上传
			// async upimg(type, tempFilePath) {
			// 	uni.showLoading({
			// 		title: "Đang gửi, vui lòng đợi..."
			// 	})
			// 	let Request = "Qwd3N5yp"
			// 	let time = parseInt(new Date().getTime() / 1000)
			// 	let str_url = ("/api/app/upload").toLowerCase()


			// 	let mdd = md5("XPFXMedS" + Request + str_url + time)

			// 	uni.uploadFile({
			// 		url: this.$http.BaseUrl + '/api/app/upload?t=' + time + "&sign=" + mdd, // 仅为示例，非真实的接口地址
			// 		filePath: tempFilePath,
			// 		name: 'file',

			// 		success: (res) => {
			// 			uni.hideLoading()
			// 			var data = JSON.parse(res.data);
			// 			// this.is_url = res.data
			// 			console.log(1111, data)
			// 			if (type == 1) {
			// 				this.formData.obverseUrl = data[0].url;
			// 			} else {
			// 				this.formData.reverseUrl = data[0].url;

			// 			}

			// 		},
			// 		error: (res) => {
			// 			uni.hideLoading()
			// 			console.log(3333, res)
			// 		},
			// 	});
			// },

			// 认证
			async gain_aouonym() {
				uni.showLoading({
					title: "Đang gửi, vui lòng đợi...",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/user/real-auth1', {
					real_name: this.value1,
					idno: this.value2,
					front_image: this.obverseUrl,
					back_image: this.reverseUrl,
					sex: this.sex, 
					birthday: this.birthday,
				})

				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/index/index'
						});
						uni.hideLoading();
					}, 1000)
				} else if (list.data.code == 1) {
					uni.$u.toast(list.data.message);

				}

			},
			async userInfo() {
				let userinfo = await this.$http.get('api/user/fastInfo', {})
				this.value1 = userinfo.data.data.real_name
				this.value2 = userinfo.data.data.idno
				this.userinfo = userinfo.data.data
				this.obverseUrl = userinfo.data.data.front_image
				this.reverseUrl = userinfo.data.data.back_image
				this.qianmingUrl = userinfo.data.data.qianming,
				this.sex = userinfo.data.data.sex?userinfo.data.data.sex:1,
				this.birthday = userinfo.data.data.birthday,
				
					// console.log(userinfo.data.data, '1111111111111');
					uni.hideLoading();
			},
		},
	};
</script>

<style lang="scss">
	::v-deep .u-input {
		background: #f5f5f5;
		font-size: 28rpx;
	}

	::v-deep  .uni-input-input {
		font-size: 30rpx;
	}

	.college-bg {
		padding: 48rpx;
		background-color: #FFFAF9;
		margin-bottom: 24rpx;
		display: flex;
		align-items: center;
	}

	.college-content {
		padding: 0rpx 30rpx;
	}

	.identity-card {
		margin: -50rpx auto 0;
		background: #fff;
		border-radius: 20rpx 20rpx 0 0;
		padding: 30rpx;


		.choice {
			color: #000;
			font-weight: 600;
			margin: 30rpx 0 10rpx;
			font-size: 28rpx;
		}

		input {
			background: #f5f5f5;
			padding: 20rpx;
			border-radius: 10rpx;
		}
	}

</style>