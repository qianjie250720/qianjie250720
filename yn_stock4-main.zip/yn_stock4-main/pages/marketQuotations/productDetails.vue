<template>
	<view style="padding-bottom: 100rpx;min-height: 100vh;">
		<view class="flex flex-b padding-20 padding-top-20" style="padding-top: 48rpx;color: #fff;">
			<image src="/static/arrow_left.png" mode="aspectFit" style="width: 20px;height: 24rpx;"
				@tap="$u.route({url:'/pages/index/index'});"></image>
			<view style="flex:1;text-align: center;color: #EA5A40;font-size: 28rpx;font-weight: 700;">
				Đặt lệnh
			</view>
		</view>


		<!-- 头部 -->
		<header style="padding:48rpx 30rpx 10rpx 24rpx;display: flex;">
			<template v-if="detail">
				<view class="flex gap10" style="margin-left: 10px;">
					<view style="color: #000;font-size: 16px;font-weight: 700;">
						{{detail.name}}
					</view>
					<view :style="{ color:detail.rate === 0 ? '#d7e500' : (detail.rate > 0 ? '#43c776' :'#ff0000') }"
						class="bold">{{toThousandFilter(detail.price)}}</view>
					<!-- <view :style="{ color:detail.rate >0 ? '#43C776':'#ff0000' }">{{detail.rateNum}}</view> -->
					<view style="padding: 1px 15px;border-radius: 4px;color: #fff;"
						:style="{ background:detail.rate === 0 ?'#d7e500' : (detail.rate > 0 ? '#43c776' :'#ff0000') }">
						{{toThousandFilter(detail.rate)}}%

					</view>
				</view>
				<view style="margin-left: auto;" @click="handleClickDelProduct()">
					<image :src="detail.is_collected !=1?'/static/stock_unfollow.png':'/static/stock_follow.png'"
						mode="widthFix" style="width: 20px;height: 20px;"></image>
				</view>
			</template>
		</header>


		<template v-if="detail&&buysell">
			<view class="flex radius10"
				style="box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px; margin: 15px;padding: 10px;">
				<view class="text-center flex-2">
					<view class="font-size-12"
						style="background: #F3F4F6;padding: 2px 5px;border-radius: 5px;width: 60%;margin-left: 15%;">
						Giá hiện tại</view>
					<view :style="{ color:detail.rate === 0 ?'#d7e500' : (detail.rate > 0 ? '#43c776' :'#ff0000') }"
						class="margin-top-5">{{toThousandFilter(detail.price)}}</view>
				</view>
				<view style="background: #979797;height: 40px;width: 1px;"></view>
				<view class="flex-4 margin-left-10">
					<view class="bold">Sức mua </view>
					<view class="margin-top-5" style="color: #43C776;">{{toThousandFilter(userInfo.money)}}</view>
				</view>
			</view>
			<view style="padding:15px;line-height: 1.8;margin-top: 24rpx;" class="flex flex-b gap10">
				<view style="flex:0 0 35%;padding: 0rpx 20rpx 0 0;">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="font-size: 12px;color: #000;">Giá hiện tại</view>
						<view
							:style="{ color:detail.rate === 0 ?'#d7e500' : (detail.rate > 0 ? '#43c776' :'#ff0000') }">
							{{toThousandFilter(detail.price)}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="font-size: 12px;color: #43C776;">Trần</view>
						<view style="color:purple;">{{toThousandFilter(detail.zt_price,2)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="font-size: 12px;color: #F4462F;">Sàn</view>
						<view style="color:blue;">{{toThousandFilter(detail.dt_price,2)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="font-size: 12px;color: #F4462F;">TC</view>
						<view style="color:#d7e500;">{{toThousandFilter(detail.last_price,2)}}</view>
					</view>
					<view style="font-size: 14px;">
						<view style="background: #FFF4F2;border-radius: 5px 5px 0 0;color: #71368F;padding:5px 10px;"
							class="text-center">{{toThousandFilter(buysell.sellzong)}}</view>
						<view class="flex flex-b" :style="jisuan(buysell.sell1,buysell.sellzong,'#FFEAE7')">
							<view style="color: #43C776;" class="bold">{{buysell.sjia1}}</view>
							<view style="color: #a49e9d;">{{toThousandFilter(buysell.sell1)}}</view>
						</view>
						<view class="flex flex-b" :style="jisuan(buysell.sell2,buysell.sellzong,'#FFEAE7')">
							<view style="color: #43C776;" class="bold">{{buysell.sjia2}}</view>
							<view style="color: #a49e9d;">{{toThousandFilter(buysell.sell2)}}</view>
						</view>
						<view class="flex flex-b" :style="jisuan(buysell.sell3,buysell.sellzong,'#FFEAE7')">
							<view style="color: #43C776;" class="bold">{{buysell.sjia3}}</view>
							<view style="color: #a49e9d;">{{toThousandFilter(buysell.sell3)}}</view>
						</view>


						<view class="flex flex-b" :style="jisuan(buysell.buy1,buysell.buyzong,'#DBF4E5')">
							<view style="color: #43C776;" class="bold">{{buysell.bjia1}}</view>
							<view style="color: #a49e9d;">{{toThousandFilter(buysell.buy1)}}</view>
						</view>
						<view class="flex flex-b" :style="jisuan(buysell.buy2,buysell.buyzong,'#DBF4E5')">
							<view style="color: #43C776;" class="bold">{{buysell.bjia2}}</view>
							<view style="color: #a49e9d;">{{toThousandFilter(buysell.buy2)}}</view>
						</view>
						<view class="flex flex-b" :style="jisuan(buysell.buy3,buysell.buyzong,'#DBF4E5')">
							<view style="color: #43C776;" class="bold">{{buysell.bjia3}}</view>
							<view style="color: #a49e9d;">{{toThousandFilter(buysell.buy3)}}</view>
						</view>
						<view style="background: #EFFFF5;border-radius:0 0 5px 5px;color: #71368F;padding:5px 10px;"
							class="text-center">{{toThousandFilter(buysell.buyzong)}}</view>
					</view>
					<view
						style="margin-top: 10px;border-radius: 5px;background: #F3F4F6;padding: 5px;text-align: center;">
						All
					</view>
				</view>
				<view style="flex:1;padding: 12rpx 0 0 12rpx;">
					<view class="flex text-center font-size-14">
						<view class="flex-1 radius10" style="background: #43C776;color: #fff;padding: 3px 10px;">Mua
						</view>
						<view class="flex-1 radius10" style="background: #F3F4F6;padding: 3px 10px;">Bán</view>
					</view>
					<view
						style="border: 1px #C3C3C3 solid;padding: 5px;margin-top: 10px;border-radius: 5px;text-align: center;font-size: 14px;">
						Lệnh ưu tiên

					</view>
					<view style="margin-top: 10px;">
						<view class="bold margin-bottom-5">Khối lượng</view>
						<u-number-box v-model="num" inputWidth="100%"></u-number-box>
					</view>

					<view style="margin-top: 10px;">
						<view class="bold margin-bottom-5">Margin</view>
						<u-number-box v-model="ganggan" inputWidth="100%" @change="gg_change"
							:asyncChange="true"></u-number-box>
					</view>
					<view class="flex margin-top-10 gap5 text-center font-size-12">
						<view style="padding: 2px;border-radius: 5px;border: 1px #C3C3C3 solid;" class="flex-1">25%
						</view>
						<view style="padding: 2px;border-radius: 5px;border: 1px #C3C3C3 solid;" class="flex-1">50%
						</view>
						<view style="padding: 2px;border-radius: 5px;border: 1px #C3C3C3 solid;" class="flex-1">75%
						</view>
						<view style="padding: 2px;border-radius: 5px;border: 1px #C3C3C3 solid;" class="flex-1">100%
						</view>
					</view>
					<view class="flex flex-b margin-top-10 font-size-14">
						<view>số dư</view>
						<view style="color: #43C776;">{{toThousandFilter(userInfo.money)}}</view>
					</view>

					<view class="flex flex-b margin-top-10 font-size-12">
						<view>GD</view>
						<view>VND</view>
					</view>
					<view class="text-center" style="background: #F3F4F6;border-radius: 5px;margin-top: 10px;">
						<view>{{toThousandFilter(num*detail.price/ganggan)}}</view>
					</view>
					<view
						style="background: #43C776;border-radius: 5px;text-align: center;padding: 5px;color: #fff;margin-top: 10px;"
						@click="show_buy=true">Mua</view>


				</view>
			</view>
		</template>

		<view>
			<view class="flex gap20" style="padding: 15px;">
				<view :class="cur==1?'bold':''" :style="cur==1?'border-bottom: 2px #000 solid;':''" @click="cur=1">Biểu
					đồ </view>
				<!-- <view  :class="cur==2?'bold':''" :style="cur==2?'border-bottom: 2px #000 solid;':''" @click="cur=2">đơn hàng</view> -->
			</view>
			<view style="height: 1px;background: #000;opacity: 0.3;margin-top: -10px;"></view>
			<!-- <view style="display: flex;align-items: center;justify-content:space-around;padding:12rpx 48rpx;">
				<block v-for="(v,k) in times" :key="k">
					<view style="border-bottom:3px solid #333333;color:#FFF;"
						:style="{borderColor:k==curTime?'#FFF':'#000' }" @click="changeTab(k)">
						{{v.label}}
					</view>
				</block>
			</view> -->

			<view class="KLineDiagram" id="kline-stock" v-show="cur==1"></view>

			<view v-show="cur==2" style="padding: 10px;">
				<view class="flex flex-b text-center">
					<view class="text-center flex-1">ngày</view>
					<view class="text-center flex-1">mua/bán</view>
					<view class="text-center flex-1">số tiền</view>
					<view class="text-center flex-1">số lượng</view>
				</view>
				<view class="flex flex-b text-center margin-top-10" v-for="(item,index) in shishis">
					<view class="text-center flex-1">{{item.time}}</view>
					<view class="text-center flex-1" :style="item.side=='B'?'color:#43C776':'color:#F4462F'">
						{{item.side=="B"?'Buy':'Sell'}}
					</view>
					<view class="text-center flex-1">{{item.price}}</view>
					<view class="text-center flex-1">{{item.volume}}</view>
				</view>
			</view>
		</view>

		<u-action-sheet :show="show" :actions="actions" title="Margin (Đòn bẩy)" @close="show = false" @select="Select">
		</u-action-sheet>

		<u-modal :show="show_buy" :content="getcontent()" confirm-text="Xác nhận Mua " cancel-text="Huỷ bỏ"
			@confirm="placeOrder" :showCancelButton="true" @cancel="show_buy=false"></u-modal>

	</view>
</template>

<script>
	import {
		init,
		dispose
	} from 'klinecharts';
	// import KLineDiagram from "../../components/kLine/KLineDiagram/KLineDiagram.vue";
	// import { init } from 'klinecharts'
	// import generatedKLineDataList from '@/utils/generatedKLineDataList.js'

	export default {
		components: {},
		data() {
			return {
				show_buy: false,
				actions: [{
					name: '1',
					index: 1
				}],
				cur: 1,
				show: false,
				gid: '', // url带入参
				ganggan: 1,
				num: 100,
				detail: null, // 详情
				buysell: [],
				curTime: 0, // 当前选中时间线
				indicator: null, // 技术指标
				// socket: null, // websocket
				// isConnected: false, // 是否链接socket
				kLineChart: null,
				userInfo: null,
				shishis: {},


			};

		},
		computed: {
			times() {
				return [{
					key: 1,
					label: `1M`
				}, {
					key: 3,
					label: `3M`
				}, {
					key: 10,
					label: `10M`
				}, {
					key: 30,
					label: `30M`
				}]
			}
		},
		onLoad(opt) {
			this.gid = opt.gid || this.gid;

		},
		onShow() {
			// if (this.socket) this.disconnect();
			this.getDetail();
			this.getUserInfo();
			// this.getZDInfo();
		},
		onHide() {
			// if (this.socket) this.disconnect();
			dispose("kline-stock");
			this.clearData();
		},
		deactivated() {
			// if (this.socket) this.disconnect();
			dispose("kline-stock");
			this.clearData();
		},
		methods: {
			getcontent() {
				if (this.detail && this.userInfo) {

					return 'Xác nhận mua cổ phiếu  ' + this.detail.name.split('/')[0] + "\n" + ` Margin X ` + this
						.ganggan + "\n" + ' Khối lượng ' + this.toThousandFilter(this.num) + "\n" + ' Số tiền giao dịch ' +
						this.toThousandFilter(this.num * this.detail.price/this.ganggan);
				}
			},
			gg_change(e) {
				this.ganggan = this.ganggan
				console.log(1111)
				this.show = true
			},
			Select(action) {
			      if (!action || action.disabled) return
			      
			      console.log('Selected leverage:', action.value)
			      
			      // 更新选中状态
			       this.ganggan = action.index || parseInt(action.name); 
			      
			      // 调用接口
			      // this.getUserInfo(this.actions)
			      
			    
			    },
			jisuan(num, zong, color) {

				let baifen = (num / zong * 100).toFixed(2)
				return "background: linear-gradient(to left,  " + color + " " + baifen + "%, transparent " + baifen +
					"%); padding: 2px";
			},
			clearData() {
				if (this.indicator) {
					this.kLineChart.removeIndicator(this.indicator);
					this.indicator = null;
				}
			},
			async getUserInfo() {
				const result = await this.$http.get('api/user/fastInfo', {});
				if (result.data.code == 0) {
					this.userInfo = result.data.data;
					this.actions = result.data.data.ganggan || [];
				}
			},
			// async getZDInfo(){
			// 	const result = await this.$http.get('api/product/zt_info', {
			// 		name: this.gid,

			// 	});
			// 	if (result.data.code == 0) {
			// 		this.zdInfo = result.data.data;

			// 	}
			// },

			async placeOrder() {
				this.show_buy = false
				console.log(this.ganggan);
				if (!this.detail) {
					return
				}
				uni.showLoading({
					title: "Đang khớp lệnh, vui lòng chờ trong giây lát ...",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/product/purchase', {
					num: this.num,
					gid: this.detail.gid,
					price: this.detail.price,
					ganggan: this.ganggan
				})
				uni.hideLoading();
				if (list.data.code == 0) {
					setTimeout(() => {
						
						uni.navigateTo({
							url: '/pages/position/position',
						});
					}, 2000)

				} 
				else if (list.data.code == 1) {
					uni.$u.toast(list.data.message);
					
				}
				else {
					uni.$u.toast(list.data.message);
				}
			},
			// 切换时间线
			changeTab(val) {
				this.curTime = val;
				this.clearData();
				uni.onSocketClose(function(res) {
					console.log('WebSocket 已关闭！');
				});
				this.getDetail();
			},

			// 产品详情
			async getDetail() {
				const result = await this.$http.post('api/product/info', {
					gid: this.gid,
					time_index: this.curTime
				})
				console.log(`result:`, result);
				if (result.data.code == 0) {
					const temp = result.data.data;
					this.detail = {
						gid: temp[0].gid,
						name: temp[0].name,
						price: temp[0].current_price * 1,
						rate: temp[0].rate * 1,
						rateNum: temp[0].rate_num * 1,
						is_collected: temp[0].is_collected,
						// 
						close: temp[1].yesterday.close,
						open: temp[1].today.open,
						high: temp[1].today.high,
						low: temp[1].yesterday.low,
						volume: temp[1].today.volume,
						zhang: temp[1].data.c * 1000,
						die: temp[1].data.f * 1000,
						dt_price: temp[1].data.dt_price * 1,
						last_price: temp[1].data.zt * 1,
						zt_price: temp[1].data.zt_price * 1,
					};
					console.log(`detail:`, this.detail);


					// kline
					if (!this.kLineChart) {
						this.kLineChart = init('kline-stock');
					}
					this.setStyleOptions()
					this.kLineChart.clearData()
					this.kLineChart.applyNewData(temp[2])
				}

				// // if (!this.socket) this.connect(this.productDetails.name);
				this.socket();
				this.BuySell()
				this.shishi();
			},

			handleTrade() {
				uni.navigateTo({
					url: `/pages/marketQuotations/purchase?gid=${this.gid}`
				});
			},

			toThousandFilter(num, fix = 0) {
				return (+num || 0).toFixed(fix).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,')
			},
			toThousandFilter1(num, fix = 0) {
				return (+num || 0).toFixed(0).replace(/\d{1,2}(?=(\d{2})+(\.\d*)?$)/g, '$&.')
			},

			socket() {
				var that = this;
				uni.onSocketClose(function(res) {
					console.log('WebSocket 已关闭！');
				});

				uni.connectSocket({
					url: this.$http.WsUrl,
					success(res) {
						console.log("连接成功");
					},
					fail() {
						console.log("连接失败");
					}
				});
				console.log("codes", this.detail)
				uni.onSocketOpen(function(res) {
					console.log('WebSocket连接已打开！');
					uni.sendSocketMessage({
						data: that.detail.name.split('/')[0],
					});

				});
				uni.onSocketMessage(function(res) {
					// console.log('收到服务器内容：' + );
					var arr = JSON.parse(res.data);
					// console.log('收到服务器内容：' + arr);


					if (that.detail.name == arr[0]) {
						console.log('收到服务器内容：' + arr);
						// console.log('goods：' + arr[53]);
						if (arr[41] * 1 > 0) {
							that.detail.price = arr[41] * 1
							that.detail.rate = arr[52]
							that.detail.rateNum = arr[51] * 1
						}

					}
				});
				uni.onSocketError(function(res) {
					console.log('WebSocket连接打开失败，请检查！');
					uni.showToast({
						icon: 'none',
						title: 'Mạng chậm'
					})
				});
			},
			setStyleOptions() {
				this.kLineChart.setStyles({
					grid: {
						show: true,
						horizontal: {
							show: true,
							size: 1,
							color: '#302F316A',
							style: 'dashed',
							dashedValue: [2, 2], // 虚线时的紧密程度
						},
						vertical: {
							show: true,
							size: 1,
							color: '#302F316A',
							style: 'dashed',
							dashedValue: [2, 2], // 虚线时的紧密程度
						}
					},
					"candle": {
						"type": "area", // candle_solid
						"tooltip": {
							"showRule": "none",
						},
						bar: {
							upColor: '#17A85B',
							downColor: '#F92855',
							noChangeColor: '#ffbfb9',
							upBorderColor: '#17A85B',
							downBorderColor: '#F92855',
							noChangeBorderColor: '#ffbfb9',
							upWickColor: '#17A85B',
							downWickColor: '#F92855',
							noChangeWickColor: '#ffbfb9'
						},
					},
				});
				// this.kLineChart.createIndicator('VOL', false);
				// 显示技术指标
				if (!this.indicator) {
					this.indicator = this.kLineChart.createIndicator('VOL');
				}
			},

			async BuySell() {
				const result = await this.$http.post('api/goods/sellbuy', {
					code: this.detail.name,
				});
				if (result.data.code == 0) {
					this.buysell = result.data.data
				}
			},
			async shishi() {
				const result = await this.$http.post('api/goods/shishibuy', {
					code: this.detail.name,
				});
				if (result.data.code == 0) {
					this.shishis = result.data.data
				}
			},

			//删除
			async handleClickDelProduct() {
				const result = await this.$http.post('api/user/collect_edit', {
					gid: this.detail.gid,
				});
				if (result.data.code == 0) {
					this.clearData();
					uni.onSocketClose(function(res) {
						console.log('WebSocket 已关闭！');
					});
					this.getDetail();
				}
			},
		},
	}
</script>

<style lang="scss">
	.kLine {
		margin: 20rpx 10px;
		background: #fff;
	}

	.KLineDiagram {
		background: transparent;
		height: 600rpx;
		color: #fff;
	}
</style>