<template>
	<view style="background-color: #fff;">
		<view class="flex flex-b padding-20 padding-top-20" style="padding-top: 48rpx;color: #fff;">
			<image src="/static/logo_name.png" mode="widthFix" style="width: 40px;height: 33px;"></image>
			<view style="color:#EA5A40" class="bold font-size-16">Thị trường</view>
			<image src="/static/sousuo.png" mode="widthFix" style="width: 20px;height: 20px;"
				@click="$u.route({url:'/pages/searchFor/searchFor'});"></image>
		</view>

		<!-- <view class="flex flex-wrap  margin-10 gap10">
			<view style="background-color: #333333;padding: 20px;flex: 1 0 10%;" class="radius10 text-center"
				v-for="(item,index) in list_zhishu">
				<view :class="item.rate<0?'red':'green'" class="font-size-18">{{toThousandFilter1(item.current_price)}}
				</view>
				<view class="flex gap5 font-size-12 justify-center">
					<view class="color-white">{{item.name}} </view>
					<view :class="item.rate<0?'red':'green'">
						{{item.rate_num?item.rate_num:'--'}}({{item.rate?item.rate:'--'}}%)
					</view>
				</view>
			</view>
		</view> -->
		<view class="flex gap10" style="margin: 0 15px;">
			<view
				style="background: linear-gradient( 180deg, #EA5A40 0%, #D63B1F 100%);width: 6px;height: 20px;border-radius: 20px;">
			</view>
			<view class="bold">
				Chỉ số phổ biến
			</view>
		</view>

		<view class="padding-10 flex flex-wrap gap10 justify-center">
			<!-- <image src="/static/banner.jpg" style="width: 100%;border-radius: 10px;" mode="widthFix"></image> -->
			<view v-for="(item,index) in list_zhishu" :key="index" class="flex-1">
				<view style="padding:10px;border-radius: 12rpx;box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;">
					<view style="color:#000;">{{item.name}}</view>
					<image :src="`/static/line_${item.rate>0?'rise':'fall'}.png`" mode="aspectFit"
						style="width: 210rpx;height: 72rpx;"></image>
					<view style="font-size: 28rpx;" :style="$theme.setStockRiseFall(item.rate>0)">
						{{item.current_price}}
					</view>
					<view style="font-size: 24rpx;" :style="$theme.setStockRiseFall(item.rate>0)">
						{{item.rate_num}} ({{item.rate}}%)
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;padding-top: 16rpx;">
						<view style="border-radius: 12rpx;background-color: #FF606A;width: 30%;height: 6rpx;">
						</view>
						<view
							style="border-radius: 12rpx;background-color: #FDD355;width: 20%;height: 6rpx;margin:0 6rpx;">
						</view>
						<view style="border-radius: 12rpx;background-color: #1AC5A8;width: 50%;height: 6rpx;">
						</view>
					</view>
				</view>
			</view>
		</view>
		<view style="height: 5px;background:#F3F4F6;margin:10px 0px;"></view>
		<view class="padding-10">
			<view class="flex gap10">
				<view
					style="background: linear-gradient( 180deg, #EA5A40 0%, #D63B1F 100%);width: 6px;height: 20px;border-radius: 20px;">
				</view>
				<view class="bold">
					Điểm tin thị trường
				</view>

			</view>
			<scroll-view scroll-x="true">
				<view class="flex gap10">
					<view v-for="(item,index) in news" :key="index" style="margin-top: 10px;width: 150px;">
						<view @click="to_skip('/pages/index/components/newsDetail',1,item.title,item.id)">
							<image :src="item.pic" style="width: 150px;height: 100px;border-radius: 5px 5px 0 0;">
							</image>
						</view>
						<view @click="to_skip('/pages/index/components/newsDetail',1,item.title,item.id)">
							<view class="font-size-14 padding-10"
								style="background: #F3F4F6;border-radius:0 0 5px 5px;">{{setText(item.title)}}</view>
						</view>
					</view>
				</view>
			</scroll-view>


		</view>

		<!-- 	<view style="display: flex;align-items: center;justify-content: space-between;padding:24rpx 36rpx;">
			<block v-for="(item,index) in tabs" :key="index">
				<view :class="top_index==index?'tops_select':'tops'" @click="top_click(index)">{{item}}</view>
			</block>
		</view> -->
		<view style="height: 5px;background:#F3F4F6;margin:10px 0px;"></view>
		<view class="up-and-down-list" style="color: #000;">
			<view class="range">
				<view class="share-certificate">Mã CK</view>
				<view class="up-to-date">
					<view>Giá TT</view>
					<view>+/-%</view>
					<view>Tỷ lệ</view>
				</view>
			</view>
			<view class="shujuk" v-for="(item,index) in list_data" :key="index" @tap="productDetails(item.sym)">
				<view class="share-certificate" style="color: #000;">
					{{item.name}}
				</view>
				<view class="up-to-date">
					<view class="current_price" :style="$theme.setStockRiseFall(item.rate>0)">
						{{toThousandFilter(item.current_price)}}
					</view>
					<view class="rate text-center" :style="$theme.setStockRiseFall(item.rate>0)">{{item.rate}}%
					</view>
					<view class="forehead" :style="$theme.setStockRiseFall(item.rate>0)">{{(item.rate_num*1)}}
					</view>
				</view>
			</view>
		</view>
		<tabBar :current="2"></tabBar>
	</view>
</template>

<script>
	import tabBar from '@/components/tabBar.vue';
	export default {
		components: {
			tabBar
		},
		data() {
			return {
				news: [],
				//是否更新
				// updateFlag: false,
				// //每次版本更新都要修改
				// version: '2.1',
				// popupshow: true,
				downloadUrl: '',
				updateDesc: "",
				update: '',
				closeOnClickOverlay: false,
				Inv: 0,
				current: 0,
				list: ['VN30', 'VNI', 'HNX', 'UPC'],
				six: '',
				rise: '',
				fall: '',
				exchange: '',
				status: 'loadmore',
				pager: {
					page: 1,
					limit: 20
				},
				timerId: null,
				list_data: [],
				list_zhishu: [],
				codes: [],

				top_index: 0
			}
		},

		computed: {
			tabs() {
				return [`HOSE`, `VN30`, `HNX`, `HNX30`, `UPCOM`]
			}
		},

		mounted() {
			// this.marketQuotations()
			// this.topSix()
			this.gain_views()
		},
		onShow() {
			if (!this.$util.checkToken()) return false;
			this.marketQuotations();
		},

		onUnload() {
			console.log('行情结束1');
			uni.closeSocket({

			})
			// clearInterval(this.timerId);
		},
		onHide() {
			console.log('行情结束2');
			uni.closeSocket({

			})
			// clearInterval(this.timerId);
		},
		onReachBottom() {
			this.status = 'loading';
			// this.pager.page++;
			// this.marketQuotations()
		},
		//下拉刷新
		onPullDownRefresh() {

			//关闭加载提示
			setTimeout(() => {
				uni.hideLoading();
			}, 1000);
			this.dataUpdate()
			uni.stopPullDownRefresh()
		},



		methods: {
			//新闻
			async gain_views() {
				let list = await this.$http.post('api/article/list', {
					type: 11,
				})
				// console.log(this.list1[index].type, '新闻列表')
				this.news = list.data.data
				// uni.hideLoading();
				// uni.stopPullDownRefresh();

			},
			setText(val, num = 20) {
				let temp = '';
				return temp = val.length <= num ? val : val.slice(0, num) + '...'
			},
			toThousandFilter1(num) {
				return (+num || 0).toFixed(2).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,')
			},
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,')
			},
			//搜索
			searchFor() {
				uni.navigateTo({
					url: '/pages/searchFor/searchFor'
				});
			},
			to_skip(url, type, title, id) {
				if (type == 1) {
					uni.navigateTo({
						url: url + `?title=${title}&id=${id}`
					});
				} else if (type == 2) {
					uni.switchTab({
						url: url
					});
				}
			},

			//产品详情
			productDetails(gid) {
				uni.navigateTo({
					url: '/pages/marketQuotations/productDetails' +
						`?gid=${gid}`
				});
			},
			top_click(index) {
				this.top_index = index
				this.marketQuotations()
			},
			//前6
			async topSix() {
				let list = await this.$http.get('api/goods/updownlistsix', {})
				this.six = list.data.data.zhang
				// console.log(this.six, '六');
			},
			//涨跌
			hose_type(top_index) {
				if (top_index == 0) {
					return 'hose';
				} else if (top_index == 1) {
					return 'VN30';
				} else if (top_index == 2) {
					return 'hnx';
				} else if (top_index == 3) {
					return 'HNX30';
				} else if (top_index == 4) {
					return 'upcom';
				}
				return null;
			},
			async marketQuotations() {
				const marketType = this.hose_type(this.top_index);
				let list = await this.$http.post('api/goods/updownlist', {
					page: this.pager.page,
					limit: this.pager.limit,
					top_index: this.top_index,
					type: marketType
				})
				// if(this.pager.page>1){
				// 	this.list_data.push(list.data.goods)
				// 	this.codes=[...this.codes,...list.data.codes]
				// }else{

				// 应客户需求， 此处改为只显示前30条数据 /by 2024.06.06
				if (list && list.data && list.data.goods) {
					console.log("指数", list.data.goods);
					const temp = Object.values(list.data.goods);
					console.log("指数", temp);
					if (temp.length <= 0) {
						this.list_data = [];
					} else {
						this.list_data = temp.length <= 30 ? temp : temp.slice(0, 30);
					}
				}


				// this.list_data = list.data.goods
				this.list_zhishu = list.data.zhishu
				this.codes = list.data.codes
				// }
				console.log("指数", list.data.goods);
				this.socket()
				//涨
				// if (this.pager.page > 1) {
				// 	this.rise = [...this.rise, ...list.data.data.zhang]
				// } else {
				// 	this.rise = list.data.data.zhang
				// }
				// if (list.data.data.zhang.length < this.pager.limit) {
				// 	this.status = 'nomore'
				// }
				// //跌		
				// if (this.pager.page > 1) {
				// 	this.fall = [...this.fall, ...list.data.data.die]
				// } else {
				// 	this.fall = list.data.data.die
				// }
				// if (list.data.data.die.length < this.pager.limit) {
				// 	this.status = 'nomore'
				// }
				// //上证指数
				// this.exchange = list.data.data.zhishu
				// console.log(this.exchange, '上涨指数');
				//大于后端刷新
			},
			socket() {
				var that = this;
				uni.onSocketClose(function(res) {
					console.log('WebSocket 已关闭！');
				});

				uni.connectSocket({
					url: this.$http.WsUrl,
					success(res) {
						console.log("连接成功");
					},
					fail() {
						console.log("连接失败");
					}
				});
				console.log("codes", that.codes.join(","))
				uni.onSocketOpen(function(res) {
					console.log('WebSocket连接已打开！');
					uni.sendSocketMessage({
						data: that.codes.join(",")
					});

				});
				uni.onSocketMessage(function(res) {
					// console.log('收到服务器内容：' + );
					var arr = JSON.parse(res.data);
					// console.log('收到服务器内容：' + arr);
					if (arr[0] == "VNINDEX" && arr[0] && arr[19]) {
						// console.log('收到服务器内容：' + arr[19]);
						that.list_zhishu[0].current_price = arr[1]
						that.list_zhishu[0].rate = arr[19]
					} else if (arr[0] == "VN30" && arr[1] && arr[19]) {
						// console.log('收到服务器内容：' + arr[19]);
						that.list_zhishu[1].current_price = arr[1]
						that.list_zhishu[1].rate = arr[19]
					} else if (arr[0] == "HNXIndex" && arr[2] && arr[19]) {
						// console.log('收到服务器内容：' + arr[19]);
						that.list_zhishu[2].current_price = arr[1]
						that.list_zhishu[2].rate = arr[19]
					} else if (arr[0] == "HNXUpcomIndex" && arr[3] && arr[19]) {
						// console.log('收到服务器内容：' + arr[19]);
						that.list_zhishu[3].current_price = arr[1]
						that.list_zhishu[3].rate = arr[19]
					} else {

						if (arr[41] * 1 > 0 && that.list_data[arr[0]]) {
							// console.log('goods：' + arr[52]);
							that.list_data[arr[0]]['current_price'] = arr[41]
							that.list_data[arr[0]]['rate'] = arr[52]
						}

					}
				});
				uni.onSocketError(function(res) {
					console.log('WebSocket连接打开失败，请检查！');
					uni.showToast({
						icon: 'none',
						title: 'Mạng chậm'
					})
				});
			},
			removeDuplicateObj(arr) {
				let obj = {}
				arr = arr.reduce((newArr, next) => {
					obj[next.gid ?? next.sn] ?
						'' :
						(obj[next.gid ?? next.gid] = true && newArr.push(next))
					return newArr
				}, [])
				return arr
			},

			async dataUpdate() {
				let list = await this.$http.get('api/goods/updownlist', {
					page: 1,
					limit: 100,
				})
				//涨
				this.rise = this.removeDuplicateObj([...this.rise, ...list.data.data.zhang])
				//跌		
				this.fall = this.removeDuplicateObj([...this.fall, ...list.data.data.die])
				//上证指数 
				this.exchange = list.data.data.zhishu
				// console.log(this.exchange, '上涨指数');
				//大于后端刷新
			},

			//版本更新
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},
			async versionUpdate() {
				let list = await this.$http.get('api/version/detail', {})
				this.update = list.data.data
				let version = list.data.data.version
				let old_version = uni.getStorageSync('version') || 1.0
				// console.log(old_version, '当前版本111111111111111');
				if (old_version < version) {
					this.updateFlag = true
					this.$refs.update.upgrade()
					uni.setStorageSync('version', version)
				}
				// console.log(list.data.data, '版本更新');
			},

		},
	}
</script>

<style lang="scss">
	.tops_select {

		padding: 6px 12rpx;
		border-radius: 5px;
		font-size: 16px;
		color: #FFF;
	}

	.tops {
		border: 1px #3E6EB2 solid;
		padding: 6px 12rpx;
		border-radius: 5px;
		font-size: 16px;
		color: #3E6EB2;
	}



	//涨跌榜
	.up-and-down-list {
		.range {
			display: flex;
			justify-content: space-around;
			align-items: center;
			padding: 0 20rpx;
			font-weight: 700;

			.share-certificate {
				width: 30%;
				font-size: 28rpx;
			}

			.up-to-date {
				width: 60%;
				display: flex;
				justify-content: space-between;
				align-items: center;
				font-size: 28rpx;
			}
		}

		.shujuk {
			display: flex;
			justify-content: space-around;
			align-items: center;
			padding: 0 30rpx;
			color: #000;

			.share-certificate {
				width: 30%;
				margin: 20rpx 0;
				color: #000;

				h6 {
					color: #fff;
					font-size: 28rpx;
					font-weight: 500;
					text-align: left;
				}

				.area {
					display: flex;
					justify-content: flex-start;
					align-items: center;
				}


				.deep-number {
					display: inline-block;
					padding: 0 0.04rem;
					background: rgba(59, 79, 222, .1);
					border-radius: 10rpx;
					color: #3b4fde;
					font-size: 24rpx;
					vertical-align: middle;
				}


				.north-number {
					display: inline-block;
					padding: 0 0.04rem;
					border-radius: 10rpx;
					font-size: 24rpx;
					vertical-align: middle;
					color: #ea6248;
					background: rgba(234, 98, 72, .1);
				}


				.shanghai-number {
					display: inline-block;
					padding: 0 0.04rem;
					border-radius: 10rpx;
					font-size: 24rpx;
					vertical-align: middle;
					color: #aa3bde;
					background: rgba(170, 59, 222, .1);
				}
			}

			.up-to-date {
				width: 60%;
				display: flex;
				justify-content: space-between;
				align-items: center;
				color: #1cdd49;
				font-size: 28rpx;

				.current_price {
					text-align: left;
					width: 33%;
				}

				.rate {
					text-align: center;
					width: 33%;
				}


				.forehead {
					// background: #09965f;
					display: inline-block;
					width: 100rpx;
					height: 50rpxx;
					line-height: 50rpx;
					border-radius: 10rpx;
					color: #000;
					text-align: right;
				}
			}
		}
	}
</style>