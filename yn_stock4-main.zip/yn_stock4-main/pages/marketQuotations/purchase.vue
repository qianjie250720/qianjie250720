<!-- 下单 -->
<template>
	<view style="padding-bottom: 100rpx;min-height: 100vh;">
		<!-- 头部 -->
		<header style="padding:48rpx 24rpx 10rpx 24rpx;display: flex;align-items: center;">
			<view style="margin-right: auto;" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" style="width: 20px;height: 24rpx;">
				</image>
			</view>
			<view style="flex:1;">
				<template v-if="detail">
					<view style="padding-left: 60rpx;display: flex;align-items: center;">
						<view style="color: #fff;font-size: 16px;font-weight: 700;text-transform:uppercase;">
							{{detail.name}}
						</view>
						<view style="padding-left: 48rpx;" :style="$theme.setStockRiseFall(detail.rate>0)">
							{{toThousandFilter(detail.price)}}
						</view>
						<view style="padding-left: 48rpx;" :style="$theme.setStockRiseFall(detail.rate>0)">
							({{detail.rate}}%)
						</view>
					</view>
				</template>
			</view>
			<view style="margin-left: auto;"></view>
		</header>

		<template v-if="detail">
			<view
				style="display: flex;align-items: flex-start;border-top: 1px solid #333;padding:0 24rpx;line-height: 1.8;margin-top: 24rpx;border-bottom: 1px solid #333;">
				<view style="flex:0 0 40%;border-right: 1px solid #333;padding: 12rpx 12rpx 0 0;">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view class="hui" style="font-size: 12px;">Trần</view>
						<view style="color: #aa3bde;">{{toThousandFilter(detail.high)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view class="hui" style="font-size: 12px;">Tham chiếu</view>
						<view style="color: #dfea48;;">{{toThousandFilter(detail.price)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view class="hui" style="font-size: 12px;">Sàn</view>
						<view style="color:aqua;">{{toThousandFilter(detail.low)}}</view>
					</view>
				</view>
				<view style="flex:1;padding: 12rpx 0 0 12rpx;">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view class="hui" style="font-size: 12px;">Sức mua</view>
						<view style="color: #FFF;">{{toThousandFilter(userInfo.money)}}</view>
					</view>
					<view style="display: flex;align-items: center;" @click="show=true">
						<view class="hui" style="font-size: 12px;">Margin</view>
						<view style="margin-left: auto;">
							<view style="display: flex;align-items: center;">
								<view style="color: #FFF;padding-right: 24rpx;">{{ganggan}}</view>
								<image src="../../static/purchase/xiabiao.png" mode="aspectFit"
									style="width: 12px;height: 12px;"></image>
							</view>
						</view>
					</view>
				</view>
			</view>
			<!-- 
			<view style="padding:24rpx;line-height: 1.6;border-radius: 12rpx;margin:24rpx;border:1px solid #333;">
				<view style="display: flex;align-items: center;">
					<view style="flex:0 0 33.33%;">
						<view class="hui" style="font-size: 12px;">Trần</view>
						<view style="color: #FFF;">{{toThousandFilter(detail.close)}}</view>
					</view>
					<view style="flex:0 0 33.33%;text-align: center;">
						<view class="hui" style="font-size: 12px;">Tham chiếu</view>
						<view style="color: #FFF;">{{toThousandFilter(detail.price)}}</view>
					</view>
					<view style="flex:0 0 33.33%;text-align: right;">
						<view class="hui" style="font-size: 12px;">Âm lượng</view>
						<view style="color: #FFF;">{{toThousandFilter(detail.volume)}}</view>
					</view>
				</view>
			</view> -->

		</template>



		<view class="padding-10">
			<view style="position: relative; height: 40px; padding: 0px 20px; color: transparent; width: max-content;">
				Khối lượng
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					 border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color:#000; font-weight: 800; width: 100%; text-align: center;">
					Khối lượng</view>
			</view>
			<input class="padding-10 margin-top-10" placeholder="Vui lòng nhập" type="number"
				style="border: 1px solid #E8EAF3;color: #fff;border-radius: 12rpx;" v-model="quantity">

			<view class="flex-wrap flex gap10" style="padding-top: 48rpx;">
				<view :class="quantity==item?'xuanzhong':'noxuanzhong'" class="text-center padding-10 radius10"
					style="flex: 1 0 25%;" v-for="(item,index) in money_list" @click="quantity=item">
					{{toThousandFilter(item)}}
				</view>
			</view>
		</view>

		<view
			style="display: flex;align-items: center;justify-content: space-between;color:#FFF;padding:0 32rpx;line-height: 1.6;">
			<view>Số tiền thanh toán</view>
			<view>
				{{toThousandFilter(total)}} VND
			</view>
		</view>

		<!-- 二选一 -->
		<!-- 	<view class="radio">
			<view :class="[flag===0?rise:fall]" @click="chooseEmer(0)">买涨</view>
			<view :class="[flag===1?rise:fall]" @click="chooseEmer(1)">买跌</view>
		</view> -->
		<u-action-sheet :show="show" :actions="actions" title="Margin (Đòn bẩy)" @close="show = false" @select="Select">
		</u-action-sheet>
		<template v-if="userInfo">
			<view style="display: flex;align-items: center;margin-top: 80rpx;justify-content: center;">
				<template v-if="userInfo.is_check!=1">
					<view @tap="authentication()" class="btn_common"
						style="font-size: 32rpx;width: 80%;margin: 20rpx auto;line-height: 64rpx;">
						Vui lòng xác minh danh tính
					</view>
				</template>
				<template v-if="userInfo.is_check==1">
					<view style="color: white;background-color:#17A85B;padding:16rpx 0;text-align: center;
						width:80%;border-radius: 12rpx;margin-right: 24rpx;" @click="show_buy=true">
						Mua</view>
				</template>
			</view>
		</template>

		<u-modal :show="show_buy" :content="getcontent()" confirm-text="Xác nhận" cancel-text="Huỷ bỏ"
			@confirm="placeOrder" :showCancelButton="true" @cancel="show_buy=false"></u-modal>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				gid: '',
				detail: null,
				userInfo: null,
				actions: [{
					name: '1',
					index: 1
				}],
				show_buy: false,
				show: false,
				list: '',
				quantity: 1000,
				productDetails: "",
				ganggan: 1,
				money_list: [1000, 5000, 10000, 20000, 50000, 100000],
				option: ""
			};
		},
		computed: {
			maxQTY() {
				if (this.detail && this.userInfo) {
					const temp = this.userInfo.money / this.detail.price;
					return Number(temp.toFixed(0))
				}
				return 0;
			},
			total() {
				if (this.detail && this.userInfo) {
					const temp = this.detail.price * this.quantity / this.ganggan;
					return Number(temp.toFixed(3))
				}
				return 0;
			}
		},
		onLoad(opt) {
			this.gid = opt.gid || this.gid;
		},
		onShow() {
			this.getDetail();
			this.getUserInfo();
		},
		onHide() {

		},
		filters: {
			addZero: function(data) {
				return data.toFixed(2)
			}
		},
		methods: {
			async getDetail() {
				const result = await this.$http.post(`api/product/info`, {
					gid: this.gid,
				});
				console.log(`result:`, result);
				if (result.data.code == 0) {
					const temp = result.data.data;
					this.detail = {
						name: temp[0].name + ` / ` + temp[0].code.split(':')[0],
						price: temp[0].current_price * 1,
						rate: temp[0].rate * 1,
						rateNum: temp[0].rate_num * 1,
						// 
						close: temp[1].yesterday.close,
						open: temp[1].today.open,
						high: temp[1].today.high,
						low: temp[1].yesterday.low,
						volume: temp[1].today.volume,
						gid: temp[0].gid,
					};
					console.log(`detail:`, this.detail);
				}
			},

			getcontent() {
				if (this.detail && this.userInfo) {
					// return 'Mua vào ' + this.productDetails.name + ',' + this.quantity + 'lô chẵn,Số tiền thanh toán' + total + ",Xác nhận mua";
					return 'Xác nhận mua cổ phiếu  ' + this.detail.name.split('/')[0] + "\n" + ` khối lượng ` + this
						.quantity + "\n" + ' Vui lòng thanh toán   ' + this.toThousandFilter(this.total) + ' VNĐ';
				}
			},
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},

			Select(e) {
				console.log(e);
				this.ganggan = e.index
			},

			//实名认证
			authentication() {
				uni.navigateTo({
					url: '/pages/index/components/openAccount/openAccount'
				});
			},
			//购买
			async placeOrder() {
				this.show_buy = false
				console.log(this.ganggan);
				if(!this.detail){
					return
				}
				uni.showLoading({
					title: "Đang khớp lệnh, vui lòng chờ trong giây lát ...",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/product/purchase', {
					num: this.quantity,
					gid: this.detail.gid,
					price: this.detail.price,
					ganggan: this.ganggan
				})
				uni.hideLoading();
				if (list.data.code == 0) {
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/position/position',
						});
					}, 2000)

				} else {
					uni.$u.toast(list.data.message);
				}
			},


			async getUserInfo() {
				const result = await this.$http.get('api/user/fastInfo', {});
				if (result.data.code == 0) {
					this.userInfo = result.data.data;
					this.actions = result.data.data.ganggan;
				}
			},

			// 	socket() {
			// 		var that = this;
			// 		uni.onSocketClose(function(res) {
			// 			console.log('WebSocket 已关闭！');
			// 		});

			// 		uni.connectSocket({
			// 			url: this.$http.WsUrl,
			// 			success(res) {
			// 				console.log("连接成功");
			// 			},
			// 			fail() {
			// 				console.log("连接失败");
			// 			}
			// 		});
			// 		console.log("codes", this.productDetails.code)
			// 		uni.onSocketOpen(function(res) {
			// 			console.log('WebSocket连接已打开！');
			// 			uni.sendSocketMessage({
			// 				data: that.productDetails.name
			// 			});

			// 		});
			// 		uni.onSocketMessage(function(res) {
			// 			// console.log('收到服务器内容：' + );
			// 			var arr = JSON.parse(res.data);
			// 			// console.log('收到服务器内容：' + arr);


			// 			if (that.productDetails.name == arr[0]) {
			// 				console.log('收到服务器内容：' + arr);
			// 				// console.log('goods：' + arr[53]);
			// 				that.today.current_price = arr[41]
			// 				that.today.rate = arr[52]
			// 			}
			// 		});
			// 		uni.onSocketError(function(res) {
			// 			console.log('WebSocket连接打开失败，请检查！');
			// 			uni.showToast({
			// 				icon: 'none',
			// 				title: 'Mạng chậm'
			// 			})
			// 		});
			// 	},
		},

	}
</script>

<style lang="scss">
	.xuanzhong {
		
		border: 1px solid #333;
	}

	.noxuanzhong {
		border: 1px solid #333;
		color: #FFF;
	}

	.quantity-content {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 20rpx 30rpx;
		font-size: 28rpx;
		color: #fff;

		//数量
		.quantity {
			display: flex;
			justify-content: space-between;
			align-items: center;

			image {
				width: 40rpx;
				height: 40rpx;
				margin-right: 20rpx;
			}
		}

		::v-deep .input-placeholder {
			font-size: 28rpx;
		}

		.quantity-input {
			background-color: #f5f5f5;
			border: 2rpx solid #e0e0e0;
			border-radius: 10rpx;
			padding: 10rpx 20rpx;
			display: flex;
			font-size: 28rpx;
		}

		//杠杆倍数
		.select {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 20rpx;
			background-color: #f5f5f5;
			width: 50%;
			border: 2rpx solid #e0e0e0;
			border-radius: 10rpx;



			.times {}

			image {
				height: 20rpx;
				width: 20rpx;

			}
		}

	}
</style>