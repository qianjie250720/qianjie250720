<template>
	<view>
		<view class="college-bg">
			<image src="/static/arrow_left.png" mode="aspectFit" style="width: 20px;height: 24rpx;" @tap="goBack()">
			</image>
			<view style="flex:1;text-align: center;color: #EA5A40;font-size: 28rpx;font-weight: 700;">Điểm nóng</view>
		</view>
		<view class="college-content">
			<block v-for="(item,index) in news" :key="index">
				<view
					style="display:flex;align-items: center; padding:10px;border-radius: 12rpx;background-color: #333333;margin-bottom: 24rpx;"
					@click="to_skip('/pages/index/components/newsDetail',1,item.title,item.id)">
					<image :src="item.pic" style="width:200rpx;height: 120rpx;padding-right: 24rpx;"></image>
					<view class="content">
						<view class="title" style="font-size: 28rpx; color: #fff;">
							<!-- {{setText(item.title)}} -->
							{{item.title}}
						</view>
						<view class="summary"
							style="font-size: 24rpx; color: #999;padding-top: 12rpx;text-align: right;">
							{{item.created_at}}
						</view>
					</view>
				</view>
			</block>
		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				news: []
			}
		},
		onShow() {
			this.getNews();
		},
		onPullDownRefresh() {
			this.getNews();
			uni.stopPullDownRefresh();
		},
		methods: {
			// 根据当前平台，执行回退方式
			goBack() {
				/*#ifdef APP-PLUS*/
				uni.navigateBack({
					delta: 1
				});
				/*#endif*/

				/*#ifdef H5*/
				history.back();
				/*#endif*/
			},

			to_skip(url, type, title, id) {
				if (type == 1) {
					uni.navigateTo({
						url: url + `?title=${title}&id=${id}`
					});
				} else if (type == 2) {
					uni.switchTab({
						url: url
					});
				}
			},
			//新闻
			async getNews() {
				let list = await this.$http.get('api/article/list', {
					type: 11,
				})
				this.news = list.data.data
			},
		}
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 48rpx;
		background-color: #FFFAF9;
		margin-bottom: 24rpx;
		display: flex;
		align-items: center;
	}

	.college-content {
		margin-top: -30rpx;
		border-radius: 30rpx 30rpx 0 0;
		padding: 30rpx;
	}
</style>