<template>
	<view style="background-color: #fff;">
		<view class="flex flex-b padding-20 padding-top-20" style="padding-top: 48rpx;color: #fff;">
			<image src="/static/logo_name.png" mode="widthFix" style="width: 40px;height: 33px;"></image>
			<view style="color:#EA5A40" class="bold font-size-16">Danh mục quan tâm</view>
			<image src="/static/sousuo.png" mode="widthFix" style="width: 20px;height: 20px;"
				@click="$u.route({url:'/pages/searchFor/searchFor'});"></image>
		</view>

		<view class="padding-10">
			<view class="flex gap10" style="margin-left: 15px;">
				<view
					style="background: linear-gradient( 180deg, #EA5A40 0%, #D63B1F 100%);width: 6px;height: 18px;border-radius: 20px;">
				</view>
				<view class="bold">
					Theo dõi
				</view>

			</view>

			<template v-if="!business || business.length<=0">
				<view style="display: flex;align-items: center;justify-content: center;margin-top: 30%;">
					<image src="/static/zanwujilu.png" style="width: 180px;height: 140px;"></image>

				</view>
				<view style="text-align: center;margin-top: 20px;font-weight: 600;">Chưa có mục yêu thích nào</view>
			</template>
			<template v-else>
				<!--  @tap="productDetails(item.gid)" -->
				<view v-for="(item,index) in business" :key="index"
					class="padding-10 radius10 flex flex-b margin-top-10" @tap="detailed(item.goods.name)">
					<view style="color: #000;" class="margin-left-10 bold">
						<view class="font-size-16 flex">
							{{item.goods.name}}

						</view>

					</view>
					<view>
						<image mode="widthFix" src="/static/lv.png" style="width: 60px;height: 60px;margin-left: 10px;"
							v-if="item.goods.rate>0"></image>
						<image mode="widthFix" src="/static/hong.png"
							style="width: 60px;height: 60px;margin-left: 10px;" v-if="item.goods.rate<0"></image>
					</view>
					<view
						:style="{ background:item.goods.rate===0 ?'#d7e500' : (item.goods.rate > 0 ? '#43c776' :'#ff0000') }"
						style="padding: 2px 10px;color: #fff;border-radius: 5px;" class="text-center">
						{{toThousandFilter(item.goods.current_price)}}

					</view>

					<view class="flex"
						:style="{ color:item.goods.rate===0 ?'#d7e500' : (item.goods.rate > 0 ? '#43c776' :'#ff0000') }">
						<view>
							<view>{{item.goods.rate}}%</view>
							<view class="font-size-12 flex justify-end">{{item.goods.rate_num}}</view>
						</view>
						<image src="/static/del.png" mode="" style="width: 20px;height: 20px;margin-left: 10px;">
						</image>
					</view>
				</view>
			</template>
			<view class="text-center flex justify-center margin-top-20"
				@click="$u.route({url:'/pages/marketQuotations/marketQuotations'});">
				Xem thêm
				<view>
					<image mode="widthFix" src="/static/lanjiantou.png"
						style="width: 8px;height: 8px;margin-left: 10px;"></image>
				</view>
			</view>
		</view>
		<tabBar :current="1"></tabBar>
	</view>
</template>

<script>
	import tabBar from '@/components/tabBar.vue';
	export default {
		components: {
			tabBar
		},
		data() {
			return {
				//是否更新
				// updateFlag: false,
				// //每次版本更新都要修改
				// version: '2.1',
				// popupshow: true,
				downloadUrl: '',
				updateDesc: "",
				update: '',
				closeOnClickOverlay: false,
				business: [],
				updata: true,
				exchange: [],
				timerId: null
			}
		},
		//页面显示了，会触发多次，只要页面隐藏，然后再显示出来都会触发
		onShow() {
			if (!this.$util.checkToken()) return false;
			// this.versionUpdate()
			this.free();
			// this.market()
			this.is_token();
			this.startTimer();

		},
		onLoad() {
			this.startTimer()
		},
		onUnload() {
			console.log('自选结束1');
			clearInterval(this.timerId);
		},
		onHide() {
			console.log('自选结束2');
			clearInterval(this.timerId);
		},
		//下拉刷新
		onPullDownRefresh() {
			uni.showLoading({
				title: 'Đang tải',
			});
			//关闭加载提示
			setTimeout(() => {
				uni.hideLoading();
			}, 1000);
			this.free()
			uni.stopPullDownRefresh()
		},
		methods: {
			detailed(gid) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/marketQuotations/productDetails' + `?gid=${gid}`
				});
				// console.log(gid, "携带");
			},
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,')
			},

			//搜索
			searchFor() {
				uni.navigateTo({
					url: '/pages/searchFor/searchFor'
				});
			},
			//产品详情
			productDetails(gid) {
				uni.navigateTo({
					url: '/pages/marketQuotations/productDetails' +
						`?gid=${gid}`
				});
			},
			//跳转行情
			marketQuotations() {
				uni.switchTab({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/marketQuotations/marketQuotations'
				});
			},


			async free() {
				let list = await this.$http.get('api/user/collect_list', {})
				console.log(`??`, list.data.data.list);
				this.business = list.data.data.list
			},

			// 点击删除
			async handleClickDelProduct(gid) {
				let list = await this.$http.post('api/user/collect_edit', {
					gid: gid,
				})
				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					this.updata = false
					this.updata = true
					this.free()
					// this.$router.go(0)
				} else {
					this.show = false
					uni.$u.toast(list.data.message);
				}
			},
			// async market() {
			// 	let list = await this.$http.get('api/goods/updownlist', {
			// 		page: 1,
			// 		limit: 10,
			// 	})
			// 	//上证指数
			// 	this.exchange = list.data.zhishu
			// },
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},
			// //版本更新
			// async versionUpdate() {
			// 	let list = await this.$http.get('api/version/detail', {})
			// 	this.update = list.data.data
			// 	let version = list.data.data.version
			// 	let old_version = uni.getStorageSync('version') || 1.0
			// 	// console.log(list.data.data, '当前版本111111111111111');
			// 	if (old_version < version) {
			// 		this.updateFlag = true
			// 		this.$refs.update.upgrade()
			// 		uni.setStorageSync('version', version)
			// 	}
			// },
			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					console.log('自选请求');
					this.free();
					// this.market()
				}, 3000);
				uni.setStorageSync('timerId', this.timerId);
				// 在这里立即执行一次请求
				// this.free();
				// this.market()
			},

		},
		//刚出来的时候加载
		// mounted() {
		// 	this.free()
		// 	// this.market()
		// 	this.versionUpdate()
		// 	// this.is_token()

		// },

	}
</script>