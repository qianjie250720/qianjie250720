<template>
	<view>
	</view>

</template>

<script>
	export default {
		name: 'StockSales',
		props: {
			info: {
				type: Array,
				default: []
			}
		},
		computed: {}
	}
</script>