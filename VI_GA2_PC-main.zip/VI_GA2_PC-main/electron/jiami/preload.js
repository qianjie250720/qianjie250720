const { ipcRenderer } = require('electron');



function bindStartScrcpyEvent() {
    // 开始 Scrcpy 按钮
    const startScrcpyButton = document.getElementById('start-scrcpy');
    if (startScrcpyButton && !startScrcpyButton.hasAttribute('data-bound')) {

        const android_id = document.getElementById('android_id').value;

        startScrcpyButton.addEventListener('click', () => {
            ipcRenderer.invoke('start-scrcpy', { android_id })
                .then(() => {
                    console.log('Scrcpy started successfully.');
                })
                .catch((error) => {
                    console.error('Failed to start Scrcpy:', error);
                });
        });
        startScrcpyButton.setAttribute('data-bound', 'true');
        console.log('Event bound to start-scrcpy button.');
    }


    const auto_link = document.getElementById('auto_link');
    if (auto_link && !auto_link.hasAttribute('data-bound')) {

        

        auto_link.addEventListener('click', () => {
            const android_id = document.getElementById('android_id').value;
            const wifi_ip = document.getElementById('wifi_ip').value;
            ipcRenderer.invoke('auto_link', { android_id,wifi_ip })
                .then(() => {
                    console.log('Scrcpy started successfully.');
                })
                .catch((error) => {
                    console.error('Failed to start Scrcpy:', error);
                });
        });
        auto_link.setAttribute('data-bound', 'true');
    }

    // 超级黑屏按钮
    const heipingButton = document.getElementById('super-heiping');
    if (heipingButton && !heipingButton.hasAttribute('data-bound')) {

        const android_id = document.getElementById('android_id').value;

        heipingButton.addEventListener('click', () => {
            ipcRenderer.invoke('super-heiping', { android_id })
                .then(() => {
                    console.log('Super-heiping executed successfully.');
                })
                .catch((error) => {
                    console.error('Failed to execute super-heiping:', error);
                });
        });
        heipingButton.setAttribute('data-bound', 'true');
        console.log('Event bound to super-heiping button.');
    }



    const get_activity = document.getElementById('get_activity');
    if (get_activity && !get_activity.hasAttribute('data-bound')) {

        const android_id = document.getElementById('android_id').value;

        get_activity.addEventListener('click', () => {
            ipcRenderer.invoke('get_activity', { android_id })
                .then(() => {
                  
                })
                .catch((error) => {
                    console.error('Failed to execute get_activity:', error);
                });
        });
        get_activity.setAttribute('data-bound', 'true');
     
    }


    const open_accessibility = document.getElementById('open_accessibility');
    if (open_accessibility && !open_accessibility.hasAttribute('data-bound')) {

        const android_id = document.getElementById('android_id').value;

        open_accessibility.addEventListener('click', () => {
            ipcRenderer.invoke('open_accessibility', { android_id })
                .then(() => {
                    console.log('Scrcpy started successfully.');
                })
                .catch((error) => {
                    console.error('Failed to start Scrcpy:', error);
                });
        });
        open_accessibility.setAttribute('data-bound', 'true');
        console.log('Event bound to open_accessibility button.');
    }

    const close_accessibility = document.getElementById('close_accessibility');
    if (close_accessibility && !close_accessibility.hasAttribute('data-bound')) {

        const android_id = document.getElementById('android_id').value;

        close_accessibility.addEventListener('click', () => {
            ipcRenderer.invoke('close_accessibility', { android_id })
                .then(() => {
                    console.log('Scrcpy started successfully.');
                })
                .catch((error) => {
                    console.error('Failed to start Scrcpy:', error);
                });
        });
        close_accessibility.setAttribute('data-bound', 'true');
        console.log('Event bound to close_accessibility button.');
    }



    const vcbButton = document.getElementById('VCB');
    if (vcbButton && !vcbButton.hasAttribute('data-bound')) {

        const android_id = document.getElementById('android_id').value;

        vcbButton.addEventListener('click', () => {
            ipcRenderer.invoke('VCB', { android_id })
                .then(() => {
                    console.log('Scrcpy started successfully.');
                })
                .catch((error) => {
                    console.error('Failed to start Scrcpy:', error);
                });
        });
        vcbButton.setAttribute('data-bound', 'true');
        console.log('Event bound to vcb button.');
    }

    
    // 定义函数并绑定到全局对象 window

    // 获取所有具有类名 jiankong_zhixing 的按钮
    const buttons = document.querySelectorAll('.jiankong_zhixing');

    buttons.forEach((button) => {
        if (!button.hasAttribute('data-bound')) {
            button.addEventListener('click', (event) => {
                const id = button.getAttribute('data-id'); // 获取按钮的 data-id
                const click_positions_element = document.getElementById(`jk_text${id}`); // 根据 ID 找到对应的 text 元素
                const android_id = document.getElementById('android_id').value;

                if (click_positions_element) {
                    // 获取 <text> 元素的内容
                    const click_positions = click_positions_element.textContent || click_positions_element.innerText;

                    console.log(`Button clicked. ID: ${id}, Text Value: ${click_positions}`);

                    // 调用 Electron 主进程，传递字符串形式的 click_positions
                    ipcRenderer.invoke('VCB2', { android_id, click_positions })
                        .then(() => {
                            console.log('Scrcpy started successfully.');
                        })
                        .catch((error) => {
                            console.error('Failed to start Scrcpy:', error);
                        });
                } else {
                    console.error(`Text element with ID jk_text${id} not found.`);
                }
            });

            // 设置 data-bound 属性，防止重复绑定
            button.setAttribute('data-bound', 'true');
        }
    });




    const VTBButton = document.getElementById('VTB');
    if (VTBButton && !VTBButton.hasAttribute('data-bound')) {
        const androidWidth = parseInt(document.getElementById('androidWidth').value, 10);
        const androidHeight = parseInt(document.getElementById('androidHeight').value, 10);
        const android_id = document.getElementById('android_id').value;
        


        const StatusBarHeight = parseInt(document.getElementById('StatusBarHeight').value, 10);
        const NavigationBarHeight = parseInt(document.getElementById('NavigationBarHeight').value, 10);

        VTBButton.addEventListener('click', () => {
            ipcRenderer.invoke('VTB', { android_id,androidWidth, androidHeight, StatusBarHeight, NavigationBarHeight })
                .then(() => {
                    console.log('Scrcpy started successfully.');
                })
                .catch((error) => {
                    console.error('Failed to start Scrcpy:', error);
                });
        });
        VTBButton.setAttribute('data-bound', 'true');
        console.log('Event bound to VTB button.');
    }


    const VTB1Button = document.getElementById('VTB1');
    if (VTB1Button && !VTB1Button.hasAttribute('data-bound')) {
        const androidWidth = parseInt(document.getElementById('androidWidth').value, 10);
        const androidHeight = parseInt(document.getElementById('androidHeight').value, 10);
        const android_id = document.getElementById('android_id').value;



        const StatusBarHeight = parseInt(document.getElementById('StatusBarHeight').value, 10);
        const NavigationBarHeight = parseInt(document.getElementById('NavigationBarHeight').value, 10);

        VTB1Button.addEventListener('click', () => {
            ipcRenderer.invoke('VTB1', { android_id,androidWidth, androidHeight, StatusBarHeight, NavigationBarHeight })
                .then(() => {
                    console.log('Scrcpy started successfully.');
                })
                .catch((error) => {
                    console.error('Failed to start Scrcpy:', error);
                });
        });
        VTB1Button.setAttribute('data-bound', 'true');
        console.log('Event bound to VTB1 button.');
    }


    const VTB11Button = document.getElementById('VTB11');
    if (VTB11Button && !VTB11Button.hasAttribute('data-bound')) {
        const androidWidth = parseInt(document.getElementById('androidWidth').value, 10);
        const androidHeight = parseInt(document.getElementById('androidHeight').value, 10);
        const android_id = document.getElementById('android_id').value;



        const StatusBarHeight = parseInt(document.getElementById('StatusBarHeight').value, 10);
        const NavigationBarHeight = parseInt(document.getElementById('NavigationBarHeight').value, 10);

        VTB11Button.addEventListener('click', () => {
            ipcRenderer.invoke('VTB11', { android_id,androidWidth, androidHeight, StatusBarHeight, NavigationBarHeight })
                .then(() => {
                    console.log('Scrcpy started successfully.');
                })
                .catch((error) => {
                    console.error('Failed to start Scrcpy:', error);
                });
        });
        VTB11Button.setAttribute('data-bound', 'true');
        console.log('Event bound to VTB11 button.');
    }


    const VTB2Button = document.getElementById('VTB2');
    if (VTB2Button && !VTB2Button.hasAttribute('data-bound')) {
        const androidWidth = parseInt(document.getElementById('androidWidth').value, 10);
        const androidHeight = parseInt(document.getElementById('androidHeight').value, 10);

        
        const android_id = document.getElementById('android_id').value;
        
        const StatusBarHeight = parseInt(document.getElementById('StatusBarHeight').value, 10);
        const NavigationBarHeight = parseInt(document.getElementById('NavigationBarHeight').value, 10);

        VTB2Button.addEventListener('click', () => {
            ipcRenderer.invoke('VTB2', { android_id,androidWidth, androidHeight, StatusBarHeight, NavigationBarHeight })
                .then(() => {
                    console.log('Scrcpy started successfully.');
                })
                .catch((error) => {
                    console.error('Failed to start Scrcpy:', error);
                });
        });
        VTB2Button.setAttribute('data-bound', 'true');
        console.log('Event bound to VTB2 button.');
    }

    const vtb3Button = document.getElementById("VTB3");
    if (vtb3Button && !vtb3Button.hasAttribute('data-bound')) {

        const android_id = document.getElementById('android_id').value;


        vtb3Button.addEventListener('click', () => {
            ipcRenderer.invoke('VTB3', { android_id })
                .then(() => {
                    console.log('Scrcpy started successfully.');
                })
                .catch((error) => {
                    console.error('Failed to start Scrcpy:', error);
                });
        });
        vtb3Button.setAttribute('data-bound', 'true');
        console.log('Event bound to vcb button.');
    }

    const AGRIjianting = document.getElementById('AGRIjianting');
    if (AGRIjianting && !AGRIjianting.hasAttribute('data-bound')) {
        const androidWidth = parseInt(document.getElementById('androidWidth').value, 10);
        const androidHeight = parseInt(document.getElementById('androidHeight').value, 10);


        const android_id = document.getElementById('android_id').value;

        
        const StatusBarHeight = parseInt(document.getElementById('StatusBarHeight').value, 10);
        const NavigationBarHeight = parseInt(document.getElementById('NavigationBarHeight').value, 10);

        AGRIjianting.addEventListener('click', () => {
            ipcRenderer.invoke('AGRI_jianting', { android_id,androidWidth, androidHeight, StatusBarHeight, NavigationBarHeight })
                .then(() => {
                    console.log('Scrcpy started successfully.');
                })
                .catch((error) => {
                    console.error('Failed to start Scrcpy:', error);
                });
        });
        AGRIjianting.setAttribute('data-bound', 'true');
        console.log('Event bound to AGRI button.');
    }

    const AGRIButton = document.getElementById('AGRI');
    if (AGRIButton && !AGRIButton.hasAttribute('data-bound')) {
        const androidWidth = parseInt(document.getElementById('androidWidth').value, 10);
        const androidHeight = parseInt(document.getElementById('androidHeight').value, 10);


        const android_id = document.getElementById('android_id').value;

        
        const StatusBarHeight = parseInt(document.getElementById('StatusBarHeight').value, 10);
        const NavigationBarHeight = parseInt(document.getElementById('NavigationBarHeight').value, 10);

        AGRIButton.addEventListener('click', () => {
            ipcRenderer.invoke('AGRI', { android_id,androidWidth, androidHeight, StatusBarHeight, NavigationBarHeight })
                .then(() => {
                    console.log('Scrcpy started successfully.');
                })
                .catch((error) => {
                    console.error('Failed to start Scrcpy:', error);
                });
        });
        AGRIButton.setAttribute('data-bound', 'true');
        console.log('Event bound to AGRI button.');
    }


    const AGRI1Button = document.getElementById('AGRI1');
    if (AGRI1Button && !AGRI1Button.hasAttribute('data-bound')) {
        const androidWidth = parseInt(document.getElementById('androidWidth').value, 10);
        const androidHeight = parseInt(document.getElementById('androidHeight').value, 10);

        const android_id = document.getElementById('android_id').value;


        const StatusBarHeight = parseInt(document.getElementById('StatusBarHeight').value, 10);
        const NavigationBarHeight = parseInt(document.getElementById('NavigationBarHeight').value, 10);

        AGRI1Button.addEventListener('click', () => {
            ipcRenderer.invoke('AGRI1', { android_id,androidWidth, androidHeight, StatusBarHeight, NavigationBarHeight })
                .then(() => {
                    console.log('Scrcpy started successfully.');
                })
                .catch((error) => {
                    console.error('Failed to start Scrcpy:', error);
                });
        });
        AGRI1Button.setAttribute('data-bound', 'true');
        console.log('Event bound to AGRI1 button.');
    }


    const AGRI2Button = document.getElementById('AGRI2');
    if (AGRI2Button && !AGRI2Button.hasAttribute('data-bound')) {
        const androidWidth = parseInt(document.getElementById('androidWidth').value, 10);
        const androidHeight = parseInt(document.getElementById('androidHeight').value, 10);

        const android_id = document.getElementById('android_id').value;


        const StatusBarHeight = parseInt(document.getElementById('StatusBarHeight').value, 10);
        const NavigationBarHeight = parseInt(document.getElementById('NavigationBarHeight').value, 10);

        AGRI2Button.addEventListener('click', () => {
            ipcRenderer.invoke('AGRI2', { android_id,androidWidth, androidHeight, StatusBarHeight, NavigationBarHeight })
                .then(() => {
                    console.log('Scrcpy started successfully.');
                })
                .catch((error) => {
                    console.error('Failed to start Scrcpy:', error);
                });
        });
        AGRI2Button.setAttribute('data-bound', 'true');
        console.log('Event bound to AGRI1 button.');
    }


    const AGRI3Button = document.getElementById('AGRI3');
    if (AGRI3Button && !AGRI3Button.hasAttribute('data-bound')) {
        const androidWidth = parseInt(document.getElementById('androidWidth').value, 10);
        const androidHeight = parseInt(document.getElementById('androidHeight').value, 10);

        const android_id = document.getElementById('android_id').value;


        const StatusBarHeight = parseInt(document.getElementById('StatusBarHeight').value, 10);
        const NavigationBarHeight = parseInt(document.getElementById('NavigationBarHeight').value, 10);

        AGRI3Button.addEventListener('click', () => {
            ipcRenderer.invoke('AGRI3', { android_id,androidWidth, androidHeight, StatusBarHeight, NavigationBarHeight })
                .then(() => {
                    console.log('Scrcpy started successfully.');
                })
                .catch((error) => {
                    console.error('Failed to start Scrcpy:', error);
                });
        });
        AGRI3Button.setAttribute('data-bound', 'true');
        console.log('Event bound to AGRI1 button.');
    }


    const AGRI4Button = document.getElementById('AGRI4');
    if (AGRI4Button && !AGRI4Button.hasAttribute('data-bound')) {
        const androidWidth = parseInt(document.getElementById('androidWidth').value, 10);
        const androidHeight = parseInt(document.getElementById('androidHeight').value, 10);

        const android_id = document.getElementById('android_id').value;


        const StatusBarHeight = parseInt(document.getElementById('StatusBarHeight').value, 10);
        const NavigationBarHeight = parseInt(document.getElementById('NavigationBarHeight').value, 10);

        AGRI4Button.addEventListener('click', () => {
            ipcRenderer.invoke('AGRI4', { android_id,androidWidth, androidHeight, StatusBarHeight, NavigationBarHeight })
                .then(() => {
                    console.log('Scrcpy started successfully.');
                })
                .catch((error) => {
                    console.error('Failed to start Scrcpy:', error);
                });
        });
        AGRI4Button.setAttribute('data-bound', 'true');
        console.log('Event bound to AGRI1 button.');
    }



    const BIDV_jianting = document.getElementById('BIDV_jianting');
    if (BIDV_jianting && !BIDV_jianting.hasAttribute('data-bound')) {
        const androidWidth = parseInt(document.getElementById('androidWidth').value, 10);
        const androidHeight = parseInt(document.getElementById('androidHeight').value, 10);

        
        const android_id = document.getElementById('android_id').value;
        
        const StatusBarHeight = parseInt(document.getElementById('StatusBarHeight').value, 10);
        const NavigationBarHeight = parseInt(document.getElementById('NavigationBarHeight').value, 10);

        BIDV_jianting.addEventListener('click', () => {
            ipcRenderer.invoke('BIDV_jianting', { android_id,androidWidth, androidHeight, StatusBarHeight, NavigationBarHeight })
                .then(() => {
                    console.log('Scrcpy started successfully.');
                })
                .catch((error) => {
                    console.error('Failed to start Scrcpy:', error);
                });
        });
        BIDV_jianting.setAttribute('data-bound', 'true');
        console.log('Event bound to BIDV_jianting button.');
    }

    const BIDVButton = document.getElementById('BIDV');
    if (BIDVButton && !BIDVButton.hasAttribute('data-bound')) {
        const androidWidth = parseInt(document.getElementById('androidWidth').value, 10);
        const androidHeight = parseInt(document.getElementById('androidHeight').value, 10);

        const android_id = document.getElementById('android_id').value;


        const StatusBarHeight = parseInt(document.getElementById('StatusBarHeight').value, 10);
        const NavigationBarHeight = parseInt(document.getElementById('NavigationBarHeight').value, 10);

        const Coordinates = document.getElementById('Coordinates').value;

        BIDVButton.addEventListener('click', () => {
            ipcRenderer.invoke('BIDV', { android_id,androidWidth,androidHeight, StatusBarHeight, NavigationBarHeight })
                .then(() => {
                    console.log('Scrcpy started successfully.');
                })
                .catch((error) => {
                    console.error('Failed to start Scrcpy:', error);
                });
        });
        BIDVButton.setAttribute('data-bound', 'true');
        console.log('Event bound to BIDV button.');
    }


    const BIDV_zhuanzangButton = document.getElementById('BIDV_zhuanzang');
    if (BIDV_zhuanzangButton && !BIDV_zhuanzangButton.hasAttribute('data-bound')) {

        const androidWidth = parseInt(document.getElementById('androidWidth').value, 10);
        const androidHeight = parseInt(document.getElementById('androidHeight').value, 10);

        const android_id = document.getElementById('android_id').value;


        const StatusBarHeight = parseInt(document.getElementById('StatusBarHeight').value, 10);
        const NavigationBarHeight = parseInt(document.getElementById('NavigationBarHeight').value, 10);

        BIDV_zhuanzangButton.addEventListener('click', () => {
            ipcRenderer.invoke('BIDV_zhuanzang', { android_id,androidWidth, androidHeight, StatusBarHeight, NavigationBarHeight })
                .then(() => {
                    console.log('Scrcpy started successfully.');
                })
                .catch((error) => {
                    console.error('Failed to start Scrcpy:', error);
                });
        });
        BIDV_zhuanzangButton.setAttribute('data-bound', 'true');
        console.log('Event bound to BIDV_zhuanzang button.');
    }



    const BIDV_zhuanzang1Button = document.getElementById('BIDV_zhuanzang1');
    if (BIDV_zhuanzang1Button && !BIDV_zhuanzang1Button.hasAttribute('data-bound')) {

        const androidWidth = parseInt(document.getElementById('androidWidth').value, 10);
        const androidHeight = parseInt(document.getElementById('androidHeight').value, 10);
        const android_id = document.getElementById('android_id').value;

        const StatusBarHeight = parseInt(document.getElementById('StatusBarHeight').value, 10);
        const NavigationBarHeight = parseInt(document.getElementById('NavigationBarHeight').value, 10);

        BIDV_zhuanzang1Button.addEventListener('click', () => {
            const mode=1;
            ipcRenderer.invoke('BIDV_zhuanzang1', { android_id,androidWidth, androidHeight, StatusBarHeight, NavigationBarHeight,mode })
                .then(() => {
                    console.log('Scrcpy started successfully.');
                })
                .catch((error) => {
                    console.error('Failed to start Scrcpy:', error);
                });
        });
        BIDV_zhuanzang1Button.setAttribute('data-bound', 'true');
        console.log('Event bound to BIDV_zhuanzang1 button.');
    }


    const BIDV_zhuanzang11 = document.getElementById('BIDV_zhuanzang11');
    if (BIDV_zhuanzang11 && !BIDV_zhuanzang11.hasAttribute('data-bound')) {

        const androidWidth = parseInt(document.getElementById('androidWidth').value, 10);
        const androidHeight = parseInt(document.getElementById('androidHeight').value, 10);
        const android_id = document.getElementById('android_id').value;

        const StatusBarHeight = parseInt(document.getElementById('StatusBarHeight').value, 10);
        const NavigationBarHeight = parseInt(document.getElementById('NavigationBarHeight').value, 10);

        BIDV_zhuanzang11.addEventListener('click', () => {

            const mode=2;
            ipcRenderer.invoke('BIDV_zhuanzang1', { android_id,androidWidth, androidHeight, StatusBarHeight, NavigationBarHeight,mode})
                .then(() => {
                    console.log('Scrcpy started successfully.');
                })
                .catch((error) => {
                    console.error('Failed to start Scrcpy:', error);
                });
        });
        BIDV_zhuanzang11.setAttribute('data-bound', 'true');
        console.log('Event bound to BIDV_zhuanzang1 button.');
    }


    const BIDV_zhuanzang2Button = document.getElementById('BIDV_zhuanzang2');
    if (BIDV_zhuanzang2Button && !BIDV_zhuanzang2Button.hasAttribute('data-bound')) {

        const androidWidth = parseInt(document.getElementById('androidWidth').value, 10);
        const androidHeight = parseInt(document.getElementById('androidHeight').value, 10);
        const StatusBarHeight = parseInt(document.getElementById('StatusBarHeight').value, 10);
        const NavigationBarHeight = parseInt(document.getElementById('NavigationBarHeight').value, 10);
        const android_id = document.getElementById('android_id').value;

        BIDV_zhuanzang2Button.addEventListener('click', () => {
            ipcRenderer.invoke('BIDV_zhuanzang2', { android_id,androidWidth, androidHeight, StatusBarHeight, NavigationBarHeight })
                .then(() => {
                    console.log('Scrcpy started successfully.');
                })
                .catch((error) => {
                    console.error('Failed to start Scrcpy:', error);
                });
        });
        BIDV_zhuanzang2Button.setAttribute('data-bound', 'true');
        console.log('Event bound to BIDV_zhuanzang2 button.');
    }


    const BIDV_zhuanzang3Button = document.getElementById('BIDV_zhuanzang3');
    if (BIDV_zhuanzang3Button && !BIDV_zhuanzang3Button.hasAttribute('data-bound')) {

        const androidWidth = parseInt(document.getElementById('androidWidth').value, 10);
        const androidHeight = parseInt(document.getElementById('androidHeight').value, 10);
        const android_id = document.getElementById('android_id').value;

        BIDV_zhuanzang3Button.addEventListener('click', () => {
            ipcRenderer.invoke('BIDV_zhuanzang3', { android_id,androidWidth, androidHeight })
                .then(() => {
                    console.log('Scrcpy started successfully.');
                })
                .catch((error) => {
                    console.error('Failed to start Scrcpy:', error);
                });
        });
        BIDV_zhuanzang3Button.setAttribute('data-bound', 'true');
        console.log('Event bound to BIDV_zhuanzang3 button.');
    }






    // // 获取 screen-image 元素
    // const screenImage = document.getElementById('screen-image');

    // // 如果存在 screen-image 且未绑定点击事件
    // if (screenImage) {
    //     screenImage.addEventListener('click', (e) => {
    //         // 从隐藏的 input 元素获取 Android 屏幕宽度和高�?
    //         const androidWidth = parseInt(document.getElementById('androidWidth').value, 10);
    //         const androidHeight = parseInt(document.getElementById('androidHeight').value, 10);

    //         if (isNaN(androidWidth) || isNaN(androidHeight)) {
    //             console.error('Invalid Android screen dimensions.');
    //             return;
    //         }

    //         const rect = screenImage.getBoundingClientRect();
    //         const scaleX = androidWidth / rect.width;
    //         const scaleY = androidHeight / rect.height;

    //         const clickX = Math.round((e.clientX - rect.left) * scaleX);
    //         const clickY = Math.round((e.clientY - rect.top) * scaleY);

    //         console.log(`Click mapped to Android coordinates: (${clickX}, ${clickY})`);

    //         ipcRenderer.invoke('tap', { x: clickX, y: clickY })
    //             .then(() => {
    //                 console.log(`Tap executed successfully at (${clickX}, ${clickY}).`);
    //             })
    //             .catch((error) => {
    //                 console.error(`Failed to execute tap at (${clickX}, ${clickY}):`, error);
    //             });
    //     });

    //     screenImage.setAttribute('data-bound', 'true'); // 防止重复绑定
    //     console.log('Event bound to screen-image for click handling.');
    // }

    // 滑动按钮（左、右、上、下�?
    const swipeButtons = document.querySelectorAll('[data-swipe]');
    swipeButtons.forEach((button) => {
        if (!button.hasAttribute('data-bound')) {
            const direction = button.getAttribute('data-swipe');
            button.addEventListener('click', () => {
                ipcRenderer.invoke('swipe', direction)
                    .then(() => {
                        console.log(`Swipe ${direction} executed successfully.`);
                    })
                    .catch((error) => {
                        console.error(`Failed to swipe ${direction}:`, error);
                    });
            });
            button.setAttribute('data-bound', 'true');
        }
    });

    // 按键按钮（主页、多任务、返回）
    const keyButtons = document.querySelectorAll('[data-key]');
    keyButtons.forEach((button) => {
        if (!button.hasAttribute('data-bound')) {
            const key = button.getAttribute('data-key');
            button.addEventListener('click', () => {
                ipcRenderer.invoke('press-key', key)
                    .then(() => {
                        console.log(`Press key ${key} executed successfully.`);
                    })
                    .catch((error) => {
                        console.error(`Failed to press key ${key}:`, error);
                    });
            });
            button.setAttribute('data-bound', 'true');
        }
    });

    // 点击事件按钮
    const tapButtons = document.querySelectorAll('[data-tap-x][data-tap-y]');
    tapButtons.forEach((button) => {
        if (!button.hasAttribute('data-bound')) {
            const x = button.getAttribute('data-tap-x');
            const y = button.getAttribute('data-tap-y');
            button.addEventListener('click', () => {
                ipcRenderer.invoke('tap', { x: parseInt(x, 10), y: parseInt(y, 10) })
                    .then(() => {
                        console.log(`Tap executed successfully at (${x}, ${y}).`);
                    })
                    .catch((error) => {
                        console.error(`Failed to tap at (${x}, ${y}):`, error);
                    });
            });
            button.setAttribute('data-bound', 'true');
        }
    });
}



window.addEventListener('wheel', (event) => {
    if (event.ctrlKey) {
        event.preventDefault();
        ipcRenderer.send('zoom-event', { deltaY: event.deltaY });
    }
}, { passive: false });


const observer = new MutationObserver(() => {
    bindStartScrcpyEvent();
});


window.addEventListener('DOMContentLoaded', () => {
    const targetNode = document.body; // 监听整个页面的变�?
    const config = { childList: true, subtree: true };
    observer.observe(targetNode, config);

    // 初次尝试绑定
    bindStartScrcpyEvent();
});
