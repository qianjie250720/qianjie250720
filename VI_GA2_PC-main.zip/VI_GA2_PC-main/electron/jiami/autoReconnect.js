
const { exec } = require('child_process');
const { getDeviceConfig  } = require('./config-utils.js');

/**
 * 使用已存储的 connectIp 执行 ADB CONNECT
 * @param {string} android_id
 * @param {function} callback - (success: boolean) => {}
 */
function autoReconnect(android_id, callback) {
    const config = getDeviceConfig(android_id);
    if (!config) {
        console.log('未找到配置信息，无法自动重连。');
        callback(false);
        return;
    }

    const { connectIp } = config;
    if (!connectIp) {
        console.log('配置信息不完整，无法自动重连。');
        callback(false);
        return;
    }

    console.log('尝试自动重连，connectIp =', connectIp);
    exec(`adb connect ${connectIp}`, (error, stdout) => {
        if (error) {
            console.error(`自动重连失败: ${error.message}`);
            callback(false);
        } else {
            console.log(`自动重连成功: ${stdout.trim()}`);
            callback(true);
        }
    });
}

module.exports = { autoReconnect };
