const fs = require('fs');
const path = require('path');
const { app } = require('electron');

// 用户数据目录路径
const logDir = app ? path.join(app.getPath('userData'), 'logs') : path.join(__dirname, 'logs');


// 确保日志目录存在
if (!fs.existsSync(logDir)) {
    fs.mkdirSync(logDir);
}

// 日志文件路径
const logFilePath = path.join(logDir, 'app.log');

// 写日志函数
function logToFile(level, message) {
    const timestamp = new Date().toISOString();
    const logMessage = `[${timestamp}] [${level}] ${message}\n`;
    fs.appendFileSync(logFilePath, logMessage, 'utf8');
    console.log(logMessage.trim());
}

// 导出日志函数
module.exports = {
    info: (message) => logToFile('INFO', message),
    warn: (message) => logToFile('WARN', message),
    error: (message) => logToFile('ERROR', message),
    logFilePath, // 方便其他模块查看日志文件路径
};
