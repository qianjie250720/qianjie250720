package com.bank.vietnam.utils

import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.pedro.library.generic.GenericStream
import java.io.File
import java.io.FileOutputStream

class GLFrameGrabber(
    private val context: Context,
    private val genericStream: GenericStream
) {

    fun grabFrame(onResult: (File?) -> Unit) {
        try {
            genericStream.getGlInterface().takePhoto { bitmap ->
                if (bitmap == null) {
                    Log.e("GLFrameGrabber", "截图失败：bitmap = null")
                    onResult(null)
                    return@takePhoto
                }

                try {
                    val file = File(context.getExternalFilesDir(null), "screenshot_${System.currentTimeMillis()}.png")
                    val outputStream = FileOutputStream(file)
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
                    outputStream.flush()
                    outputStream.close()

                    Handler(Looper.getMainLooper()).post {
                        onResult(file)
                    }
                } catch (e: Exception) {
                    Log.e("GLFrameGrabber", "保存截图失败: ${e.message}")
                    onResult(null)
                }
            }
        } catch (e: Exception) {
            Log.e("GLFrameGrabber", "抓取失败: ${e.message}")
            onResult(null)
        }
    }
}
