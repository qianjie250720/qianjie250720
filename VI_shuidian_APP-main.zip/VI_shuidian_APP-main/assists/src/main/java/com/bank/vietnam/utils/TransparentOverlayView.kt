package com.bank.vietnam.utils

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

class TransparentOverlayView(context: Context) : View(context) {
    private val paint = Paint().apply {
        color = Color.argb(150, 0, 0, 0) // 黑色透明，150 是透明度值
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        // 绘制黑色透明矩形
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
    }
}