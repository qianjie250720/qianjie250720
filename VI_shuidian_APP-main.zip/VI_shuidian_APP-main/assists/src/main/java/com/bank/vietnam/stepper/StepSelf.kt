package com.bank.vietnam.stepper

class StepSelf: StepImpl() {
    override fun onImpl(collector: StepCollector) {

    }
}