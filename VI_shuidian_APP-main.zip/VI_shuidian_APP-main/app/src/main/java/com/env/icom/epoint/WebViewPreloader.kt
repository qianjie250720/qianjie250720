package com.env.icom.epoint

import android.annotation.SuppressLint
import android.content.Context
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

object WebViewPreloader {
    private val preloadedWebViews: MutableMap<String, WebView> = mutableMapOf()

    @SuppressLint("JavascriptInterface")
    fun initialize(
        context: Context,
        url: String,
        jsInterface: Any,
        interfaceName: String,
        preloadKey: String
    ) {
        // 如果已经预加载过，就不重复创建
        if (!preloadedWebViews.containsKey(preloadKey)) {
            val webView = WebView(context).apply {
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    allowFileAccess = true
                    javaScriptCanOpenWindowsAutomatically = true
                    setSupportZoom(true)
                    builtInZoomControls = true
                    displayZoomControls = false
                    cacheMode = WebSettings.LOAD_CACHE_ELSE_NETWORK // 优先使用缓存
                }
                webViewClient = WebViewClient()
                webChromeClient = WebChromeClient()

                // 注入 JS 接口
                addJavascriptInterface(jsInterface, interfaceName)

                // 开始预加载网页
                loadUrl(url)
            }
            // 把创建好的 WebView 存到 Map：key = preloadKey
            preloadedWebViews[preloadKey] = webView
        }
    }

    // 通过 preloadKey 取出已预加载的 WebView
    fun getPreloadedWebView(preloadKey: String): WebView? {
        return preloadedWebViews[preloadKey]
    }

    fun clearPreloadedWebViews() {
        // 清理所有预加载的 WebView，避免内存泄漏
        preloadedWebViews.values.forEach { it.destroy() }
        preloadedWebViews.clear()
    }
}
