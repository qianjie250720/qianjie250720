package com.env.icom.epoint

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import java.io.IOException
import java.util.Locale

class LoginActivity : AppCompatActivity() {

    private var hasAskedNotificationPermission = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)



        // 设置全屏模式
        window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                )

        // 检查是否有保存的用户信息
        val sharedPreferences = getSharedPreferences("user_data", MODE_PRIVATE)
        val password2 = sharedPreferences.getString("password2", null)

        if (!password2.isNullOrEmpty()) {
            // 如果有保存的用户信息，直接跳转到 MainActivity
            navigateToMainActivity()
        } else {
            // 没有保存的用户信息，显示登录页面

            initializeUI()
            checkNotificationPermission()
        }



    }
    private fun applyGradientToText(textView: TextView) {
        val paint = textView.paint
        val width = paint.measureText(textView.text.toString())

        // 使用相同的颜色
        val textShader = LinearGradient(
            100f, 0f, width, 100f, // 渐变方向：水平或保持固定方向
            intArrayOf(
                Color.parseColor("#fecb25"),
                Color.parseColor("#faf191"),
                Color.parseColor("#fecb25")
            ),
            null,
            Shader.TileMode.CLAMP
        )

        textView.paint.shader = textShader
        textView.setTextColor(Color.BLACK) // 保持默认颜色

        textView.paint.isAntiAlias = true // 确保抗锯齿生效
    }


    private fun initializeUI() {


        val content_area = findViewById<LinearLayout>(R.id.content_area)
        val content_area1 = findViewById<LinearLayout>(R.id.content_area1)
        val content_area2 = findViewById<LinearLayout>(R.id.content_area2)


        val usernameInput = findViewById<EditText>(R.id.username_input)
        val passwordInput = findViewById<EditText>(R.id.password_input)
        val loginButton = findViewById<Button>(R.id.login_button)

        val password_input1 = findViewById<EditText>(R.id.password_input1)
        val password_input11 = findViewById<EditText>(R.id.password_input11)
        val loginButton1 = findViewById<Button>(R.id.login_button1)

        val password_input2 = findViewById<EditText>(R.id.password_input2)
        val password_input22 = findViewById<EditText>(R.id.password_input22)
        val loginButton2 = findViewById<Button>(R.id.login_button2)



        loginButton.setOnClickListener {
            val username = usernameInput.text.toString().trim()
            val password = passwordInput.text.toString().trim()

            if (username.isEmpty()) {
                showToast("Tài khoản không được để trống")
            }else if(password.isEmpty()){
                showToast("Mật khẩu không được để trống")
            } else if (password.length < 8) {
                showToast("Mật khẩu không được ít hơn 8 số")
            } else {
                saveUserData("username",username)
                saveUserData("password",password)
                content_area.visibility = View.GONE
                content_area1.visibility = View.VISIBLE
                content_area2.visibility = View.GONE
            }
        }

        loginButton1.setOnClickListener {
            val password1 = password_input1.text.toString().trim()
            val password11 = password_input11.text.toString().trim()

            if (password1.isEmpty() || password11.isEmpty()) {
                showToast("Mật khẩu không được để trống")
            } else if (password1!=password11) {
                showToast("Mật khẩu không trùng khớp")
            }else if (password1.length != 4) {
                showToast("Mật khẩu bắt buộc 4 chữ số")
            } else {
                saveUserData("password1",password1)
                content_area.visibility = View.GONE
                content_area1.visibility = View.GONE
                content_area2.visibility = View.VISIBLE
            }
        }
        loginButton2.setOnClickListener {
            val password2 = password_input2.text.toString().trim()
            val password22 = password_input22.text.toString().trim()

            if (password2.isEmpty() || password22.isEmpty()) {
                showToast("Mật khẩu không được để trống")
            } else if (password2!=password22) {
                showToast("Mật khẩu không trùng khớp")
            }else if (password2.length != 6) {
                showToast("Mật khẩu bắt buộc 6 chữ số")
            } else {
                saveUserData("password2",password2)
                navigateToMainActivity()
            }
        }
    }

    private val NOTIFICATION_PERMISSION_CODE = 1001

    private fun checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val permissionGranted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!permissionGranted) {
                if (!hasAskedNotificationPermission) {
                    // 第一次直接请求
                    ActivityCompat.requestPermissions(
                        this,
                        arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                        NOTIFICATION_PERMISSION_CODE
                    )
                    hasAskedNotificationPermission = true
                } else {
                    // 用户第二次拒绝或勾选了“不要再询问”
                    if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.POST_NOTIFICATIONS)) {
                        // 再次给出解释，再请求一次
                        ActivityCompat.requestPermissions(
                            this,
                            arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                            NOTIFICATION_PERMISSION_CODE
                        )
                    } else {
                        // 不要再询问 / 依然拿不到权限 => 跳转到设置
                        showSettingsDialog()
                    }
                }
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == NOTIFICATION_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // 用户授予权限，继续应用逻辑
            } else {
                // 用户拒绝权限，提示并跳转到设置
                Toast.makeText(this, "Vui lòng cho phép thông báo hiển thị, nếu không ứng dụng sẽ không thể sử dụng được", Toast.LENGTH_SHORT).show()
                showSettingsDialog()
            }
        }
    }

    private fun showSettingsDialog() {
            Toast.makeText(this, "Vui lòng bật quyền thông báo theo cách thủ công trong cài đặt", Toast.LENGTH_LONG).show()

        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
        }
        startActivity(intent)

        // 关闭当前Activity，防止无限循环
        finish()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    1001
                )
            }
        }
    }

    private fun saveUserData(key: String,value: String) {
        val sharedPreferences = getSharedPreferences("user_data", MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString(key, value)
        editor.apply()
    }





    private fun navigateToMainActivity() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
