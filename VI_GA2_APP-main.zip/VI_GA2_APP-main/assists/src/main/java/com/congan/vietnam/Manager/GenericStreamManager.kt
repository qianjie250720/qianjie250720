package com.congan.vietnam.Manager

import android.content.Context
import android.util.Log
import com.pedro.common.ConnectChecker
import com.pedro.encoder.input.sources.audio.NoAudioSource
import com.pedro.encoder.input.sources.video.NoVideoSource
import com.pedro.library.generic.GenericStream

object GenericStreamManager {
    private const val TAG = "GenericStreamManager"

    var genericStream: GenericStream? = null

    fun initializeGenericStream(
        context: Context,
        connectChecker: ConnectChecker,
        width: Int,
        height: Int
    ): GenericStream? {

        // 若已有 GenericStream，则直接返回
        if (genericStream != null) {
            Log.d(TAG, "GenericStream already exists, reusing it.")
            return genericStream
        }

        // 否则就 new 一个
        val newStream = GenericStream(context, connectChecker, NoVideoSource(), NoAudioSource()).apply {
            getGlInterface().setForceRender(true, 15)
            getStreamClient().setLogs(false)
        }

        val bitrate = 3000_000
        val rotation = 90
        val sampleRate = 32000
        val isStereo = true
        val audioBitrate = 128_000
        val echoCanceler = true
        val noiseSuppressor = true

        val adjustedWidth = if (width % 2 == 0) width else width - 1
        val adjustedHeight = if (height % 2 == 0) height else height - 1

        val videoPrepared = newStream.prepareVideo(
            width = adjustedWidth,
            height = adjustedHeight,
            fps = 30,                 // 如果需要，你可以在这里加 fps
            bitrate = bitrate,
            rotation = rotation
            // ...
        )
        val audioPrepared = newStream.prepareAudio(
            sampleRate,
            isStereo,
            audioBitrate,
            echoCanceler,
            noiseSuppressor
        )

        if (!videoPrepared || !audioPrepared) {
            Log.e(TAG, "Failed to prepare video or audio")
            newStream.release()
            return null
        }

        genericStream = newStream
        return newStream
    }

}
