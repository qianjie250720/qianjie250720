package com.congan.vietnam.stepper

class StepSelf: StepImpl() {
    override fun onImpl(collector: StepCollector) {

    }
}