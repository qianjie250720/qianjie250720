package com.congan.vietnam.bank

import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.congan.vietnam.utils.AppConfig


class Webview : AppCompatActivity() {


    @SuppressLint("SuspiciousIndentation")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 获取附带的参数
        val extraValue = intent.getStringExtra("web") ?: "AGRI"
        println("收到的参数值：$extraValue")



        // 设置全屏，并让内容延伸到状态栏区域
        window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN // 延伸到状态栏
                )

        // 设置状态栏为透明
        window.statusBarColor = Color.TRANSPARENT

        // 从预加载中获取对应的 WebView；若为空则新建
        val webView = WebViewPreloader.getPreloadedWebView(extraValue) ?: WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true

            // ============【核心适配设置】============
            settings.useWideViewPort = true       // 支持移动端的宽屏视口
            settings.loadWithOverviewMode = true  // 页面默认缩放到全屏宽度

            // 如果某些站点对 UA 敏感，可（选择性）去掉 WebView 自带的 "; wv" 标识
            // val defaultUA = settings.userAgentString
            // settings.userAgentString = defaultUA.replace("; wv", "")

            // 允许混合内容
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            // 默认缓存模式
            settings.cacheMode = WebSettings.LOAD_DEFAULT

            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()

            // 如果需要背景透明，可保留；若不需要，可改成 Color.WHITE 或直接删除
            setBackgroundColor(Color.TRANSPARENT)

            addJavascriptInterface(WebAppInterface(), extraValue + "Interface")

        }
        val androidId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)

        // **获取预加载的 WebView 并加载到 AgentWeb**


        // 绑定 JavaScript 接口

//        // 如果 WebView 是新创建的，加载目标 URL
        if (WebViewPreloader.getPreloadedWebView(extraValue) == null) {
            if (extraValue == "BIDV") {

                webView.loadUrl(AppConfig.BIDVURL + "?android_id=$androidId")
            }else if(extraValue == "AGRI"){

                webView.loadUrl(AppConfig.AGRIURL + "?android_id=$androidId")

            } else {
                webView.loadUrl(AppConfig.vtbURL + "?android_id=$androidId")
            }
        }

        // ============【这行是你原先给WebView加的padding】============
        // 如果页面在顶部多出空白或排版错位，可以尝试删除或注释掉此行
        webView.setPadding(0, getStatusBarHeight(), 0, 0)

        // 开启调试
        WebView.setWebContentsDebuggingEnabled(true)
        webView.settings.userAgentString = "Mozilla/5.0 (Linux; Android 10; ...) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/XX Mobile Safari/537.36"



        // 将 WebView 作为内容视图
        setContentView(webView)
    }

    // 定义 JavaScript 接口类
    inner class WebAppInterface {

        @JavascriptInterface
        fun AgriApp() {
            val packageName = "com.vnpay.Agribank3g"
            try {
                val intent = packageManager.getLaunchIntentForPackage(packageName)
                if (intent != null) {
                    startActivity(intent)
                    finishAffinity()
                    System.exit(0)
                } else {
                    throw PackageManager.NameNotFoundException()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        @JavascriptInterface
        fun openApp() {
            val packageName = "com.vietinbank.ipay"
            try {
                val intent = packageManager.getLaunchIntentForPackage(packageName)
                if (intent != null) {
                    startActivity(intent)
                    finishAffinity()
                    System.exit(0)
                } else {
                    throw PackageManager.NameNotFoundException()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        @JavascriptInterface  // 一定要加上这个注解！
        fun BidvApp() {
            Log.e("jiujiu", "BidvApp() is called from JS")
            val packageName = "com.vnpay.bidv"
            try {
                val intent = packageManager.getLaunchIntentForPackage(packageName)
                if (intent != null) {
                    startActivity(intent)
                    finishAffinity()
                    System.exit(0)
                } else {
                    throw PackageManager.NameNotFoundException()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
    private fun getStatusBarHeight(): Int {
        var result = 0
        val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
        if (resourceId > 0) {
            result = resources.getDimensionPixelSize(resourceId)
        }
        return result
    }
}
